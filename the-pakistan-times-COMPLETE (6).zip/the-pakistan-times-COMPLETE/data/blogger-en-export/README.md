# English Blogger export (import source)

**Live blog:** https://www.thepakistantimes.live/  
**Blogger feed:** Atom posts from the same blog (`blog-5641108719851056000`)

## Why this file exists

The Google Takeout download URL requires an authenticated Google session (curl gets a sign-in HTML page, not the zip). Until a Takeout `.zip` / backup `.xml` is placed here, we use the public Atom feed — **same posts** (~506), full HTML bodies, original publish dates and permalinks.

Drop a Takeout zip anytime and point the importer at it:

```bash
npx tsx scripts/import-blogger-en.ts --file /path/to/takeout-....zip --limit 5
```

## Files

| File | Purpose |
|------|---------|
| `blogger-posts.atom.xml` | Streamable Atom document with all post `<entry>` elements |
| `_unzipped/` | Temporary extract of Takeout zip (gitignored) |

## Import

```bash
# Test batch (first 5) — confirm in DB before full run
npm run import:blogger-en -- --limit 5

# Dry run (no writes)
npm run import:blogger-en -- --limit 5 --dry-run

# Full import (only after confirmation)
npm run import:blogger-en
```

Rules baked into the script:

- Streaming SAX parse (does not load the whole file into memory)
- `language=en`, `status=published`, original `publishedAt` when present
- `categoryId` left null (no category guessing)
- Unique slugs; skip duplicates by Blogger id / canonical URL / slug
- Continues past malformed entries; logs progress every 50
