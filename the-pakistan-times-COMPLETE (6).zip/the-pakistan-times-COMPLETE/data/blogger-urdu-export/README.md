# Urdu Blogger crawl export

**Source only:** https://urdu.thepakistantimes.live/  
**English site (`www.thepakistantimes.live`) was not crawled or imported.**

## Method

1. Blogger JSON feed: `/feeds/posts/default?alt=json&max-results=50`
2. Sitemap cross-check: `/sitemap.xml` (15 URLs, all matched feed)
3. Per-post HTML for meta description / Open Graph when available

## Files

| File | Purpose |
|------|---------|
| `articles.json` | Full import payload (15 Urdu articles) |
| `pages/*.html` | Cached HTML snapshots (where fetch succeeded) |
| `README.md` | This summary |

## Import into CMS

```bash
# dry run
npx tsx scripts/import-blogger-urdu.ts --dry-run

# write Urdu rows only (language=ur). Never updates language=en.
npx tsx scripts/import-blogger-urdu.ts
```

Idempotent key: `canonicalUrl` / Blogger permalink on existing `language=ur` articles.
