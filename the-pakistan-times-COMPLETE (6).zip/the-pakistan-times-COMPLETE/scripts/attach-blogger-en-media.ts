/**
 * Attach featured Media for English Blogger-imported articles.
 * Pulls the first real image URL from body HTML → Media (language=en) → featuredImageId.
 * Does NOT touch Urdu articles.
 *
 *   npx tsx scripts/attach-blogger-en-media.ts
 *   npx tsx scripts/attach-blogger-en-media.ts --limit 20
 *   npx tsx scripts/attach-blogger-en-media.ts --dry-run
 */
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const DRY = process.argv.includes("--dry-run");
const limitArg = process.argv.indexOf("--limit");
const LIMIT =
  limitArg >= 0 ? Math.max(1, parseInt(process.argv[limitArg + 1] || "0", 10) || 0) : null;

function extractImageUrls(html: string): string[] {
  const out: string[] = [];
  const re = /(?:src|data-src)=["']([^"']+)["']/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const raw = (m[1] || "").trim();
    if (!raw) continue;
    if (raw.startsWith("data:")) continue;
    if (!/^https?:\/\//i.test(raw)) continue;
    // Skip tracking pixels / icons
    if (/\b(1x1|pixel|spacer|emoji|icon-)\b/i.test(raw)) continue;
    if (raw.length < 20) continue;
    out.push(raw.split(/\s+/)[0]);
  }
  return [...new Set(out)];
}

function mimeFromUrl(url: string) {
  const u = url.toLowerCase();
  if (u.includes(".png")) return "image/png";
  if (u.includes(".webp")) return "image/webp";
  if (u.includes(".gif")) return "image/gif";
  return "image/jpeg";
}

async function ensureMedia(url: string, title: string) {
  const existing = await prisma.media.findFirst({
    where: { url, language: "en", deletedAt: null },
  });
  if (existing) return existing;
  const filename = url.split("/").pop()?.split("?")[0] || "image.jpg";
  return prisma.media.create({
    data: {
      filename: filename.slice(0, 180),
      originalName: filename.slice(0, 180),
      path: url,
      url,
      mimeType: mimeFromUrl(url),
      size: 0,
      alt: title.slice(0, 180),
      type: "image",
      language: "en",
    },
  });
}

async function main() {
  const articles = await prisma.article.findMany({
    where: {
      language: "en",
      deletedAt: null,
      featuredImageId: null,
      OR: [
        { canonicalUrl: { contains: "thepakistantimes.live" } },
        { canonicalUrl: { startsWith: "tag:blogger" } },
        { canonicalUrl: { startsWith: "blogger:" } },
      ],
    },
    select: { id: true, slug: true, title: true, body: true },
    orderBy: { publishedAt: "desc" },
    ...(LIMIT ? { take: LIMIT } : {}),
  });

  console.log(`EN blogger articles missing featured image: ${articles.length}`);
  console.log(DRY ? "DRY RUN" : "LIVE WRITE");

  let attached = 0;
  let noImage = 0;
  let errors = 0;

  for (const article of articles) {
    try {
      const urls = extractImageUrls(article.body || "");
      const url = urls[0];
      if (!url) {
        noImage += 1;
        continue;
      }
      if (DRY) {
        console.log(`WOULD ATTACH ${article.slug} ← ${url.slice(0, 80)}`);
        attached += 1;
        continue;
      }
      const media = await ensureMedia(url, article.title);
      await prisma.article.update({
        where: { id: article.id },
        data: {
          featuredImageId: media.id,
          ogImage: url,
        },
      });
      attached += 1;
      if (attached % 50 === 0) {
        console.log(`Attached ${attached}/${articles.length} (no-image ${noImage}, errors ${errors})`);
      }
    } catch (e) {
      errors += 1;
      const msg = e instanceof Error ? e.message : String(e);
      console.warn(`FAIL ${article.slug}: ${msg.slice(0, 120)}`);
    }
  }

  console.log({ attached, noImage, errors, dry: DRY });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
