#!/usr/bin/env bash
# Vercel build — generate, migrate (required), then next build.
set -euo pipefail

echo "==> prisma generate"
npx prisma generate

echo "==> prisma migrate deploy"
npx prisma migrate deploy

echo "==> next build"
npx next build
