import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const fixes: Record<string, string> = {
  "fresh-developments-in-pakistan-economy":
    "Analysts point to improving exports and remittances as Pakistan’s economy shows fresh signs of momentum.",
  "national-team-seals-emphatic-win":
    "Pakistan’s cricket team delivered a dominant performance to seal an emphatic win in a key fixture.",
  "tech-startups-gain-momentum":
    "Technology startups across Pakistan are attracting fresh investment as the sector gains momentum.",
  "global-peace-talks-gather-pace":
    "Diplomatic activity is intensifying as global peace talks gather pace on the international stage.",
  "key-bill-presented-in-national-assembly":
    "The government has presented a major economic reforms bill in the National Assembly in Islamabad.",
  "heavy-rain-alert-issued-for-karachi":
    "The meteorological department has issued a heavy rain alert for Karachi and coastal areas.",
};

async function main() {
  await prisma.article.updateMany({
    where: { slug: "asslam-o-allikum" },
    data: { status: "draft", publishedAt: null },
  });
  console.log("unpublished asslam-o-allikum");

  for (const [slug, excerpt] of Object.entries(fixes)) {
    const row = await prisma.article.findFirst({ where: { slug } });
    if (!row) continue;
    if ((row.excerpt || "").trim() === (row.title || "").trim()) {
      await prisma.article.update({ where: { id: row.id }, data: { excerpt } });
      console.log("excerpt fixed", slug);
    }
  }
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
