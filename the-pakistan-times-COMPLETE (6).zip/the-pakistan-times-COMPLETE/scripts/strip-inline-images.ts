import { PrismaClient } from "@prisma/client";
import { stripOversizedDataUris } from "../src/lib/article-html";

const prisma = new PrismaClient();

function cleanUrl(url?: string | null) {
  if (!url) return url ?? null;
  if (!url.startsWith("data:image")) return url;
  if (url.length <= 2000) return url;
  return null;
}

async function main() {
  const articles = await prisma.article.findMany({
    select: { id: true, slug: true, ogImage: true, body: true, bodyUr: true },
  });
  let updated = 0;
  for (const a of articles) {
    const patch: {
      ogImage?: string | null;
      body?: string;
      bodyUr?: string | null;
    } = {};
    const og = cleanUrl(a.ogImage);
    if (og !== a.ogImage) patch.ogImage = og;
    const body = stripOversizedDataUris(a.body || "");
    if (body !== (a.body || "")) patch.body = body;
    const bodyUr = a.bodyUr ? stripOversizedDataUris(a.bodyUr) : a.bodyUr;
    if (bodyUr !== a.bodyUr) patch.bodyUr = bodyUr;
    if (Object.keys(patch).length) {
      await prisma.article.update({ where: { id: a.id }, data: patch });
      updated += 1;
      console.log("cleaned", a.slug, Object.keys(patch), "ogWas", (a.ogImage || "").length);
    }
  }

  const media = await prisma.media.findMany({ select: { id: true, url: true } });
  for (const m of media) {
    if (m.url?.startsWith("data:image") && m.url.length > 20_000) {
      await prisma.media.update({ where: { id: m.id }, data: { url: "/icon-512.png" } });
      console.log("media", m.id, m.url.length);
    }
  }
  console.log("updated", updated);
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
