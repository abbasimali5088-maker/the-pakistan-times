/**
 * One-shot: convert legacy data:image media rows into /uploads/… files.
 * Run: npx tsx scripts/repair-data-media.ts
 */
import { PrismaClient } from "@prisma/client";
import { persistMediaUrl } from "../src/lib/media-persist";

const prisma = new PrismaClient();

async function main() {
  const rows = await prisma.media.findMany({
    where: { deletedAt: null, url: { startsWith: "data:image" } },
    select: { id: true, url: true, filename: true, mimeType: true, language: true },
  });
  console.log("data: media rows", rows.length);
  let ok = 0;
  let fail = 0;
  for (const row of rows) {
    try {
      const persisted = await persistMediaUrl(
        row.url,
        row.filename || "image.jpg",
        row.mimeType,
      );
      await prisma.media.update({
        where: { id: row.id },
        data: {
          url: persisted.url,
          path: persisted.path,
          size: persisted.size || undefined,
          mimeType: persisted.mimeType,
        },
      });
      console.log("fixed", row.id, row.language, persisted.url);
      ok += 1;
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      console.log("skip", row.id, msg.slice(0, 120));
      fail += 1;
    }
  }
  console.log({ ok, fail });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
