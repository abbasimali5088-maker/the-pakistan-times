/**
 * Zero all view counters so EN/UR Views properties start clean.
 * Does NOT delete articles. Does NOT touch English Blogger.
 *
 *   npx tsx scripts/reset-views.ts
 */
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const articles = await prisma.article.updateMany({
    data: { viewCount: 0 },
  });
  const events = await prisma.analyticsEvent.deleteMany({
    where: { eventType: { in: ["article_view", "pageview"] } },
  });
  console.log({
    articlesViewCountReset: articles.count,
    analyticsEventsDeleted: events.count,
    note: "Views start at zero; new visits will count per language property.",
  });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
