/**
 * One-time streaming import of English Blogger Atom posts → Prisma Article.
 *
 * Sources (same blog, posts only):
 *   - Google Takeout Blogger backup XML (or zip containing it)
 *   - Offline Atom export: data/blogger-en-export/blogger-posts.atom.xml
 *
 * NEVER touches auth/sessions/JWT. Does NOT guess categories (categoryId stays null).
 * Skips duplicates by Blogger post ID (canonicalUrl) or slug. Continues past bad entries.
 *
 * Usage:
 *   npx tsx scripts/import-blogger-en.ts --limit 5
 *   npx tsx scripts/import-blogger-en.ts --limit 5 --dry-run
 *   npx tsx scripts/import-blogger-en.ts --file /path/to/blog-XXXX.xml
 *   npx tsx scripts/import-blogger-en.ts --file /path/to/takeout.zip
 *   BLOGGER_EN_EXPORT=/path/to/file.xml npx tsx scripts/import-blogger-en.ts
 */
import { createReadStream, existsSync, readdirSync, statSync } from "fs";
import { resolve, join, basename, extname } from "path";
import { createInterface } from "readline";
import { PrismaClient, type Prisma } from "@prisma/client";
import sax from "sax";
import { makeSlug, uniqueSlug } from "../src/lib/slug";
import { stripTags } from "../src/lib/article-html";

const prisma = new PrismaClient();

const POST_KIND = "http://schemas.google.com/blogger/2008/kind#post";
const DEFAULT_EXPORT = resolve(
  process.cwd(),
  process.env.BLOGGER_EN_EXPORT || "data/blogger-en-export/blogger-posts.atom.xml",
);

type Cli = {
  file: string;
  limit: number | null;
  dryRun: boolean;
  skip: number;
};

type BloggerPost = {
  bloggerId: string;
  title: string;
  bodyHtml: string;
  publishedAt: Date | null;
  permalink: string | null;
  slugHint: string | null;
};

function parseArgs(argv: string[]): Cli {
  let file = DEFAULT_EXPORT;
  let limit: number | null = null;
  let dryRun = false;
  let skip = 0;
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (a === "--file" && argv[i + 1]) {
      file = resolve(process.cwd(), argv[++i]);
    } else if (a === "--limit" && argv[i + 1]) {
      limit = Math.max(0, parseInt(argv[++i], 10) || 0);
    } else if (a === "--skip" && argv[i + 1]) {
      skip = Math.max(0, parseInt(argv[++i], 10) || 0);
    } else if (a === "--dry-run") {
      dryRun = true;
    } else if (a === "--help" || a === "-h") {
      console.log(`Usage: npx tsx scripts/import-blogger-en.ts [--file path] [--limit N] [--skip N] [--dry-run]`);
      process.exit(0);
    }
  }
  return { file, limit, dryRun, skip };
}

/** Decode common XML/HTML entities used in Blogger Atom content. */
function decodeEntities(raw: string): string {
  if (!raw) return "";
  return raw
    .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&nbsp;/g, "\u00a0")
    .replace(/&amp;/g, "&");
}

function slugFromPermalink(permalink: string | null, title: string): string {
  if (permalink) {
    try {
      const u = new URL(permalink);
      const base = u.pathname.split("/").filter(Boolean).pop() || "";
      const cleaned = base.replace(/\.html$/i, "").replace(/-+$/g, "");
      if (cleaned && cleaned !== "blog-post" && !/^-+$/.test(cleaned)) {
        return makeSlug(cleaned, "article");
      }
    } catch {
      /* fall through */
    }
  }
  return makeSlug(title, "article");
}

function excerptFromHtml(html: string): string | null {
  const plain = stripTags(html).replace(/\s+/g, " ").trim();
  if (!plain) return null;
  return plain.slice(0, 280);
}

/**
 * Resolve XML path. If given a Takeout zip, extract the largest .xml under Blogger/
 * into a temp path (streaming unzip via system unzip — zip is stored on disk, not loaded whole).
 */
async function resolveXmlPath(input: string): Promise<string> {
  if (!existsSync(input)) {
    throw new Error(`Export not found: ${input}`);
  }
  const st = statSync(input);
  if (st.isDirectory()) {
    const xmls = findXmlFiles(input);
    if (!xmls.length) throw new Error(`No .xml files under ${input}`);
    xmls.sort((a, b) => b.size - a.size);
    console.log(`Using largest XML in dir: ${xmls[0].path} (${(xmls[0].size / 1e6).toFixed(1)} MB)`);
    return xmls[0].path;
  }
  const ext = extname(input).toLowerCase();
  if (ext === ".xml" || ext === ".atom") return input;
  if (ext === ".zip") {
    const outDir = resolve(process.cwd(), "data/blogger-en-export/_unzipped");
    const { execFileSync } = await import("child_process");
    execFileSync("mkdir", ["-p", outDir], { stdio: "inherit" });
    console.log(`Unzipping Takeout (streamed by unzip) → ${outDir} ...`);
    // -o overwrite, -j would flatten; keep structure so we can find Blogger XML
    execFileSync("unzip", ["-o", "-q", input, "-d", outDir], { stdio: "inherit" });
    const xmls = findXmlFiles(outDir).filter(
      (x) => /blogger/i.test(x.path) || /backup|blog-/i.test(basename(x.path)),
    );
    const pool = xmls.length ? xmls : findXmlFiles(outDir);
    if (!pool.length) throw new Error(`No XML found inside zip ${input}`);
    pool.sort((a, b) => b.size - a.size);
    console.log(`Using ${pool[0].path} (${(pool[0].size / 1e6).toFixed(1)} MB)`);
    return pool[0].path;
  }
  throw new Error(`Unsupported file type: ${input} (use .xml or .zip)`);
}

function findXmlFiles(dir: string): { path: string; size: number }[] {
  const out: { path: string; size: number }[] = [];
  const walk = (d: string) => {
    let entries: string[];
    try {
      entries = readdirSync(d);
    } catch {
      return;
    }
    for (const name of entries) {
      const p = join(d, name);
      let st;
      try {
        st = statSync(p);
      } catch {
        continue;
      }
      if (st.isDirectory()) walk(p);
      else if (st.isFile() && /\.xml$/i.test(name)) out.push({ path: p, size: st.size });
    }
  };
  walk(dir);
  return out;
}

/**
 * Stream-parse Atom/Blogger XML. Yields one post at a time without loading the file into memory.
 * For Takeout backups, only entries with kind#post (or no kind scheme at all, as in feed exports).
 */
async function* streamBloggerPosts(xmlPath: string): AsyncGenerator<BloggerPost> {
  const stream = createReadStream(xmlPath, { encoding: "utf8", highWaterMark: 64 * 1024 });
  const parser = sax.createStream(true, { trim: false, normalize: false, lowercase: false });

  type Frame = {
    inEntry: boolean;
    depth: number;
    kinds: string[];
    id: string;
    title: string;
    published: string;
    content: string;
    contentType: string;
    permalink: string | null;
    textBuf: string;
    currentTag: string | null;
    collecting: "id" | "title" | "published" | "updated" | "content" | "summary" | null;
  };

  const frame: Frame = {
    inEntry: false,
    depth: 0,
    kinds: [],
    id: "",
    title: "",
    published: "",
    content: "",
    contentType: "",
    permalink: null,
    textBuf: "",
    currentTag: null,
    collecting: null,
  };

  const queue: BloggerPost[] = [];
  let waiting: ((v: IteratorResult<BloggerPost>) => void) | null = null;
  let done = false;
  let error: Error | null = null;
  let entryDepth = 0;

  const localName = (name: string) => {
    const i = name.indexOf(":");
    return i >= 0 ? name.slice(i + 1) : name;
  };

  const flushEntry = () => {
    const hasKindScheme = frame.kinds.some((k) => k.includes("schemas.google.com/blogger/2008/kind"));
    const isPost = !hasKindScheme || frame.kinds.includes(POST_KIND);
    if (!isPost) return;
    const title = decodeEntities(frame.title).trim();
    if (!title && !frame.content) return;
    const bodyRaw = frame.content || "";
    const bodyHtml =
      frame.contentType === "html" || /&lt;|&gt;|<[a-z]/i.test(bodyRaw)
        ? decodeEntities(bodyRaw)
        : bodyRaw;
    let publishedAt: Date | null = null;
    if (frame.published) {
      const d = new Date(frame.published);
      if (!Number.isNaN(d.getTime())) publishedAt = d;
    }
    const bloggerId = (frame.id || frame.permalink || title).trim();
    queue.push({
      bloggerId,
      title: title || "Untitled",
      bodyHtml,
      publishedAt,
      permalink: frame.permalink,
      slugHint: frame.permalink ? slugFromPermalink(frame.permalink, title) : null,
    });
    if (waiting) {
      const w = waiting;
      waiting = null;
      w({ value: queue.shift()!, done: false });
    }
  };

  parser.on("opentag", (node) => {
    const name = localName(node.name);
    if (name === "entry") {
      frame.inEntry = true;
      entryDepth += 1;
      frame.kinds = [];
      frame.id = "";
      frame.title = "";
      frame.published = "";
      frame.content = "";
      frame.contentType = "";
      frame.permalink = null;
      frame.collecting = null;
      frame.textBuf = "";
      return;
    }
    if (!frame.inEntry) return;

    if (name === "category") {
      const term = String(node.attributes.term || node.attributes.TERM || "");
      const scheme = String(node.attributes.scheme || node.attributes.SCHEME || "");
      if (scheme.includes("blogger/2008/kind") || term.includes("blogger/2008/kind")) {
        frame.kinds.push(term || scheme);
      } else if (term.startsWith("http://schemas.google.com/blogger/2008/kind")) {
        frame.kinds.push(term);
      }
      return;
    }

    if (name === "link") {
      const rel = String(node.attributes.rel || "");
      const type = String(node.attributes.type || "");
      const href = String(node.attributes.href || "");
      if (rel === "alternate" && type.includes("html") && href) {
        frame.permalink = href;
      }
      return;
    }

    if (name === "id") frame.collecting = "id";
    else if (name === "title") frame.collecting = "title";
    else if (name === "published") frame.collecting = "published";
    else if (name === "content") {
      frame.collecting = "content";
      frame.contentType = String(node.attributes.type || "html").toLowerCase();
    } else if (name === "summary" && !frame.content) {
      frame.collecting = "summary";
    } else {
      // nested tags inside content — keep collecting content text including markup
      if (frame.collecting === "content" || frame.collecting === "summary") {
        // sax strips tags; reconstruct minimal open tag for HTML bodies that used nested XML
        // Blogger usually entity-encodes HTML so nested tags are rare in <content>.
      } else {
        frame.collecting = null;
      }
    }
    frame.textBuf = "";
  });

  parser.on("closetag", (rawName) => {
    const name = localName(rawName);
    if (name === "entry") {
      flushEntry();
      entryDepth = Math.max(0, entryDepth - 1);
      frame.inEntry = entryDepth > 0;
      frame.collecting = null;
      return;
    }
    if (!frame.inEntry) return;
    if (frame.collecting === "id" && name === "id") {
      frame.id = frame.textBuf.trim();
      frame.collecting = null;
    } else if (frame.collecting === "title" && name === "title") {
      frame.title = frame.textBuf;
      frame.collecting = null;
    } else if (frame.collecting === "published" && name === "published") {
      frame.published = frame.textBuf.trim();
      frame.collecting = null;
    } else if (frame.collecting === "content" && name === "content") {
      frame.content = frame.textBuf;
      frame.collecting = null;
    } else if (frame.collecting === "summary" && name === "summary") {
      if (!frame.content) frame.content = frame.textBuf;
      frame.collecting = null;
    }
  });

  parser.on("text", (t) => {
    if (frame.collecting) frame.textBuf += t;
  });
  parser.on("cdata", (t) => {
    if (frame.collecting) frame.textBuf += t;
  });

  parser.on("error", (err) => {
    // Recover from malformed fragments when possible
    console.warn("XML parse warning (continuing):", err.message);
    try {
      (parser as unknown as { _parser: { error: null; resume: () => void } })._parser.error = null;
      (parser as unknown as { _parser: { resume: () => void } })._parser.resume();
    } catch {
      error = err;
      done = true;
      if (waiting) {
        waiting({ value: undefined as unknown as BloggerPost, done: true });
        waiting = null;
      }
    }
  });

  parser.on("end", () => {
    done = true;
    if (waiting) {
      waiting({ value: undefined as unknown as BloggerPost, done: true });
      waiting = null;
    }
  });

  stream.on("error", (err) => {
    error = err;
    done = true;
    if (waiting) {
      waiting({ value: undefined as unknown as BloggerPost, done: true });
      waiting = null;
    }
  });

  stream.pipe(parser);

  while (true) {
    if (error) throw error;
    if (queue.length) {
      yield queue.shift()!;
      continue;
    }
    if (done) break;
    const next = await new Promise<IteratorResult<BloggerPost>>((resolvePromise) => {
      waiting = resolvePromise;
    });
    if (next.done) break;
    yield next.value;
  }
}

async function ensureEnglishSite() {
  const existing = await prisma.site.findFirst({
    where: { OR: [{ language: "en" }, { slug: "english" }, { slug: "pakistan-times-en" }] },
    orderBy: { language: "asc" },
  });
  if (existing) return existing;
  return prisma.site.create({
    data: {
      name: "The Pakistan Times",
      slug: "english",
      language: "en",
      isDefault: false,
      domain: "www.thepakistantimes.live",
      status: "active",
    },
  });
}

async function ensureAuthor(name: string) {
  const n = (name || "The Pakistan Times").trim() || "The Pakistan Times";
  const slug = makeSlug(n, "author");
  const found = await prisma.author.findFirst({
    where: { OR: [{ name: n }, { slug }] },
  });
  if (found) return found;
  return prisma.author.create({
    data: { name: n, slug, status: "active", bio: "Imported from English Blogger" },
  });
}

async function main() {
  const cli = parseArgs(process.argv.slice(2));
  const xmlPath = await resolveXmlPath(cli.file);
  const sizeMb = (statSync(xmlPath).size / 1e6).toFixed(1);

  console.log(`Streaming English Blogger import from ${xmlPath} (${sizeMb} MB)`);
  console.log(cli.dryRun ? "DRY RUN — no writes" : "LIVE WRITE");
  if (cli.limit != null) console.log(`Limit: first ${cli.limit} posts`);
  if (cli.skip) console.log(`Skip first: ${cli.skip}`);

  const site = await ensureEnglishSite();
  const author = await ensureAuthor("The Pakistan Times");

  // Prefetch existing EN slugs + canonicals for collision / duplicate checks
  const existingRows = await prisma.article.findMany({
    where: { language: "en", deletedAt: null },
    select: { slug: true, canonicalUrl: true },
  });
  const existingSlugs = existingRows.map((a) => a.slug);
  const existingCanonicals = new Set(
    existingRows.map((a) => a.canonicalUrl).filter((c): c is string => Boolean(c)),
  );
  // Also key by blogger post id fragment stored in canonicalUrl or as suffix
  const existingBloggerIds = new Set<string>();
  for (const c of existingCanonicals) {
    existingBloggerIds.add(c);
    const m = c.match(/post-(\d+)/);
    if (m) existingBloggerIds.add(`post-${m[1]}`);
    if (c.includes("blogger.com") || c.includes("tag:blogger")) existingBloggerIds.add(c);
  }

  let seen = 0;
  let imported = 0;
  let skipped = 0;
  let errors = 0;
  const skipReasons: Record<string, number> = {};
  const bump = (reason: string) => {
    skipped += 1;
    skipReasons[reason] = (skipReasons[reason] || 0) + 1;
  };

  // Rough total for progress (optional; cheap scan of <entry count via line grep would load file —
  // we just log every 50 without requiring total)
  let expectedTotal: number | null = cli.limit;
  if (expectedTotal == null) {
    // Lightweight entry count: stream lines counting "<entry" (not full DOM)
    expectedTotal = await countEntriesApprox(xmlPath);
    console.log(`Approx post entries in file: ${expectedTotal}`);
  }

  for await (const post of streamBloggerPosts(xmlPath)) {
    seen += 1;
    if (seen <= cli.skip) continue;
    // --limit N = process at most N posts from the file (after --skip)
    if (cli.limit != null && imported + skipped >= cli.limit) break;

    try {
      const title = post.title.trim();
      if (!title) {
        bump("empty-title");
        continue;
      }

      const canonical =
        post.permalink ||
        (post.bloggerId.startsWith("tag:blogger") ? post.bloggerId : null) ||
        `blogger:${post.bloggerId}`;

      const bloggerKey =
        post.bloggerId.match(/post-\d+/)?.[0] ||
        post.bloggerId;

      if (
        existingCanonicals.has(canonical) ||
        existingBloggerIds.has(post.bloggerId) ||
        existingBloggerIds.has(bloggerKey) ||
        existingBloggerIds.has(canonical)
      ) {
        bump("duplicate-blogger-id-or-canonical");
        continue;
      }

      const baseSlug = post.slugHint || slugFromPermalink(post.permalink, title);
      const slug = uniqueSlug(baseSlug, existingSlugs);

      // Secondary slug collision against DB (race-safe check)
      const slugHit = await prisma.article.findFirst({
        where: {
          deletedAt: null,
          OR: [{ slug }, { siteId: site.id, slug }],
        },
        select: { id: true, language: true, canonicalUrl: true, slug: true },
      });
      let finalSlug = slug;
      if (slugHit) {
        if (
          slugHit.canonicalUrl === canonical ||
          (slugHit.canonicalUrl && slugHit.canonicalUrl === post.bloggerId)
        ) {
          bump("duplicate-slug-same-post");
          continue;
        }
        finalSlug = uniqueSlug(baseSlug, [...existingSlugs, slugHit.slug]);
      }

      const publishedAt = post.publishedAt || new Date();
      const body = post.bodyHtml || "";
      const excerpt = excerptFromHtml(body);

      console.log(
        `${cli.dryRun ? "WOULD CREATE" : "CREATE"} ${finalSlug} ← ${title.slice(0, 70)}`,
      );

      if (!cli.dryRun) {
        const data: Prisma.ArticleCreateInput = {
          title,
          slug: finalSlug,
          excerpt,
          body,
          language: "en",
          status: "published",
          workflowStep: "published",
          priority: "normal",
          site: { connect: { id: site.id } },
          author: { connect: { id: author.id } },
          // Leave uncategorized — do not guess from Blogger labels
          category: undefined,
          publishAt: publishedAt,
          publishedAt,
          canonicalUrl: canonical,
          seoTitle: title.slice(0, 70),
          seoDescription: excerpt,
          ogTitle: title,
          ogDescription: excerpt,
          schemaType: "NewsArticle",
        };
        await prisma.article.create({ data });
      }

      existingSlugs.push(finalSlug);
      existingCanonicals.add(canonical);
      existingBloggerIds.add(post.bloggerId);
      existingBloggerIds.add(bloggerKey);
      imported += 1;

      const totalHint = expectedTotal ?? "?";
      if (imported % 50 === 0 || (cli.limit != null && imported === cli.limit)) {
        console.log(`Imported ${imported}/${totalHint} (skipped ${skipped}, errors ${errors})`);
      }
    } catch (err) {
      errors += 1;
      const msg = err instanceof Error ? err.message : String(err);
      console.warn(`SKIP bad entry #${seen}: ${msg}`);
      bump("error");
      // unique constraint → treat as skip duplicate
      if (/Unique constraint|P2002/i.test(msg)) {
        skipReasons["unique-constraint"] = (skipReasons["unique-constraint"] || 0) + 1;
      }
    }
  }

  console.log("\n=== Import summary ===");
  console.log({
    scanned: seen,
    imported,
    skipped,
    errors,
    dryRun: cli.dryRun,
    skipReasons,
    limit: cli.limit,
  });
}

async function countEntriesApprox(xmlPath: string): Promise<number> {
  let n = 0;
  const rl = createInterface({ input: createReadStream(xmlPath, { encoding: "utf8" }), crlfDelay: Infinity });
  for await (const line of rl) {
    // Count opening entry tags (Takeout + Atom)
    const matches = line.match(/<entry\b/g);
    if (matches) n += matches.length;
  }
  return n;
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
