#!/usr/bin/env bash
# Build ONE complete project zip (Frontend + Backend + Admin + Prisma DB schema)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="$ROOT/public/download"
OUT_ZIP="$OUT_DIR/the-pakistan-times-COMPLETE.zip"
TMP="$(mktemp -d)"
NAME="the-pakistan-times-COMPLETE"

mkdir -p "$OUT_DIR" "$TMP/$NAME"

cd "$ROOT"
tar -cf - \
  --exclude=./node_modules \
  --exclude=./.next \
  --exclude=./.git \
  --exclude=./.vercel \
  --exclude=./uploads \
  --exclude='./*.zip' \
  --exclude=./.env \
  --exclude=./.env.local \
  --exclude=./.env.vercel.local \
  --exclude=./.env.bak-supabase \
  --exclude=./tsconfig.tsbuildinfo \
  --exclude=./mobile/node_modules \
  --exclude=./mobile/.expo \
  --exclude='./public/download/*.zip' \
  --exclude=./.agents \
  --exclude=./.claude \
  --exclude=./.windsurf \
  . | (cd "$TMP/$NAME" && tar -xf -)

if [[ -f "$ROOT/.env.example" ]]; then
  cp "$ROOT/.env.example" "$TMP/$NAME/.env.example"
fi

cat > "$TMP/$NAME/START-HERE.txt" <<'EOF'
THE PAKISTAN TIMES — COMPLETE PROJECT (Frontend + Backend + Admin + Database)
==============================================================================

This ONE zip contains the full Next.js app:
  - Public frontend (news site)
  - Admin panel (/admin)
  - API backend (/api/*)
  - Prisma PostgreSQL schema + migrations

HOW TO RUN (computer):
  1. Unzip this folder
  2. cp .env.example .env
  3. Edit .env — set DATABASE_URL, DIRECT_DATABASE_URL, JWT_SECRET
  4. npm install
  5. npm run db:deploy
  6. npm run db:seed
  7. npm run dev
  8. Open http://127.0.0.1:4355
     Admin: http://127.0.0.1:4355/admin/login

MOBILE LIVE SITE (already online — open on phone):
  https://the-pakistan-times-live.vercel.app

Default admin (after seed — change password):
  See .env.example ADMIN_EMAIL / ADMIN_PASSWORD
EOF

rm -f "$OUT_ZIP"
(cd "$TMP" && zip -r -q "$OUT_ZIP" "$NAME")
rm -rf "$TMP"
ls -lh "$OUT_ZIP"
echo "Wrote $OUT_ZIP"
