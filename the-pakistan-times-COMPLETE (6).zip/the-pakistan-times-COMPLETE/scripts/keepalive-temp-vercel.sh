#!/usr/bin/env bash
# Keep temporary Vercel deployment alive by redeploying before expiry (~50 min).
# This is NOT a substitute for claiming — claim for permanent hosting.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
LOG=/tmp/pt-keepalive.log
while true; do
  {
    echo "==== $(date -u +%Y-%m-%dT%H:%M:%SZ) keepalive start ===="
    set -a
    # shellcheck disable=SC1091
    source "$ROOT/.env.vercel.local"
    set +a
    env -u VERCEL_TOKEN npx vercel deploy --temporary --yes --force \
      -e "DATABASE_URL=$DATABASE_URL" \
      -e "DIRECT_DATABASE_URL=$DIRECT_DATABASE_URL" \
      -e "JWT_SECRET=$JWT_SECRET" \
      -e "ADMIN_EMAIL=$ADMIN_EMAIL" \
      -e "ADMIN_PASSWORD=$ADMIN_PASSWORD" \
      -e "ADMIN_NAME=$ADMIN_NAME" \
      -e "NEXT_PUBLIC_SITE_NAME_UR=$NEXT_PUBLIC_SITE_NAME_UR" \
      -e "NEXT_PUBLIC_SITE_NAME_EN=$NEXT_PUBLIC_SITE_NAME_EN" \
      -e "NEXT_PUBLIC_SITE_URL=${NEXT_PUBLIC_SITE_URL}" \
      -e "NEXT_PUBLIC_API_BASE=/api" \
      -e "UPLOAD_MAX_MB=10" || echo "deploy failed"
    if [[ -f .vercel/anonymous.json ]]; then
      python3 -c "import json; a=json.load(open('.vercel/anonymous.json')); print('URL claim', a.get('claimUrl')); print('expiresAt', a.get('expiresAt'))"
    fi
    echo "sleeping 45 minutes..."
  } >>"$LOG" 2>&1
  sleep 2700
done
