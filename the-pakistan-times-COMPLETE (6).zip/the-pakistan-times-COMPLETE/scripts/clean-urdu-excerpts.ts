/**
 * Strip English Blogger bylines mixed into Urdu excerpt/SEO fields.
 * Does not touch language=en articles.
 */
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

function strip(s: string | null | undefined): string | null | undefined {
  if (s == null) return s;
  let t = s.trim();
  t = t.replace(/^The Pakistan Times[^۔\n]{0,100}[|–—\-]\s*/i, "");
  t = t.replace(/^The Pakistan Times\s*[—–|\-].*?(?=[؀-ۿA-Za-z])/i, "");
  t = t.replace(/^(دی پاکستان ٹائمز اردو\s*){2,}/u, "دی پاکستان ٹائمز اردو ");
  return t.trim();
}

async function main() {
  const rows = await prisma.article.findMany({
    where: { language: "ur", deletedAt: null },
    select: {
      id: true,
      excerpt: true,
      excerptUr: true,
      seoDescriptionUr: true,
      ogDescriptionUr: true,
      titleUr: true,
    },
  });
  let n = 0;
  for (const r of rows) {
    const excerptUr = strip(r.excerptUr) ?? null;
    const excerpt = strip(r.excerpt) ?? null;
    const seoDescriptionUr = strip(r.seoDescriptionUr) ?? null;
    const ogDescriptionUr = strip(r.ogDescriptionUr) ?? null;
    if (
      excerptUr !== r.excerptUr ||
      excerpt !== r.excerpt ||
      seoDescriptionUr !== r.seoDescriptionUr ||
      ogDescriptionUr !== r.ogDescriptionUr
    ) {
      await prisma.article.update({
        where: { id: r.id },
        data: { excerptUr, excerpt, seoDescriptionUr, ogDescriptionUr },
      });
      n += 1;
      console.log("cleaned", (r.titleUr || "").slice(0, 50));
    }
  }
  console.log({ cleaned: n, totalUr: rows.length });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
