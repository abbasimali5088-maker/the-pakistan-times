/**
 * Import Urdu articles crawled from https://urdu.thepakistantimes.live/
 * into this CMS. NEVER touches language=en rows or www English Blogger.
 *
 * Usage:
 *   npx tsx scripts/import-blogger-urdu.ts
 *   npx tsx scripts/import-blogger-urdu.ts --dry-run
 */
import { readFileSync } from "fs";
import { resolve } from "path";
import { PrismaClient } from "@prisma/client";
import { makeSlug, uniqueSlug } from "../src/lib/slug";
import { toArticleHtml } from "../src/lib/article-html";

const prisma = new PrismaClient();
const DRY = process.argv.includes("--dry-run");
const EXPORT_PATH = resolve(
  process.cwd(),
  process.env.BLOGGER_URDU_EXPORT || "data/blogger-urdu-export/articles.json",
);

type ExportArticle = {
  language: string;
  title: string;
  bodyHtml: string;
  excerpt?: string;
  publishedAt?: string;
  updatedAt?: string;
  authorName?: string;
  permalink: string;
  canonicalUrl?: string;
  labels?: string[];
  images?: string[];
  featuredImageUrl?: string | null;
  seo?: { title?: string; description?: string; ogImage?: string | null };
  bloggerId?: string;
};

type ExportFile = {
  source: string;
  count: number;
  articles: ExportArticle[];
};

function slugFromPermalink(permalink: string, title: string) {
  try {
    const u = new URL(permalink);
    if (!u.hostname.includes("urdu.thepakistantimes.live")) {
      throw new Error(`Refusing non-Urdu host: ${u.hostname}`);
    }
    const base = u.pathname.split("/").filter(Boolean).pop() || "";
    const cleaned = base.replace(/\.html$/i, "").replace(/-+$/g, "");
    if (cleaned && cleaned !== "blog-post" && !/^-+$/.test(cleaned) && cleaned !== "8") {
      return makeSlug(cleaned, "urdu-post");
    }
    // Ambiguous Blogger slugs — derive from title + date folder
    const parts = u.pathname.split("/").filter(Boolean);
    const y = parts[0] || "2026";
    const m = parts[1] || "01";
    return makeSlug(`${title}-${y}${m}`, "urdu-post");
  } catch {
    return makeSlug(title, "urdu-post");
  }
}

function labelToCategory(label: string) {
  const t = label.trim();
  if (!t) return null;
  // Language marker, not a topical category
  if (/^urdu$/i.test(t)) return null;
  return t;
}

async function ensureUrduSite() {
  const existing = await prisma.site.findFirst({
    where: { OR: [{ language: "ur" }, { isDefault: true }, { slug: "pakistan-times-ur" }] },
    orderBy: { isDefault: "desc" },
  });
  if (existing) return existing;
  return prisma.site.create({
    data: {
      name: "دی پاکستان ٹائمز اردو",
      slug: "pakistan-times-ur",
      language: "ur",
      isDefault: true,
      domain: "urdu.thepakistantimes.live",
      status: "active",
    },
  });
}

async function ensureAuthor(name: string) {
  const n = (name || "دی پاکستان ٹائمز اردو").trim() || "دی پاکستان ٹائمز اردو";
  const slug = makeSlug(n, "author");
  const found = await prisma.author.findFirst({
    where: { OR: [{ name: n }, { slug }] },
  });
  if (found) return found;
  return prisma.author.create({
    data: { name: n, slug, status: "active", bio: "Imported from Urdu Blogger" },
  });
}

async function ensureCategory(siteId: string, name: string) {
  const slug = makeSlug(name, "category");
  const found = await prisma.category.findFirst({
    where: { siteId, language: "ur", OR: [{ slug }, { name }, { nameUr: name }] },
  });
  if (found) return found;
  return prisma.category.create({
    data: {
      siteId,
      name,
      nameUr: name,
      slug,
      language: "ur",
      status: "active",
    },
  });
}

async function ensureMedia(url: string, title: string) {
  const existing = await prisma.media.findFirst({
    where: { url, language: "ur", deletedAt: null },
  });
  if (existing) return existing;
  const filename = url.split("/").pop()?.split("?")[0] || "image.jpg";
  return prisma.media.create({
    data: {
      filename,
      originalName: filename,
      path: url,
      url,
      mimeType: filename.toLowerCase().endsWith(".png")
        ? "image/png"
        : filename.toLowerCase().endsWith(".webp")
          ? "image/webp"
          : "image/jpeg",
      size: 0,
      alt: title.slice(0, 180),
      type: "image",
      language: "ur",
    },
  });
}

async function main() {
  const raw = JSON.parse(readFileSync(EXPORT_PATH, "utf8")) as ExportFile;
  if (!raw.articles?.length) throw new Error(`No articles in ${EXPORT_PATH}`);
  if (!String(raw.source || "").includes("urdu.thepakistantimes.live")) {
    throw new Error(`Export source is not Urdu Blogger: ${raw.source}`);
  }

  console.log(`Importing ${raw.articles.length} Urdu articles from ${raw.source}`);
  console.log(DRY ? "DRY RUN — no writes" : "LIVE WRITE");

  const site = await ensureUrduSite();
  const author = await ensureAuthor("دی پاکستان ٹائمز اردو");
  const existingSlugs = (
    await prisma.article.findMany({
      where: { siteId: site.id, deletedAt: null },
      select: { slug: true },
    })
  ).map((a) => a.slug);

  let created = 0;
  let updated = 0;
  let skipped = 0;

  for (const item of raw.articles) {
    if (item.language !== "ur") {
      console.warn("SKIP non-ur language", item.permalink);
      skipped += 1;
      continue;
    }
    if (!item.permalink?.startsWith("https://urdu.thepakistantimes.live/")) {
      console.warn("SKIP non-urdu permalink", item.permalink);
      skipped += 1;
      continue;
    }

    const title = (item.title || "").trim();
    if (!title) {
      skipped += 1;
      continue;
    }

    const baseSlug = slugFromPermalink(item.permalink, title);
    const bodyUr = toArticleHtml(item.bodyHtml || "");
    const excerptUr = (item.excerpt || item.seo?.description || "").trim().slice(0, 500) || null;
    const publishedAt = item.publishedAt ? new Date(item.publishedAt) : new Date();
    const canonical = item.canonicalUrl || item.permalink;

    const topicLabels = (item.labels || [])
      .map(labelToCategory)
      .filter((x): x is string => Boolean(x));

    // Prefer topical label; else general news
    const categoryName = topicLabels[0] || "خبریں";

    // Idempotent match: same canonical / permalink among URDU rows only
    const existing = await prisma.article.findFirst({
      where: {
        language: "ur",
        deletedAt: null,
        OR: [{ canonicalUrl: canonical }, { canonicalUrl: item.permalink }],
      },
    });

    let slug = existing?.slug || uniqueSlug(baseSlug, existingSlugs);
    if (!existing) existingSlugs.push(slug);

    console.log(
      `${existing ? "UPDATE" : "CREATE"} ${slug} ← ${title.slice(0, 60)}`,
    );

    if (DRY) {
      if (existing) updated += 1;
      else created += 1;
      continue;
    }

    const category = await ensureCategory(site.id, categoryName);
    const featuredUrl = item.featuredImageUrl || item.images?.[0] || item.seo?.ogImage || null;
    const media = featuredUrl ? await ensureMedia(featuredUrl, title) : null;

    const data = {
      title,
      titleUr: title,
      slug,
      slugUr: slug,
      excerpt: excerptUr,
      excerptUr,
      body: bodyUr,
      bodyUr,
      language: "ur" as const,
      status: "published",
      workflowStep: "published",
      priority: "normal",
      siteId: site.id,
      authorId: author.id,
      categoryId: null as string | null,
      categoryUrId: category.id,
      featuredImageId: null as string | null,
      featuredImageUrId: media?.id || null,
      publishAt: publishedAt,
      publishedAt,
      seoTitle: item.seo?.title || title,
      seoDescription: item.seo?.description || excerptUr,
      seoTitleUr: item.seo?.title || title,
      seoDescriptionUr: item.seo?.description || excerptUr,
      canonicalUrl: canonical,
      ogTitle: item.seo?.title || title,
      ogDescription: item.seo?.description || excerptUr,
      ogTitleUr: item.seo?.title || title,
      ogDescriptionUr: item.seo?.description || excerptUr,
      ogImage: featuredUrl,
      ogImageUr: featuredUrl,
      schemaType: "NewsArticle",
      searchKeywordsUr: topicLabels.join(", ") || null,
    };

    if (existing) {
      // Hard safety: never update an English row
      if (existing.language !== "ur") {
        console.warn("REFUSE update non-ur article", existing.id, existing.language);
        skipped += 1;
        continue;
      }
      await prisma.article.update({ where: { id: existing.id }, data });
      updated += 1;
    } else {
      await prisma.article.create({ data });
      created += 1;
    }
  }

  console.log({ created, updated, skipped, dry: DRY });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
