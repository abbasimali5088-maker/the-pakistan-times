# Audit report (historical)

Earlier audits of the old static HTML prototype are obsolete.

Current production path: bcrypt passwords, JWT cookie sessions, middleware-protected `/admin`.  
Never commit or publish admin passwords.
