/**
 * Central site settings catalog — admin UI, seed, and public site share these keys.
 * Editors can change everything here without touching code.
 */

export type SettingFieldType =
  | "text"
  | "textarea"
  | "url"
  | "email"
  | "color"
  | "tel"
  | "toggle"
  | "password";

/** True unless value is explicitly off / 0 / false / no. */
export function isSettingOn(value: string | undefined | null, fallback = true): boolean {
  const v = (value ?? "").trim().toLowerCase();
  if (!v) return fallback;
  return !["off", "0", "false", "no", "disabled", "hide"].includes(v);
}

/** Ticker rate keys controlled from Admin (master + each item). */
export const RATE_VISIBILITY_KEYS = [
  { key: "showRatePetrol", rateKey: "petrol", label: "Petrol", labelUr: "پیٹرول" },
  { key: "showRateDiesel", rateKey: "diesel", label: "Diesel", labelUr: "ڈیزل" },
  { key: "showRateHiOctane", rateKey: "hiOctane", label: "Hi-Octane", labelUr: "ہائی آکٹین" },
  { key: "showRateGold24k", rateKey: "gold24k", label: "Gold 24K", labelUr: "سونا" },
  { key: "showRateUsd", rateKey: "usd", label: "US Dollar", labelUr: "ڈالر" },
  { key: "showRateSar", rateKey: "sar", label: "Saudi Riyal", labelUr: "ریال" },
] as const;

export type SettingFieldDef = {
  key: string;
  label: string;
  labelUr?: string;
  type?: SettingFieldType;
  hint?: string;
  placeholder?: string;
  urdu?: boolean;
};

export type SettingGroupDef = {
  key: string;
  title: string;
  titleUr: string;
  description?: string;
  fields: SettingFieldDef[];
};

/** Canonical groups shown in Admin → Settings */
export const SETTING_GROUPS: SettingGroupDef[] = [
  {
    key: "general",
    title: "General / Site identity",
    titleUr: "عام / سائٹ کی شناخت",
    description: "Brand names, taglines, and basic contact details.",
    fields: [
      {
        key: "siteNameUr",
        label: "Site name (Urdu)",
        labelUr: "سائٹ کا نام (اردو)",
        urdu: true,
        placeholder: "دی پاکستان ٹائمز اردو",
      },
      {
        key: "siteNameEn",
        label: "Site name (English)",
        placeholder: "The Pakistan Times",
      },
      {
        key: "taglineUr",
        label: "Tagline (Urdu)",
        labelUr: "ٹیگ لائن (اردو)",
        urdu: true,
        placeholder: "آزاد، حقیقت پر مبنی صحافت",
      },
      {
        key: "taglineEn",
        label: "Tagline (English)",
        placeholder: "Independent reporting from the newsroom",
      },
      { key: "contactEmail", label: "Contact email", type: "email", placeholder: "news@example.com" },
      { key: "contactPhone", label: "Contact phone", type: "tel", placeholder: "+92 300 1234567" },
      {
        key: "addressUr",
        label: "Address (Urdu)",
        labelUr: "پتہ (اردو)",
        type: "textarea",
        urdu: true,
      },
      { key: "addressEn", label: "Address (English)", type: "textarea" },
    ],
  },
  {
    key: "social",
    title: "Social links",
    titleUr: "سوشل لنکس",
    description: "These appear on the public website footer. Paste full profile/page URLs.",
    fields: [
      {
        key: "facebook",
        label: "Facebook",
        type: "url",
        placeholder: "https://facebook.com/yourpage",
        hint: "Full Facebook page URL",
      },
      {
        key: "twitter",
        label: "X (Twitter)",
        type: "url",
        placeholder: "https://x.com/yourhandle",
      },
      {
        key: "instagram",
        label: "Instagram",
        type: "url",
        placeholder: "https://instagram.com/yourhandle",
      },
      {
        key: "whatsapp",
        label: "WhatsApp",
        type: "url",
        placeholder: "https://wa.me/923001234567",
        hint: "Use wa.me link, e.g. https://wa.me/923001234567",
      },
      {
        key: "youtube",
        label: "YouTube",
        type: "url",
        placeholder: "https://youtube.com/@yourchannel",
      },
      {
        key: "tiktok",
        label: "TikTok",
        type: "url",
        placeholder: "https://tiktok.com/@yourhandle",
      },
      {
        key: "linkedin",
        label: "LinkedIn",
        type: "url",
        placeholder: "https://linkedin.com/company/yourorg",
      },
      {
        key: "telegram",
        label: "Telegram",
        type: "url",
        placeholder: "https://t.me/yourchannel",
      },
      {
        key: "threads",
        label: "Threads",
        type: "url",
        placeholder: "https://threads.net/@yourhandle",
      },
    ],
  },
  {
    key: "theme",
    title: "Theme & branding",
    titleUr: "تھیم اور برانڈنگ",
    fields: [
      {
        key: "accentColor",
        label: "Accent color",
        type: "color",
        placeholder: "#1DB954",
        hint: "Bright brand green default: #1DB954 (white text pops)",
      },
      { key: "logoUrl", label: "Logo URL", type: "url", placeholder: "https://…" },
      { key: "faviconUrl", label: "Favicon URL", type: "url" },
      { key: "fontFamily", label: "Font family note", placeholder: "Noto Nastaliq Urdu / Source Serif" },
      {
        key: "showRatesBar",
        label: "Rates bar — master ON/OFF",
        labelUr: "ریٹس پٹی — ماسٹر آن/آف",
        type: "toggle",
        placeholder: "on",
        hint: "Backend only. Off = whole rates ticker hidden. On = individual items below still apply.",
      },
      {
        key: "showRatePetrol",
        label: "Show petrol",
        labelUr: "پیٹرول دکھائیں",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showRateDiesel",
        label: "Show diesel",
        labelUr: "ڈیزل دکھائیں",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showRateHiOctane",
        label: "Show hi-octane",
        labelUr: "ہائی آکٹین دکھائیں",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showRateGold24k",
        label: "Show gold",
        labelUr: "سونا دکھائیں",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showRateUsd",
        label: "Show US dollar",
        labelUr: "ڈالر دکھائیں",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showRateSar",
        label: "Show Saudi riyal",
        labelUr: "ریال دکھائیں",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showBreakingBar",
        label: "Breaking news bar — ON/OFF",
        labelUr: "بریکنگ نیوز پٹی — آن/آف",
        type: "toggle",
        placeholder: "on",
        hint: "Backend only. Off = breaking ticker hidden on the public site.",
      },
      { key: "customCss", label: "Custom CSS", type: "textarea", hint: "Optional advanced CSS" },
    ],
  },
  {
    key: "features",
    title: "Feature ON / OFF",
    titleUr: "فیچرز آن / آف",
    description: "ہر سیکشن کا ماسٹر سوئچ — بیک اینڈ سے فرنٹ کنٹرول کریں۔",
    fields: [
      {
        key: "showLive",
        label: "Live coverage — ON/OFF",
        labelUr: "لائیو کوریج — آن/آف",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showVideos",
        label: "Videos section — ON/OFF",
        labelUr: "ویڈیوز — آن/آف",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showGalleries",
        label: "Galleries section — ON/OFF",
        labelUr: "گیلریز — آن/آف",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showMostRead",
        label: "Most read — ON/OFF",
        labelUr: "زیادہ پڑھی گئیں — آن/آف",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showPolls",
        label: "Polls — ON/OFF",
        labelUr: "پولز — آن/آف",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showQuizzes",
        label: "Quizzes — ON/OFF",
        labelUr: "کوئز — آن/آف",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showAds",
        label: "Ads — ON/OFF",
        labelUr: "اشتہارات — آن/آف",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showCategorySections",
        label: "Homepage category sections — ON/OFF",
        labelUr: "ہوم کیٹیگری سیکشنز — آن/آف",
        type: "toggle",
        placeholder: "on",
      },
      {
        key: "showBreakingEn",
        label: "Breaking EN headlines — ON/OFF",
        labelUr: "بریکنگ انگریزی — آن/آف",
        type: "toggle",
        placeholder: "on",
        hint: "When off, English site ticker hides even if bar is on.",
      },
      {
        key: "showBreakingUr",
        label: "Breaking UR headlines — ON/OFF",
        labelUr: "بریکنگ اردو — آن/آف",
        type: "toggle",
        placeholder: "on",
        hint: "When off, Urdu site ticker hides even if bar is on.",
      },
    ],
  },
  {
    key: "headings",
    title: "SEO H1 / H2 headings",
    titleUr: "SEO H1 / H2 سرخیاں",
    description: "ہوم اور سیکشنز کی H1/H2 — English اور اردو الگ۔ خالی چھوڑیں تو ڈیفالٹ ٹائٹل استعمال ہوگا۔",
    fields: [
      { key: "h1HomeEn", label: "Homepage H1 (EN)", placeholder: "The Pakistan Times" },
      { key: "h1HomeUr", label: "ہوم پیج H1 (اردو)", urdu: true, placeholder: "دی پاکستان ٹائمز" },
      { key: "h2LatestEn", label: "Latest H2 (EN)", placeholder: "Latest" },
      { key: "h2LatestUr", label: "تازہ ترین H2 (اردو)", urdu: true, placeholder: "تازہ ترین" },
      { key: "h2BreakingEn", label: "Breaking page H1 (EN)", placeholder: "Breaking news" },
      { key: "h2BreakingUr", label: "بریکنگ H1 (اردو)", urdu: true, placeholder: "بریکنگ نیوز" },
      { key: "h2LiveEn", label: "Live page H1 (EN)", placeholder: "Live" },
      { key: "h2LiveUr", label: "لائیو H1 (اردو)", urdu: true, placeholder: "لائیو" },
      { key: "h2VideosEn", label: "Videos H2 (EN)", placeholder: "Videos" },
      { key: "h2VideosUr", label: "ویڈیوز H2 (اردو)", urdu: true, placeholder: "ویڈیوز" },
      { key: "h2GalleriesEn", label: "Galleries H2 (EN)", placeholder: "Galleries" },
      { key: "h2GalleriesUr", label: "گیلریز H2 (اردو)", urdu: true, placeholder: "تصویری گیلریز" },
      { key: "h2MostReadEn", label: "Most read H2 (EN)", placeholder: "Most read" },
      { key: "h2MostReadUr", label: "زیادہ پڑھی گئیں H2 (اردو)", urdu: true, placeholder: "زیادہ پڑھی گئیں" },
    ],
  },
  {
    key: "security",
    title: "Security / Launcher",
    titleUr: "سیکورٹی / لانچر",
    description:
      "Password for the Front+Backend laptop file. Change anytime, then re-download the file.",
    fields: [
      {
        key: "launcherPassword",
        label: "Front+Backend launcher password",
        labelUr: "فرنٹ+بیک اینڈ پاس ورڈ",
        type: "password",
        placeholder: "Set a unique launcher password",
        hint: "Saved in database. Separate from admin login. Use /open after setting.",
      },
    ],
  },
  {
    key: "seo",
    title: "SEO defaults",
    titleUr: "SEO ڈیفالٹس",
    fields: [
      { key: "defaultTitleEn", label: "Default meta title (EN)", placeholder: "The Pakistan Times" },
      { key: "defaultTitleUr", label: "ڈیفالٹ میٹا عنوان (اردو)", urdu: true },
      { key: "defaultTitle", label: "Default meta title (legacy)", urdu: true, hint: "Kept for older rows — prefer EN/UR above" },
      { key: "defaultDescriptionEn", label: "Default meta description (EN)", type: "textarea" },
      { key: "defaultDescriptionUr", label: "ڈیفالٹ میٹا تفصیل (اردو)", type: "textarea", urdu: true },
      { key: "defaultDescription", label: "Default meta description (legacy)", type: "textarea", urdu: true },
      { key: "ogImage", label: "Default OG image URL", type: "url" },
      {
        key: "twitterHandle",
        label: "X / Twitter @handle",
        placeholder: "@PakistanTimes",
        hint: "Used in Twitter cards (with or without @)",
      },
      {
        key: "ownerDomain",
        label: "Owner domain / live URL (legacy)",
        labelUr: "مالک ڈومین / لائیو یو آر ایل",
        type: "url",
        placeholder: "https://the-pakistan-times-live.vercel.app",
        hint: "Legacy single domain — prefer EN/UR domains below",
      },
      {
        key: "ownerDomainEn",
        label: "English Search Console domain",
        labelUr: "انگلش سرچ کنسول ڈومین",
        type: "url",
        placeholder: "https://www.thepakistantimes.live",
        hint: "Google Search Console property for English site (www)",
      },
      {
        key: "ownerDomainUr",
        label: "Urdu Search Console domain",
        labelUr: "اردو سرچ کنسول ڈومین",
        type: "url",
        placeholder: "https://urdu.thepakistantimes.live",
        hint: "Google Search Console property for Urdu site (urdu subdomain)",
      },
      {
        key: "indexHomepage",
        label: "Index homepage in Google",
        labelUr: "ہوم پیج گوگل میں انڈیکس",
        placeholder: "on",
        hint: "on = allow Google index for homepage. off = noindex homepage.",
      },
      {
        key: "performanceNote",
        label: "Performance note",
        labelUr: "پرفارمنس نوٹ",
        type: "textarea",
        placeholder: "Vercel Speed Insights active…",
      },
    ],
  },
  {
    key: "footer",
    title: "Footer text",
    titleUr: "فوٹر متن",
    fields: [
      {
        key: "aboutUr",
        label: "About blurb (Urdu)",
        labelUr: "تعارف (اردو)",
        type: "textarea",
        urdu: true,
      },
      { key: "aboutEn", label: "About blurb (English)", type: "textarea" },
      { key: "copyrightUr", label: "Copyright line (Urdu)", urdu: true },
      { key: "copyrightEn", label: "Copyright line (English)" },
    ],
  },
  {
    key: "integrations",
    title: "Search Console & Analytics",
    titleUr: "سرچ کنسول اور اینالیٹکس",
    description:
      "Separate Google Search Console / GA for Urdu vs English domains. Paste verification codes from each GSC property.",
    fields: [
      {
        key: "searchConsoleVerificationUr",
        label: "Search Console verification — Urdu",
        labelUr: "سرچ کنسول تصدیق — اردو",
        placeholder: "AbCdEf… یا پورا meta tag",
        hint: "HTML tag verification for urdu.thepakistantimes.live property",
      },
      {
        key: "searchConsoleVerificationEn",
        label: "Search Console verification — English",
        labelUr: "سرچ کنسول تصدیق — انگلش",
        placeholder: "AbCdEf… یا پورا meta tag",
        hint: "HTML tag verification for www.thepakistantimes.live property",
      },
      {
        key: "searchConsoleVerification",
        label: "Search Console verification (legacy / fallback)",
        labelUr: "گوگل سرچ کنسول تصدیق (پرانا)",
        placeholder: "AbCdEf… یا پورا meta tag",
        hint: "Used only if EN/UR codes are empty",
      },
      {
        key: "gaMeasurementIdUr",
        label: "GA4 ID — Urdu",
        labelUr: "گوگل اینالیٹکس — اردو",
        placeholder: "G-XXXXXXXXXX",
      },
      {
        key: "gaMeasurementIdEn",
        label: "GA4 ID — English",
        labelUr: "گوگل اینالیٹکس — انگلش",
        placeholder: "G-XXXXXXXXXX",
      },
      {
        key: "gaMeasurementId",
        label: "GA4 ID (legacy / fallback)",
        labelUr: "گوگل اینالیٹکس (پرانا)",
        placeholder: "G-XXXXXXXXXX",
      },
      {
        key: "gtmContainerId",
        label: "Google Tag Manager ID",
        labelUr: "ٹیگ مینیجر",
        placeholder: "GTM-XXXXXXX",
      },
    ],
  },
];

/** Legacy snake_case keys from older seed → canonical keys */
const LEGACY_ALIASES: Record<string, { group: string; key: string }> = {
  "general.site_name_ur": { group: "general", key: "siteNameUr" },
  "general.site_name_en": { group: "general", key: "siteNameEn" },
  "general.description": { group: "general", key: "taglineUr" },
  "theme.accent": { group: "theme", key: "accentColor" },
  "theme.font": { group: "theme", key: "fontFamily" },
  "custom.css": { group: "theme", key: "customCss" },
  "integrations.ga_measurement_id": { group: "integrations", key: "gaMeasurementId" },
};

export type SettingsMap = Record<string, Record<string, string>>;

export function emptySettingsMap(): SettingsMap {
  const map: SettingsMap = {};
  for (const g of SETTING_GROUPS) {
    map[g.key] = {};
    for (const f of g.fields) map[g.key][f.key] = "";
  }
  return map;
}

export function defaultSettingsMap(): SettingsMap {
  const map = emptySettingsMap();
  map.general.siteNameUr = "دی پاکستان ٹائمز اردو";
  map.general.siteNameEn = "The Pakistan Times";
  map.general.taglineUr = "آزاد، حقیقت پر مبنی صحافت";
  map.general.taglineEn = "Independent reporting from the newsroom";
  map.general.contactEmail = "news@thepakistantimes.pk";
  map.general.contactPhone = "+92 300 0000000";
  map.theme.accentColor = "#1DB954";
  map.theme.showRatesBar = "on";
  map.theme.showRatePetrol = "on";
  map.theme.showRateDiesel = "on";
  map.theme.showRateHiOctane = "on";
  map.theme.showRateGold24k = "on";
  map.theme.showRateUsd = "on";
  map.theme.showRateSar = "on";
  map.theme.showBreakingBar = "on";
  map.features.showLive = "on";
  map.features.showVideos = "on";
  map.features.showGalleries = "on";
  map.features.showMostRead = "on";
  map.features.showPolls = "on";
  map.features.showQuizzes = "on";
  map.features.showAds = "on";
  map.features.showCategorySections = "on";
  map.features.showBreakingEn = "on";
  map.features.showBreakingUr = "on";
  // Never ship a known default launcher password — must be set in Admin Settings or LAUNCHER_PASSWORD env.
  map.security.launcherPassword = "";
  map.seo.defaultTitle = "دی پاکستان ٹائمز اردو";
  map.seo.defaultTitleUr = "دی پاکستان ٹائمز اردو";
  map.seo.defaultTitleEn = "The Pakistan Times";
  map.seo.defaultDescription = "خبریں، تجزیے، لائیو کوریج";
  map.seo.defaultDescriptionUr = "خبریں، تجزیے، لائیو کوریج";
  map.seo.defaultDescriptionEn = "Latest news, analysis and live coverage";
  map.headings.h1HomeEn = "The Pakistan Times";
  map.headings.h1HomeUr = "دی پاکستان ٹائمز";
  map.headings.h2LatestEn = "Latest";
  map.headings.h2LatestUr = "تازہ ترین";
  map.headings.h2BreakingEn = "Breaking news";
  map.headings.h2BreakingUr = "بریکنگ نیوز";
  map.headings.h2LiveEn = "Live";
  map.headings.h2LiveUr = "لائیو";
  map.headings.h2VideosEn = "Videos";
  map.headings.h2VideosUr = "ویڈیوز";
  map.headings.h2GalleriesEn = "Galleries";
  map.headings.h2GalleriesUr = "تصویری گیلریز";
  map.headings.h2MostReadEn = "Most read";
  map.headings.h2MostReadUr = "زیادہ پڑھی گئیں";
  map.seo.twitterHandle = "@ThePakistanTimes";
  map.seo.ownerDomain = "https://the-pakistan-times-live.vercel.app";
  map.seo.ownerDomainEn = "https://www.thepakistantimes.live";
  map.seo.ownerDomainUr = "https://urdu.thepakistantimes.live";
  map.seo.indexHomepage = "on";
  map.seo.performanceNote = "Vercel Analytics + Speed Insights on live deployment";
  map.footer.aboutUr = "دی پاکستان ٹائمز اردو — آزاد صحافت، قومی اور عالمی کوریج۔";
  map.footer.aboutEn = "The Pakistan Times — independent journalism covering Pakistan and the world.";
  // Public social profiles — edit anytime in Admin → Settings → Social links
  map.social.facebook = "https://www.facebook.com/thepakistantimes";
  map.social.twitter = "https://x.com/thepakistantimes";
  map.social.instagram = "https://www.instagram.com/thepakistantimes";
  map.social.whatsapp = "https://wa.me/923000000000";
  map.social.youtube = "https://www.youtube.com/@thepakistantimes";
  map.social.tiktok = "https://www.tiktok.com/@thepakistantimes";
  return map;
}

/** Normalize DB rows (including legacy keys) into the canonical nested map. */
export function normalizeSettingsMap(raw: SettingsMap): SettingsMap {
  const map = emptySettingsMap();

  for (const [group, entries] of Object.entries(raw || {})) {
    for (const [key, value] of Object.entries(entries || {})) {
      const alias = LEGACY_ALIASES[`${group}.${key}`];
      const targetGroup = alias?.group || group;
      const targetKey = alias?.key || key;
      if (!map[targetGroup]) map[targetGroup] = {};
      // Prefer non-empty values; don't overwrite filled canonical with empty legacy
      if (value || !map[targetGroup][targetKey]) {
        map[targetGroup][targetKey] = value ?? "";
      }
    }
  }
  return map;
}

export function flattenSettingsMap(
  map: SettingsMap,
): Array<{ group: string; key: string; value: string }> {
  const rows: Array<{ group: string; key: string; value: string }> = [];
  for (const [group, entries] of Object.entries(map || {})) {
    for (const [key, value] of Object.entries(entries || {})) {
      rows.push({ group, key, value: value ?? "" });
    }
  }
  return rows;
}

export const SOCIAL_LINK_KEYS = [
  "facebook",
  "twitter",
  "instagram",
  "whatsapp",
  "youtube",
  "tiktok",
  "linkedin",
  "telegram",
  "threads",
] as const;

export type SocialKey = (typeof SOCIAL_LINK_KEYS)[number];

export const SOCIAL_LABELS: Record<SocialKey, { en: string; ur: string }> = {
  facebook: { en: "Facebook", ur: "فیس بک" },
  twitter: { en: "X (Twitter)", ur: "ایکس (ٹوئٹر)" },
  instagram: { en: "Instagram", ur: "انسٹاگرام" },
  whatsapp: { en: "WhatsApp", ur: "واٹس ایپ" },
  youtube: { en: "YouTube", ur: "یوٹیوب" },
  tiktok: { en: "TikTok", ur: "ٹک ٹاک" },
  linkedin: { en: "LinkedIn", ur: "لنکڈ اِن" },
  telegram: { en: "Telegram", ur: "ٹیلی گرام" },
  threads: { en: "Threads", ur: "تھریڈز" },
};

/** Seed rows: [group, key, value] for all catalog fields + extras kept for publishing/media. */
export function seedSettingRows(extra: {
  defaultAuthorId?: string;
  defaultCategoryId?: string;
  uploadMaxMb?: string;
} = {}): Array<[string, string, string]> {
  const defaults = defaultSettingsMap();
  const rows: Array<[string, string, string]> = [];
  for (const g of SETTING_GROUPS) {
    for (const f of g.fields) {
      rows.push([g.key, f.key, defaults[g.key]?.[f.key] ?? ""]);
    }
  }
  if (extra.defaultAuthorId) rows.push(["publishing", "defaultAuthorId", extra.defaultAuthorId]);
  if (extra.defaultCategoryId) rows.push(["publishing", "defaultCategoryId", extra.defaultCategoryId]);
  rows.push(["media", "uploadMaxMb", extra.uploadMaxMb || "10"]);
  rows.push([
    "media",
    "allowedFormats",
    "jpg,jpeg,png,webp,avif,gif,mp4,mp3,pdf,doc,docx,xls,xlsx",
  ]);
  return rows;
}
