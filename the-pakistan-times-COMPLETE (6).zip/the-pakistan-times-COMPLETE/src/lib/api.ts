import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { ZodError } from "zod";
import { AuthError } from "./auth";
import { HttpError } from "./http-error";

export { HttpError } from "./http-error";

function corsOrigin() {
  const site = (process.env.NEXT_PUBLIC_SITE_URL || "").replace(/\/$/, "");
  return site || "*";
}

function withCors(init?: ResponseInit): ResponseInit {
  return {
    ...init,
    headers: {
      ...(init?.headers || {}),
      "Access-Control-Allow-Origin": corsOrigin(),
      "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, Accept",
      Vary: "Origin",
    },
  };
}

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json({ success: true, data }, withCors(init));
}

export function fail(message: string, status = 400, details?: unknown) {
  return NextResponse.json({ success: false, error: message, details }, withCors({ status }));
}

export async function handleApi<T>(fn: () => Promise<T>) {
  try {
    const data = await fn();
    if (data instanceof NextResponse) return data;
    return ok(data);
  } catch (err) {
    if (err instanceof AuthError) return fail(err.message, err.status);
    if (err instanceof HttpError) return fail(err.message, err.status);
    if (err instanceof ZodError) {
      return fail("Validation failed", 422, err.flatten());
    }
    if (err instanceof Prisma.PrismaClientKnownRequestError) {
      console.error("[prisma]", err.code, err.message, err.meta);
      if (err.code === "P2002") {
        return fail("Duplicate value — slug or unique field already exists", 409, err.meta);
      }
      if (err.code === "P2003") {
        return fail(
          "Invalid related record (category, tag, image, or author). Clear the field or pick a valid item.",
          422,
          err.meta,
        );
      }
      if (err.code === "P2025") {
        return fail("Record not found", 404, err.meta);
      }
      return fail(
        process.env.NODE_ENV === "production" ? "Database constraint error" : err.message,
        400,
        err.meta,
      );
    }
    console.error(err);
    const message = err instanceof Error ? err.message.slice(0, 300) : "Unknown error";
    return fail(message || "Internal server error", 500);
  }
}

export function getPagination(url: URL) {
  const page = Math.max(1, Number(url.searchParams.get("page") || 1));
  const pageSize = Math.min(100, Math.max(1, Number(url.searchParams.get("pageSize") || 20)));
  const skip = (page - 1) * pageSize;
  return { page, pageSize, skip, take: pageSize };
}
