import webpush from "web-push";
import { prisma } from "@/lib/db";

let configured = false;

/**
 * Lazily configures web-push with VAPID keys from env.
 * Returns false (and logs once) if keys are missing, so callers can
 * no-op instead of crashing — push notifications are an enhancement,
 * never something that should break breaking-news publishing.
 */
function ensureConfigured(): boolean {
  if (configured) return true;
  const publicKey = process.env.VAPID_PUBLIC_KEY;
  const privateKey = process.env.VAPID_PRIVATE_KEY;
  const subject = process.env.VAPID_SUBJECT || "mailto:admin@thepakistantimes.local";
  if (!publicKey || !privateKey) {
    console.warn(
      "[push] VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY not set — skipping push notifications. " +
        "Generate a pair with `npx web-push generate-vapid-keys` and add them to your env.",
    );
    return false;
  }
  webpush.setVapidDetails(subject, publicKey, privateKey);
  configured = true;
  return true;
}

export type BreakingPushPayload = {
  title: string;
  body: string;
  url: string;
  lang: "en" | "ur";
};

/**
 * Sends a push notification to every stored subscription for the given
 * language. Never throws — a failed or expired subscription is deleted
 * and the rest continue; a caller (the breaking-news API route) should
 * fire this and not await-block the actual save/response on it.
 */
export async function notifyBreakingSubscribers(payload: BreakingPushPayload): Promise<void> {
  if (!ensureConfigured()) return;

  const subs = await prisma.pushSubscription.findMany({
    where: { lang: payload.lang },
  });
  if (subs.length === 0) return;

  const body = JSON.stringify({
    title: payload.title,
    body: payload.body,
    url: payload.url,
    icon: "/icon-192.png",
    badge: "/icon-192.png",
  });

  const staleIds: string[] = [];

  await Promise.all(
    subs.map(async (sub) => {
      try {
        await webpush.sendNotification(
          {
            endpoint: sub.endpoint,
            keys: { p256dh: sub.p256dh, auth: sub.auth },
          },
          body,
        );
      } catch (err: unknown) {
        const statusCode = (err as { statusCode?: number })?.statusCode;
        // 404/410 = subscription no longer valid on the browser's push service
        if (statusCode === 404 || statusCode === 410) {
          staleIds.push(sub.id);
        } else {
          console.error("[push] send failed:", err);
        }
      }
    }),
  );

  if (staleIds.length > 0) {
    await prisma.pushSubscription.deleteMany({ where: { id: { in: staleIds } } }).catch(() => {
      /* best-effort cleanup */
    });
  }
}
