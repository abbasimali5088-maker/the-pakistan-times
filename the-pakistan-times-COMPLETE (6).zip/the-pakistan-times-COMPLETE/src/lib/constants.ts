export const BRAND = {
  ur: process.env.NEXT_PUBLIC_SITE_NAME_UR || "دی پاکستان ٹائمز اردو",
  en: process.env.NEXT_PUBLIC_SITE_NAME_EN || "The Pakistan Times",
  /** Bright theme green — white text pops on buttons / badges */
  accent: "#1DB954",
  accentDeep: "#159A45",
  accentSoft: "#E8F9EF",
  ink: "#141414",
};

export const WORKFLOW_STEPS = [
  "draft",
  "review",
  "fact_check",
  "seo_check",
  "approval",
  "scheduled",
  "published",
] as const;

export const ARTICLE_STATUSES = [
  "draft",
  "pending_review",
  "rejected",
  "scheduled",
  "published",
  "unpublished",
  "archived",
] as const;

export const PRIORITIES = ["breaking", "high", "normal", "low"] as const;
