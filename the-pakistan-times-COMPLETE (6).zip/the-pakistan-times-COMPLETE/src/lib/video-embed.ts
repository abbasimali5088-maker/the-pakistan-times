/** Build a safe iframe/embed HTML snippet from common video URL patterns. */
export function videoEmbedSrc(raw?: string | null): string | null {
  const url = (raw || "").trim();
  if (!url) return null;
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "").toLowerCase();

    if (host === "youtu.be") {
      const id = u.pathname.split("/").filter(Boolean)[0];
      return id ? `https://www.youtube.com/embed/${id}` : null;
    }
    if (host === "youtube.com" || host === "m.youtube.com" || host === "youtube-nocookie.com") {
      const v = u.searchParams.get("v");
      if (v) return `https://www.youtube.com/embed/${v}`;
      const parts = u.pathname.split("/").filter(Boolean);
      if (parts[0] === "embed" && parts[1]) return `https://www.youtube.com/embed/${parts[1]}`;
      if (parts[0] === "shorts" && parts[1]) return `https://www.youtube.com/embed/${parts[1]}`;
      if (parts[0] === "live" && parts[1]) return `https://www.youtube.com/embed/${parts[1]}`;
    }
    if (host === "vimeo.com" || host === "player.vimeo.com") {
      const id = u.pathname.split("/").filter(Boolean).pop();
      return id && /^\d+$/.test(id) ? `https://player.vimeo.com/video/${id}` : null;
    }
    if (host === "dailymotion.com" || host === "www.dailymotion.com") {
      const id = u.pathname.split("/").filter(Boolean).pop()?.replace(/^video-/, "");
      return id ? `https://www.dailymotion.com/embed/video/${id}` : null;
    }
    // Direct mp4/webm — return original for <video>
    if (/\.(mp4|webm|ogg)(\?|$)/i.test(u.pathname)) return url;
    return null;
  } catch {
    return null;
  }
}

export function isDirectVideoFile(src: string) {
  return /\.(mp4|webm|ogg)(\?|$)/i.test(src);
}
