import type { Lang } from "@/lib/language";
import { BRAND } from "@/lib/constants";

/**
 * Host → site profile for dual-domain deployment:
 *   urdu.thepakistantimes.live  → Urdu-only
 *   www.thepakistantimes.live   → English-only
 *
 * Same Next.js app + same Postgres; content filtered by Article.language.
 * Never invents content — only routes/filters what already exists in DB.
 */

export type SiteHostProfile = {
  /** Request hostname without port */
  host: string;
  /** Content language for this host */
  lang: Lang;
  /** If true, do not allow switching language on this host */
  locked: boolean;
  /** Canonical public base URL for SEO (no trailing slash) */
  siteUrl: string;
  brandName: string;
  ogLocale: string;
  htmlLang: string;
  /** Sibling site for hreflang / switcher (optional) */
  alternate?: {
    lang: Lang;
    siteUrl: string;
    label: string;
  };
  /** Preview / local / unknown hosts keep bilingual switcher */
  isPreview: boolean;
};

function stripPort(host: string) {
  return host.split(":")[0].trim().toLowerCase();
}

function cleanUrl(value?: string | null) {
  return (value || "").trim().replace(/\/$/, "");
}

export function englishSiteUrl() {
  return (
    cleanUrl(process.env.NEXT_PUBLIC_ENGLISH_SITE_URL) ||
    cleanUrl(process.env.NEXT_PUBLIC_SITE_URL_EN) ||
    "https://www.thepakistantimes.live"
  );
}

export function urduSiteUrl() {
  return (
    cleanUrl(process.env.NEXT_PUBLIC_URDU_SITE_URL) ||
    cleanUrl(process.env.NEXT_PUBLIC_SITE_URL_UR) ||
    "https://urdu.thepakistantimes.live"
  );
}

export function fallbackSiteUrl() {
  return (
    cleanUrl(process.env.NEXT_PUBLIC_SITE_URL) ||
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "") ||
    "http://127.0.0.1:4355"
  );
}

function isUrduHost(host: string) {
  return (
    host === "urdu.thepakistantimes.live" ||
    host.startsWith("urdu.") ||
    Boolean(process.env.URDU_HOSTS?.split(",").map((h) => h.trim().toLowerCase()).includes(host))
  );
}

function isEnglishHost(host: string) {
  if (isUrduHost(host)) return false;
  return (
    host === "www.thepakistantimes.live" ||
    host === "thepakistantimes.live" ||
    Boolean(process.env.ENGLISH_HOSTS?.split(",").map((h) => h.trim().toLowerCase()).includes(host))
  );
}

/**
 * Resolve which public site this Host belongs to.
 * Preview / localhost stay bilingual (unlocked) so existing workflows keep working.
 */
export function resolveHostProfile(rawHost?: string | null): SiteHostProfile {
  const host = stripPort(rawHost || "");

  if (host && isUrduHost(host)) {
    return {
      host,
      lang: "ur",
      locked: true,
      siteUrl: urduSiteUrl(),
      brandName: BRAND.ur,
      ogLocale: "ur_PK",
      htmlLang: "ur",
      alternate: {
        lang: "en",
        siteUrl: englishSiteUrl(),
        label: "English",
      },
      isPreview: false,
    };
  }

  if (host && isEnglishHost(host)) {
    return {
      host,
      lang: "en",
      locked: true,
      siteUrl: englishSiteUrl(),
      brandName: BRAND.en,
      ogLocale: "en_US",
      htmlLang: "en",
      alternate: {
        lang: "ur",
        siteUrl: urduSiteUrl(),
        label: "اردو",
      },
      isPreview: false,
    };
  }

  // Preview / local / unknown — bilingual CMS preview (default Urdu, switcher on)
  const base = fallbackSiteUrl();
  return {
    host: host || "localhost",
    lang: "ur",
    locked: false,
    siteUrl: base,
    brandName: BRAND.ur,
    ogLocale: "ur_PK",
    htmlLang: "ur",
    alternate: {
      lang: "en",
      siteUrl: englishSiteUrl(),
      label: "English",
    },
    isPreview: true,
  };
}

export function profileFromHeaders(get: (name: string) => string | null) {
  const fromHeader = get("x-site-host") || get("x-forwarded-host") || get("host");
  const lockedHeader = get("x-lang-locked");
  const profile = resolveHostProfile(fromHeader);
  if (lockedHeader === "0") {
    return { ...profile, locked: false };
  }
  if (lockedHeader === "1") {
    return { ...profile, locked: true };
  }
  return profile;
}
