/**
 * Turn plain text (or light HTML) into safe paragraph HTML for article body.
 * Markdown-lite headings: lines starting with ## become <h2>, # become <h3>.
 * No separate mandatory H2 field — writers use headings inside the body.
 */
export function toArticleHtml(raw?: string | null): string {
  const text = (raw || "").trim();
  if (!text) return "";
  const cleaned = stripOversizedDataUris(text);
  if (/<[a-z][\s\S]*>/i.test(cleaned)) return cleaned;
  return cleaned
    .split(/\n{2,}/)
    .map((block) => block.trim())
    .filter(Boolean)
    .map((block) => {
      const lines = block.split("\n").map((l) => l.trim());
      if (lines.length === 1) {
        const h2 = lines[0].match(/^##\s+(.+)$/);
        if (h2) return `<h2>${escapeHtml(h2[1])}</h2>`;
        const h3 = lines[0].match(/^#\s+(.+)$/);
        if (h3) return `<h3>${escapeHtml(h3[1])}</h3>`;
      }
      const withBreaks = lines
        .map((line) => {
          const h2 = line.match(/^##\s+(.+)$/);
          if (h2) return `</p><h2>${escapeHtml(h2[1])}</h2><p>`;
          const h3 = line.match(/^#\s+(.+)$/);
          if (h3) return `</p><h3>${escapeHtml(h3[1])}</h3><p>`;
          return escapeHtml(line);
        })
        .join("<br/>");
      return `<p>${withBreaks}</p>`.replace(/<p><\/p>/g, "");
    })
    .join("");
}

function escapeHtml(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/**
 * Remove oversized inline data:image URIs that explode page weight.
 * Keep small icons (≤48KB); larger embeds must use Media library URLs.
 */
export function stripOversizedDataUris(html: string, maxBytes = 48_000): string {
  if (!html || !html.includes("data:image")) return html;
  return html.replace(
    /(?:src\s*=\s*["']|url\()\s*(data:image\/[a-zA-Z0-9+.-]+;base64,[A-Za-z0-9+/=\s]+)(?:["']|\))/gi,
    (full, dataUri: string) => {
      const compact = dataUri.replace(/\s+/g, "");
      // base64 ≈ 4/3 of binary size
      const approxBytes = Math.floor((compact.length - compact.indexOf(",") - 1) * 0.75);
      if (approxBytes <= maxBytes) return full;
      if (/src\s*=/i.test(full)) {
        return 'src="" data-stripped-inline-image="1" alt="Image removed — use Media library URL"';
      }
      return 'url("")';
    },
  );
}

/** Reject oversized data: URLs for ogImage / featured fields (use http(s) media URLs). */
export function sanitizePublicImageUrl(url?: string | null, maxChars = 2000): string | null {
  if (!url?.trim()) return null;
  const v = url.trim();
  if (v.startsWith("data:image") && v.length > maxChars) return null;
  return v;
}

/** Strip tags for SEO / plain excerpts. */
export function stripTags(html?: string | null) {
  return (html || "")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}
