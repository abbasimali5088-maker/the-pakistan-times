/** Convert empty / whitespace-only strings to null for Prisma FK safety. */
export function nullIfEmpty(value: unknown): string | null {
  if (value === undefined || value === null) return null;
  const s = String(value).trim();
  return s.length ? s : null;
}

/** Keep only id-looking tokens (cuid/uuid/hex) so free-text tags never hit FK errors. */
export function filterValidIds(ids: unknown): string[] {
  if (!Array.isArray(ids)) return [];
  const out: string[] = [];
  for (const raw of ids) {
    const id = nullIfEmpty(raw);
    if (!id) continue;
    // Prisma cuid() ~25 chars starting with c; also allow uuid-like
    if (/^[a-z0-9_-]{8,64}$/i.test(id) && !/[\s,]/.test(id)) out.push(id);
  }
  return [...new Set(out)];
}
