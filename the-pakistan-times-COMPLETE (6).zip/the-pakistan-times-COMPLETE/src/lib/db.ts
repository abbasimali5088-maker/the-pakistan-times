import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as {
  prisma?: PrismaClient;
};

/**
 * Prisma Postgres (db.prisma.io) has a tiny connection budget.
 * Every Vercel serverless isolate must use at most ONE connection.
 */
function datasourceUrl() {
  const raw =
    process.env.DATABASE_URL?.trim() ||
    process.env.PRISMA_DATABASE_URL?.trim() ||
    process.env.POSTGRES_URL?.trim();
  if (!raw) return undefined;
  try {
    const url = new URL(raw);
    url.searchParams.set("connection_limit", "1");
    url.searchParams.set("pool_timeout", "10");
    url.searchParams.set("connect_timeout", "8");
    url.searchParams.set("socket_timeout", "10");
    return url.toString();
  } catch {
    const join = raw.includes("?") ? "&" : "?";
    return `${raw}${join}connection_limit=1&pool_timeout=10&connect_timeout=8`;
  }
}

function createPrismaClient() {
  const url = datasourceUrl();
  return new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
    ...(url ? { datasources: { db: { url } } } : {}),
  });
}

export const prisma = globalForPrisma.prisma ?? createPrismaClient();
globalForPrisma.prisma = prisma;

/** True when Prisma/Postgres is out of connections or unreachable. */
export function isDbCapacityError(err: unknown) {
  const msg = err instanceof Error ? err.message : String(err || "");
  return (
    /too many connections/i.test(msg) ||
    /P2037/i.test(msg) ||
    /Can't reach database/i.test(msg) ||
    /PrismaClientInitializationError/i.test(msg) ||
    /Connection terminated/i.test(msg) ||
    /remaining connection slots/i.test(msg)
  );
}
