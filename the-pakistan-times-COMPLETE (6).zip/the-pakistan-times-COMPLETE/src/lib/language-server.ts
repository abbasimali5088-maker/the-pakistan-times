import { cookies, headers } from "next/headers";
import { isLang, LANG_COOKIE, normalizeLang, type Lang } from "./language";
import { resolveHostProfile } from "./site-host";

export async function getRequestLang(searchParams?: {
  lang?: string | string[];
}): Promise<Lang> {
  const h = await headers();
  const locked = h.get("x-lang-locked") === "1";
  const headerLang = h.get("x-lang");

  // Locked public hosts (urdu.* / www.*) always use host language.
  if (locked && isLang(headerLang)) {
    return headerLang;
  }

  const fromQuery = Array.isArray(searchParams?.lang)
    ? searchParams?.lang[0]
    : searchParams?.lang;
  if (isLang(fromQuery)) return fromQuery;

  if (isLang(headerLang)) return headerLang;

  const jar = await cookies();
  return normalizeLang(jar.get(LANG_COOKIE)?.value);
}

/** Host profile for the current request (SEO base URL, lock, brand). */
export async function getRequestHostProfile() {
  const h = await headers();
  const host =
    h.get("x-site-host") || h.get("x-forwarded-host") || h.get("host") || "";
  const profile = resolveHostProfile(host);
  if (h.get("x-lang-locked") === "1") return { ...profile, locked: true };
  if (h.get("x-lang-locked") === "0") return { ...profile, locked: false };
  return profile;
}
