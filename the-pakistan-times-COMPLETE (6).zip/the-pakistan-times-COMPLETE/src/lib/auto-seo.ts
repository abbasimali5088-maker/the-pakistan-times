import { makeSlug } from "@/lib/slug";

/** Soft SEO title length (Google typically shows ~50–60 Latin chars; Urdu is glyph-heavier). */
const SEO_TITLE_MAX_EN = 60;
const SEO_TITLE_MAX_UR = 70;
const META_DESC_MAX = 160;

export function truncateSeo(text: string, max: number): string {
  const t = (text || "").trim().replace(/\s+/g, " ");
  if (!t) return "";
  if (t.length <= max) return t;
  const cut = t.slice(0, max - 1);
  const soft = cut.replace(/\s+\S*$/, "");
  return `${(soft.length > max * 0.5 ? soft : cut).trim()}…`;
}

export function autoSeoTitle(title: string, lang: "en" | "ur"): string {
  return truncateSeo(title, lang === "ur" ? SEO_TITLE_MAX_UR : SEO_TITLE_MAX_EN);
}

export function autoMetaDescription(excerptOrMeta: string): string {
  return truncateSeo(excerptOrMeta, META_DESC_MAX);
}

export function autoSlugFromTitle(title: string, fallback = "article"): string {
  return makeSlug(title, fallback);
}

export type AutoSeoInput = {
  lang: "en" | "ur";
  title: string;
  excerpt?: string | null;
  metaDescription?: string | null;
  seoTitle?: string | null;
  ogTitle?: string | null;
  ogDescription?: string | null;
  imageUrl?: string | null;
  ogImage?: string | null;
  slug?: string | null;
  canonicalUrl?: string | null;
  robotsMeta?: string | null;
};

export type AutoSeoResult = {
  seoTitle: string;
  seoDescription: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string | null;
  slug: string;
  canonicalUrl: string | null;
  robotsMeta: string;
};

/**
 * Fill SEO/OG from title + excerpt when fields are empty.
 * Manual overrides (non-empty) always win.
 */
export function resolveAutoSeo(input: AutoSeoInput): AutoSeoResult {
  const title = (input.title || "").trim();
  const excerpt = (input.excerpt || "").trim();
  const metaDesc = (input.metaDescription || "").trim() || excerpt;
  const seoTitle = (input.seoTitle || "").trim() || autoSeoTitle(title, input.lang);
  const seoDescription = autoMetaDescription(metaDesc);
  const ogTitle = (input.ogTitle || "").trim() || seoTitle || title;
  const ogDescription =
    (input.ogDescription || "").trim() || seoDescription || excerpt;
  const ogImage = (input.ogImage || "").trim() || (input.imageUrl || "").trim() || null;
  const slug =
    (input.slug || "").trim() ||
    autoSlugFromTitle(title, input.lang === "ur" ? "urdu" : "article");
  const canonicalUrl = (input.canonicalUrl || "").trim() || null;
  const robotsMeta = (input.robotsMeta || "").trim() || "index,follow";

  return {
    seoTitle,
    seoDescription,
    ogTitle,
    ogDescription,
    ogImage,
    slug,
    canonicalUrl,
    robotsMeta,
  };
}
