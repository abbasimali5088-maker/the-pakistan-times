/** Lightweight UA / referrer helpers for Views analytics (no extra deps). */

export type ParsedUa = {
  browser: string;
  os: string;
};

const LANG_RE = /^[a-z]{2}(-[A-Za-z0-9]+)?$/i;

export function looksLikeUserAgent(value: string | null | undefined): boolean {
  if (!value) return false;
  return /Mozilla|AppleWebKit|Chrome|Safari|Firefox|Edg|Android|iPhone|Windows NT|Macintosh|Linux/i.test(
    value,
  );
}

export function parseUserAgent(ua: string | null | undefined): ParsedUa {
  const s = (ua || "").trim();
  if (!s) return { browser: "Other", os: "Other" };

  let os = "Other";
  if (/android/i.test(s)) os = "Android";
  else if (/iPhone|iPad|iPod/i.test(s)) os = "iPhone";
  else if (/Macintosh|Mac OS X/i.test(s)) os = "Macintosh";
  else if (/Windows NT|Windows/i.test(s)) os = "Windows";
  else if (/CrOS/i.test(s)) os = "Chrome OS";
  else if (/Linux/i.test(s)) os = "Linux";

  let browser = "Other";
  if (/Edg\//i.test(s)) browser = "Edge";
  else if (/OPR\/|Opera/i.test(s)) browser = "Opera";
  else if (/CriOS/i.test(s)) browser = "CriOS";
  else if (/FxiOS/i.test(s)) browser = "Firefox";
  else if (/Firefox\//i.test(s)) browser = "Firefox";
  else if (/Chrome\//i.test(s) && !/Chromium/i.test(s)) browser = "Chrome";
  else if (/Safari\//i.test(s) && !/Chrome\//i.test(s)) browser = "Safari";
  else if (/HeadlessChrome/i.test(s)) browser = "Chrome";

  return { browser, os };
}

/** Normalize stored browser/device rows (legacy: browser=language, device=UA). */
export function resolveBrowserOs(row: {
  browser?: string | null;
  device?: string | null;
}): ParsedUa {
  const browserRaw = (row.browser || "").trim();
  const deviceRaw = (row.device || "").trim();

  if (looksLikeUserAgent(deviceRaw)) {
    const parsed = parseUserAgent(deviceRaw);
    // Prefer explicit short browser label if already stored correctly
    if (browserRaw && !LANG_RE.test(browserRaw) && !looksLikeUserAgent(browserRaw)) {
      return { browser: browserRaw, os: parsed.os };
    }
    return parsed;
  }

  if (browserRaw && !LANG_RE.test(browserRaw) && !looksLikeUserAgent(browserRaw)) {
    return {
      browser: browserRaw,
      os: deviceRaw && !looksLikeUserAgent(deviceRaw) ? deviceRaw : "Other",
    };
  }

  if (looksLikeUserAgent(browserRaw)) return parseUserAgent(browserRaw);
  return { browser: "Other", os: deviceRaw || "Other" };
}

export function referrerHost(referrer: string | null | undefined): string {
  const raw = (referrer || "").trim();
  if (!raw) return "Direct / Other";
  try {
    const u = new URL(raw);
    return u.hostname.replace(/^www\./, "") || "Other";
  } catch {
    return raw.slice(0, 80) || "Other";
  }
}

/** Named traffic channels for Views (always shown, even at 0). */
export const TRAFFIC_CHANNELS = [
  "Google",
  "Facebook",
  "Instagram",
  "WhatsApp",
  "Blogger",
  "YouTube",
  "X / Twitter",
  "TikTok",
  "Backend / Admin",
  "Direct / Other",
] as const;

export type TrafficChannel = (typeof TRAFFIC_CHANNELS)[number];

/**
 * Map a referrer URL to a traffic channel.
 * Any hit (even one view) from Google/FB/etc. shows under that channel.
 */
export function referrerChannel(referrer: string | null | undefined): TrafficChannel {
  const raw = (referrer || "").trim();
  if (!raw) return "Direct / Other";

  let host = "";
  let path = "";
  try {
    const u = new URL(raw.startsWith("http") ? raw : `https://${raw}`);
    host = u.hostname.replace(/^www\./, "").toLowerCase();
    path = (u.pathname || "").toLowerCase();
  } catch {
    host = raw.toLowerCase().slice(0, 120);
  }

  const hay = `${host}${path}`;

  if (
    /google\./.test(host) ||
    host === "google.com" ||
    /googleusercontent|gstatic|googleapis|googlesyndication/.test(host)
  ) {
    return "Google";
  }
  if (/facebook\.|fb\.com|fb\.me|m\.facebook|l\.facebook/.test(host)) return "Facebook";
  if (/instagram\.|instagr\.am/.test(host)) return "Instagram";
  if (/whatsapp\.|wa\.me|api\.whatsapp|chat\.whatsapp/.test(host)) return "WhatsApp";
  if (/blogger\.|blogspot\./.test(host)) return "Blogger";
  if (/youtube\.|youtu\.be|youtubekids\./.test(host)) return "YouTube";
  if (/twitter\.|x\.com|t\.co/.test(host)) return "X / Twitter";
  if (/tiktok\./.test(host)) return "TikTok";
  if (
    /\/admin(\/|$)/.test(path) ||
    /admin\./.test(host) ||
    hay.includes("/admin/") ||
    hay.includes("admin@")
  ) {
    return "Backend / Admin";
  }

  return "Direct / Other";
}

/** Seed channel map with zeros so UI always lists Google/FB/… even before traffic. */
export function emptyChannelCounts(): Map<string, number> {
  const map = new Map<string, number>();
  for (const name of TRAFFIC_CHANNELS) map.set(name, 0);
  return map;
}

export function referrerUrlKey(referrer: string | null | undefined): string {
  const raw = (referrer || "").trim();
  if (!raw) return "Other";
  try {
    const u = new URL(raw);
    const path = u.pathname === "/" ? "" : u.pathname.slice(0, 40);
    return `${u.protocol}//${u.hostname}${path}`;
  } catch {
    return raw.slice(0, 100);
  }
}

export function countryLabel(code: string | null | undefined): string {
  const c = (code || "").trim().toUpperCase();
  if (!c || c === "XX" || c === "T1") return "Other";
  const names: Record<string, string> = {
    PK: "Pakistan",
    US: "United States",
    GB: "United Kingdom",
    CA: "Canada",
    AE: "United Arab Emirates",
    SA: "Saudi Arabia",
    IN: "India",
    DE: "Germany",
    FR: "France",
    AU: "Australia",
    CN: "China",
    SG: "Singapore",
    BR: "Brazil",
    HK: "Hong Kong",
    TR: "Turkey",
    QA: "Qatar",
    KW: "Kuwait",
    MY: "Malaysia",
    BD: "Bangladesh",
    NL: "Netherlands",
  };
  return names[c] || c;
}

export type NamedCount = { name: string; count: number; color?: string };

const PALETTE = [
  "#1DB954",
  "#159A45",
  "#34D399",
  "#6EE7B7",
  "#A7F3D0",
  "#047857",
  "#10B981",
  "#059669",
  "#86EFAC",
  "#BBF7D0",
];

export function topCounts(
  map: Map<string, number>,
  limit = 10,
): NamedCount[] {
  const sorted = [...map.entries()].sort((a, b) => b[1] - a[1]);
  const top = sorted.slice(0, limit);
  const rest = sorted.slice(limit);
  const other = rest.reduce((s, [, n]) => s + n, 0);
  const rows = top.map(([name, count], i) => ({
    name,
    count,
    color: PALETTE[i % PALETTE.length],
  }));
  if (other > 0) {
    rows.push({ name: "Other", count: other, color: "#E0E0E0" });
  }
  return rows;
}

/** Keep fixed channel order; include zeros. */
export function channelCounts(map: Map<string, number>): NamedCount[] {
  return TRAFFIC_CHANNELS.map((name, i) => ({
    name,
    count: map.get(name) || 0,
    color: PALETTE[i % PALETTE.length],
  }));
}

export function dayKey(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export function startOfDay(d: Date): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}
