import { prisma } from "./db";
import { stripOversizedDataUris, sanitizePublicImageUrl } from "./article-html";

const mediaSelect = {
  id: true,
  url: true,
  alt: true,
  caption: true,
  credit: true,
  width: true,
  height: true,
  language: true,
} as const;

export const articlePublicInclude = {
  category: true,
  categoryUr: true,
  author: true,
  featuredImage: { select: mediaSelect },
  featuredImageUr: { select: mediaSelect },
  tags: { include: { tag: true } },
  coAuthors: { include: { author: true } },
} as const;

export async function getSettingMap(siteId?: string | null) {
  try {
    const rows = await prisma.setting.findMany({
      where: siteId ? { siteId } : undefined,
    });
    const map: Record<string, Record<string, string>> = {};
    for (const row of rows) {
      map[row.group] ||= {};
      map[row.group][row.key] = row.value;
    }
    return map;
  } catch {
    return {};
  }
}

export async function getDefaultSite() {
  return (
    (await prisma.site.findFirst({ where: { isDefault: true } })) ||
    (await prisma.site.findFirst())
  );
}

type MediaLike = {
  id: string;
  url: string;
  alt: string | null;
  caption?: string | null;
  credit?: string | null;
  width: number | null;
  height: number | null;
  language?: string | null;
} | null;

function mapImage(img: MediaLike) {
  if (!img?.url?.trim()) return null;
  const url = img.url.trim();
  // Never replace a real article photo with the site logo.
  // Oversized data: URLs are unusable on the public site — treat as missing
  // so the UI shows a neutral placeholder (not /icon-512.png).
  if (url.startsWith("data:image") && url.length > 48_000) {
    return null;
  }
  return {
    id: img.id,
    url,
    alt: img.alt,
    width: img.width,
    height: img.height,
    language: img.language || null,
  };
}

function safeOg(raw: string | null | undefined, fallback: string | null | undefined) {
  const cleaned = sanitizePublicImageUrl(raw || null);
  if (cleaned) return cleaned;
  return sanitizePublicImageUrl(fallback || null);
}

export function serializeArticle(
  article: {
    id: string;
    title: string;
    titleUr: string | null;
    slug: string;
    slugUr?: string | null;
    subtitle: string | null;
    excerpt: string | null;
    excerptUr: string | null;
    body: string;
    bodyUr: string | null;
    toolTitle?: string | null;
    toolCode?: string | null;
    toolTitleUr?: string | null;
    toolCodeUr?: string | null;
    language: string;
    status: string;
    priority: string;
    liveExpiresAt?: Date | null;
    location: string | null;
    imageCaption: string | null;
    imageCredit: string | null;
    imageCaptionUr?: string | null;
    imageCreditUr?: string | null;
    videoUrl?: string | null;
    videoUrlUr?: string | null;
    featuredImageId?: string | null;
    featuredImageUrId?: string | null;
    categoryId?: string | null;
    categoryUrId?: string | null;
    publishAt: Date | null;
    publishedAt: Date | null;
    updatedAt: Date;
    viewCount: number;
    isFeatured: boolean;
    isBreaking: boolean;
    seoTitle: string | null;
    seoDescription: string | null;
    seoTitleUr?: string | null;
    seoDescriptionUr?: string | null;
    focusKeyword: string | null;
    focusKeywordUr?: string | null;
    searchKeywords?: string | null;
    searchKeywordsUr?: string | null;
    canonicalUrl: string | null;
    robotsMeta: string | null;
    ogTitle: string | null;
    ogDescription: string | null;
    ogTitleUr?: string | null;
    ogDescriptionUr?: string | null;
    ogImage: string | null;
    ogImageUr?: string | null;
    schemaType: string;
    category?: { id: string; name: string; nameUr: string | null; slug: string; language?: string | null } | null;
    categoryUr?: { id: string; name: string; nameUr: string | null; slug: string; language?: string | null } | null;
    author?: { id: string; name: string; slug: string; photoUrl: string | null; bio: string | null; position: string | null } | null;
    featuredImage?: MediaLike;
    featuredImageUr?: MediaLike;
    tags?: { locale?: string; tag: { id: string; name: string; nameUr: string | null; slug: string; language?: string | null } }[];
    coAuthors?: { author: { id: string; name: string; slug: string } }[];
  },
  opts?: { lite?: boolean },
) {
  const lite = Boolean(opts?.lite);
  const tagsEn = (article.tags || []).filter((t) => (t.locale || "en") === "en" || t.tag.language === "en");
  const tagsUr = (article.tags || []).filter((t) => t.locale === "ur" || t.tag.language === "ur");
  // If legacy rows have no locale split, expose all under EN and UR-named under UR
  const enTags =
    tagsEn.length > 0
      ? tagsEn
      : (article.tags || []).filter((t) => t.tag.language !== "ur");
  const urTags =
    tagsUr.length > 0
      ? tagsUr
      : (article.tags || []).filter((t) => Boolean(t.tag.nameUr) || t.tag.language === "ur");

  return {
    id: article.id,
    title: article.title,
    titleUr: article.titleUr || null,
    titleEn: article.title,
    slug: article.slug,
    slugUr: article.slugUr || null,
    subtitle: article.subtitle,
    excerpt: article.excerpt,
    excerptUr: article.excerptUr || null,
    excerptEn: article.excerpt,
    body: lite ? "" : stripOversizedDataUris(article.body || ""),
    bodyUr: lite ? null : article.bodyUr ? stripOversizedDataUris(article.bodyUr) : null,
    bodyEn: lite ? "" : stripOversizedDataUris(article.body || ""),
    // Dedicated interactive tools — never mixed into article body
    toolTitle: article.toolTitle || null,
    toolCode: lite ? null : article.toolCode || null,
    toolTitleUr: article.toolTitleUr || null,
    toolCodeUr: lite ? null : article.toolCodeUr || null,
    language: article.language,
    status: article.status,
    priority: article.priority,
    liveExpiresAt: article.liveExpiresAt || null,
    location: article.location,
    imageCaption: article.imageCaption || article.featuredImage?.caption || null,
    imageCredit: article.imageCredit || article.featuredImage?.credit || null,
    imageCaptionUr: article.imageCaptionUr || article.featuredImageUr?.caption || null,
    imageCreditUr: article.imageCreditUr || article.featuredImageUr?.credit || null,
    videoUrl: article.videoUrl || null,
    videoUrlUr: article.videoUrlUr || null,
    featuredImageId: article.featuredImageId || article.featuredImage?.id || null,
    featuredImageUrId: article.featuredImageUrId || article.featuredImageUr?.id || null,
    categoryId: article.categoryId || article.category?.id || null,
    categoryUrId: article.categoryUrId || article.categoryUr?.id || null,
    searchKeywords: article.searchKeywords || null,
    searchKeywordsUr: article.searchKeywordsUr || null,
    publishAt: article.publishAt,
    publishedAt: article.publishedAt,
    updatedAt: article.updatedAt,
    viewCount: article.viewCount,
    isFeatured: article.isFeatured,
    isBreaking: article.isBreaking,
    seo: {
      title: article.seoTitle,
      titleUr: article.seoTitleUr ?? null,
      description: article.seoDescription,
      descriptionUr: article.seoDescriptionUr ?? null,
      focusKeyword: article.focusKeyword,
      focusKeywordUr: article.focusKeywordUr ?? null,
      searchKeywords: article.searchKeywords ?? null,
      searchKeywordsUr: article.searchKeywordsUr ?? null,
      canonical: article.canonicalUrl,
      robots: article.robotsMeta,
      ogTitle: article.ogTitle,
      ogTitleUr: article.ogTitleUr ?? null,
      ogDescription: article.ogDescription,
      ogDescriptionUr: article.ogDescriptionUr ?? null,
      ogImage: safeOg(article.ogImage, article.featuredImage?.url),
      ogImageUr: safeOg(article.ogImageUr, article.featuredImageUr?.url),
      schemaType: article.schemaType,
    },
    category: article.category
      ? {
          id: article.category.id,
          name: article.category.name,
          nameUr: article.category.nameUr || null,
          nameEn: article.category.name,
          slug: article.category.slug,
          language: article.category.language || "en",
        }
      : null,
    categoryUr: article.categoryUr
      ? {
          id: article.categoryUr.id,
          name: article.categoryUr.name,
          nameUr: article.categoryUr.nameUr || article.categoryUr.name,
          nameEn: article.categoryUr.name,
          slug: article.categoryUr.slug,
          language: article.categoryUr.language || "ur",
        }
      : null,
    author: article.author
      ? {
          id: article.author.id,
          name: article.author.name,
          slug: article.author.slug,
          photoUrl: article.author.photoUrl,
          bio: lite ? null : article.author.bio,
          position: article.author.position,
        }
      : null,
    image: mapImage(article.featuredImage || null),
    imageUr: mapImage(article.featuredImageUr || null),
    tags: enTags.map((t) => ({
      id: t.tag.id,
      name: t.tag.name,
      nameUr: t.tag.nameUr || null,
      slug: t.tag.slug,
      language: t.tag.language || "en",
      locale: "en" as const,
    })),
    tagsUr: urTags.map((t) => ({
      id: t.tag.id,
      name: t.tag.name,
      nameUr: t.tag.nameUr || null,
      slug: t.tag.slug,
      language: t.tag.language || "ur",
      locale: "ur" as const,
    })),
    coAuthors: (article.coAuthors || []).map((c) => ({
      id: c.author.id,
      name: c.author.name,
      slug: c.author.slug,
    })),
    href: `/${article.slug}`,
  };
}
