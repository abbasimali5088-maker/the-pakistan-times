import { prisma } from "./db";
import { articlePublicInclude, serializeArticle } from "./content";
import type {
  AdUnit,
  BreakingItem,
  GalleryItem,
  HomepagePayload,
  LiveStory,
  MenuPayload,
  Paginated,
  PublicArticle,
  PublicAuthor,
  PublicCategory,
  PublicTag,
  StaticPage,
  VideoItem,
} from "./public-types";
import { fallbackSiteUrl, resolveHostProfile } from "./site-host";
import type { Lang } from "./language";
import { liveStoryMatchesLang } from "./language";
import { headers } from "next/headers";

type ApiEnvelope<T> = {
  success?: boolean;
  data?: T;
  error?: string;
};

/** Public/canonical site URL for this request host (SEO, OG, absolute links). */
export function siteBaseUrl() {
  // Sync fallback when headers() is unavailable (edge/build)
  return fallbackSiteUrl();
}

export async function siteBaseUrlAsync() {
  try {
    const h = await headers();
    const fromHeader = h.get("x-site-url");
    if (fromHeader) return fromHeader.replace(/\/$/, "");
    const host = h.get("x-site-host") || h.get("x-forwarded-host") || h.get("host");
    return resolveHostProfile(host).siteUrl;
  } catch {
    return fallbackSiteUrl();
  }
}

/**
 * Base URL for rare HTTP fallbacks. Prefer this deployment's VERCEL_URL
 * so a mis-set NEXT_PUBLIC_SITE_URL cannot break reads.
 */
function internalBaseUrl() {
  if (process.env.VERCEL_URL) {
    return `https://${process.env.VERCEL_URL}`.replace(/\/$/, "");
  }
  return siteBaseUrl();
}

function apiBase() {
  const base = process.env.NEXT_PUBLIC_API_BASE || "/api";
  if (base.startsWith("http")) return base.replace(/\/$/, "");
  return `${internalBaseUrl()}${base.startsWith("/") ? base : `/${base}`}`;
}

export function absoluteUrl(path = "/") {
  if (path.startsWith("http")) return path;
  return `${siteBaseUrl()}${path.startsWith("/") ? path : `/${path}`}`;
}

export async function absoluteUrlAsync(path = "/") {
  if (path.startsWith("http")) return path;
  const base = await siteBaseUrlAsync();
  return `${base}${path.startsWith("/") ? path : `/${path}`}`;
}

async function publicFetch<T>(
  path: string,
  init?: RequestInit & { fallback?: T },
): Promise<T> {
  const fallback = init?.fallback as T;
  const { fallback: _ignored, ...rest } = init || {};
  void _ignored;
  const url = path.startsWith("http")
    ? path
    : `${apiBase()}${path.startsWith("/") ? path : `/${path}`}`;

  try {
    const res = await fetch(url, {
      ...rest,
      headers: {
        Accept: "application/json",
        ...(rest.headers || {}),
      },
      cache: rest.cache || "no-store",
    });

    if (!res.ok) {
      if (fallback !== undefined) return fallback;
      throw new Error(`API ${res.status} for ${url}`);
    }

    const json = (await res.json()) as ApiEnvelope<T> | T;
    if (json && typeof json === "object" && "success" in (json as object)) {
      const env = json as ApiEnvelope<T>;
      if (!env.success) {
        if (fallback !== undefined) return fallback;
        throw new Error(env.error || "API error");
      }
      return (env.data as T) ?? fallback;
    }
    return json as T;
  } catch {
    if (fallback !== undefined) return fallback;
    throw new Error(`Failed to fetch ${url}`);
  }
}

function qs(params: Record<string, string | number | undefined | null>) {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === "") continue;
    sp.set(k, String(v));
  }
  const s = sp.toString();
  return s ? `?${s}` : "";
}

const emptyPage = <T,>(): Paginated<T> => ({
  items: [],
  page: 1,
  pageSize: 20,
  total: 0,
  totalPages: 0,
});

function publishedWhere() {
  return {
    deletedAt: null,
    status: "published",
    OR: [{ publishAt: null }, { publishAt: { lte: new Date() } }],
  } as const;
}

function mapCategory(c: {
  id: string;
  name: string;
  nameUr: string | null;
  slug: string;
  parentId?: string | null;
  description?: string | null;
  language?: string | null;
}): PublicCategory & { parentId?: string | null; language?: string | null } {
  // Keep English `name` and Urdu `nameUr` totally separate — no cross-fill.
  return {
    id: c.id,
    name: c.name,
    nameUr: c.nameUr || null,
    nameEn: c.name,
    slug: c.slug,
    parentId: c.parentId ?? null,
    description: c.description ?? null,
    language: c.language || "en",
  };
}

export async function getArticles(params: {
  language?: string;
  category?: string;
  tag?: string;
  authorId?: string;
  page?: number;
  pageSize?: number;
  q?: string;
  priority?: string;
} = {}) {
  try {
    const page = Math.max(1, Number(params.page) || 1);
    const pageSize = Math.min(50, Math.max(1, Number(params.pageSize) || 20));
    const skip = (page - 1) * pageSize;
    const where: Record<string, unknown> = { ...publishedWhere() };
    const andClauses: Record<string, unknown>[] = [];
    if (params.category) {
      andClauses.push({
        OR: [
          { category: { slug: params.category } },
          { categoryUr: { slug: params.category } },
        ],
      });
    }
    if (params.language === "en" || params.language === "ur") {
      where.language = params.language;
    }
    if (params.priority) where.priority = params.priority;
    if (params.authorId) where.authorId = params.authorId;
    if (params.tag) where.tags = { some: { tag: { slug: params.tag } } };
    if (params.q) {
      andClauses.push({
        OR: [
          { title: { contains: params.q, mode: "insensitive" } },
          { titleUr: { contains: params.q, mode: "insensitive" } },
          { excerpt: { contains: params.q, mode: "insensitive" } },
          { excerptUr: { contains: params.q, mode: "insensitive" } },
          { body: { contains: params.q, mode: "insensitive" } },
          { bodyUr: { contains: params.q, mode: "insensitive" } },
          { slug: { contains: params.q, mode: "insensitive" } },
        ],
      });
    }
    if (andClauses.length) where.AND = andClauses;

    const [total, rows] = await Promise.all([
      prisma.article.count({ where }),
      prisma.article.findMany({
        where,
        include: articlePublicInclude,
        orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
        skip,
        take: pageSize,
      }),
    ]);

    return {
      items: rows.map((row) => serializeArticle(row, { lite: true })) as PublicArticle[],
      page,
      pageSize,
      total,
      totalPages: Math.ceil(total / pageSize),
    };
  } catch {
    return emptyPage<PublicArticle>();
  }
}

export async function getArticle(
  idOrSlug: string,
  opts?: { language?: Lang | string | null },
) {
  try {
    const lang =
      opts?.language === "en" || opts?.language === "ur" ? opts.language : undefined;
    const article = await prisma.article.findFirst({
      where: {
        AND: [
          { OR: [{ id: idOrSlug }, { slug: idOrSlug }, { slugUr: idOrSlug }] },
          { deletedAt: null },
          { status: "published" },
          { OR: [{ publishAt: null }, { publishAt: { lte: new Date() } }] },
          ...(lang ? [{ language: lang }] : []),
        ],
      },
      include: {
        ...articlePublicInclude,
        relationsFrom: {
          include: { toArticle: { include: articlePublicInclude } },
          take: 6,
        },
      },
    });
    if (!article) return null;
    const base = serializeArticle(article) as PublicArticle & {
      relations?: { type: string; article: PublicArticle }[];
    };
    const relations = (article.relationsFrom || [])
      .filter((r) => {
        const t = r.toArticle;
        if (!t || t.deletedAt) return false;
        if (t.status !== "published") return false;
        if (t.publishAt && t.publishAt > new Date()) return false;
        // Keep related articles same language when host is language-locked
        if (lang && t.language && t.language !== lang) return false;
        return true;
      })
      .map((r) => ({
        type: r.relationType,
        article: serializeArticle(r.toArticle) as PublicArticle,
      }));
    if (relations.length) base.relations = relations;
    return base;
  } catch {
    return null;
  }
}

export async function getCategories(params: { language?: string } = {}) {
  try {
    const lang = params.language === "en" || params.language === "ur" ? params.language : undefined;
    const items = await prisma.category.findMany({
      where: {
        status: "active",
        ...(lang ? { language: lang } : {}),
      },
      orderBy: { sortOrder: "asc" },
    });
    // Prefer language-matched rows. If a locale has none yet, fall back to all
    // active categories that have a name for that locale (legacy bilingual rows).
    if (lang && items.length === 0) {
      const all = await prisma.category.findMany({
        where: { status: "active" },
        orderBy: { sortOrder: "asc" },
      });
      return all
        .filter((c) => (lang === "ur" ? Boolean(c.nameUr?.trim()) : Boolean(c.name?.trim())))
        .map(mapCategory);
    }
    return items.map(mapCategory);
  } catch {
    return [];
  }
}

export async function getCategory(slug: string, language?: string) {
  try {
    const lang = language === "en" || language === "ur" ? language : undefined;
    const c = await prisma.category.findFirst({
      where: {
        slug,
        status: "active",
        ...(lang ? { language: lang } : {}),
      },
      orderBy: lang ? undefined : { language: "asc" },
    });
    if (c) return mapCategory(c);
    // Fallback: any language with this slug (legacy hybrid rows)
    const any = await prisma.category.findFirst({
      where: { slug, status: "active" },
    });
    return any ? mapCategory(any) : null;
  } catch {
    return null;
  }
}

export async function getTags(params: { page?: number; q?: string } = {}) {
  try {
    const page = Math.max(1, Number(params.page) || 1);
    const pageSize = 20;
    const skip = (page - 1) * pageSize;
    const where = params.q
      ? {
          OR: [
            { name: { contains: params.q, mode: "insensitive" as const } },
            { slug: { contains: params.q, mode: "insensitive" as const } },
          ],
        }
      : {};
    const [total, rows] = await Promise.all([
      prisma.tag.count({ where }),
      prisma.tag.findMany({ where, orderBy: { name: "asc" }, skip, take: pageSize }),
    ]);
    return {
      items: rows.map((t) => ({
        id: t.id,
        name: t.name,
        nameUr: t.nameUr || null,
        slug: t.slug,
      })) as PublicTag[],
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize),
    };
  } catch {
    return emptyPage<PublicTag>();
  }
}

export async function getTag(slug: string) {
  try {
    const t = await prisma.tag.findFirst({ where: { slug } });
    return t
      ? ({ id: t.id, name: t.name, nameUr: t.nameUr || null, slug: t.slug } as PublicTag)
      : null;
  } catch {
    return null;
  }
}

export async function getAuthors(params: { page?: number } = {}) {
  try {
    const page = Math.max(1, Number(params.page) || 1);
    const pageSize = 20;
    const skip = (page - 1) * pageSize;
    const [total, rows] = await Promise.all([
      prisma.author.count(),
      prisma.author.findMany({
        orderBy: { name: "asc" },
        skip,
        take: pageSize,
      }),
    ]);
    return {
      items: rows.map((a) => ({
        id: a.id,
        name: a.name,
        slug: a.slug,
        photoUrl: a.photoUrl,
        bio: a.bio,
        position: a.position,
      })) as PublicAuthor[],
      page,
      pageSize,
      total,
      totalPages: Math.ceil(total / pageSize),
    };
  } catch {
    return emptyPage<PublicAuthor>();
  }
}

export async function getAuthor(slug: string) {
  try {
    const a = await prisma.author.findFirst({ where: { slug } });
    if (!a) return null;
    return {
      id: a.id,
      name: a.name,
      slug: a.slug,
      photoUrl: a.photoUrl,
      bio: a.bio,
      position: a.position,
    } as PublicAuthor;
  } catch {
    return null;
  }
}

export async function getBreaking(lang?: "en" | "ur") {
  try {
    const now = new Date();
    const items = await prisma.breakingNews.findMany({
      where: {
        status: "active",
        AND: [
          { OR: [{ startAt: null }, { startAt: { lte: now } }] },
          { OR: [{ endAt: null }, { endAt: { gte: now } }] },
        ],
      },
      include: {
        article: { select: { id: true, title: true, slug: true, language: true } },
      },
      orderBy: [{ priority: "desc" }, { createdAt: "desc" }],
      take: 40,
    });
    const mapped = items.map((b) => ({
      id: b.id,
      headline: b.headline,
      headlineUr: b.headlineUr || null,
      headlineEn: b.headline,
      priority: b.priority,
      article: b.article,
      href: b.article?.slug ? `/${b.article.slug}` : undefined,
    })) as BreakingItem[];

    if (lang === "ur") {
      // Urdu frontend: only rows with real Urdu headline text
      return mapped.filter((b) => Boolean((b.headlineUr || "").trim()));
    }
    if (lang === "en") {
      // English frontend: EN-only rows (no Urdu headline filled)
      return mapped.filter(
        (b) =>
          Boolean((b.headlineEn || b.headline || "").trim()) &&
          (b.headlineEn || b.headline) !== "—" &&
          !(b.headlineUr || "").trim(),
      );
    }
    return mapped;
  } catch {
    return [];
  }
}

export async function getMenus(location = "main") {
  try {
    const menu = await prisma.menu.findFirst({
      where: { location, status: "active" },
      include: {
        items: {
          where: { status: "active" },
          orderBy: { sortOrder: "asc" },
        },
      },
    });
    if (!menu) return null;
    return {
      id: menu.id,
      name: menu.name,
      location: menu.location,
      items: menu.items.map((it) => ({
        id: it.id,
        // Canonical English label; Urdu lives in labelUr only.
        label: it.label,
        labelUr: it.labelUr || null,
        labelEn: it.label,
        url: it.url,
        target: it.target,
        parentId: it.parentId,
        sortOrder: it.sortOrder,
      })),
    } as MenuPayload;
  } catch {
    return null;
  }
}

export async function getHomepage(params: { language?: string } = {}) {
  try {
    const now = new Date();
    const lang = params.language === "en" || params.language === "ur" ? params.language : undefined;
    const items = await prisma.homepageBlock.findMany({
      where: {
        isVisible: true,
        AND: [
          { OR: [{ startAt: null }, { startAt: { lte: now } }] },
          { OR: [{ endAt: null }, { endAt: { gte: now } }] },
        ],
      },
      include: { article: { include: articlePublicInclude } },
      orderBy: [{ sectionKey: "asc" }, { sortOrder: "asc" }, { priority: "desc" }],
    });
    const blocks = items
      .map((b) => ({
        id: b.id,
        sectionKey: b.sectionKey,
        title: b.title,
        sortOrder: b.sortOrder,
        priority: b.priority,
        isVisible: b.isVisible,
        configJson: b.configJson,
        article: b.article ? (serializeArticle(b.article) as PublicArticle) : null,
      }))
      .filter((b) => {
        if (!lang || !b.article) return true;
        return (b.article.language || "ur") === lang;
      });
    const sections: Record<string, typeof blocks> = {};
    for (const block of blocks) {
      (sections[block.sectionKey] ||= []).push(block);
    }
    return { blocks, sections } as HomepagePayload;
  } catch {
    return { blocks: [], sections: {} };
  }
}

/** Active live blogs OR articles marked live — for the global LIVE header badge. */
export async function getActiveLiveCount(params: { language?: string } = {}) {
  try {
    const now = new Date();
    await prisma.article.updateMany({
      where: {
        priority: "live",
        liveExpiresAt: { lte: now },
      },
      data: {
        priority: "normal",
        liveExpiresAt: null,
      },
    });
    const lang = params.language === "en" || params.language === "ur" ? params.language : undefined;

    // Prefer language-scoped article LIVE counts. Legacy LiveStory has no language
    // column — when lang is set, only include stories that match that locale script.
    const articleCount = await prisma.article.count({
      where: {
        deletedAt: null,
        status: "published",
        priority: "live",
        ...(lang ? { language: lang } : {}),
        OR: [{ publishAt: null }, { publishAt: { lte: now } }],
        AND: [
          {
            OR: [{ liveExpiresAt: null }, { liveExpiresAt: { gt: now } }],
          },
        ],
      },
    });

    const storyRows = await prisma.liveStory.findMany({
      where: { status: { in: ["live", "published", "active"] } },
      select: { title: true, titleUr: true },
    });
    const storyCount = lang
      ? storyRows.filter((s) => liveStoryMatchesLang(s, lang)).length
      : storyRows.length;

    return storyCount + articleCount;
  } catch {
    return 0;
  }
}

/**
 * BBC-style LIVE stream: published articles toggled Live in admin,
 * filtered by locale so EN/UR feeds never mix.
 * Expired liveExpiresAt rows are auto-cleared (priority → normal).
 */
export async function getLiveFeed(params: { language?: string; take?: number } = {}) {
  try {
    const now = new Date();
    // Auto-clear expired LIVE articles so the feed never shows stale LIVE.
    await prisma.article.updateMany({
      where: {
        priority: "live",
        liveExpiresAt: { lte: now },
      },
      data: {
        priority: "normal",
        liveExpiresAt: null,
      },
    });

    const take = Math.min(20, Math.max(1, Number(params.take) || 8));
    const lang = params.language === "en" || params.language === "ur" ? params.language : undefined;
    // Never mix: if caller omitted language, return empty (call sites must pass lang).
    if (!lang) return [];

    const rows = await prisma.article.findMany({
      where: {
        deletedAt: null,
        status: "published",
        priority: "live",
        language: lang,
        OR: [{ publishAt: null }, { publishAt: { lte: now } }],
        AND: [
          {
            OR: [{ liveExpiresAt: null }, { liveExpiresAt: { gt: now } }],
          },
        ],
      },
      include: articlePublicInclude,
      orderBy: [{ publishedAt: "desc" }, { updatedAt: "desc" }],
      take,
    });
    return rows
      .filter((row) => row.language === lang)
      .map((row) => serializeArticle(row, { lite: true })) as PublicArticle[];
  } catch {
    return [];
  }
}

export async function getPage(slug: string) {
  try {
    const page = await prisma.staticPage.findFirst({
      where: { slug, status: "published" },
    });
    if (!page) return null;
    return {
      id: page.id,
      title: page.title,
      titleUr: page.titleUr || null,
      slug: page.slug,
      body: page.body,
      bodyUr: page.bodyUr || null,
      status: page.status,
      seoTitle: page.seoTitle,
      seoDescription: page.seoDescription,
      seoTitleUr: page.seoTitleUr || null,
      seoDescriptionUr: page.seoDescriptionUr || null,
    } as StaticPage;
  } catch {
    return null;
  }
}

export async function getSearch(q: string, page = 1, language?: string) {
  if (!q.trim()) return emptyPage<PublicArticle>();
  return getArticles({ q, page, language });
}

export async function getLiveStories(params: { language?: string } = {}) {
  try {
    const lang = params.language === "en" || params.language === "ur" ? params.language : undefined;
    const items = await prisma.liveStory.findMany({
      where: { status: { in: ["live", "published", "active"] } },
      include: { category: true },
      orderBy: { updatedAt: "desc" },
      take: 60,
    });
    const mapped = items.map((s) => ({
      id: s.id,
      title: s.title,
      titleUr: s.titleUr || null,
      titleEn: s.title,
      slug: s.slug,
      slugUr: s.slugUr || null,
      description: s.description,
      descriptionUr: s.descriptionUr || null,
      status: s.status,
      startAt: s.startAt,
      endAt: s.endAt,
      category: s.category ? mapCategory(s.category) : null,
    })) as LiveStory[];
    if (!lang) return mapped.slice(0, 30);
    return mapped.filter((s) => liveStoryMatchesLang(s, lang)).slice(0, 30);
  } catch {
    return [];
  }
}

export async function getLiveStory(idOrSlug: string, params: { language?: string } = {}) {
  try {
    const lang = params.language === "en" || params.language === "ur" ? params.language : undefined;
    const s = await prisma.liveStory.findFirst({
      where: {
        OR: [{ id: idOrSlug }, { slug: idOrSlug }, { slugUr: idOrSlug }],
      },
      include: {
        category: true,
        updates: { orderBy: { publishedAt: "desc" }, take: 100 },
      },
    });
    if (!s) return null;
    if (lang && !liveStoryMatchesLang(s, lang)) return null;
    return {
      id: s.id,
      title: s.title,
      titleUr: s.titleUr || null,
      titleEn: s.title,
      slug: s.slug,
      slugUr: s.slugUr || null,
      description: s.description,
      descriptionUr: s.descriptionUr || null,
      status: s.status,
      startAt: s.startAt,
      endAt: s.endAt,
      category: s.category ? mapCategory(s.category) : null,
      updates: s.updates.map((u) => ({
        id: u.id,
        body: u.body,
        bodyUr: u.bodyUr || null,
        type: u.type,
        mediaUrl: u.mediaUrl,
        quote: u.quote,
        quoteUr: u.quoteUr || null,
        location: u.location,
        isPinned: u.isPinned,
        isImportant: u.isImportant,
        publishedAt: u.publishedAt,
      })),
    } as LiveStory;
  } catch {
    return null;
  }
}

export async function getVideos(params: { page?: number } = {}) {
  try {
    const page = Math.max(1, Number(params.page) || 1);
    const pageSize = 12;
    const skip = (page - 1) * pageSize;
    const where = { status: "published" };
    const [total, rows] = await Promise.all([
      prisma.video.count({ where }),
      prisma.video.findMany({
        where,
        orderBy: { updatedAt: "desc" },
        skip,
        take: pageSize,
      }),
    ]);
    return {
      items: rows.map((v) => ({
        id: v.id,
        title: v.title,
        slug: v.slug,
        description: v.description,
        thumbnail: v.thumbnail,
        url: v.url,
        duration: v.duration,
        provider: v.provider,
        status: v.status,
      })) as VideoItem[],
      page,
      pageSize,
      total,
      totalPages: Math.ceil(total / pageSize),
    };
  } catch {
    return emptyPage<VideoItem>();
  }
}

export async function getVideo(slug: string) {
  try {
    const v = await prisma.video.findFirst({
      where: { slug, status: "published" },
    });
    if (!v) return null;
    return {
      id: v.id,
      title: v.title,
      slug: v.slug,
      description: v.description,
      thumbnail: v.thumbnail,
      url: v.url,
      duration: v.duration,
      provider: v.provider,
      status: v.status,
    } as VideoItem;
  } catch {
    return null;
  }
}

export async function getGalleries(params: { page?: number } = {}) {
  try {
    const page = Math.max(1, Number(params.page) || 1);
    const pageSize = 12;
    const skip = (page - 1) * pageSize;
    const where = { status: "published" };
    const [total, rows] = await Promise.all([
      prisma.gallery.count({ where }),
      prisma.gallery.findMany({
        where,
        include: { _count: { select: { items: true } } },
        orderBy: { updatedAt: "desc" },
        skip,
        take: pageSize,
      }),
    ]);
    return {
      items: rows.map((g) => ({
        id: g.id,
        title: g.title,
        slug: g.slug,
        description: g.description,
        coverUrl: g.coverUrl,
        status: g.status,
      })) as GalleryItem[],
      page,
      pageSize,
      total,
      totalPages: Math.ceil(total / pageSize),
    };
  } catch {
    return emptyPage<GalleryItem>();
  }
}

export async function getGallery(slug: string) {
  try {
    const g = await prisma.gallery.findFirst({
      where: { slug, status: "published" },
      include: {
        items: { include: { media: true }, orderBy: { sortOrder: "asc" } },
      },
    });
    if (!g) return null;
    return {
      id: g.id,
      title: g.title,
      slug: g.slug,
      description: g.description,
      coverUrl: g.coverUrl,
      status: g.status,
      items: g.items.map((img) => ({
        id: img.id,
        imageUrl: img.imageUrl || img.media?.url || "",
        caption: img.caption,
        credit: img.credit,
      })),
    } as GalleryItem;
  } catch {
    return null;
  }
}

export async function getAd(unitKey: string) {
  try {
    const now = new Date();
    const ad = await prisma.advertisement.findFirst({
      where: {
        unitKey,
        status: "active",
        AND: [
          { OR: [{ startAt: null }, { startAt: { lte: now } }] },
          { OR: [{ endAt: null }, { endAt: { gte: now } }] },
        ],
      },
      orderBy: { priority: "desc" },
    });
    if (!ad) return null;
    return {
      id: ad.id,
      unitKey: ad.unitKey,
      name: ad.name,
      code: ad.code,
      imageUrl: ad.imageUrl,
      targetUrl: ad.targetUrl,
      device: ad.device,
      priority: ad.priority,
    } as AdUnit;
  } catch {
    return null;
  }
}

export async function getAds(opts?: { unitKey?: string; take?: number }) {
  try {
    const now = new Date();
    const take = opts?.take ?? 20;
    const rows = await prisma.advertisement.findMany({
      where: {
        status: "active",
        unitKey: opts?.unitKey || undefined,
        AND: [
          { OR: [{ startAt: null }, { startAt: { lte: now } }] },
          { OR: [{ endAt: null }, { endAt: { gte: now } }] },
        ],
      },
      orderBy: [{ priority: "desc" }, { createdAt: "desc" }],
      take,
    });
    return rows.map(
      (ad) =>
        ({
          id: ad.id,
          unitKey: ad.unitKey,
          name: ad.name,
          code: ad.code,
          imageUrl: ad.imageUrl,
          targetUrl: ad.targetUrl,
          device: ad.device,
          priority: ad.priority,
        }) as AdUnit,
    );
  } catch {
    return [];
  }
}

export async function getActivePoll() {
  try {
    const now = new Date();
    const poll = await prisma.poll.findFirst({
      where: {
        status: "active",
        AND: [
          { OR: [{ startAt: null }, { startAt: { lte: now } }] },
          { OR: [{ endAt: null }, { endAt: { gte: now } }] },
        ],
      },
      include: { options: true, _count: { select: { votes: true } } },
      orderBy: { createdAt: "desc" },
    });
    if (!poll) return null;
    return {
      id: poll.id,
      question: poll.question,
      options: poll.options.map((o) => ({
        id: o.id,
        label: o.label,
        votes: o.votes,
      })),
      _count: poll._count,
    };
  } catch {
    return null;
  }
}

export async function getPublishedQuiz() {
  try {
    const quiz = await prisma.quiz.findFirst({
      where: { status: "published" },
      include: { questions: { orderBy: { sortOrder: "asc" } } },
      orderBy: { createdAt: "desc" },
    });
    if (!quiz || quiz.questions.length === 0) return null;
    return {
      id: quiz.id,
      title: quiz.title,
      description: quiz.description,
      questions: quiz.questions.map((q) => ({
        id: q.id,
        question: q.question,
        options: JSON.parse(q.optionsJson) as string[],
        sortOrder: q.sortOrder,
      })),
    };
  } catch {
    return null;
  }
}

// Keep HTTP helper available for rare client-adjacent callers
export { publicFetch, qs };
