import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(value?: string | Date | null, locale = "ur-PK") {
  if (!value) return "";
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat(locale, {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(d);
}

/**
 * BBC-style relative time from publish datetime.
 * EN: "3 hours ago" · UR: "3 گھنٹے قبل" (Western digits like BBC Urdu; auto from clock).
 */
export function formatRelativeTime(
  value?: string | Date | null,
  lang: "ur" | "en" = "ur",
) {
  if (!value) return "";
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return "";
  const diffMs = Date.now() - d.getTime();
  // Future timestamps: fall back to absolute date
  if (diffMs < -60_000) return formatDate(d, lang === "ur" ? "ur-PK" : "en-GB");

  const sec = Math.floor(diffMs / 1000);
  if (lang === "ur") {
    if (sec < 45) return "ابھی";
    const mins = Math.floor(sec / 60);
    if (mins < 60) {
      if (mins <= 1) return "1 منٹ قبل";
      return `${mins} منٹ قبل`;
    }
    const hours = Math.floor(mins / 60);
    if (hours < 48) {
      if (hours <= 1) return "1 گھنٹہ قبل";
      return `${hours} گھنٹے قبل`;
    }
    const days = Math.floor(hours / 24);
    if (days < 30) {
      if (days <= 1) return "1 دن قبل";
      return `${days} دن قبل`;
    }
    return formatDate(d, "ur-PK");
  }

  const rtf = new Intl.RelativeTimeFormat("en", { numeric: "auto" });
  if (sec < 45) return "just now";
  const mins = Math.round(sec / 60);
  if (mins < 60) return rtf.format(-mins, "minute");
  const hours = Math.round(sec / 3600);
  if (hours < 48) return rtf.format(-hours, "hour");
  const days = Math.round(sec / 86400);
  if (days < 30) return rtf.format(-days, "day");
  return formatDate(d, "en-GB");
}
