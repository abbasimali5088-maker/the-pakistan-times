import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { randomBytes } from "crypto";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");

function extFromMime(mime: string, filename: string) {
  const fromName = (filename || "").toLowerCase().match(/\.(jpe?g|png|gif|webp|avif)$/);
  if (fromName) return fromName[1] === "jpeg" ? "jpg" : fromName[1];
  if (mime.includes("png")) return "png";
  if (mime.includes("webp")) return "webp";
  if (mime.includes("gif")) return "gif";
  if (mime.includes("avif")) return "avif";
  return "jpg";
}

/**
 * Persist data:image uploads to /public/uploads and return a public /uploads/… URL.
 * Leaves http(s) and already-local /uploads paths unchanged.
 * Rejects oversized payloads that would bloat the DB / break next/image.
 */
export async function persistMediaUrl(
  url: string,
  filename = "image.jpg",
  mimeHint?: string | null,
): Promise<{ url: string; path: string; size: number; mimeType: string }> {
  const raw = (url || "").trim();
  if (!raw) throw new Error("Empty media URL");

  if (/^https?:\/\//i.test(raw) || raw.startsWith("/uploads/") || raw.startsWith("/icon-")) {
    return {
      url: raw,
      path: raw.startsWith("/") ? raw : raw,
      size: 0,
      mimeType: mimeHint || "image/jpeg",
    };
  }

  const m = raw.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,([\s\S]+)$/i);
  if (!m) {
    // Unknown scheme — refuse so we never store garbage that becomes the logo fallback
    throw new Error("Only http(s) image URLs or image file uploads are allowed");
  }

  const mimeType = m[1].toLowerCase();
  const b64 = m[2].replace(/\s+/g, "");
  const buf = Buffer.from(b64, "base64");
  if (buf.length < 32) throw new Error("Image data too small");
  if (buf.length > 4 * 1024 * 1024) throw new Error("Image too large (max 4MB)");

  await mkdir(UPLOAD_DIR, { recursive: true });
  const ext = extFromMime(mimeType, filename);
  const id = randomBytes(12).toString("hex");
  const safeName = `${id}.${ext}`;
  const diskPath = path.join(UPLOAD_DIR, safeName);
  await writeFile(diskPath, buf);
  const publicUrl = `/uploads/${safeName}`;
  return { url: publicUrl, path: publicUrl, size: buf.length, mimeType };
}
