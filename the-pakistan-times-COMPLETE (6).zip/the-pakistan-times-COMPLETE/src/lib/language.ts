import { BRAND } from "./constants";
import { stripTags, toArticleHtml } from "./article-html";

export type Lang = "ur" | "en";

export const LANG_COOKIE = "lang";

export function isLang(value: unknown): value is Lang {
  return value === "ur" || value === "en";
}

export function normalizeLang(value?: string | null): Lang {
  return value === "en" ? "en" : "ur";
}

export function brandName(lang: Lang) {
  return lang === "en" ? BRAND.en : BRAND.ur;
}

/** True if string contains Arabic/Urdu script. */
export function hasUrduScript(value?: string | null) {
  return Boolean(value && /[\u0600-\u06FF]/.test(value));
}

/** Keep only Urdu-script text; drop English pasted into Urdu fields. */
export function urduOnly(value?: string | null) {
  const t = (value || "").trim();
  return hasUrduScript(t) ? t : "";
}

/** Keep only non-Urdu (English) text; drop Urdu pasted into EN fields. */
export function englishOnly(value?: string | null) {
  const t = (value || "").trim();
  if (!t) return "";
  return hasUrduScript(t) ? "" : t;
}

/**
 * Classify legacy LiveStory rows (no language column) without mixing EN/UR.
 * Urdu creates copy titleUr → title; English creates leave titleUr null.
 */
export function liveStoryLocale(story: {
  title?: string | null;
  titleUr?: string | null;
}): Lang | null {
  if (urduOnly(story.titleUr) || hasUrduScript(story.title)) return "ur";
  if (englishOnly(story.title)) return "en";
  return null;
}

export function liveStoryMatchesLang(
  story: { title?: string | null; titleUr?: string | null },
  lang: Lang,
) {
  return liveStoryLocale(story) === lang;
}

/**
 * Strict language pick — never mix EN into Urdu view or Urdu into English view.
 * Missing locale returns fallback (default empty), not the other language.
 */
export function pickText(
  lang: Lang,
  ur?: string | null,
  en?: string | null,
  fallback = "",
) {
  if (lang === "en") return ((en || "").trim() || fallback).trim();
  return ((ur || "").trim() || fallback).trim();
}

/** Pick body HTML for a language; reject wrong-script content. */
export function pickBodyHtml(
  lang: Lang,
  bodyUr?: string | null,
  bodyEn?: string | null,
) {
  const ur = (bodyUr || "").trim();
  const en = (bodyEn || "").trim();
  if (lang === "ur") {
    if (hasUrduScript(ur)) return toArticleHtml(ur);
    // Misplaced: Urdu typed into English body field
    if (hasUrduScript(en)) return toArticleHtml(en);
    return "";
  }
  if (en && !hasUrduScript(en)) return toArticleHtml(en);
  // English body that still has enough Latin letters (mixed quotes OK)
  if (en && /[A-Za-z]{12,}/.test(stripTags(en))) return toArticleHtml(en);
  return "";
}

export type LocalizedArticleFields = {
  title?: string | null;
  titleUr?: string | null;
  titleEn?: string | null;
  language?: string | null;
  excerpt?: string | null;
  excerptUr?: string | null;
  excerptEn?: string | null;
  body?: string | null;
  bodyUr?: string | null;
  bodyEn?: string | null;
  toolTitle?: string | null;
  toolCode?: string | null;
  toolTitleUr?: string | null;
  toolCodeUr?: string | null;
  videoUrl?: string | null;
  videoUrlUr?: string | null;
  imageCaption?: string | null;
  imageCredit?: string | null;
  imageCaptionUr?: string | null;
  imageCreditUr?: string | null;
  seoTitle?: string | null;
  seoTitleUr?: string | null;
  seoDescription?: string | null;
  seoDescriptionUr?: string | null;
  ogTitle?: string | null;
  ogTitleUr?: string | null;
  ogDescription?: string | null;
  ogDescriptionUr?: string | null;
  focusKeyword?: string | null;
  focusKeywordUr?: string | null;
  category?: {
    name?: string | null;
    nameUr?: string | null;
    nameEn?: string | null;
    slug?: string;
  } | null;
  categoryUr?: {
    name?: string | null;
    nameUr?: string | null;
    nameEn?: string | null;
    slug?: string;
  } | null;
  image?: { id?: string; url?: string; alt?: string | null } | null;
  imageUr?: { id?: string; url?: string; alt?: string | null } | null;
  tags?: Array<{ id: string; name: string; nameUr?: string | null; slug: string }>;
  tagsUr?: Array<{ id: string; name: string; nameUr?: string | null; slug: string }>;
  seo?: {
    title?: string | null;
    titleUr?: string | null;
    description?: string | null;
    descriptionUr?: string | null;
    ogTitle?: string | null;
    ogTitleUr?: string | null;
    ogDescription?: string | null;
    ogDescriptionUr?: string | null;
    focusKeyword?: string | null;
    focusKeywordUr?: string | null;
    ogImage?: string | null;
    ogImageUr?: string | null;
    schemaType?: string | null;
  } | null;
};

/** Strip trailing Latin/English noise from Urdu display strings (Blogger imports). */
function scrubUrduDisplay(value: string) {
  let t = value.trim();
  // Leading English site byline: "The Pakistan Times — Islamabad | August 20, 2026 …"
  t = t.replace(/^The\s+Pakistan\s+Times[\s\S]*?(?=[؀-ۿ])/i, "");
  // Drop "The Pakistan Times — City | Date..." style English tails
  t = t.replace(
    /\s*(?:The\s+Pakistan\s+Times|AFP|GETTY|VIA\s+GETTY)[\s\S]*$/i,
    "",
  );
  t = t.replace(/\s*[|—–-]\s*[A-Za-z][A-Za-z\s,./0-9-]{8,}$/u, "");
  t = t.replace(/^(دی پاکستان ٹائمز اردو\s*){2,}/u, "دی پاکستان ٹائمز اردو ");
  return t.trim();
}

export function localizeArticle<T extends LocalizedArticleFields>(article: T, lang: Lang) {
  const titleEn = englishOnly(article.titleEn || article.title);
  let titleUr = urduOnly(article.titleUr) || (hasUrduScript(article.title) ? String(article.title) : "");
  if (titleUr) titleUr = scrubUrduDisplay(titleUr);
  const excerptEn = englishOnly(article.excerptEn || article.excerpt);
  let excerptUr = urduOnly(article.excerptUr) || (hasUrduScript(article.excerpt) ? String(article.excerpt || "") : "");
  if (excerptUr) excerptUr = scrubUrduDisplay(excerptUr);
  const bodyHtml = pickBodyHtml(lang, article.bodyUr, article.bodyEn || article.body);

  const seoTitleEn = englishOnly(article.seo?.title || article.seoTitle) || titleEn;
  const seoTitleUr =
    urduOnly(article.seo?.titleUr || article.seoTitleUr) || titleUr;
  const seoDescEn =
    englishOnly(article.seo?.description || article.seoDescription) || excerptEn;
  const seoDescUr =
    urduOnly(article.seo?.descriptionUr || article.seoDescriptionUr) || excerptUr;
  const ogTitleEn =
    englishOnly(article.seo?.ogTitle || article.ogTitle) || seoTitleEn;
  const ogTitleUr =
    urduOnly(article.seo?.ogTitleUr || article.ogTitleUr) || seoTitleUr;
  const ogDescEn =
    englishOnly(article.seo?.ogDescription || article.ogDescription) || seoDescEn;
  const ogDescUr =
    urduOnly(article.seo?.ogDescriptionUr || article.ogDescriptionUr) || seoDescUr;

  const displayTitle = pickText(lang, titleUr, titleEn, "");
  let displayExcerpt = pickText(lang, excerptUr, excerptEn, "");
  if (
    displayExcerpt &&
    displayTitle &&
    displayExcerpt.replace(/\s+/g, "") === displayTitle.replace(/\s+/g, "")
  ) {
    displayExcerpt = "";
  }

  let displayBody = bodyHtml;
  if (displayTitle && displayBody) {
    const titlePlain = displayTitle.replace(/\s+/g, " ").trim();
    const chunks = displayBody.split(/(?=<p\b|<h[12]\b)/i).filter((c) => c.trim());
    if (chunks.length > 0) {
      const firstPlain = stripTags(chunks[0]).replace(/\s+/g, " ").trim();
      if (firstPlain === titlePlain) {
        displayBody = chunks.slice(1).join("").trim() || displayBody;
      }
    }
  }

  const displayImage =
    lang === "ur"
      ? article.imageUr || (article.language === "ur" ? article.image : null) || null
      : article.image || (article.language === "en" ? article.imageUr : null) || null;
  const displayVideoUrl = lang === "ur" ? article.videoUrlUr || null : article.videoUrl || null;
  const displayOgImage =
    lang === "ur"
      ? article.seo?.ogImageUr || article.imageUr?.url || null
      : article.seo?.ogImage || article.image?.url || null;
  const displayTags = lang === "ur" ? article.tagsUr || [] : article.tags || [];
  const displayCategoryObj = lang === "ur" ? article.categoryUr || article.category : article.category;
  const displayImageCaption =
    lang === "ur" ? article.imageCaptionUr || null : article.imageCaption || null;
  const displayImageCredit =
    lang === "ur" ? article.imageCreditUr || null : article.imageCredit || null;
  const displayToolTitle =
    lang === "ur" ? (article.toolTitleUr || "").trim() || null : (article.toolTitle || "").trim() || null;
  const displayToolCode =
    lang === "ur" ? (article.toolCodeUr || "").trim() || null : (article.toolCode || "").trim() || null;

  return {
    ...article,
    displayTitle: pickText(lang, titleUr, titleEn, ""),
    displayExcerpt,
    displayBody,
    displayCategory: displayCategoryObj
      ? pickText(
          lang,
          urduOnly(displayCategoryObj.nameUr || displayCategoryObj.name),
          englishOnly(displayCategoryObj.nameEn || displayCategoryObj.name),
          "",
        )
      : "",
    displayCategorySlug: displayCategoryObj?.slug || "",
    displaySeoTitle: pickText(lang, seoTitleUr, seoTitleEn, ""),
    displaySeoDescription: pickText(lang, seoDescUr, seoDescEn, ""),
    displayOgTitle: pickText(lang, ogTitleUr, ogTitleEn, ""),
    displayOgDescription: pickText(lang, ogDescUr, ogDescEn, ""),
    displayImage,
    displayVideoUrl,
    displayOgImage,
    displayTags,
    displayImageCaption,
    displayImageCredit,
    displayToolTitle,
    displayToolCode,
  };
}
