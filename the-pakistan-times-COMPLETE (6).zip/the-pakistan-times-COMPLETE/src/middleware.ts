import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { jwtVerify } from "jose";
import { resolveHostProfile, englishSiteUrl, urduSiteUrl } from "@/lib/site-host";

export const runtime = "nodejs";

const SESSION_COOKIE = "pt_session";

function corsOrigin(req: NextRequest) {
  const origin = req.headers.get("origin") || "";
  const site = (process.env.NEXT_PUBLIC_SITE_URL || "").replace(/\/$/, "");
  const allowed = new Set(
    [
      site,
      englishSiteUrl(),
      urduSiteUrl(),
      "http://127.0.0.1:4355",
      "http://localhost:4355",
      "http://127.0.0.1:8081",
      "http://localhost:8081",
      process.env.CORS_ORIGIN?.trim(),
    ].filter(Boolean) as string[],
  );
  if (origin && allowed.has(origin)) return origin;
  if (site) return site;
  return "*";
}

function withCors(req: NextRequest, res: NextResponse) {
  res.headers.set("Access-Control-Allow-Origin", corsOrigin(req));
  res.headers.set("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
  res.headers.set("Access-Control-Allow-Headers", "Content-Type, Authorization, Accept");
  res.headers.set("Access-Control-Max-Age", "86400");
  res.headers.set("Vary", "Origin");
  return res;
}

function jwtSecret() {
  const secret = process.env.JWT_SECRET?.trim();
  if (secret) return secret;
  if (process.env.NODE_ENV === "production" || process.env.VERCEL === "1") return "";
  return "dev-secret-local-only";
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const host = req.headers.get("x-forwarded-host") || req.headers.get("host") || "";
  const profile = resolveHostProfile(host);

  if (pathname.startsWith("/api/")) {
    if (req.method === "OPTIONS") {
      return withCors(req, new NextResponse(null, { status: 204 }));
    }
    return withCors(req, NextResponse.next());
  }

  if (pathname === "/backend" || pathname === "/console" || pathname === "/back" || pathname === "/fb") {
    const session = req.cookies.get(SESSION_COOKIE)?.value;
    const dest = req.nextUrl.clone();
    if (pathname === "/fb") {
      dest.pathname = "/open";
      dest.search = "";
      return NextResponse.redirect(dest);
    }
    dest.pathname = session ? "/admin" : "/admin/login";
    dest.search = "";
    return NextResponse.redirect(dest);
  }
  if (pathname === "/front" || pathname === "/share" || pathname === "/website") {
    const home = req.nextUrl.clone();
    home.pathname = "/";
    home.search = "";
    return NextResponse.redirect(home);
  }
  if (pathname === "/panel" || pathname === "/system" || pathname === "/owner") {
    const dest = req.nextUrl.clone();
    dest.pathname = "/admin/login";
    dest.search = "";
    return NextResponse.redirect(dest);
  }

  // Admin is shared CMS for both languages — do not language-lock admin routes.
  const isAdmin = pathname.startsWith("/admin");

  if (isAdmin && pathname !== "/admin/login") {
    const session = req.cookies.get(SESSION_COOKIE)?.value;
    const login = req.nextUrl.clone();
    login.pathname = "/admin/login";
    login.search = "";
    if (!session) return NextResponse.redirect(login);
    const secret = jwtSecret();
    if (!secret) return NextResponse.redirect(login);
    try {
      await jwtVerify(session, new TextEncoder().encode(secret));
    } catch {
      const res = NextResponse.redirect(login);
      res.cookies.set(SESSION_COOKIE, "", { path: "/", maxAge: 0 });
      return res;
    }
  }

  const queryLang = req.nextUrl.searchParams.get("lang");
  const cookieLang = req.cookies.get("lang")?.value;

  let lang = profile.lang;
  if (isAdmin || !profile.locked) {
    lang =
      queryLang === "ur" || queryLang === "en"
        ? queryLang
        : cookieLang === "ur" || cookieLang === "en"
          ? cookieLang
          : profile.lang;
  } else {
    // Locked public host: ignore cross-language ?lang= / cookie
    lang = profile.lang;
  }

  const requestHeaders = new Headers(req.headers);
  requestHeaders.set("x-lang", lang);
  requestHeaders.set("x-lang-locked", !isAdmin && profile.locked ? "1" : "0");
  requestHeaders.set("x-site-host", profile.host);
  requestHeaders.set("x-site-url", profile.siteUrl);
  requestHeaders.set("x-url", req.nextUrl.href);
  requestHeaders.set("x-pathname", pathname);

  // On locked host, strip conflicting ?lang= so URLs stay clean (duplicate-content protection)
  if (!isAdmin && profile.locked && queryLang && queryLang !== profile.lang) {
    const clean = req.nextUrl.clone();
    clean.searchParams.delete("lang");
    const redirect = NextResponse.redirect(clean, 302);
    redirect.cookies.set("lang", profile.lang, {
      path: "/",
      maxAge: 60 * 60 * 24 * 365,
      sameSite: "lax",
    });
    return redirect;
  }

  const res = NextResponse.next({
    request: { headers: requestHeaders },
  });

  if (isAdmin || !profile.locked) {
    if (queryLang === "ur" || queryLang === "en") {
      res.cookies.set("lang", queryLang, {
        path: "/",
        maxAge: 60 * 60 * 24 * 365,
        sameSite: "lax",
      });
    } else if (!req.cookies.get("lang")) {
      res.cookies.set("lang", profile.lang, {
        path: "/",
        maxAge: 60 * 60 * 24 * 365,
        sameSite: "lax",
      });
    }
  } else {
    res.cookies.set("lang", profile.lang, {
      path: "/",
      maxAge: 60 * 60 * 24 * 365,
      sameSite: "lax",
    });
  }

  return res;
}

export const config = {
  matcher: ["/api/:path*", "/((?!_next/static|_next/image|favicon.ico|.*\\..*).*)"],
};
