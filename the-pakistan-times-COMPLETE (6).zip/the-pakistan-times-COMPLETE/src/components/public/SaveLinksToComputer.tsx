"use client";

import Link from "next/link";

/**
 * Safe links only — never embeds launcher/admin passwords in HTML downloads.
 */
export function SaveLinksToComputer({ site }: { site: string; launcherPassword?: string }) {
  return (
    <div className="mt-6 space-y-4">
      <div className="rounded-2xl border-2 border-[#1DB954] bg-[var(--surface)] p-5">
        <h2 className="mb-1 text-center text-xl font-bold text-[#1DB954]">Front + Backend</h2>
        <p className="mb-4 text-center text-sm text-[var(--muted)]">
          پاس ورڈ یہاں نہیں دکھایا جاتا — /open پر سرور چیک کرتا ہے
        </p>
        <Link
          href="/open"
          className="block w-full rounded-xl bg-[#1DB954] px-4 py-5 text-center text-lg font-bold text-white shadow"
        >
          کھولیں — /open
        </Link>
        <p className="mt-3 break-all text-center text-xs text-[var(--muted)]" dir="ltr">
          {site}/open
        </p>
        <Link
          href="/admin/login"
          className="mt-3 block w-full rounded-xl bg-[#111] px-4 py-4 text-center text-base font-bold text-white shadow"
        >
          ایڈمن لاگ اِن
        </Link>
      </div>
    </div>
  );
}
