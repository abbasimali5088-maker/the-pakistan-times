"use client";

import { useEffect, useState } from "react";
import { formatRelativeTime } from "@/lib/utils";

/** Theme-green relative-time chip — same visual weight as مزید پڑھیں. */
export function TimeBadge({
  value,
  lang,
  className = "",
}: {
  value?: string | Date | null;
  lang: "ur" | "en";
  className?: string;
}) {
  const [, setTick] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => setTick((n) => n + 1), 30_000);
    return () => window.clearInterval(id);
  }, []);

  const label = formatRelativeTime(value, lang);
  if (!label) return null;
  const dateTime =
    typeof value === "string" ? value : value instanceof Date ? value.toISOString() : undefined;

  return (
    <time dateTime={dateTime} className={`time-badge ui-sans ${className}`.trim()}>
      {label}
    </time>
  );
}
