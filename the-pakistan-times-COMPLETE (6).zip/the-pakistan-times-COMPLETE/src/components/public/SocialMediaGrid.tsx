import type { Lang } from "@/lib/language";
import {
  SOCIAL_LABELS,
  SOCIAL_LINK_KEYS,
  type SocialKey,
} from "@/lib/site-settings";
import { SocialBrandIcon, SOCIAL_BRAND_COLOR } from "./SocialBrandIcon";

/** BBC Urdu-style 2-column social blocks with brand colors. */
export function SocialMediaGrid({
  lang,
  social,
  title,
}: {
  lang: Lang;
  social?: Partial<Record<SocialKey, string>>;
  title?: string;
}) {
  const order: SocialKey[] = [
    "youtube",
    "whatsapp",
    "facebook",
    "instagram",
    "tiktok",
    "twitter",
    ...SOCIAL_LINK_KEYS.filter(
      (k) => !["youtube", "whatsapp", "facebook", "instagram", "tiktok", "twitter"].includes(k),
    ),
  ];

  const links = order
    .map((key) => {
      const href = social?.[key]?.trim();
      if (!href) return null;
      return {
        key,
        href,
        label: SOCIAL_LABELS[key].en,
        labelUr: SOCIAL_LABELS[key].ur,
        color: SOCIAL_BRAND_COLOR[key] || "#333",
      };
    })
    .filter(Boolean) as Array<{
    key: SocialKey;
    href: string;
    label: string;
    labelUr: string;
    color: string;
  }>;

  if (!links.length) return null;

  const heading =
    title ||
    (lang === "ur" ? "دی پاکستان ٹائمز سوشل میڈیا" : "The Pakistan Times on social");

  return (
    <section className="my-10">
      <h2 className="section-title mb-4">{heading}</h2>
      <ul className="grid grid-cols-2 gap-3 sm:gap-4">
        {links.map((item) => (
          <li key={item.key}>
            <a
              href={item.href}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 border border-[var(--line)] bg-[var(--surface)] p-2 pe-3 transition hover:border-[var(--accent)]"
            >
              <span
                className="inline-flex h-12 w-12 shrink-0 items-center justify-center text-white sm:h-14 sm:w-14"
                style={{ backgroundColor: item.color }}
              >
                <SocialBrandIcon name={item.key} className="h-6 w-6 sm:h-7 sm:w-7" />
              </span>
              <span className="ui-sans text-sm font-semibold text-[var(--ink)]">
                {item.label}
              </span>
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}
