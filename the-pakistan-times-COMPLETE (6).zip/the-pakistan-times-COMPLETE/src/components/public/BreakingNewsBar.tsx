import Link from "next/link";
import type { Lang } from "@/lib/language";
import { englishOnly, urduOnly } from "@/lib/language";
import type { BreakingItem } from "@/lib/public-types";

/** Display-only ticker — On/Off is controlled in Admin → Settings. */
export function BreakingNewsBar({
  lang,
  items,
}: {
  lang: Lang;
  items: BreakingItem[];
}) {
  const visible = items.filter((item) => {
    if (lang === "ur") return Boolean(urduOnly(item.headlineUr));
    return Boolean(englishOnly(item.headlineEn || item.headline));
  });
  if (!visible.length) return null;

  const label = lang === "ur" ? "بریکنگ" : "Breaking";
  const doubled = [...visible, ...visible];

  return (
    <div className="overflow-hidden border-b border-[var(--line)] bg-[#f3faf6]">
      <div className="mx-auto flex max-w-[var(--maxw)] items-center gap-2 px-3 py-2 sm:gap-3">
        <span className="ui-sans shrink-0 bg-[var(--accent)] px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-white">
          {label}
        </span>
        <div className="min-w-0 flex-1 overflow-hidden">
          <div className="ticker-track">
            {doubled.map((item, idx) => {
              const text =
                lang === "ur"
                  ? urduOnly(item.headlineUr)
                  : englishOnly(item.headlineEn || item.headline);
              const href =
                item.href || (item.article?.slug ? `/${item.article.slug}` : "/breaking");
              return (
                <Link
                  key={`${item.id}-${idx}`}
                  href={href}
                  className="ui-sans text-sm font-medium hover:text-[var(--accent)]"
                >
                  {text}
                </Link>
              );
            })}
          </div>
        </div>
        <Link
          href="/breaking"
          className="ui-sans hidden shrink-0 text-xs font-bold text-[var(--accent)] sm:inline"
        >
          {lang === "ur" ? "مزید" : "More"}
        </Link>
      </div>
    </div>
  );
}
