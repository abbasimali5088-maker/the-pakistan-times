import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { pickText } from "@/lib/language";
import { getRequestLang } from "@/lib/language-server";
import { absoluteUrl, getPage } from "@/lib/public-api";

export const dynamic = "force-dynamic";

const ALIASES: Record<string, string[]> = {
  corrections: ["corrections", "corrections-policy"],
};

export async function loadStaticPage(routeSlug: string) {
  const candidates = ALIASES[routeSlug] || [routeSlug];
  for (const slug of candidates) {
    const page = await getPage(slug);
    if (page) return page;
  }
  return null;
}

export async function staticPageMetadata(routeSlug: string): Promise<Metadata> {
  const page = await loadStaticPage(routeSlug);
  const lang = await getRequestLang();
  const title =
    pickText(lang, page?.seoTitleUr || page?.titleUr, page?.seoTitle || page?.title, "") ||
    routeSlug;
  const description =
    pickText(lang, page?.seoDescriptionUr, page?.seoDescription, "") || undefined;
  const canonical = absoluteUrl(`/${routeSlug === "corrections" ? "corrections" : routeSlug}`);
  return {
    title,
    description,
    alternates: { canonical },
  };
}

export async function StaticPageView({
  routeSlug,
  searchParams,
}: {
  routeSlug: string;
  searchParams: Promise<{ lang?: string }>;
}) {
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const page = await loadStaticPage(routeSlug);
  if (!page) notFound();

  const title = pickText(lang, page.titleUr, page.title, page.title);
  const body =
    lang === "en"
      ? page.body || ""
      : page.bodyUr || page.body || "";

  return (
    <article
      className="article-reading fade-in mx-auto max-w-3xl"
      style={{ backgroundColor: "#ffffff", color: "#141414" }}
    >
      <h1 className="mb-6 text-3xl text-[var(--ink)]">{title}</h1>
      <div className="prose-article whitespace-pre-line">{body}</div>
    </article>
  );
}
