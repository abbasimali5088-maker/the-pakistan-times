import type { Lang } from "@/lib/language";
import { getAd, getAds } from "@/lib/public-api";
import type { AdUnit } from "@/lib/public-types";
import { AdCreative } from "./AdCreative";

/**
 * Server ad slot — loads the highest-priority active ad for a unit key.
 * Unit keys used on the site: homepage_top, homepage_mid, homepage_sidebar,
 * article_top, article_bottom, category_top.
 */
export async function AdSlot({
  unitKey,
  lang,
  className,
  fallbackUnitKeys = [],
}: {
  unitKey: string;
  lang: Lang;
  className?: string;
  /** Try these keys if the primary slot is empty */
  fallbackUnitKeys?: string[];
}) {
  let ad = await getAd(unitKey);
  if (!ad) {
    for (const key of fallbackUnitKeys) {
      ad = await getAd(key);
      if (ad) break;
    }
  }
  // Last resort: any active ad with matching prefix (e.g. "homepage")
  if (!ad) {
    const prefix = unitKey.split("_")[0];
    const pool = await getAds({ take: 20 });
    ad =
      pool.find((a) => a.unitKey === unitKey) ||
      pool.find((a) => a.unitKey.startsWith(prefix)) ||
      null;
  }
  if (!ad) return null;
  return <AdCreative ad={ad} lang={lang} className={className} />;
}

export type { AdUnit };
