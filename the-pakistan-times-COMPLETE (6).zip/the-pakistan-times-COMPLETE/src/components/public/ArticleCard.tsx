import Link from "next/link";
import type { Lang } from "@/lib/language";
import { localizeArticle } from "@/lib/language";
import type { PublicArticle } from "@/lib/public-types";
import { formatDate, formatRelativeTime, cn } from "@/lib/utils";
import { CoverImage } from "./CoverImage";
import { TimeBadge } from "./TimeBadge";

export type ArticleCardVariant =
  | "large"
  | "medium"
  | "small"
  | "horizontal"
  | "compact"
  | "featured";

export function ArticleCard({
  article,
  lang,
  variant = "medium",
}: {
  article: PublicArticle;
  lang: Lang;
  variant?: ArticleCardVariant;
}) {
  const a = localizeArticle(article, lang);
  const href = article.href || `/${article.slug}`;
  const locale = lang === "ur" ? "ur-PK" : "en-GB";
  const date = formatDate(article.publishedAt || article.publishAt, locale);
  const relative = formatRelativeTime(article.publishedAt || article.publishAt, lang);
  const image = a.displayImage?.url || (lang === "ur" ? article.imageUr?.url : article.image?.url);
  const readMore = lang === "ur" ? "مزید پڑھیں ←" : "Read more →";
  const readMoreClass =
    "read-more-link ui-sans inline-flex items-center gap-1 bg-[var(--accent)] px-4 py-2.5 text-base font-extrabold tracking-wide text-white hover:bg-[var(--accent-deep)] hover:text-white";
  const isLive = article.priority === "live";

  const liveBadge = isLive ? (
    <span className="ui-sans mb-2 inline-flex items-center gap-2 text-sm font-black uppercase tracking-wide text-[var(--accent-deep)]">
      <span className="live-beacon" aria-hidden>
        <span className="live-beacon__ping" />
        <span className="live-beacon__dot" />
      </span>
      {lang === "ur" ? "لائیو" : "LIVE"}
    </span>
  ) : null;

  const timeRow = (
    <div className="mt-3 flex flex-wrap items-center gap-2">
      <TimeBadge value={article.publishedAt || article.publishAt} lang={lang} />
      {!relative && date ? <span className="meta">{date}</span> : null}
      <Link href={href} className={readMoreClass}>
        {readMore}
      </Link>
    </div>
  );

  if (variant === "featured") {
    return (
      <article className="group relative isolate overflow-hidden border border-[var(--line)] bg-[var(--surface)]">
        <Link href={href} className="relative block aspect-[16/10] w-full overflow-hidden bg-[#f3faf6]">
          {image ? (
            <CoverImage
              src={image}
              alt={article.image?.alt || a.displayTitle}
              fill
              priority
              className="object-cover transition duration-700 group-hover:scale-[1.03]"
              sizes="100vw"
            />
          ) : (
            <div className="absolute inset-0 bg-[#e8f5ee]" />
          )}
        </Link>
        <div className="relative z-10 px-5 pb-6 pt-5 sm:px-6 sm:pb-8">
          <div className="max-w-3xl">
            {liveBadge}
            {a.displayCategory ? (
              <p className="ui-sans mb-2 text-xs font-bold uppercase tracking-[0.14em] text-[var(--accent)]">
                {a.displayCategory}
              </p>
            ) : null}
            <h2 className="mb-3 text-3xl leading-tight text-[var(--ink)] sm:text-4xl">
              <Link href={href} className="hover:text-[var(--accent)]">
                {a.displayTitle}
              </Link>
            </h2>
            {a.displayExcerpt ? (
              <p className="max-w-2xl text-base text-[var(--muted)] sm:text-lg line-clamp-3">
                {a.displayExcerpt}
              </p>
            ) : null}
            <p className="meta mt-4 flex flex-wrap items-center gap-3">
              <TimeBadge value={article.publishedAt || article.publishAt} lang={lang} />
              <Link href={href} className={readMoreClass}>
                {readMore}
              </Link>
            </p>
          </div>
        </div>
      </article>
    );
  }

  if (variant === "horizontal") {
    return (
      <article className="grid grid-cols-[88px_minmax(0,1fr)] gap-3 sm:grid-cols-[140px_1fr]">
        <Link href={href} className="relative aspect-[4/3] overflow-hidden bg-[var(--paper-deep)]">
          {image ? (
            <CoverImage
              src={image}
              alt={article.image?.alt || a.displayTitle}
              fill
              className="object-cover"
              sizes="140px"
            />
          ) : null}
        </Link>
        <div className="min-w-0">
          {a.displayCategory ? (
            <p className="ui-sans mb-1 text-[11px] font-bold uppercase tracking-wide text-[var(--accent)]">
              {a.displayCategory}
            </p>
          ) : null}
          <h3 className="break-words text-base leading-snug sm:text-lg">
            <Link href={href} className="hover:text-[var(--accent)]">
              {a.displayTitle}
            </Link>
          </h3>
          {a.displayExcerpt ? (
            <p className="mt-1 line-clamp-2 text-sm text-[var(--muted)]">{a.displayExcerpt}</p>
          ) : null}
          <p className="meta mt-1 flex flex-wrap gap-2">
            <TimeBadge value={article.publishedAt || article.publishAt} lang={lang} />
            <Link href={href} className={readMoreClass}>
              {readMore}
            </Link>
          </p>
        </div>
      </article>
    );
  }

  if (variant === "compact") {
    return (
      <article className="grid grid-cols-[76px_minmax(0,1fr)] gap-3 border-b border-[var(--line)] py-3 last:border-0 sm:grid-cols-[96px_1fr]">
        <Link
          href={href}
          className="relative aspect-[4/3] overflow-hidden bg-[var(--paper-deep)]"
        >
          {image ? (
            <CoverImage
              src={image}
              alt={article.image?.alt || a.displayTitle}
              fill
              className="object-cover"
              sizes="96px"
            />
          ) : (
            <div className="absolute inset-0 bg-[var(--accent-soft)]" />
          )}
        </Link>
        <div className="min-w-0">
          <h3 className="text-[0.98rem] leading-snug">
            <Link href={href} className="hover:text-[var(--accent)]">
              {a.displayTitle}
            </Link>
          </h3>
          {a.displayExcerpt ? (
            <p className="mt-1 line-clamp-2 text-sm text-[var(--muted)]">{a.displayExcerpt}</p>
          ) : null}
          <p className="meta mt-1 flex flex-wrap gap-2">
            <TimeBadge value={article.publishedAt || article.publishAt} lang={lang} />
            <Link href={href} className={readMoreClass}>
              {readMore}
            </Link>
          </p>
        </div>
      </article>
    );
  }

  if (variant === "small") {
    return (
      <article className="group">
        {a.displayCategory ? (
          <p className="ui-sans mb-1 text-[11px] font-bold uppercase tracking-wide text-[var(--accent)]">
            {a.displayCategory}
          </p>
        ) : null}
        <h3 className="text-base leading-snug">
          <Link href={href} className="hover:text-[var(--accent)]">
            {a.displayTitle}
          </Link>
        </h3>
        <Link href={href} className="relative my-3 block overflow-hidden bg-[var(--paper-deep)]">
          <div className="relative aspect-[16/10] w-full">
            {image ? (
              <CoverImage
                src={image}
                alt={article.image?.alt || a.displayTitle}
                fill
                className="object-cover transition duration-500 group-hover:scale-[1.02]"
                sizes="(max-width:768px) 100vw, 33vw"
              />
            ) : (
              <div className="absolute inset-0 bg-[var(--accent-soft)]" />
            )}
          </div>
        </Link>
        {a.displayExcerpt ? (
          <p className="line-clamp-2 text-sm text-[var(--muted)]">{a.displayExcerpt}</p>
        ) : null}
        <p className="meta mt-2 flex flex-wrap gap-2">
          <TimeBadge value={article.publishedAt || article.publishAt} lang={lang} />
          <Link href={href} className={readMoreClass}>
            {readMore}
          </Link>
        </p>
      </article>
    );
  }

  const isLarge = variant === "large";

  /* Listing flow: title → image → excerpt → Read more */
  return (
    <article className={cn("group", isLarge && "md:col-span-2")}>
      {liveBadge}
      {a.displayCategory ? (
        <p className="ui-sans mb-1 text-[11px] font-bold uppercase tracking-wide text-[var(--accent)]">
          {a.displayCategory}
        </p>
      ) : null}
      <h3 className={cn("leading-snug", isLarge ? "text-2xl sm:text-3xl" : "text-lg")}>
        <Link href={href} className="hover:text-[var(--accent)]">
          {a.displayTitle}
        </Link>
      </h3>
      <div className="relative my-3 overflow-hidden bg-[var(--paper-deep)]">
        <Link href={href} className="relative block">
          <div className={cn("relative w-full", isLarge ? "aspect-[16/9]" : "aspect-[16/10]")}>
            {image ? (
              <CoverImage
                src={image}
                alt={article.image?.alt || a.displayTitle}
                fill
                className="object-cover transition duration-500 group-hover:scale-[1.02]"
                sizes={isLarge ? "(max-width:768px) 100vw, 66vw" : "(max-width:768px) 100vw, 33vw"}
              />
            ) : (
              <div className="absolute inset-0 bg-[var(--accent-soft)]" />
            )}
          </div>
        </Link>
      </div>
      {a.displayExcerpt ? (
        <p className="line-clamp-3 text-sm leading-relaxed text-[var(--muted)] sm:text-[0.95rem]">
          {a.displayExcerpt}
        </p>
      ) : null}
      {timeRow}
    </article>
  );
}
