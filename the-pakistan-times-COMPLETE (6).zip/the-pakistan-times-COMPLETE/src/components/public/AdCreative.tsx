"use client";

import type { Lang } from "@/lib/language";
import type { AdUnit } from "@/lib/public-types";

/**
 * Renders one ad creative: image+link, or sanitized HTML embed code.
 */
export function AdCreative({
  ad,
  lang,
  className,
}: {
  ad: AdUnit;
  lang: Lang;
  className?: string;
}) {
  const label = lang === "ur" ? "اشتہار" : "Advertisement";

  if (ad.code?.trim()) {
    return (
      <aside
        className={`ad-slot my-4 overflow-hidden border border-[var(--line)] bg-[var(--paper-deep)] ${className || ""}`}
        aria-label={label}
      >
        <p className="ui-sans px-2 py-1 text-[10px] font-bold uppercase tracking-wide text-[var(--muted)]">
          {label}
        </p>
        <div
          className="ad-embed px-2 pb-2 [&_iframe]:max-w-full [&_img]:mx-auto [&_img]:max-h-[280px] [&_img]:w-auto"
          // Admin-authored ad HTML only — never user comments
          dangerouslySetInnerHTML={{ __html: ad.code }}
        />
      </aside>
    );
  }

  if (ad.imageUrl?.trim()) {
    const img = (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={ad.imageUrl}
        alt={ad.name || label}
        className="mx-auto max-h-[280px] w-full max-w-full object-contain"
        loading="lazy"
      />
    );
    return (
      <aside
        className={`ad-slot my-4 overflow-hidden border border-[var(--line)] bg-[var(--paper-deep)] ${className || ""}`}
        aria-label={label}
      >
        <p className="ui-sans px-2 py-1 text-[10px] font-bold uppercase tracking-wide text-[var(--muted)]">
          {label}
        </p>
        <div className="px-2 pb-2">
          {ad.targetUrl ? (
            <a href={ad.targetUrl} target="_blank" rel="noopener noreferrer sponsored">
              {img}
            </a>
          ) : (
            img
          )}
        </div>
      </aside>
    );
  }

  return null;
}
