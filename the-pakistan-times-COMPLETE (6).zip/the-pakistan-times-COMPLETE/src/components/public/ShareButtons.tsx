"use client";

import { useState } from "react";
import type { Lang } from "@/lib/language";
import { SocialBrandIcon, SOCIAL_BRAND_COLOR } from "./SocialBrandIcon";
import type { SocialKey } from "@/lib/site-settings";
import { cn } from "@/lib/utils";

type ShareItem = {
  key: SocialKey | "copy";
  label: string;
  href?: string;
};

function buildLinks(title: string, url: string, lang: Lang): ShareItem[] {
  const encoded = encodeURIComponent(url);
  const text = encodeURIComponent(title);
  // BBC-style order — WhatsApp sits in the middle of the row
  return [
    {
      key: "facebook",
      label: "Facebook",
      href: `https://www.facebook.com/sharer/sharer.php?u=${encoded}`,
    },
    {
      key: "twitter",
      label: "X",
      href: `https://twitter.com/intent/tweet?url=${encoded}&text=${text}`,
    },
    {
      key: "whatsapp",
      label: "WhatsApp",
      href: `https://api.whatsapp.com/send?text=${text}%20${encoded}`,
    },
    {
      key: "telegram",
      label: "Telegram",
      href: `https://t.me/share/url?url=${encoded}&text=${text}`,
    },
    {
      key: "linkedin",
      label: "LinkedIn",
      href: `https://www.linkedin.com/sharing/share-offsite/?url=${encoded}`,
    },
    { key: "copy", label: lang === "ur" ? "کاپی لنک" : "Copy link" },
  ];
}

export function ShareButtons({
  lang,
  title,
  url,
  variant = "bar",
}: {
  lang: Lang;
  title: string;
  url: string;
  /** bar = BBC strip below content; rail = desktop side rail. Overlay on images is removed. */
  variant?: "bar" | "rail";
}) {
  const [copied, setCopied] = useState(false);
  const links = buildLinks(title, url, lang);

  async function copy() {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      /* ignore */
    }
  }

  function renderItem(
    link: ShareItem,
    opts?: { large?: boolean; showLabel?: boolean; overlay?: boolean },
  ) {
    const color = SOCIAL_BRAND_COLOR[link.key] || "#334155";
    const label =
      link.key === "copy" && copied ? (lang === "ur" ? "کاپی ہو گیا" : "Copied") : link.label;
    const large = opts?.large;
    const showLabel = opts?.showLabel;
    const overlay = opts?.overlay;
    const isWa = link.key === "whatsapp";

    const inner = (
      <>
        <span
          className={cn(
            "inline-flex items-center justify-center rounded-full text-white shadow-md ring-2 ring-white/90",
            large ? "h-12 w-12 sm:h-14 sm:w-14" : overlay ? "h-9 w-9 sm:h-10 sm:w-10" : "h-10 w-10",
            isWa && large && "ring-[#25D366]/60",
          )}
          style={{ backgroundColor: color }}
        >
          <SocialBrandIcon
            name={link.key === "copy" ? "copy" : link.key}
            className={large ? "h-5 w-5 sm:h-6 sm:w-6" : "h-4 w-4"}
          />
        </span>
        {showLabel ? (
          <span
            className={cn(
              "font-semibold",
              large ? "text-sm sm:text-base" : "text-xs",
              isWa && "text-[#128C7E]",
            )}
          >
            {label}
          </span>
        ) : null}
      </>
    );

    const className = cn(
      "inline-flex items-center gap-2 transition hover:opacity-90 hover:scale-[1.04]",
      showLabel && "rounded-full border border-[var(--line)] bg-white pe-3 ps-1 py-1",
      large && showLabel && "border-[#25D366]/50 bg-[#25D366]/12 pe-4 shadow-sm",
    );

    if (link.key === "copy") {
      return (
        <button key={link.key} type="button" onClick={copy} className={className} title={label} aria-label={label}>
          {inner}
        </button>
      );
    }

    return (
      <a
        key={link.key}
        href={link.href}
        target="_blank"
        rel="noopener noreferrer"
        className={className}
        title={label}
        aria-label={label}
      >
        {inner}
      </a>
    );
  }

  if (variant === "rail") {
    return (
      <aside
        className="ui-sans sticky top-24 hidden lg:flex lg:flex-col lg:items-center lg:gap-2.5"
        aria-label={lang === "ur" ? "شیئر کریں" : "Share"}
      >
        <span className="mb-1 text-[10px] font-bold uppercase tracking-wide text-[var(--muted)]">
          {lang === "ur" ? "شیئر" : "Share"}
        </span>
        {links.map((link) =>
          renderItem(link, { large: link.key === "whatsapp", showLabel: false }),
        )}
      </aside>
    );
  }

  // Default BBC-style horizontal bar — labels + WhatsApp center emphasis
  return (
    <div
      className="ui-sans rounded-xl border border-[var(--line)] bg-[rgba(255,252,246,0.95)] px-3 py-3 sm:px-4"
      aria-label={lang === "ur" ? "شیئر کریں" : "Share"}
    >
      <div className="mb-2 text-xs font-bold uppercase tracking-wide text-[var(--muted)]">
        {lang === "ur" ? "اس خبر کو شیئر کریں" : "Share this story"}
      </div>
      <div className="flex flex-wrap items-center justify-center gap-2 sm:justify-start sm:gap-3">
        {links.map((link) =>
          renderItem(link, {
            large: link.key === "whatsapp",
            showLabel: true,
          }),
        )}
      </div>
    </div>
  );
}
