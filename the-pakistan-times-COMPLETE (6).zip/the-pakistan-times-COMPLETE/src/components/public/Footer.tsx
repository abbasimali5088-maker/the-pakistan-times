import Link from "next/link";
import type { Lang } from "@/lib/language";
import { brandName } from "@/lib/language";
import type { SocialKey } from "@/lib/site-settings";
import { Newsletter } from "./Newsletter";
import { SocialLinks } from "./SocialLinks";

const LEGAL = [
  { href: "/app", ur: "موبائل ایپ", en: "Mobile app" },
  { href: "/about", ur: "ہمارے بارے میں", en: "About" },
  { href: "/contact", ur: "رابطہ", en: "Contact" },
  { href: "/feed.xml", ur: "آر ایس ایس", en: "RSS feed" },
  { href: "/privacy", ur: "پرائیویسی", en: "Privacy" },
  { href: "/terms", ur: "شرائط", en: "Terms" },
  { href: "/disclaimer", ur: "ڈس کلیمر", en: "Disclaimer" },
  { href: "/editorial-policy", ur: "ادارتی پالیسی", en: "Editorial policy" },
  { href: "/corrections", ur: "تصحیحات", en: "Corrections" },
];

export type FooterSiteSettings = {
  aboutUr?: string;
  aboutEn?: string;
  copyrightUr?: string;
  copyrightEn?: string;
  contactEmail?: string;
  contactPhone?: string;
  social?: Partial<Record<SocialKey, string>>;
};

export function Footer({
  lang,
  site,
}: {
  lang: Lang;
  site?: FooterSiteSettings;
}) {
  const brand = brandName(lang);
  const about =
    lang === "ur"
      ? site?.aboutUr || "دی پاکستان ٹائمز اردو — آزاد صحافت، قومی اور عالمی کوریج۔"
      : site?.aboutEn ||
        "The Pakistan Times — independent journalism covering Pakistan and the world.";
  const copyright =
    lang === "ur"
      ? site?.copyrightUr || `© ${new Date().getFullYear()} ${brand}`
      : site?.copyrightEn || `© ${new Date().getFullYear()} ${brand}`;

  return (
    <footer className="mt-auto bg-[var(--masthead-red)] text-[#e8f5ec]">
      <div className="mx-auto grid max-w-[var(--maxw)] gap-8 px-4 py-10 md:grid-cols-[1.2fr_1fr]">
        <div>
          <p className="brand-lockup mb-3 text-2xl text-white">{brand}</p>
          <p className="max-w-md text-sm leading-relaxed text-white/75">{about}</p>
          {site?.contactEmail || site?.contactPhone ? (
            <p className="meta mt-3 text-white/65">
              {site.contactEmail ? (
                <a className="hover:text-white" href={`mailto:${site.contactEmail}`}>
                  {site.contactEmail}
                </a>
              ) : null}
              {site.contactEmail && site.contactPhone ? " · " : null}
              {site.contactPhone ? (
                <a className="hover:text-white" href={`tel:${site.contactPhone.replace(/\s+/g, "")}`}>
                  {site.contactPhone}
                </a>
              ) : null}
            </p>
          ) : null}
          <SocialLinks lang={lang} social={site?.social} />
          <div className="mt-6">
            <Newsletter lang={lang} />
          </div>
        </div>
        <div>
          <p className="ui-sans mb-3 text-sm font-bold uppercase tracking-wide text-white">
            {lang === "ur" ? "ادارہ" : "Organization"}
          </p>
          <ul className="ui-sans grid grid-cols-2 gap-2 text-sm">
            {LEGAL.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="hover:text-white">
                  {lang === "ur" ? item.ur : item.en}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="border-t border-white/15 px-4 py-4 text-center text-xs text-white/60">
        {copyright}
      </div>
    </footer>
  );
}
