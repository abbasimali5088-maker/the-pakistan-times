"use client";

import { useMemo, useState } from "react";
import { stripOversizedDataUris } from "@/lib/article-html";

/**
 * One hero image on the article page only.
 * Always strip <img>/<figure> from body so مزید پڑھیں never reveals a second photo.
 */
function stripBodyImages(html: string) {
  let out = html;
  out = out.replace(/<figure\b[^>]*>[\s\S]*?<\/figure>/gi, "");
  out = out.replace(/<img\b[^>]*>/gi, "");
  out = out.replace(/<p>\s*(?:&nbsp;|\s)*<\/p>/gi, "");
  return out;
}

/**
 * Article body:
 * - Summary always visible (theme-green خلاصہ label)
 * - "مکمل خبر / تجزیہ" fused to مزید پڑھیں (theme green, no red)
 * - Expanded body never re-shows images
 */
export function ArticleBody({
  lang,
  html,
  excerpt,
  textOnly = false,
}: {
  lang: "ur" | "en";
  html: string;
  excerpt?: string;
  textOnly?: boolean;
  /** @deprecated kept for call-site compat; images always stripped */
  featuredImageUrl?: string | null;
}) {
  const full = useMemo(() => {
    const cleaned = stripOversizedDataUris((html || "").trim());
    return stripBodyImages(cleaned);
  }, [html]);
  const summary = (excerpt || "").trim();
  const [expanded, setExpanded] = useState(false);

  const plainFull = useMemo(
    () =>
      full
        .replace(/<[^>]+>/g, " ")
        .replace(/\s+/g, " ")
        .trim(),
    [full],
  );

  if (!full && summary) {
    return (
      <div className="article-body-stack bg-[var(--surface)]">
        <p className="summary-label ui-sans">
          {lang === "ur" ? "خلاصہ" : "Summary"}
        </p>
        <p className="mb-0 text-lg leading-relaxed text-[#141414]">{summary}</p>
      </div>
    );
  }

  if (!full) {
    return (
      <p className="text-[#5a5a5a]">
        {lang === "ur" ? "اس خبر کا مکمل متن ابھی دستیاب نہیں۔" : "Full article text is not available yet."}
      </p>
    );
  }

  const needsToggle = Boolean(summary) || plainFull.length > 320;
  const showFull = expanded || !needsToggle;

  return (
    <div className="article-body-stack bg-[var(--surface)]">
      {summary ? (
        <div className="mb-5 border-b border-[#eee] pb-5">
          <p className="summary-label ui-sans">
            {lang === "ur" ? "خلاصہ" : "Summary"}
          </p>
          <p className="text-lg leading-[1.9] text-[#141414] sm:text-xl">{summary}</p>
        </div>
      ) : null}

      {!showFull ? (
        <div className="read-more-stack">
          {summary ? (
            <div
              className="ui-sans select-none border border-[var(--accent)] border-b-0 bg-[var(--accent-soft)] px-4 py-2.5 text-center text-sm font-bold uppercase tracking-[0.12em] text-[var(--accent-deep)]"
              aria-hidden
            >
              {lang === "ur" ? "مکمل خبر / تجزیہ" : "Full analysis"}
            </div>
          ) : null}
          <button
            type="button"
            onClick={() => setExpanded(true)}
            className="read-more-cta ui-sans inline-flex w-full items-center justify-center gap-2 border border-[var(--accent)] bg-[var(--accent)] px-4 py-3.5 text-lg font-extrabold text-white transition hover:bg-[var(--accent-deep)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)] focus-visible:ring-offset-2"
          >
            {lang === "ur" ? "مزید پڑھیں ←" : "Read more →"}
          </button>
        </div>
      ) : (
        <div
          className={`prose-article ${summary ? "mt-3" : "mt-0"} ${textOnly ? "[&_img]:hidden [&_figure]:hidden [&_iframe]:hidden" : ""} [&_img]:hidden [&_figure]:hidden`}
          dangerouslySetInnerHTML={{ __html: full }}
        />
      )}
    </div>
  );
}
