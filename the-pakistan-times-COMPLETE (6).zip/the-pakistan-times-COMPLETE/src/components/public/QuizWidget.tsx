"use client";

import { useState } from "react";
import type { Lang } from "@/lib/language";

export type PublicQuizQuestion = {
  id: string;
  question: string;
  options: string[];
  sortOrder?: number;
};

export type PublicQuiz = {
  id: string;
  title: string;
  description?: string | null;
  questions: PublicQuizQuestion[];
};

type AttemptResult = {
  score: number;
  total: number;
  results: Array<{
    questionId: string;
    correct: boolean;
    correctIndex: number;
    explanation?: string | null;
  }>;
};

export function QuizWidget({
  quiz,
  lang,
}: {
  quiz: PublicQuiz;
  lang: Lang;
}) {
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AttemptResult | null>(null);

  const allAnswered =
    quiz.questions.length > 0 &&
    quiz.questions.every((q) => typeof answers[q.id] === "number");

  async function submit() {
    if (!allAnswered || busy || result) return;
    setBusy(true);
    setError(null);
    try {
      const ordered = quiz.questions.map((q) => answers[q.id] ?? -1);
      const res = await fetch(`/api/quizzes/${quiz.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "attempt", answers: ordered }),
      });
      const json = await res.json();
      if (!res.ok || json.success === false) {
        throw new Error(json.error || "Submit failed");
      }
      const data = (json.data || json) as AttemptResult;
      setResult(data);
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : lang === "ur"
            ? "جمع نہیں ہوا"
            : "Could not submit quiz",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="my-6 overflow-hidden border border-[var(--line)] bg-[var(--surface)]">
      <div className="border-b border-[var(--line)] bg-[var(--accent-soft)] px-4 py-2.5">
        <h2 className="ui-sans text-sm font-extrabold uppercase tracking-wide text-[var(--accent-deep)]">
          {lang === "ur" ? "کوئز" : "Quiz"}
        </h2>
      </div>
      <div className="space-y-4 p-4">
        <div>
          <h3 className="text-lg font-bold leading-snug text-[var(--ink)] sm:text-xl">
            {quiz.title}
          </h3>
          {quiz.description ? (
            <p className="mt-1 text-sm text-[var(--muted)]">{quiz.description}</p>
          ) : null}
        </div>

        {quiz.questions.map((q, qi) => {
          const outcome = result?.results.find((r) => r.questionId === q.id);
          return (
            <fieldset key={q.id} className="space-y-2 border-t border-[var(--line)] pt-4">
              <legend className="mb-2 text-sm font-semibold text-[var(--ink)] sm:text-base">
                {qi + 1}. {q.question}
              </legend>
              <div className="space-y-2">
                {q.options.map((opt, oi) => {
                  const chosen = answers[q.id] === oi;
                  let ring = "border-[var(--line)]";
                  if (result && outcome) {
                    if (oi === outcome.correctIndex) ring = "border-[var(--accent)] bg-[var(--accent-soft)]";
                    else if (chosen && !outcome.correct) ring = "border-slate-400 bg-slate-100";
                  } else if (chosen) {
                    ring = "border-[var(--accent)] bg-[var(--accent-soft)]";
                  }
                  return (
                    <button
                      key={`${q.id}-${oi}`}
                      type="button"
                      disabled={Boolean(result) || busy}
                      onClick={() => setAnswers((prev) => ({ ...prev, [q.id]: oi }))}
                      className={`flex min-h-11 w-full items-start gap-3 border px-3 py-2.5 text-start text-sm ${ring}`}
                    >
                      <span className="ui-sans mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center border border-current text-[11px] font-bold">
                        {String.fromCharCode(65 + oi)}
                      </span>
                      <span>{opt}</span>
                    </button>
                  );
                })}
              </div>
              {outcome?.explanation ? (
                <p className="text-xs text-[var(--muted)]">{outcome.explanation}</p>
              ) : null}
            </fieldset>
          );
        })}

        {result ? (
          <p className="ui-sans rounded-md bg-[var(--accent-soft)] px-3 py-3 text-center text-base font-extrabold text-[var(--accent-deep)]">
            {lang === "ur"
              ? `سکور: ${result.score} / ${result.total}`
              : `Score: ${result.score} / ${result.total}`}
          </p>
        ) : (
          <button
            type="button"
            disabled={!allAnswered || busy}
            onClick={() => void submit()}
            className="ui-sans min-h-11 w-full bg-[var(--accent)] px-4 py-2.5 text-sm font-extrabold text-white hover:bg-[var(--accent-deep)] disabled:opacity-50"
          >
            {busy
              ? "…"
              : lang === "ur"
                ? "جوابات جمع کریں"
                : "Submit answers"}
          </button>
        )}
        {error ? (
          <p className="text-sm text-[var(--accent-deep)]" role="alert">
            {error}
          </p>
        ) : null}
      </div>
    </section>
  );
}
