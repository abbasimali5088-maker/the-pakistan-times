import Link from "next/link";
import type { Lang } from "@/lib/language";
import { localizeArticle } from "@/lib/language";
import type { PublicArticle } from "@/lib/public-types";
import { ArticleCard } from "./ArticleCard";
import { TimeBadge } from "./TimeBadge";

/**
 * BBC-style top block: large lead story + stacked secondary stories
 * (title → summary → time → مزید پڑھیں).
 */
export function FeaturedStory({
  article,
  sideStories = [],
  lang,
}: {
  article: PublicArticle | null;
  sideStories?: PublicArticle[];
  lang: Lang;
}) {
  if (!article) return null;

  return (
    <section className="fade-in mb-10 border-b border-[var(--line)] pb-8">
      <div className="grid gap-8 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)] lg:gap-10">
        <div className="min-w-0">
          <ArticleCard article={article} lang={lang} variant="featured" />
        </div>

        {sideStories.length > 0 ? (
          <div className="flex min-w-0 flex-col divide-y divide-[var(--line)] border-t border-[var(--line)] lg:border-t-0">
            <p className="ui-sans mb-1 pt-1 text-[11px] font-bold uppercase tracking-[0.14em] text-[var(--accent)]">
              {lang === "ur" ? "اہم خبریں" : "Top stories"}
            </p>
            {sideStories.map((story) => {
              const a = localizeArticle(story, lang);
              const href = story.href || `/${story.slug}`;
              return (
                <article key={story.id} className="min-w-0 py-4 first:pt-2">
                  {a.displayCategory ? (
                    <p className="ui-sans mb-1 text-[11px] font-bold uppercase tracking-wide text-[var(--accent)]">
                      {a.displayCategory}
                    </p>
                  ) : null}
                  <h3 className="break-words text-lg leading-snug sm:text-xl">
                    <Link href={href} className="hover:text-[var(--accent)]">
                      {a.displayTitle}
                    </Link>
                  </h3>
                  {a.displayExcerpt ? (
                    <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-[var(--muted)]">
                      {a.displayExcerpt}
                    </p>
                  ) : null}
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <TimeBadge value={story.publishedAt || story.publishAt} lang={lang} />
                    <Link
                      href={href}
                      className="read-more-link ui-sans inline-flex items-center gap-1 bg-[var(--accent)] px-4 py-2.5 text-base font-extrabold tracking-wide text-white hover:bg-[var(--accent-deep)] hover:text-white"
                    >
                      {lang === "ur" ? "مزید پڑھیں ←" : "Read more →"}
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        ) : null}
      </div>
    </section>
  );
}
