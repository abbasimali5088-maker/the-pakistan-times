import Link from "next/link";
import type { Lang } from "@/lib/language";
import { localizeArticle } from "@/lib/language";
import type { PublicArticle } from "@/lib/public-types";
import { TimeBadge } from "./TimeBadge";

/**
 * LIVE strip at the TOP of the article stream.
 * Green ring + pulsing red core (BBC-style beacon, theme border).
 */
export function LiveStreamBlock({
  articles,
  lang,
}: {
  articles: PublicArticle[];
  lang: Lang;
}) {
  if (!articles.length) return null;

  const heading = lang === "ur" ? "لائیو" : "Live";
  const more = lang === "ur" ? "تمام لائیو کوریج" : "All live coverage";

  return (
    <section
      className="live-stream mb-8 border border-[var(--line)] bg-white"
      aria-label={heading}
      id="live-stream"
    >
      <div className="flex items-center justify-between gap-3 border-b border-[var(--line)] bg-[var(--accent-soft)] px-4 py-3.5">
        <div className="flex items-center gap-3">
          <span className="live-beacon live-beacon--lg" aria-hidden>
            <span className="live-beacon__ping" />
            <span className="live-beacon__dot" />
          </span>
          <h2 className="ui-sans m-0 text-base font-black uppercase tracking-[0.16em] text-[var(--accent-deep)]">
            {heading}
          </h2>
        </div>
        <Link
          href={lang === "en" ? "/live?lang=en" : "/live?lang=ur"}
          className="ui-sans text-sm font-bold text-[var(--accent-deep)] hover:underline"
        >
          {more}
        </Link>
      </div>

      <ul className="divide-y divide-[var(--line)]">
        {articles
          .filter((article) => article.language === lang)
          .map((article) => {
          const a = localizeArticle(article, lang);
          if (!a.displayTitle?.trim()) return null;
          const href = article.href || `/${article.slug}`;
          return (
            <li key={article.id} className="live-stream__item">
              <Link
                href={href}
                className="flex items-start gap-3 px-4 py-3.5 transition hover:bg-[var(--accent-soft)]"
              >
                <span className="live-beacon mt-1 shrink-0" aria-hidden>
                  <span className="live-beacon__ping" />
                  <span className="live-beacon__dot" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="ui-sans mb-1 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-[var(--accent-deep)]">
                    {lang === "ur" ? "لائیو" : "LIVE"}
                    {a.displayCategory ? (
                      <span className="font-semibold normal-case tracking-normal text-[var(--muted)]">
                        {a.displayCategory}
                      </span>
                    ) : null}
                  </span>
                  <span className="block text-base font-semibold leading-snug text-[var(--ink)] sm:text-lg">
                    {a.displayTitle}
                  </span>
                  {a.displayExcerpt ? (
                    <span className="mt-1 block line-clamp-2 text-sm leading-relaxed text-[var(--muted)]">
                      {a.displayExcerpt}
                    </span>
                  ) : null}
                  <span className="mt-2 block">
                    <TimeBadge value={article.publishedAt || article.publishAt} lang={lang} />
                  </span>
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
