"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { Lang } from "@/lib/language";
import { pickText } from "@/lib/language";
import type { MenuItem, PublicCategory } from "@/lib/public-types";
import { SearchBox } from "./SearchBox";

function normalizeMenuUrl(url: string, categories: PublicCategory[]) {
  if (!url || url === "/") return url || "/";
  if (
    url.startsWith("/category/") ||
    url.startsWith("http") ||
    url.startsWith("/live") ||
    url.startsWith("/videos") ||
    url.startsWith("/galleries") ||
    url.startsWith("/latest") ||
    url.startsWith("/breaking") ||
    url.startsWith("/search") ||
    url.startsWith("/about") ||
    url.startsWith("/contact") ||
    url.startsWith("/author") ||
    url.startsWith("/tag")
  ) {
    return url;
  }
  const slug = url.replace(/^\//, "").split("/")[0];
  if (categories.some((c) => c.slug === slug)) return `/category/${slug}`;
  return url;
}

function categoryLabel(lang: Lang, c: PublicCategory) {
  // Locale trees: UR rows store Urdu in `name`/`nameUr`; EN rows store English in `name`.
  if (lang === "ur") return (c.nameUr || c.name || "").trim();
  return (c.nameEn || c.name || "").trim();
}

export function Navigation({
  lang,
  items,
  categories,
}: {
  lang: Lang;
  items: MenuItem[];
  categories: PublicCategory[];
  pathname?: string;
}) {
  const pathname = usePathname() || "/";

  const topCats = categories
    .filter((c) => !(c as { parentId?: string | null }).parentId)
    .slice(0, 8);

  const catBySlug = new Map(topCats.map((c) => [c.slug, c]));

  // Prefer DB category labels for /category/* links so EN/UR never mix.
  const fromMenu =
    items.length > 0
      ? items.map((item) => {
          const href = normalizeMenuUrl(item.url, categories);
          const slug = href.startsWith("/category/") ? href.split("/")[2] : null;
          const cat = slug ? catBySlug.get(slug) : undefined;
          const label = cat
            ? categoryLabel(lang, cat)
            : pickText(lang, item.labelUr, item.labelEn || item.label, "");
          return { href, label };
        })
      : null;

  const defaults = [
    { href: "/", label: lang === "ur" ? "ہوم" : "Home" },
    { href: "/latest", label: lang === "ur" ? "تازہ ترین" : "Latest" },
    ...topCats.map((c) => ({
      href: `/category/${c.slug}`,
      label: categoryLabel(lang, c),
    })),
    { href: "/videos", label: lang === "ur" ? "ویڈیوز" : "Videos" },
    { href: "/galleries", label: lang === "ur" ? "تصاویر" : "Galleries" },
    { href: "/live", label: lang === "ur" ? "لائیو" : "Live" },
  ];

  // If DB menu labels are wrong-language / empty for this locale, use defaults
  // so EN chrome never appears on Urdu (and vice versa).
  const menuLooksValid =
    fromMenu &&
    fromMenu.filter((l) => l.label.trim()).length >= Math.min(3, fromMenu.length) &&
    (lang !== "ur" ||
      fromMenu.some((l) => /[\u0600-\u06FF]/.test(l.label)) ||
      fromMenu.every((l) => !/Home|Latest|Videos|Live|News/i.test(l.label)));

  const links = menuLooksValid ? fromMenu! : defaults;

  return (
    <nav className="bg-[var(--masthead-red)]" aria-label={lang === "ur" ? "مرکزی مینو" : "Main"}>
      <div className="mx-auto flex max-w-[var(--maxw)] items-center gap-2 overflow-x-auto px-3">
        <ul className="flex min-w-0 flex-1 items-center">
          {links.map((link) => {
            const active =
              link.href === "/"
                ? pathname === "/"
                : pathname === link.href || pathname.startsWith(`${link.href}/`);
            return (
              <li key={link.href + link.label}>
                <Link
                  href={link.href}
                  className="nav-link whitespace-nowrap"
                  aria-current={active ? "page" : undefined}
                >
                  {link.label}
                </Link>
              </li>
            );
          })}
        </ul>
        <div className="hidden shrink-0 py-2 md:block">
          <SearchBox lang={lang} compact />
        </div>
      </div>
    </nav>
  );
}
