"use client";

import { useEffect, useState } from "react";
import type { Lang } from "@/lib/language";

const DISMISS_KEY = "pt-push-optin-dismissed";

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; i++) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}

/**
 * A small dismissible prompt inviting visitors to enable breaking-news
 * push alerts. Renders nothing if the browser doesn't support push, the
 * site hasn't configured a VAPID public key yet, or the user already
 * granted/denied/dismissed it.
 */
export function PushOptIn({ lang }: { lang: Lang }) {
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const vapidPublicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!vapidPublicKey) return;
    if (!("Notification" in window) || !("serviceWorker" in navigator) || !("PushManager" in window)) return;
    if (Notification.permission !== "default") return;
    if (window.localStorage.getItem(DISMISS_KEY) === "1") return;
    setVisible(true);
  }, [vapidPublicKey]);

  async function subscribe() {
    setBusy(true);
    try {
      const permission = await Notification.requestPermission();
      if (permission !== "granted") {
        setVisible(false);
        return;
      }
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublicKey!) as BufferSource,
      });
      const json = sub.toJSON();
      await fetch("/api/push/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          endpoint: json.endpoint,
          keys: json.keys,
          lang,
        }),
      });
    } catch (err) {
      console.warn("[push] subscribe failed", err);
    } finally {
      setVisible(false);
      setBusy(false);
    }
  }

  function dismiss() {
    window.localStorage.setItem(DISMISS_KEY, "1");
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div
      className="ui-sans fixed inset-x-3 bottom-3 z-50 mx-auto flex max-w-md items-center gap-3 rounded-xl border border-[var(--line)] bg-[var(--surface)] p-3 shadow-lg sm:inset-x-auto sm:right-4"
      role="dialog"
      aria-label={lang === "ur" ? "بریکنگ نیوز الرٹس" : "Breaking news alerts"}
    >
      <span className="live-beacon live-beacon--sm shrink-0" aria-hidden />
      <p className="min-w-0 flex-1 text-sm text-[var(--ink)]">
        {lang === "ur"
          ? "بریکنگ نیوز کی فوری اطلاع پائیں؟"
          : "Get instant alerts for breaking news?"}
      </p>
      <button
        type="button"
        onClick={subscribe}
        disabled={busy}
        className="btn shrink-0 px-3 py-1.5 text-sm"
      >
        {lang === "ur" ? "فعال کریں" : "Enable"}
      </button>
      <button
        type="button"
        onClick={dismiss}
        aria-label={lang === "ur" ? "بند کریں" : "Dismiss"}
        className="shrink-0 px-1 text-[var(--muted)]"
      >
        ✕
      </button>
    </div>
  );
}
