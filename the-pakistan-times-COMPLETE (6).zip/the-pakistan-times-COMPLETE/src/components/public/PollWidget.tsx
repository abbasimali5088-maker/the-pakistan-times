"use client";

import { useEffect, useMemo, useState } from "react";
import type { Lang } from "@/lib/language";

export type PublicPollOption = {
  id: string;
  label: string;
  votes: number;
};

export type PublicPoll = {
  id: string;
  question: string;
  options: PublicPollOption[];
  _count?: { votes?: number };
};

function voterKeyStorage(pollId: string) {
  return `pt_poll_vote_${pollId}`;
}

function makeVoterKey() {
  try {
    const existing = localStorage.getItem("pt_voter_key");
    if (existing) return existing;
    const key =
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `v_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    localStorage.setItem("pt_voter_key", key);
    return key;
  } catch {
    return `v_${Date.now()}`;
  }
}

export function PollWidget({
  poll: initial,
  lang,
}: {
  poll: PublicPoll;
  lang: Lang;
}) {
  const [poll, setPoll] = useState(initial);
  const [selected, setSelected] = useState<string | null>(null);
  const [voted, setVoted] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      if (localStorage.getItem(voterKeyStorage(poll.id))) setVoted(true);
    } catch {
      /* ignore */
    }
  }, [poll.id]);

  const total = useMemo(
    () => poll.options.reduce((sum, o) => sum + (o.votes || 0), 0),
    [poll.options],
  );

  async function submit() {
    if (!selected || voted || busy) return;
    setBusy(true);
    setError(null);
    try {
      const voterKey = makeVoterKey();
      const res = await fetch(`/api/polls/${poll.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "vote", optionId: selected, voterKey }),
      });
      const json = await res.json();
      if (!res.ok || json.success === false) {
        throw new Error(json.error || "Vote failed");
      }
      const data = (json.data || json) as PublicPoll;
      setPoll({
        id: data.id,
        question: data.question,
        options: data.options || [],
        _count: data._count,
      });
      try {
        localStorage.setItem(voterKeyStorage(poll.id), selected);
      } catch {
        /* ignore */
      }
      setVoted(true);
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : lang === "ur"
            ? "ووٹ نہیں ہوا"
            : "Could not submit vote",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="my-6 overflow-hidden border border-[var(--line)] bg-[var(--surface)]">
      <div className="border-b border-[var(--line)] bg-[var(--accent-soft)] px-4 py-2.5">
        <h2 className="ui-sans text-sm font-extrabold uppercase tracking-wide text-[var(--accent-deep)]">
          {lang === "ur" ? "رائے شماری" : "Poll"}
        </h2>
      </div>
      <div className="space-y-3 p-4">
        <p className="text-base font-semibold leading-snug text-[var(--ink)] sm:text-lg">
          {poll.question}
        </p>
        <ul className="space-y-2">
          {poll.options.map((opt) => {
            const pct = total > 0 ? Math.round((opt.votes / total) * 100) : 0;
            const isSel = selected === opt.id;
            return (
              <li key={opt.id}>
                {voted ? (
                  <div className="relative overflow-hidden border border-[var(--line)] bg-[var(--paper-deep)] px-3 py-2.5">
                    <div
                      className="absolute inset-y-0 start-0 bg-[var(--accent-soft)]"
                      style={{ width: `${pct}%` }}
                      aria-hidden
                    />
                    <div className="relative flex items-center justify-between gap-2 text-sm">
                      <span>{opt.label}</span>
                      <span className="ui-sans shrink-0 font-bold text-[var(--accent-deep)]">
                        {pct}%
                      </span>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setSelected(opt.id)}
                    className={`flex min-h-11 w-full items-center gap-3 border px-3 py-2.5 text-start text-sm transition ${
                      isSel
                        ? "border-[var(--accent)] bg-[var(--accent-soft)]"
                        : "border-[var(--line)] hover:border-[var(--accent)]"
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 shrink-0 rounded-full border-2 ${
                        isSel ? "border-[var(--accent)] bg-[var(--accent)]" : "border-slate-300"
                      }`}
                      aria-hidden
                    />
                    {opt.label}
                  </button>
                )}
              </li>
            );
          })}
        </ul>
        {!voted ? (
          <button
            type="button"
            disabled={!selected || busy}
            onClick={() => void submit()}
            className="ui-sans min-h-11 w-full bg-[var(--accent)] px-4 py-2.5 text-sm font-extrabold text-white hover:bg-[var(--accent-deep)] disabled:opacity-50"
          >
            {busy
              ? "…"
              : lang === "ur"
                ? "ووٹ دیں"
                : "Vote"}
          </button>
        ) : (
          <p className="meta text-center">
            {lang === "ur"
              ? `کل ووٹ: ${total}`
              : `${total} total vote${total === 1 ? "" : "s"}`}
          </p>
        )}
        {error ? (
          <p className="text-sm text-[var(--accent-deep)]" role="alert">
            {error}
          </p>
        ) : null}
      </div>
    </section>
  );
}
