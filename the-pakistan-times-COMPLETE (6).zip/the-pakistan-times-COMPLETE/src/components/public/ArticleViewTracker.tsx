"use client";

import { useEffect, useRef } from "react";
import { parseUserAgent } from "@/lib/analytics-ua";

const VISITOR_KEY = "pt_vid";
const VIEWED_PREFIX = "pt_av:";

function getVisitorId(): string {
  try {
    let id = localStorage.getItem(VISITOR_KEY);
    if (!id) {
      id =
        typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `v_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
      localStorage.setItem(VISITOR_KEY, id);
    }
    return id;
  } catch {
    return `anon_${Date.now()}`;
  }
}

function clientHints() {
  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
  const parsed = parseUserAgent(ua);
  return {
    device: parsed.os,
    browser: parsed.browser,
    ua,
    language: typeof navigator !== "undefined" ? navigator.language : null,
  };
}

/**
 * Records a unique article page view (once per visitor per article per 12h session gate).
 * Increments Article.viewCount via /api/analytics when accepted.
 */
export function ArticleViewTracker({
  articleId,
  slug,
}: {
  articleId: string;
  slug: string;
}) {
  const sent = useRef(false);

  useEffect(() => {
    if (!articleId || sent.current) return;
    if (typeof window === "undefined") return;

    const gateKey = `${VIEWED_PREFIX}${articleId}`;
    try {
      if (sessionStorage.getItem(gateKey) === "1") return;
    } catch {
      /* continue — still try server dedupe */
    }

    sent.current = true;
    const visitor = getVisitorId();
    const hints = clientHints();
    const t = window.setTimeout(() => {
      void fetch("/api/analytics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          eventType: "article_view",
          articleId,
          path: `/${slug}`,
          referrer: document.referrer || null,
          source: "web",
          device: hints.device,
          browser: hints.browser,
          meta: { visitor, ua: hints.ua.slice(0, 220), lang: hints.language },
        }),
        keepalive: true,
      })
        .then(async (res) => {
          const json = (await res.json().catch(() => null)) as
            | { success?: boolean; data?: { recorded?: boolean; skipped?: boolean } }
            | null;
          if (json?.data?.recorded) {
            try {
              sessionStorage.setItem(gateKey, "1");
            } catch {
              /* ignore */
            }
          }
        })
        .catch(() => {
          /* ignore */
        });
    }, 500);

    return () => window.clearTimeout(t);
  }, [articleId, slug]);

  return null;
}
