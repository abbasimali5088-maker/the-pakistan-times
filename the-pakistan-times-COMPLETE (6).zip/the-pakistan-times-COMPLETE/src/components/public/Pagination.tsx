import Link from "next/link";
import type { Lang } from "@/lib/language";

export function Pagination({
  page,
  totalPages,
  lang,
  basePath,
  query = {},
}: {
  page: number;
  totalPages: number;
  lang: Lang;
  basePath: string;
  query?: Record<string, string>;
}) {
  if (totalPages <= 1) return null;

  function href(p: number) {
    const sp = new URLSearchParams({ ...query, lang });
    sp.set("page", String(p));
    const q = sp.toString();
    return `${basePath}?${q}`;
  }

  return (
    <nav
      className="ui-sans mt-8 flex flex-wrap items-center justify-center gap-2 sm:gap-3"
      aria-label="Pagination"
    >
      {page > 1 ? (
        <Link href={href(page - 1)} className="btn-ghost btn min-h-11 px-4">
          {lang === "ur" ? "پچھلا" : "Previous"}
        </Link>
      ) : (
        <span className="btn btn-ghost min-h-11 px-4 opacity-40">
          {lang === "ur" ? "پچھلا" : "Previous"}
        </span>
      )}
      <span className="meta px-1 text-center">
        {lang === "ur" ? `صفحہ ${page} از ${totalPages}` : `Page ${page} of ${totalPages}`}
      </span>
      {page < totalPages ? (
        <Link href={href(page + 1)} className="btn min-h-11 px-4">
          {lang === "ur" ? "اگلا" : "Next"}
        </Link>
      ) : (
        <span className="btn min-h-11 px-4 opacity-40">{lang === "ur" ? "اگلا" : "Next"}</span>
      )}
    </nav>
  );
}
