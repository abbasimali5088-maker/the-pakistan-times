import Link from "next/link";
import type { Lang } from "@/lib/language";
import { brandName } from "@/lib/language";
import type { MenuItem, PublicCategory } from "@/lib/public-types";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { Navigation } from "./Navigation";
import { SearchBox } from "./SearchBox";
import { ThemeToggle } from "./ThemeToggle";

/**
 * BBC-style masthead. LIVE coverage lives in the article stream
 * (LiveStreamBlock), not as a dead utility-bar button.
 */
export function Header({
  lang,
  menuItems,
  categories,
  taglineUr,
  taglineEn,
  langLocked,
  alternateUrl,
  alternateLabel,
}: {
  lang: Lang;
  menuItems: MenuItem[];
  categories: PublicCategory[];
  taglineUr?: string;
  taglineEn?: string;
  langLocked?: boolean;
  alternateUrl?: string | null;
  alternateLabel?: string | null;
  /** @deprecated LIVE is rendered in the feed stream, not the masthead. */
  liveActive?: boolean;
  social?: unknown;
}) {
  const brand = brandName(lang);
  const newsWord = lang === "ur" ? "خبریں" : "NEWS";
  const tagline =
    lang === "ur"
      ? taglineUr || "آزاد، حقیقت پر مبنی صحافت"
      : taglineEn || "Independent reporting from the newsroom";

  return (
    <header className="site-header">
      <div className="flex items-center justify-between gap-3 bg-[var(--masthead-red)] px-3 py-2 text-xs text-white/90 ui-sans sm:px-4">
        <span className="min-w-0 truncate">
          {lang === "ur" ? "پاکستان اور دنیا سے تازہ خبریں" : "Pakistan & world news desk"}
        </span>
        <div className="ms-auto flex shrink-0 items-center gap-2 sm:gap-3">
          <ThemeToggle />
          <LanguageSwitcher
            lang={lang}
            locked={langLocked}
            alternateUrl={alternateUrl}
            alternateLabel={alternateLabel}
          />
        </div>
      </div>

      <div className="border-b border-[var(--line)] bg-[rgba(255,252,246,0.88)] px-3 py-4 text-center sm:px-4 sm:py-5">
        <Link href="/" className="brand-lockup inline-block max-w-full text-[var(--ink)]">
          <span className="text-[var(--accent)]">{brand}</span>
        </Link>
        <p className="meta mx-auto mt-2 max-w-xl px-1">{tagline}</p>
      </div>

      <div className="bg-[var(--accent)] text-white">
        <div className="mx-auto flex max-w-[var(--maxw)] items-center justify-between gap-2 px-3 py-2.5 sm:gap-3 sm:px-4 sm:py-3">
          <span className="ui-sans text-lg font-black tracking-wide sm:text-xl">{newsWord}</span>
          <div className="min-w-0 md:hidden">
            <SearchBox lang={lang} compact />
          </div>
        </div>
      </div>

      <Navigation lang={lang} items={menuItems} categories={categories} />
    </header>
  );
}
