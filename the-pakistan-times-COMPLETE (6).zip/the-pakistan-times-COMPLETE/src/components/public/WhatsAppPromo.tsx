import type { Lang } from "@/lib/language";

const BRAND_GREEN = "#1DB954";

/**
 * WhatsApp CTA — always brand green background + white copy.
 * Uses configured WhatsApp URL from site settings (never invents a random link).
 */
export function WhatsAppPromo({
  lang,
  href,
}: {
  lang: Lang;
  href?: string | null;
}) {
  const link = (href || "").trim();
  if (!link) return null;

  return (
    <section
      className="whatsapp-promo my-10 overflow-hidden rounded-sm"
      style={{ backgroundColor: BRAND_GREEN, color: "#ffffff" }}
      aria-label={lang === "ur" ? "واٹس ایپ" : "WhatsApp"}
    >
      <div className="px-5 py-8 text-center sm:px-8 sm:py-10" style={{ color: "#ffffff" }}>
        <h2
          className="text-2xl font-bold leading-snug sm:text-3xl"
          style={{ color: "#ffffff", margin: 0 }}
        >
          {lang === "ur"
            ? "دی پاکستان ٹائمز اب واٹس ایپ پر"
            : "The Pakistan Times is now on WhatsApp"}
        </h2>
        <p
          className="mx-auto mt-3 max-w-xl text-sm leading-relaxed sm:text-base"
          style={{ color: "#ffffff", opacity: 0.95 }}
        >
          {lang === "ur"
            ? "اہم خبریں اور بریکنگ اپ ڈیٹس سیدھا اپنے فون پر حاصل کریں۔"
            : "Get top headlines and breaking updates straight to your phone."}
        </p>
        <div className="mx-auto mt-6 flex h-24 w-24 items-center justify-center rounded-3xl sm:h-28 sm:w-28"
          style={{ backgroundColor: "rgba(255,255,255,0.18)" }}
        >
          <span
            className="inline-flex h-14 w-14 items-center justify-center rounded-2xl sm:h-16 sm:w-16"
            style={{ backgroundColor: "#25D366", color: "#ffffff" }}
            aria-hidden
          >
            <svg viewBox="0 0 24 24" className="h-8 w-8 fill-current" aria-hidden>
              <path d="M12.04 2c-5.46 0-9.91 4.43-9.91 9.9 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.9-4.44 9.9-9.91C21.94 6.43 17.5 2 12.04 2zm5.79 14.13c-.24.68-1.4 1.25-1.93 1.33-.49.07-1.12.1-1.81-.11-.42-.13-.96-.31-1.65-.61-2.9-1.26-4.79-4.19-4.94-4.38-.14-.19-1.2-1.6-1.2-3.05 0-1.45.76-2.16 1.03-2.45.27-.29.59-.36.79-.36h.57c.18 0 .42-.07.66.5.24.59.82 2.01.89 2.15.07.14.12.31.02.5-.1.19-.14.31-.29.48-.14.17-.31.37-.44.5-.14.14-.29.29-.12.57.17.28.74 1.22 1.59 1.98 1.1.98 2.02 1.28 2.3 1.42.29.14.45.12.62-.07.17-.19.72-.84.91-1.13.19-.29.38-.24.64-.14.27.1 1.7.8 1.99.95.29.14.49.22.56.34.07.12.07.7-.17 1.38z" />
            </svg>
          </span>
        </div>
        <a
          href={link}
          target="_blank"
          rel="noopener noreferrer"
          className="ui-sans mt-6 inline-flex w-full max-w-md items-center justify-center gap-2 px-4 py-3.5 text-sm font-bold shadow-sm"
          style={{ backgroundColor: "#ffffff", color: BRAND_GREEN }}
        >
          <span aria-hidden>›</span>
          {lang === "ur" ? "سبسکرائب کرنے کے لیے کلک کریں" : "Click to subscribe"}
        </a>
      </div>
    </section>
  );
}
