"use client";

import Image from "next/image";

/** Renders remote or data: URLs safely (next/image rejects data URLs). */
export function CoverImage({
  src,
  alt,
  fill,
  className,
  sizes,
  priority,
  width,
  height,
}: {
  src: string;
  alt: string;
  fill?: boolean;
  className?: string;
  sizes?: string;
  priority?: boolean;
  width?: number;
  height?: number;
}) {
  if (src.startsWith("data:") || src.startsWith("blob:")) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={src}
        alt={alt}
        className={fill ? `absolute inset-0 h-full w-full ${className || ""}` : className}
        style={fill ? undefined : { width, height }}
      />
    );
  }

  if (fill) {
    return (
      <Image
        src={src}
        alt={alt}
        fill
        priority={priority}
        className={className}
        sizes={sizes}
      />
    );
  }

  return (
    <Image
      src={src}
      alt={alt}
      width={width || 800}
      height={height || 450}
      priority={priority}
      className={className}
      sizes={sizes}
    />
  );
}
