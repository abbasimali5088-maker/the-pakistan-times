"use client";

export function OwnerOpenBoth({
  frontUrl,
  backendUrl,
}: {
  frontUrl: string;
  backendUrl: string;
}) {
  function openBoth() {
    // Open backend first (user intent), then front after a tick — fewer popup blocks
    const back = window.open(backendUrl, "pt_backend");
    window.setTimeout(() => {
      window.open(frontUrl, "pt_front");
    }, 250);
    if (!back) {
      // Popup blocked — navigate this tab to backend
      window.location.assign(backendUrl);
    }
  }

  return (
    <button
      type="button"
      onClick={openBoth}
      className="w-full rounded-2xl border-2 border-[#111] bg-[#111] px-4 py-4 text-lg font-bold text-white transition hover:bg-black"
    >
      ① + ② دونوں ایک ساتھ کھولیں (Front سبز · Backend سیاہ)
    </button>
  );
}
