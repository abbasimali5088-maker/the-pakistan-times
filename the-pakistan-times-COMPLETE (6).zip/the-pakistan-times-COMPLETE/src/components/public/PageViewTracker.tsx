"use client";

import { useEffect, useRef } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import { parseUserAgent } from "@/lib/analytics-ua";

/**
 * Built-in analytics for Admin → Views / Analytics.
 * Throttled: at most one pageview write per path per browser tab session.
 */
export function PageViewTracker() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const sent = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!pathname || pathname.startsWith("/admin")) return;

    const qs = searchParams?.toString();
    const path = qs ? `${pathname}?${qs}` : pathname;
    if (sent.current.has(path)) return;
    sent.current.add(path);

    const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
    const parsed = parseUserAgent(ua);

    const payload = {
      eventType: "pageview",
      path,
      referrer: typeof document !== "undefined" ? document.referrer || null : null,
      source: "web",
      device: parsed.os,
      browser: parsed.browser,
      meta: { ua: ua.slice(0, 220) },
    };

    const t = window.setTimeout(() => {
      void fetch("/api/analytics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        keepalive: true,
      }).catch(() => {
        /* ignore */
      });
    }, 400);

    return () => window.clearTimeout(t);
  }, [pathname, searchParams]);

  return null;
}
