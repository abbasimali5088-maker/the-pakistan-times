import type { SocialKey } from "@/lib/site-settings";

/** Official-looking brand SVGs (inline, no external icon CDN). */
export function SocialBrandIcon({
  name,
  className = "h-4 w-4",
}: {
  name: SocialKey | "copy" | "share";
  className?: string;
}) {
  const common = {
    viewBox: "0 0 24 24",
    className,
    fill: "currentColor",
    "aria-hidden": true as const,
  };

  switch (name) {
    case "facebook":
      return (
        <svg {...common}>
          <path d="M14 8.5h2.5V5.2C16.1 5.1 15 5 13.7 5 11.1 5 9.3 6.6 9.3 9.6V12H6.5v3.5h2.8V22h3.5v-6.5H15l.5-3.5h-3.2V9.8c0-1 .3-1.3 1.7-1.3z" />
        </svg>
      );
    case "twitter":
      return (
        <svg {...common}>
          <path d="M18.9 2H22l-6.8 7.8L23 22h-6.2l-4.9-6.4L6.3 22H3.2l7.3-8.3L1 2h6.4l4.4 5.8L18.9 2zm-1.1 18h1.7L6.3 3.9H4.5L17.8 20z" />
        </svg>
      );
    case "instagram":
      return (
        <svg {...common}>
          <path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5zm0 2a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7zm11 1.5a1.2 1.2 0 1 1 0 2.4 1.2 1.2 0 0 1 0-2.4zM12 7.5A4.5 4.5 0 1 1 12 16.5 4.5 4.5 0 0 1 12 7.5zm0 2A2.5 2.5 0 1 0 12 14.5 2.5 2.5 0 0 0 12 9.5z" />
        </svg>
      );
    case "whatsapp":
      return (
        <svg {...common}>
          <path d="M12.04 2a9.9 9.9 0 0 0-8.5 14.9L2 22l5.3-1.4A9.9 9.9 0 1 0 12.04 2zm0 1.8a8.1 8.1 0 0 1 6.9 12.3 8.1 8.1 0 0 1-9.5 2.1l-.3-.2-3.1.8.8-3-.2-.3a8.1 8.1 0 0 1 5.4-11.7zm4.6 10.5c-.2-.1-1.4-.7-1.6-.8-.2-.1-.4-.1-.6.1-.2.2-.7.8-.8 1-.1.2-.3.2-.5.1-1.4-.7-2.4-1.3-3.3-2.9-.2-.3 0-.4.2-.6.1-.1.2-.3.3-.4.1-.1.1-.2.2-.4 0-.1 0-.3-.1-.4-.1-.1-.6-1.4-.8-1.9-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.4.1-.6.3-.2.2-.8.8-.8 1.9s.8 2.2.9 2.3c.1.2 1.6 2.5 3.9 3.4 2.3.9 2.3.6 2.7.6.4 0 1.3-.5 1.5-1 .2-.5.2-.9.1-1z" />
        </svg>
      );
    case "youtube":
      return (
        <svg {...common}>
          <path d="M23.5 7.2a3 3 0 0 0-2.1-2.1C19.5 4.5 12 4.5 12 4.5s-7.5 0-9.4.6A3 3 0 0 0 .5 7.2 31.5 31.5 0 0 0 0 12a31.5 31.5 0 0 0 .5 4.8 3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1A31.5 31.5 0 0 0 24 12a31.5 31.5 0 0 0-.5-4.8zM9.8 15.5v-7l6.3 3.5-6.3 3.5z" />
        </svg>
      );
    case "tiktok":
      return (
        <svg {...common}>
          <path d="M19.6 7.2a6.3 6.3 0 0 1-3.7-1.2v8.1a5.7 5.7 0 1 1-5.7-5.7c.3 0 .6 0 .9.1v2.8a2.9 2.9 0 1 0 2 2.8V2h2.8c.2 1.7 1.4 3.2 3 4v1.2z" />
        </svg>
      );
    case "linkedin":
      return (
        <svg {...common}>
          <path d="M4.98 3.5A2.5 2.5 0 1 1 5 8.5a2.5 2.5 0 0 1-.02-5zM3.5 9.5h3V21h-3V9.5zM9.5 9.5h2.9v1.6h.1c.4-.8 1.4-1.7 3-1.7 3.2 0 3.8 2.1 3.8 4.8V21h-3v-5.4c0-1.3 0-3-1.8-3s-2.1 1.4-2.1 2.9V21h-3V9.5z" />
        </svg>
      );
    case "telegram":
      return (
        <svg {...common}>
          <path d="M9.7 15.3 9.4 19c.4 0 .6-.2.8-.4l2-1.9 4.1 3c.8.4 1.3.2 1.5-.7l2.7-12.7c.2-.9-.3-1.3-1.1-1L3.9 10.2c-.9.3-.9.9-.2 1.1l4.5 1.4 10.4-6.5c.5-.3.9-.1.6.2L9.7 15.3z" />
        </svg>
      );
    case "threads":
      return (
        <svg {...common}>
          <path d="M16.5 9.3c-.3-2.3-1.9-3.8-4.5-3.8-3.2 0-5.3 2.4-5.3 6.5 0 3.9 1.9 6.5 5.3 6.5 2.4 0 4-1.2 4.7-3.1l-1.9-.7c-.5 1.2-1.4 1.9-2.8 1.9-2 0-3.2-1.6-3.2-4.6s1.2-4.6 3.2-4.6c1.3 0 2.2.6 2.6 1.7h-2.3v1.8h4.2c0-.2.1-.8.1-1.1zm1.8 2.2v-.2c0-3.5-2.3-6.2-6.3-6.2-4.2 0-7.1 3.1-7.1 8.3s2.9 8.3 7.1 8.3c3.2 0 5.5-1.7 6.5-4.4l-1.8-.8c-.7 1.9-2.2 3.2-4.7 3.2-3 0-5.1-2.2-5.1-6.3s2.1-6.3 5.1-6.3c2.4 0 4.1 1.4 4.5 3.7h1.8z" />
        </svg>
      );
    case "copy":
      return (
        <svg {...common} fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="8" y="8" width="12" height="12" rx="2" />
          <path d="M4 16V6a2 2 0 0 1 2-2h10" />
        </svg>
      );
    default:
      return (
        <svg {...common} fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="18" cy="5" r="3" />
          <circle cx="6" cy="12" r="3" />
          <circle cx="18" cy="19" r="3" />
          <path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4" />
        </svg>
      );
  }
}

export const SOCIAL_BRAND_COLOR: Partial<Record<SocialKey | "copy", string>> = {
  facebook: "#1877F2",
  twitter: "#111111",
  instagram: "#E4405F",
  whatsapp: "#25D366",
  youtube: "#FF0000",
  tiktok: "#010101",
  linkedin: "#0A66C2",
  telegram: "#229ED9",
  threads: "#000000",
  copy: "#475569",
};
