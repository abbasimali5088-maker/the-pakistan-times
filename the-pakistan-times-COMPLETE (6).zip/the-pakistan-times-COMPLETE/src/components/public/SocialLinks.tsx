import type { Lang } from "@/lib/language";
import {
  SOCIAL_LABELS,
  SOCIAL_LINK_KEYS,
  type SocialKey,
} from "@/lib/site-settings";
import { SocialBrandIcon, SOCIAL_BRAND_COLOR } from "./SocialBrandIcon";

const PRIMARY: SocialKey[] = [
  "facebook",
  "twitter",
  "instagram",
  "whatsapp",
  "youtube",
  "tiktok",
];

export function SocialLinks({
  lang,
  social,
  compact = false,
}: {
  lang: Lang;
  social?: Partial<Record<SocialKey, string>>;
  compact?: boolean;
}) {
  const ordered = [
    ...PRIMARY,
    ...SOCIAL_LINK_KEYS.filter((k) => !PRIMARY.includes(k)),
  ];

  const links = ordered
    .map((key) => {
      const href = social?.[key]?.trim();
      if (!href) return null;
      return {
        key,
        href,
        label: lang === "ur" ? SOCIAL_LABELS[key].ur : SOCIAL_LABELS[key].en,
        color: SOCIAL_BRAND_COLOR[key] || "#333",
      };
    })
    .filter(Boolean) as Array<{
    key: SocialKey;
    href: string;
    label: string;
    color: string;
  }>;

  if (!links.length) return null;

  // Header: logo + full name — one neat scrollable row (not removed, not tangled)
  if (compact) {
    return (
      <ul
        className="ui-sans flex max-w-[min(72vw,520px)] flex-nowrap items-center justify-end gap-1.5 overflow-x-auto pb-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:max-w-none sm:gap-2"
        aria-label={lang === "ur" ? "سوشل لنکس" : "Social links"}
      >
        {links.map((item) => (
          <li key={item.key} className="shrink-0">
            <a
              href={item.href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={item.label}
              title={item.label}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/30 bg-black/20 py-1 pe-2.5 ps-1 text-[11px] font-semibold text-white backdrop-blur-sm transition hover:bg-white hover:text-[var(--masthead-red)]"
            >
              <span
                className="inline-flex h-5 w-5 items-center justify-center rounded-full text-white"
                style={{ backgroundColor: item.color }}
              >
                <SocialBrandIcon name={item.key} className="h-3 w-3" />
              </span>
              <span className="whitespace-nowrap">{item.label}</span>
            </a>
          </li>
        ))}
      </ul>
    );
  }

  return (
    <ul
      className="ui-sans mt-5 flex flex-wrap gap-2"
      aria-label={lang === "ur" ? "سوشل لنکس" : "Social links"}
    >
      {links.map((item) => (
        <li key={item.key}>
          <a
            href={item.href}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={item.label}
            title={item.label}
            className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/8 px-3.5 py-2 text-xs font-semibold text-white shadow-sm transition hover:border-white/45 hover:bg-white/18"
          >
            <span
              className="inline-flex h-6 w-6 items-center justify-center rounded-full text-white shadow-sm"
              style={{ backgroundColor: item.color }}
            >
              <SocialBrandIcon name={item.key} className="h-3.5 w-3.5" />
            </span>
            <span>{item.label}</span>
          </a>
        </li>
      ))}
    </ul>
  );
}
