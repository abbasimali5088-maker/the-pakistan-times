"use client";

import { useMemo } from "react";
import type { Lang } from "@/lib/language";

/**
 * Renders a dedicated article tool (calculator, converter, embed, etc.)
 * from the separate HTML/Tool Code field — never from the article body.
 * Visitors see the working tool inside a sandboxed iframe, not raw source.
 */
export function ArticleToolBlock({
  lang,
  title,
  code,
}: {
  lang: Lang;
  title?: string | null;
  code?: string | null;
}) {
  const raw = (code || "").trim();

  const srcDoc = useMemo(() => {
    if (!raw) return "";
    const looksComplete = /<!DOCTYPE|<html[\s>]/i.test(raw);
    if (looksComplete) return raw;
    return `<!DOCTYPE html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><style>html,body{margin:0;padding:12px;font-family:system-ui,sans-serif;background:#fff;color:#141414;}*{box-sizing:border-box;}</style></head><body>${raw}</body></html>`;
  }, [raw]);

  if (!raw) return null;

  const heading =
    (title || "").trim() ||
    (lang === "ur" ? "انٹرایکٹو ٹول" : "Interactive tool");

  return (
    <section
      className="my-8 overflow-hidden border border-[var(--line)] bg-[var(--surface)]"
      aria-label={heading}
    >
      <div className="border-b border-[var(--line)] bg-[var(--accent-soft)] px-4 py-2.5">
        <h2 className="ui-sans text-sm font-extrabold uppercase tracking-wide text-[var(--accent-deep)]">
          {heading}
        </h2>
      </div>
      <iframe
        title={heading}
        srcDoc={srcDoc}
        sandbox="allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin"
        className="block w-full border-0"
        style={{ minHeight: 320, height: 420 }}
        loading="lazy"
        referrerPolicy="no-referrer"
      />
    </section>
  );
}
