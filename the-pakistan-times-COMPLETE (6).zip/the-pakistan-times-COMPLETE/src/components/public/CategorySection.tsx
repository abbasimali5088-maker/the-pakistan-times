import Link from "next/link";
import type { Lang } from "@/lib/language";
import type { PublicArticle } from "@/lib/public-types";
import { ArticleCard } from "./ArticleCard";

export function CategorySection({
  title,
  href,
  articles,
  lang,
}: {
  title: string;
  href?: string;
  articles: PublicArticle[];
  lang: Lang;
}) {
  if (!articles.length) return null;

  const [lead, ...rest] = articles;

  return (
    <section className="fade-in-delay mb-12">
      <div className="mb-5 flex items-end justify-between gap-3 border-b-2 border-[var(--ink)] pb-2">
        <h2 className="section-title mb-0 flex-1 border-0 pb-0">{title}</h2>
        {href ? (
          <Link href={href} className="ui-sans shrink-0 text-sm font-bold text-[var(--accent)]">
            {lang === "ur" ? "مزید دیکھیں" : "View more"}
          </Link>
        ) : null}
      </div>
      <div className="grid gap-8 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <ArticleCard article={lead} lang={lang} variant="medium" />
        <div className="divide-y divide-[var(--line)]">
          {rest.slice(0, 4).map((article) => (
            <ArticleCard key={article.id} article={article} lang={lang} variant="compact" />
          ))}
        </div>
      </div>
    </section>
  );
}
