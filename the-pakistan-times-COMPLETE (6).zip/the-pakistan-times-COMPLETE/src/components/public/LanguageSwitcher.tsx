"use client";

import type { Lang } from "@/lib/language";
import { cn } from "@/lib/utils";

type Props = {
  lang: Lang;
  /** When true, do not switch language on this host — link to sibling domain instead */
  locked?: boolean;
  alternateUrl?: string | null;
  alternateLabel?: string | null;
};

export function LanguageSwitcher({
  lang,
  locked = false,
  alternateUrl,
  alternateLabel,
}: Props) {
  function setLang(next: Lang) {
    if (locked) return;
    const secure = window.location.protocol === "https:" ? ";secure" : "";
    document.cookie = `lang=${next};path=/;max-age=31536000;samesite=lax${secure}`;
    const url = new URL(window.location.href);
    url.searchParams.set("lang", next);
    window.location.assign(url.pathname + url.search);
  }

  if (locked && alternateUrl) {
    return (
      <div className="lang-switch ui-sans inline-flex gap-1" role="group" aria-label="Language">
        <span
          className={cn(
            "border px-2.5 py-1 text-xs font-bold",
            "border-white bg-white text-[var(--masthead-red)]",
          )}
        >
          {lang === "ur" ? "اردو" : "EN"}
        </span>
        <a
          href={alternateUrl}
          className="border border-white/45 bg-transparent px-2.5 py-1 text-xs font-bold text-white hover:border-white hover:bg-white/10"
        >
          {alternateLabel || (lang === "ur" ? "EN" : "اردو")}
        </a>
      </div>
    );
  }

  return (
    <div className="lang-switch ui-sans inline-flex gap-1" role="group" aria-label="Language">
      <button
        type="button"
        className={cn(
          "border px-2.5 py-1 text-xs font-bold transition",
          lang === "ur"
            ? "border-white bg-white text-[var(--masthead-red)]"
            : "border-white/45 bg-transparent text-white hover:border-white hover:bg-white/10",
        )}
        aria-pressed={lang === "ur"}
        onClick={() => setLang("ur")}
      >
        اردو
      </button>
      <button
        type="button"
        className={cn(
          "border px-2.5 py-1 text-xs font-bold transition",
          lang === "en"
            ? "border-white bg-white text-[var(--masthead-red)]"
            : "border-white/45 bg-transparent text-white hover:border-white hover:bg-white/10",
        )}
        aria-pressed={lang === "en"}
        onClick={() => setLang("en")}
      >
        EN
      </button>
    </div>
  );
}
