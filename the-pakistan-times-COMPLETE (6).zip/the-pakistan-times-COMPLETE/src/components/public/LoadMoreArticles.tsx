"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ArticleCard } from "./ArticleCard";
import type { Lang } from "@/lib/language";
import type { PublicArticle } from "@/lib/public-types";

type ApiEnvelope = {
  success: boolean;
  data?: {
    items: PublicArticle[];
    page: number;
    totalPages: number;
  };
  error?: string;
};

export function LoadMoreArticles({
  lang,
  initialItems,
  initialPage,
  totalPages,
  category,
  tag,
  authorId,
  priority,
  pageSize = 12,
}: {
  lang: Lang;
  initialItems: PublicArticle[];
  initialPage: number;
  totalPages: number;
  /** Optional filters — same params the public /api/articles endpoint accepts. */
  category?: string;
  tag?: string;
  authorId?: string;
  priority?: string;
  pageSize?: number;
}) {
  const [items, setItems] = useState<PublicArticle[]>(initialItems);
  const [page, setPage] = useState(initialPage);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(initialPage >= totalPages);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  const loadMore = useCallback(async () => {
    if (loading || done) return;
    setLoading(true);
    try {
      const nextPage = page + 1;
      const params = new URLSearchParams({
        public: "1",
        page: String(nextPage),
        pageSize: String(pageSize),
        language: lang,
      });
      if (category) params.set("category", category);
      if (tag) params.set("tag", tag);
      if (authorId) params.set("authorId", authorId);
      if (priority) params.set("priority", priority);

      const res = await fetch(`/api/articles?${params.toString()}`);
      const json: ApiEnvelope = await res.json();
      if (!json.success || !json.data) {
        setDone(true);
        return;
      }
      setItems((prev) => {
        const seen = new Set(prev.map((a) => a.id));
        const fresh = json.data!.items.filter((a) => !seen.has(a.id));
        return [...prev, ...fresh];
      });
      setPage(json.data.page);
      if (json.data.page >= json.data.totalPages) setDone(true);
    } catch {
      // Network hiccup — leave the button so the reader can retry manually.
    } finally {
      setLoading(false);
    }
  }, [loading, done, page, pageSize, lang, category, tag, authorId, priority]);

  // Auto-load when the sentinel scrolls into view, so most readers never
  // need to click — the button remains as a fallback / explicit action.
  useEffect(() => {
    if (done) return;
    const el = sentinelRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) void loadMore();
      },
      { rootMargin: "600px" },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [loadMore, done]);

  return (
    <>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((article) => (
          <ArticleCard key={article.id} article={article} lang={lang} variant="medium" />
        ))}
      </div>
      <div ref={sentinelRef} aria-hidden className="h-1" />
      <div className="ui-sans mt-8 flex justify-center">
        {!done ? (
          <button type="button" onClick={() => void loadMore()} disabled={loading} className="btn min-h-11 px-6">
            {loading
              ? lang === "ur"
                ? "لوڈ ہو رہا ہے…"
                : "Loading…"
              : lang === "ur"
                ? "مزید خبریں دکھائیں"
                : "Load more"}
          </button>
        ) : items.length > 0 ? (
          <p className="meta text-center text-sm text-[var(--muted)]">
            {lang === "ur" ? "مزید خبریں دستیاب نہیں" : "You're all caught up"}
          </p>
        ) : null}
      </div>
    </>
  );
}
