"use client";

import { isDirectVideoFile, videoEmbedSrc } from "@/lib/video-embed";

export function ArticleVideo({ url, title }: { url?: string | null; title?: string }) {
  const src = videoEmbedSrc(url);
  if (!src) return null;

  if (isDirectVideoFile(src)) {
    return (
      <div className="my-6 overflow-hidden bg-[#1DB954]/10">
        <video controls className="aspect-video w-full bg-black" src={src} title={title || "Video"}>
          <track kind="captions" />
        </video>
      </div>
    );
  }

  return (
    <div className="my-6 overflow-hidden bg-[#1DB954]/10">
      <iframe
        src={src}
        title={title || "Video"}
        className="aspect-video w-full border-0 bg-black"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
        loading="lazy"
        referrerPolicy="strict-origin-when-cross-origin"
      />
    </div>
  );
}
