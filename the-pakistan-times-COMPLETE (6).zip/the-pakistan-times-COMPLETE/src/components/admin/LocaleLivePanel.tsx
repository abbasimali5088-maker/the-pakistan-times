"use client";

import Link from "next/link";
import { FormEvent, useCallback, useEffect, useState } from "react";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { DataTable } from "@/components/admin/DataTable";
import { FormField, TextInput, TextSelect, TextTextarea } from "@/components/admin/FormField";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { ConfirmButton } from "@/components/admin/ConfirmButton";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";
import type { ArticleLocale } from "@/components/admin/article-locale";
import { liveStoryMatchesLang } from "@/lib/language";

type LiveStory = {
  id: string;
  title: string;
  titleUr?: string | null;
  slug: string;
  slugUr?: string | null;
  description?: string | null;
  descriptionUr?: string | null;
  status?: string;
};

const empty = {
  title: "",
  titleUr: "",
  slug: "",
  slugUr: "",
  description: "",
  descriptionUr: "",
  status: "draft",
};

export default function LocaleLivePanel({ locale }: { locale?: ArticleLocale }) {
  const isUr = locale === "ur";
  const isEn = locale === "en";
  const localeMode = Boolean(locale);
  const [rows, setRows] = useState<LiveStory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(empty);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const qs =
        isUr || isEn
          ? `/api/live?language=${isUr ? "ur" : "en"}&pageSize=200`
          : "/api/live?pageSize=200";
      const data = await adminFetch<{ items?: LiveStory[] }>(qs, { allowNotFound: true });
      const items = data?.items || [];
      if (isUr) {
        setRows(items.filter((r) => liveStoryMatchesLang(r, "ur")));
      } else if (isEn) {
        setRows(items.filter((r) => liveStoryMatchesLang(r, "en")));
      } else {
        setRows(items);
      }
    } catch (err) {
      setRows([]);
      setError(err instanceof AdminApiError ? err.message : "Failed to load live stories");
    } finally {
      setLoading(false);
    }
  }, [isEn, isUr]);

  useEffect(() => {
    void load();
  }, [load]);

  function setField(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function startEdit(row: LiveStory) {
    setEditingId(row.id);
    setForm({
      title: row.title || "",
      titleUr: row.titleUr || "",
      slug: row.slug || "",
      slugUr: row.slugUr || "",
      description: row.description || "",
      descriptionUr: row.descriptionUr || "",
      status: row.status || "draft",
    });
    setNotice(null);
  }

  function resetForm() {
    setEditingId(null);
    setForm(empty);
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const titleEn = form.title.trim();
      const titleUr = form.titleUr.trim();

      if (isUr) {
        if (!titleUr) throw new Error("اردو عنوان ضروری ہے");
      } else if (isEn) {
        if (!titleEn) throw new Error("English title required");
      } else {
        if (!titleEn) throw new Error("English title required");
        if (!titleUr) throw new Error("اردو عنوان ضروری ہے");
      }

      // Locale-strict payload — never cross-write the other language from this hub.
      const payload = isUr
        ? {
            title: titleUr,
            titleUr,
            slug: form.slugUr.trim() || form.slug.trim() || undefined,
            slugUr: form.slugUr.trim() || form.slug.trim() || null,
            description: null,
            descriptionUr: form.descriptionUr.trim() || null,
            status: form.status,
            locale: "ur",
          }
        : isEn
          ? {
              title: titleEn,
              titleUr: null,
              slug: form.slug.trim() || undefined,
              slugUr: null,
              description: form.description.trim() || null,
              descriptionUr: null,
              status: form.status,
              locale: "en",
            }
          : {
              title: titleEn,
              titleUr,
              slug: form.slug.trim() || undefined,
              slugUr: form.slugUr.trim() || null,
              description: form.description.trim() || null,
              descriptionUr: form.descriptionUr.trim() || null,
              status: form.status,
            };

      if (editingId) {
        await adminFetch(`/api/live/${editingId}`, {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        setNotice(isUr ? "اردو لائیو محفوظ" : "English live story saved");
      } else {
        await adminFetch("/api/live", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        setNotice(isUr ? "اردو لائیو بن گئی" : "English live story created");
      }
      resetForm();
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError || err instanceof Error ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    try {
      await adminFetch(`/api/live/${id}`, { method: "DELETE" });
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Delete failed");
    }
  }

  return (
    <div>
      {!localeMode ? (
        <AdminPageHeader
          title="Live stories"
          description="Use Articles English or Articles اردو hubs for locale-only live coverage."
        />
      ) : (
        <p className="mb-3 text-sm text-slate-600">
          {isUr
            ? "صرف اردو عنوان/تفصیل — English Title یہاں نہیں ہے۔"
            : "English title only — no Urdu title field in this workspace."}
        </p>
      )}

      {error ? (
        <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          {error}
        </div>
      ) : null}
      {notice ? (
        <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-900">
          {notice}
        </div>
      ) : null}

      <AdminPanel title={editingId ? "Edit live story" : "Create live story"} className="mb-4">
        <form onSubmit={onSubmit} className="space-y-4">
          {isUr ? (
            <div className="rounded-lg border border-emerald-200 bg-emerald-50/60 p-3 space-y-3">
              <FormField label="عنوان (اردو)">
                <TextInput
                  required
                  dir="rtl"
                  value={form.titleUr}
                  onChange={(e) => setField("titleUr", e.target.value)}
                  placeholder="لائیو: قومی اسمبلی"
                />
              </FormField>
              <FormField label="Slug (اردو URL — اختیاری)">
                <TextInput
                  dir="ltr"
                  value={form.slugUr}
                  onChange={(e) => setField("slugUr", e.target.value)}
                  placeholder="live-national-assembly-ur"
                />
              </FormField>
              <FormField label="تفصیل (اردو)">
                <TextTextarea
                  dir="rtl"
                  value={form.descriptionUr}
                  onChange={(e) => setField("descriptionUr", e.target.value)}
                />
              </FormField>
            </div>
          ) : isEn ? (
            <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3 space-y-3">
              <FormField label="Title (EN)">
                <TextInput
                  required
                  dir="ltr"
                  value={form.title}
                  onChange={(e) => setField("title", e.target.value)}
                  placeholder="Live: National Assembly"
                />
              </FormField>
              <FormField label="Slug (EN URL)">
                <TextInput dir="ltr" value={form.slug} onChange={(e) => setField("slug", e.target.value)} />
              </FormField>
              <FormField label="Description (EN)">
                <TextTextarea
                  dir="ltr"
                  value={form.description}
                  onChange={(e) => setField("description", e.target.value)}
                />
              </FormField>
            </div>
          ) : (
            <>
              <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3 space-y-3">
                <p className="text-xs font-bold uppercase tracking-wide text-sky-800">① English</p>
                <FormField label="Title (EN)">
                  <TextInput
                    required
                    dir="ltr"
                    value={form.title}
                    onChange={(e) => setField("title", e.target.value)}
                  />
                </FormField>
                <FormField label="Slug (EN URL)">
                  <TextInput dir="ltr" value={form.slug} onChange={(e) => setField("slug", e.target.value)} />
                </FormField>
                <FormField label="Description (EN)">
                  <TextTextarea
                    dir="ltr"
                    value={form.description}
                    onChange={(e) => setField("description", e.target.value)}
                  />
                </FormField>
              </div>
              <div className="rounded-lg border border-emerald-200 bg-emerald-50/60 p-3 space-y-3">
                <p className="text-xs font-bold uppercase tracking-wide text-emerald-800">② اردو</p>
                <FormField label="عنوان (اردو)">
                  <TextInput
                    required
                    dir="rtl"
                    value={form.titleUr}
                    onChange={(e) => setField("titleUr", e.target.value)}
                  />
                </FormField>
                <FormField label="Slug (اردو URL — اختیاری)">
                  <TextInput
                    dir="ltr"
                    value={form.slugUr}
                    onChange={(e) => setField("slugUr", e.target.value)}
                  />
                </FormField>
                <FormField label="تفصیل (اردو)">
                  <TextTextarea
                    dir="rtl"
                    value={form.descriptionUr}
                    onChange={(e) => setField("descriptionUr", e.target.value)}
                  />
                </FormField>
              </div>
            </>
          )}

          <FormField label="Status" className="max-w-xs">
            <TextSelect value={form.status} onChange={(e) => setField("status", e.target.value)}>
              <option value="draft">draft</option>
              <option value="live">live</option>
              <option value="ended">ended</option>
            </TextSelect>
          </FormField>

          <div className="flex flex-wrap gap-2">
            <button
              type="submit"
              disabled={busy}
              className="rounded-md bg-[#1DB954] px-4 py-2 text-sm font-medium text-white hover:bg-[#159A45] disabled:opacity-60"
            >
              {busy ? "…" : editingId ? "Save" : "Create"}
            </button>
            {editingId ? (
              <button type="button" onClick={resetForm} className="rounded-md border px-4 py-2 text-sm">
                Cancel
              </button>
            ) : null}
          </div>
        </form>
      </AdminPanel>

      {loading ? (
        <p className="text-sm text-slate-500">Loading…</p>
      ) : (
        <DataTable
          rows={rows}
          rowKey={(r) => r.id}
          empty="No live stories yet."
          columns={[
            {
              key: "title",
              header: isUr ? "عنوان (اردو)" : "Title (EN)",
              render: (r) => (
                <Link
                  href={`/admin/live/${r.id}`}
                  className="font-medium text-[#1DB954] hover:underline"
                  dir={isUr ? "rtl" : "ltr"}
                >
                  {isUr ? r.titleUr || r.title : r.title}
                </Link>
              ),
            },
            {
              key: "slug",
              header: "Slug",
              render: (r) => (isUr ? r.slugUr || r.slug : r.slug),
            },
            { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
            {
              key: "actions",
              header: "Actions",
              render: (r) => (
                <div className="flex flex-wrap gap-2">
                  <Link href={`/admin/live/${r.id}`} className="text-sm text-slate-600 hover:underline">
                    Updates
                  </Link>
                  <button
                    type="button"
                    onClick={() => startEdit(r)}
                    className="text-sm text-[#1DB954] hover:underline"
                  >
                    Edit
                  </button>
                  <ConfirmButton label="Delete" confirmLabel="Delete?" onConfirm={() => remove(r.id)} />
                </div>
              ),
            },
          ]}
        />
      )}
    </div>
  );
}
