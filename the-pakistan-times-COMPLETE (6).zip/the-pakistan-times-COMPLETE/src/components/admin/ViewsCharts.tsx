"use client";

import type { NamedCount } from "@/lib/analytics-ua";

type Props = {
  title: string;
  items: NamedCount[];
  empty?: string;
};

function Donut({ items }: { items: NamedCount[] }) {
  const total = items.reduce((s, i) => s + i.count, 0) || 1;
  const r = 42;
  const c = 2 * Math.PI * r;
  let offset = 0;

  return (
    <svg viewBox="0 0 120 120" className="mx-auto h-36 w-36" aria-hidden>
      <circle cx="60" cy="60" r={r} fill="none" stroke="#f3f4f6" strokeWidth="16" />
      {items.map((item) => {
        const len = (item.count / total) * c;
        const el = (
          <circle
            key={item.name}
            cx="60"
            cy="60"
            r={r}
            fill="none"
            stroke={item.color || "#90A4AE"}
            strokeWidth="16"
            strokeDasharray={`${len} ${c - len}`}
            strokeDashoffset={-offset}
            transform="rotate(-90 60 60)"
          />
        );
        offset += len;
        return el;
      })}
      <circle cx="60" cy="60" r="28" fill="#fff" />
    </svg>
  );
}

export function AudienceDonutCard({ title, items, empty = "No data yet" }: Props) {
  const has = items.some((i) => i.count > 0);
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-1 text-base font-semibold text-slate-800">{title}</h3>
      <p className="mb-3 text-xs text-slate-500">Absolute numbers</p>
      {!has ? (
        <p className="py-8 text-center text-sm text-slate-400">{empty}</p>
      ) : (
        <>
          <Donut items={items} />
          <ul className="mt-3 divide-y divide-slate-100">
            {items.map((item) => (
              <li
                key={item.name}
                className="flex items-center justify-between gap-3 py-2.5 text-sm"
              >
                <span className="flex min-w-0 items-center gap-2 text-slate-700">
                  <span
                    className="h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ background: item.color || "#90A4AE" }}
                  />
                  <span className="truncate">{item.name}</span>
                </span>
                <span className="font-semibold tabular-nums text-slate-900">{item.count}</span>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

type SeriesPoint = { date: string; count: number };

export function ViewsLineChart({
  title,
  series,
  height = 160,
}: {
  title?: string;
  series: SeriesPoint[];
  height?: number;
}) {
  const w = 360;
  const h = height;
  const pad = 28;
  const max = Math.max(1, ...series.map((s) => s.count));
  const points = series.map((s, i) => {
    const x = pad + (i / Math.max(1, series.length - 1)) * (w - pad * 2);
    const y = h - pad - (s.count / max) * (h - pad * 2);
    return `${x},${y}`;
  });
  const labels = series.filter((_, i) => i === 0 || i === series.length - 1 || i === Math.floor(series.length / 2));

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      {title ? <h3 className="mb-2 text-base font-semibold text-slate-800">{title}</h3> : null}
      <svg viewBox={`0 0 ${w} ${h}`} className="h-auto w-full" role="img">
        {[0, 0.5, 1].map((t) => {
          const y = h - pad - t * (h - pad * 2);
          return (
            <g key={t}>
              <line x1={pad} x2={w - pad} y1={y} y2={y} stroke="#eef2f7" />
              <text x={4} y={y + 3} fontSize="10" fill="#94a3b8">
                {Math.round(max * t)}
              </text>
            </g>
          );
        })}
        <polyline
          fill="none"
          stroke="#1DB954"
          strokeWidth="2.5"
          points={points.join(" ")}
        />
        {series.map((s, i) => {
          const x = pad + (i / Math.max(1, series.length - 1)) * (w - pad * 2);
          const y = h - pad - (s.count / max) * (h - pad * 2);
          return <circle key={s.date} cx={x} cy={y} r="3" fill="#1DB954" />;
        })}
        {labels.map((s) => {
          const i = series.findIndex((x) => x.date === s.date);
          const x = pad + (i / Math.max(1, series.length - 1)) * (w - pad * 2);
          return (
            <text key={s.date} x={x} y={h - 8} fontSize="10" fill="#64748b" textAnchor="middle">
              {s.date.slice(5)}
            </text>
          );
        })}
      </svg>
    </div>
  );
}
