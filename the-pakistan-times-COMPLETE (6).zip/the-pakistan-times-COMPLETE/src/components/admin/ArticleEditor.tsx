"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { FeaturedImagePicker } from "@/components/admin/FeaturedImagePicker";
import { FormField, TextInput, TextSelect, TextTextarea } from "@/components/admin/FormField";
import { ArticleBodyEditor } from "@/components/admin/ArticleBodyEditor";
import { ARTICLE_STATUSES } from "@/lib/constants";
import { adminFetch, AdminApiError, parseCommaList } from "@/lib/admin-fetch";
import type { ArticleLocale } from "@/components/admin/article-locale";
import { resolveAutoSeo, autoSlugFromTitle } from "@/lib/auto-seo";

type Category = {
  id: string;
  name: string;
  nameUr?: string | null;
  slug: string;
  language?: string | null;
};
type Tag = { id: string; name: string; nameUr?: string | null; slug: string; language?: string | null };

type ArticleFormState = {
  title: string;
  titleUr: string;
  slug: string;
  slugUr: string;
  excerpt: string;
  excerptUr: string;
  body: string;
  bodyUr: string;
  categoryId: string;
  categoryUrId: string;
  status: string;
  priority: string;
  featuredImageId: string;
  imageUrl: string;
  imageCaption: string;
  imageCredit: string;
  featuredImageUrId: string;
  imageUrlUr: string;
  imageCaptionUr: string;
  imageCreditUr: string;
  videoUrl: string;
  videoUrlUr: string;
  seoTitle: string;
  seoDescription: string;
  seoTitleUr: string;
  seoDescriptionUr: string;
  focusKeyword: string;
  focusKeywordUr: string;
  searchKeywords: string;
  searchKeywordsUr: string;
  canonicalUrl: string;
  robotsMeta: string;
  ogTitle: string;
  ogDescription: string;
  ogTitleUr: string;
  ogDescriptionUr: string;
  ogImage: string;
  ogImageUr: string;
  tags: string;
  tagsUr: string;
  isFeatured: boolean;
  isBreaking: boolean;
  isLive: boolean;
  liveDurationHours: string;
  toolTitle: string;
  toolCode: string;
  toolTitleUr: string;
  toolCodeUr: string;
};

const emptyForm: ArticleFormState = {
  title: "",
  titleUr: "",
  slug: "",
  slugUr: "",
  excerpt: "",
  excerptUr: "",
  body: "",
  bodyUr: "",
  categoryId: "",
  categoryUrId: "",
  status: "draft",
  priority: "normal",
  featuredImageId: "",
  imageUrl: "",
  imageCaption: "",
  imageCredit: "",
  featuredImageUrId: "",
  imageUrlUr: "",
  imageCaptionUr: "",
  imageCreditUr: "",
  videoUrl: "",
  videoUrlUr: "",
  seoTitle: "",
  seoDescription: "",
  seoTitleUr: "",
  seoDescriptionUr: "",
  focusKeyword: "",
  focusKeywordUr: "",
  searchKeywords: "",
  searchKeywordsUr: "",
  canonicalUrl: "",
  robotsMeta: "",
  ogTitle: "",
  ogDescription: "",
  ogTitleUr: "",
  ogDescriptionUr: "",
  ogImage: "",
  ogImageUr: "",
  tags: "",
  tagsUr: "",
  isFeatured: false,
  isBreaking: false,
  isLive: false,
  liveDurationHours: "1",
  toolTitle: "",
  toolCode: "",
  toolTitleUr: "",
  toolCodeUr: "",
};

function sameText(a?: string | null, b?: string | null) {
  return (a || "").trim() === (b || "").trim() && Boolean((a || "").trim());
}

function mapArticleToForm(data: Record<string, unknown>): ArticleFormState {
  const seo = (data.seo as Record<string, string | null> | undefined) || {};
  const image = data.image as { id?: string; url?: string } | null | undefined;
  const imageUr = data.imageUr as { id?: string; url?: string } | null | undefined;
  const tags = Array.isArray(data.tags)
    ? (data.tags as Array<{ id?: string; slug?: string; locale?: string }>)
    : [];
  const tagsUrArr = Array.isArray(data.tagsUr)
    ? (data.tagsUr as Array<{ id?: string; slug?: string; locale?: string }>)
    : [];
  const category = data.category as { id?: string } | null | undefined;
  const categoryUr = data.categoryUr as { id?: string } | null | undefined;
  const enTags = tags.map((t) => t.slug || t.id || "").filter(Boolean);
  const urTags = (tagsUrArr.length ? tagsUrArr : tags.filter((t) => t.locale === "ur"))
    .map((t) => t.slug || t.id || "")
    .filter(Boolean);
  return {
    ...emptyForm,
    title: String(data.title || ""),
    titleUr: String(data.titleUr || ""),
    slug: String(data.slug || ""),
    slugUr: String(data.slugUr || ""),
    excerpt: String(data.excerpt || ""),
    excerptUr: String(data.excerptUr || ""),
    body: String(data.body || ""),
    bodyUr: String(data.bodyUr || ""),
    categoryId: String(category?.id || data.categoryId || ""),
    categoryUrId: String(categoryUr?.id || data.categoryUrId || ""),
    status: String(data.status || "draft"),
    priority: String(data.priority || "normal"),
    featuredImageId: String(image?.id || data.featuredImageId || ""),
    imageUrl: String(image?.url || ""),
    imageCaption: String(data.imageCaption || ""),
    imageCredit: String(data.imageCredit || ""),
    featuredImageUrId: String(imageUr?.id || data.featuredImageUrId || ""),
    imageUrlUr: String(imageUr?.url || ""),
    imageCaptionUr: String(data.imageCaptionUr || ""),
    imageCreditUr: String(data.imageCreditUr || ""),
    videoUrl: String(data.videoUrl || ""),
    videoUrlUr: String(data.videoUrlUr || ""),
    seoTitle: String(data.seoTitle || seo.title || ""),
    seoDescription: String(data.seoDescription || seo.description || ""),
    seoTitleUr: String(data.seoTitleUr || ""),
    seoDescriptionUr: String(data.seoDescriptionUr || ""),
    focusKeyword: String(data.focusKeyword || ""),
    focusKeywordUr: String(data.focusKeywordUr || ""),
    searchKeywords: String(data.searchKeywords || ""),
    searchKeywordsUr: String(data.searchKeywordsUr || ""),
    canonicalUrl: String(data.canonicalUrl || seo.canonical || ""),
    robotsMeta: String(data.robotsMeta || seo.robots || ""),
    ogTitle: String(data.ogTitle || ""),
    ogDescription: String(data.ogDescription || ""),
    ogTitleUr: String(data.ogTitleUr || ""),
    ogDescriptionUr: String(data.ogDescriptionUr || ""),
    ogImage: String(data.ogImage || ""),
    ogImageUr: String(data.ogImageUr || ""),
    tags: enTags.join(", "),
    tagsUr: urTags.join(", "),
    isFeatured: Boolean(data.isFeatured),
    isBreaking: Boolean(data.isBreaking),
    isLive: String(data.priority || "") === "live" || Boolean(data.isLive),
    liveDurationHours: (() => {
      const exp = data.liveExpiresAt ? new Date(String(data.liveExpiresAt)).getTime() : NaN;
      if (!Number.isFinite(exp)) return "1";
      const hoursLeft = Math.max(1, Math.round((exp - Date.now()) / 3_600_000));
      if (hoursLeft >= 3) return "3";
      if (hoursLeft >= 2) return "2";
      return "1";
    })(),
    toolTitle: String(data.toolTitle || ""),
    toolCode: String(data.toolCode || ""),
    toolTitleUr: String(data.toolTitleUr || ""),
    toolCodeUr: String(data.toolCodeUr || ""),
  };
}

export function ArticleEditor({
  mode,
  locale: localeProp,
}: {
  mode: "create" | "edit";
  locale?: ArticleLocale;
}) {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const searchParams = useSearchParams();
  const locale: ArticleLocale =
    localeProp || (searchParams.get("lang") === "en" ? "en" : "ur");
  const isUr = locale === "ur";
  const hub = `/admin/articles/${locale}`;

  const [form, setForm] = useState<ArticleFormState>(emptyForm);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tagIndex, setTagIndex] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(mode === "edit");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [showAdvancedSeo, setShowAdvancedSeo] = useState(false);
  /** Once the writer edits the slug, stop auto-syncing from title. */
  const slugTouched = useRef(false);
  const seoTouched = useRef({
    seoTitle: false,
    seoDescription: false,
    ogTitle: false,
    ogDescription: false,
    ogImage: false,
    robots: false,
    canonical: false,
  });

  useEffect(() => {
    let cancelled = false;
    async function boot() {
      try {
        const catUrl = isUr ? "/api/categories?language=ur" : "/api/categories?language=en";
        const tagUrl = isUr ? "/api/tags?pageSize=200&language=ur" : "/api/tags?pageSize=200&language=en";
        const [cats, tags] = await Promise.all([
          adminFetch<{ items?: Category[] }>(catUrl, { allowNotFound: true }),
          adminFetch<{ items?: Tag[] }>(tagUrl, { allowNotFound: true }),
        ]);
        if (cancelled) return;
        setCategories(cats?.items || []);
        setTagIndex(tags?.items || []);
        if (mode === "edit" && id) {
          const data = await adminFetch<Record<string, unknown>>(`/api/articles/${id}`);
          if (!cancelled) {
            const mapped = mapArticleToForm(data);
            // Guard: editing wrong language article via wrong hub
            const articleLang = String(data.language || "");
            if (articleLang && articleLang !== locale) {
              setError(
                isUr
                  ? "یہ انگلش آرٹیکل ہے — اردو ایڈیٹر میں نہیں کھلے گا۔"
                  : "This is an Urdu article — open it from the Urdu articles hub.",
              );
              setLoading(false);
              return;
            }
            setForm(mapped);
            slugTouched.current = Boolean(mapped.slug || mapped.slugUr);
          }
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof AdminApiError ? err.message : "Failed to load");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void boot();
    return () => {
      cancelled = true;
    };
  }, [mode, id, isUr, locale]);

  const title = useMemo(() => {
    if (mode === "create") return isUr ? "نیا اردو آرٹیکل" : "New English article";
    return isUr ? "اردو آرٹیکل ترمیم" : "Edit English article";
  }, [mode, isUr]);

  const enCategories = categories.filter((c) => (c.language || "en") === "en");
  const urCategories = categories.filter((c) => (c.language || "en") === "ur");
  // Never fall back to the other language's categories (cross-contamination).
  const localeCategories = isUr ? urCategories : enCategories;

  /** Live preview of what will be saved for SEO (manual overrides win). */
  const autoPreview = useMemo(() => {
    if (isUr) {
      return resolveAutoSeo({
        lang: "ur",
        title: form.titleUr,
        excerpt: form.excerptUr,
        metaDescription: form.seoDescriptionUr,
        seoTitle: form.seoTitleUr,
        ogTitle: form.ogTitleUr,
        ogDescription: form.ogDescriptionUr,
        imageUrl: form.imageUrlUr,
        ogImage: form.ogImageUr,
        slug: form.slugUr || form.slug,
        canonicalUrl: form.canonicalUrl,
        robotsMeta: form.robotsMeta,
      });
    }
    return resolveAutoSeo({
      lang: "en",
      title: form.title,
      excerpt: form.excerpt,
      metaDescription: form.seoDescription,
      seoTitle: form.seoTitle,
      ogTitle: form.ogTitle,
      ogDescription: form.ogDescription,
      imageUrl: form.imageUrl,
      ogImage: form.ogImage,
      slug: form.slug,
      canonicalUrl: form.canonicalUrl,
      robotsMeta: form.robotsMeta,
    });
  }, [form, isUr]);

  function set<K extends keyof ArticleFormState>(key: K, value: ArticleFormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function onTitleChange(value: string) {
    setForm((prev) => {
      const next = { ...prev };
      if (isUr) {
        next.titleUr = value;
        if (!slugTouched.current) {
          const s = autoSlugFromTitle(value, "urdu");
          next.slugUr = s;
          next.slug = s;
        }
        if (!seoTouched.current.seoTitle) next.seoTitleUr = "";
        if (!seoTouched.current.ogTitle) next.ogTitleUr = "";
      } else {
        next.title = value;
        if (!slugTouched.current) {
          next.slug = autoSlugFromTitle(value, "article");
        }
        if (!seoTouched.current.seoTitle) next.seoTitle = "";
        if (!seoTouched.current.ogTitle) next.ogTitle = "";
      }
      return next;
    });
  }

  function onExcerptChange(value: string) {
    setForm((prev) => {
      const next = { ...prev };
      if (isUr) {
        next.excerptUr = value;
        if (!seoTouched.current.seoDescription) next.seoDescriptionUr = "";
        if (!seoTouched.current.ogDescription) next.ogDescriptionUr = "";
      } else {
        next.excerpt = value;
        if (!seoTouched.current.seoDescription) next.seoDescription = "";
        if (!seoTouched.current.ogDescription) next.ogDescription = "";
      }
      return next;
    });
  }

  function resolveTagIds(raw: string, loc: "en" | "ur"): string[] {
    const parts = parseCommaList(raw);
    const ids: string[] = [];
    for (const part of parts) {
      const found = tagIndex.find(
        (t) =>
          (t.id === part || t.slug === part || t.name === part || t.nameUr === part) &&
          (!t.language || t.language === loc || (loc === "ur" && Boolean(t.nameUr))),
      );
      if (found?.id) ids.push(found.id);
    }
    return [...new Set(ids)];
  }

  async function save(publish = false) {
    setSaving(true);
    setError(null);
    setMessage(null);

    if (isUr) {
      if (!form.titleUr.trim()) {
        setError("اردو عنوان ضروری ہے");
        setSaving(false);
        return;
      }
      if (sameText(form.excerptUr, form.titleUr) && form.titleUr.trim()) {
        setError("اردو خلاصہ عنوان جیسا نہ لکھیں");
        setSaving(false);
        return;
      }
    } else if (!form.title.trim()) {
      setError("English Title is required");
      setSaving(false);
      return;
    } else if (sameText(form.excerpt, form.title) && form.title.trim()) {
      setError("English excerpt must not repeat the title");
      setSaving(false);
      return;
    }

    const priority = form.isLive
      ? "live"
      : form.isBreaking
        ? "breaking"
        : form.priority === "live" || form.priority === "breaking"
          ? "normal"
          : form.priority || "normal";

    const liveHours =
      Number(form.liveDurationHours) === 2 || Number(form.liveDurationHours) === 3
        ? Number(form.liveDurationHours)
        : 1;
    const liveExpiresAt = form.isLive
      ? new Date(Date.now() + liveHours * 3_600_000).toISOString()
      : null;

    const seo = isUr
      ? resolveAutoSeo({
          lang: "ur",
          title: form.titleUr,
          excerpt: form.excerptUr,
          metaDescription: form.seoDescriptionUr,
          seoTitle: form.seoTitleUr,
          ogTitle: form.ogTitleUr,
          ogDescription: form.ogDescriptionUr,
          imageUrl: form.imageUrlUr,
          ogImage: form.ogImageUr,
          slug: form.slugUr || form.slug,
          canonicalUrl: form.canonicalUrl,
          robotsMeta: form.robotsMeta,
        })
      : resolveAutoSeo({
          lang: "en",
          title: form.title,
          excerpt: form.excerpt,
          metaDescription: form.seoDescription,
          seoTitle: form.seoTitle,
          ogTitle: form.ogTitle,
          ogDescription: form.ogDescription,
          imageUrl: form.imageUrl,
          ogImage: form.ogImage,
          slug: form.slug,
          canonicalUrl: form.canonicalUrl,
          robotsMeta: form.robotsMeta,
        });

    try {
      if (mode === "create" && isUr) {
        const urduPayload = {
          titleUr: form.titleUr.trim(),
          slugUr: seo.slug,
          excerptUr: form.excerptUr.trim() || null,
          bodyUr: form.bodyUr || null,
          toolTitleUr: form.toolTitleUr.trim() || null,
          toolCodeUr: form.toolCodeUr || null,
          categoryUrId: form.categoryUrId || null,
          featuredImageUrId: form.featuredImageUrId || null,
          imageCaptionUr: form.imageCaptionUr || null,
          imageCreditUr: form.imageCreditUr || null,
          videoUrlUr: form.videoUrlUr || null,
          seoTitleUr: seo.seoTitle,
          seoDescriptionUr: seo.seoDescription || null,
          focusKeywordUr: form.focusKeywordUr || null,
          searchKeywordsUr: form.searchKeywordsUr || null,
          ogTitleUr: seo.ogTitle,
          ogDescriptionUr: seo.ogDescription || null,
          ogImageUr: seo.ogImage,
          canonicalUrl: seo.canonicalUrl,
          robotsMeta: seo.robotsMeta,
          tagIdsUr: resolveTagIds(form.tagsUr, "ur"),
          status: publish ? "published" : form.status,
          priority,
          isFeatured: form.isFeatured,
          isBreaking: form.isBreaking || form.isLive,
          isLive: form.isLive,
          liveExpiresAt,
          liveDurationHours: form.isLive ? liveHours : null,
        };
        const created = await adminFetch<{ id: string }>("/api/articles/urdu", {
          method: "POST",
          body: JSON.stringify(urduPayload),
        });
        setMessage("اردو آرٹیکل محفوظ ہو گیا۔");
        router.push(`/admin/articles/${created.id}?lang=ur`);
        return;
      }

      const payload = isUr
        ? {
            // Urdu edit: only touch Urdu + shared status fields (never wipe EN columns).
            titleUr: form.titleUr,
            slug: seo.slug,
            slugUr: seo.slug,
            excerptUr: form.excerptUr || null,
            bodyUr: form.bodyUr || null,
            toolTitleUr: form.toolTitleUr.trim() || null,
            toolCodeUr: form.toolCodeUr || null,
            language: "ur" as const,
            categoryUrId: form.categoryUrId || null,
            status: publish ? "published" : form.status,
            priority,
            featuredImageUrId: form.featuredImageUrId || null,
            imageCaptionUr: form.imageCaptionUr || null,
            imageCreditUr: form.imageCreditUr || null,
            videoUrlUr: form.videoUrlUr || null,
            seoTitleUr: seo.seoTitle,
            seoDescriptionUr: seo.seoDescription || null,
            focusKeywordUr: form.focusKeywordUr || null,
            searchKeywordsUr: form.searchKeywordsUr || null,
            canonicalUrl: seo.canonicalUrl,
            robotsMeta: seo.robotsMeta,
            ogTitleUr: seo.ogTitle,
            ogDescriptionUr: seo.ogDescription || null,
            ogImageUr: seo.ogImage,
            tagIdsUr: resolveTagIds(form.tagsUr, "ur"),
            isFeatured: form.isFeatured,
            isBreaking: form.isBreaking || form.isLive,
            liveExpiresAt,
            liveDurationHours: form.isLive ? liveHours : null,
            ...(publish && mode === "edit" ? { action: "publish" as const } : {}),
          }
        : {
            title: form.title,
            slug: seo.slug,
            excerpt: form.excerpt || null,
            body: form.body || "",
            toolTitle: form.toolTitle.trim() || null,
            toolCode: form.toolCode || null,
            language: "en" as const,
            categoryId: form.categoryId || null,
            status: publish ? "published" : form.status,
            priority,
            featuredImageId: form.featuredImageId || null,
            imageCaption: form.imageCaption || null,
            imageCredit: form.imageCredit || null,
            videoUrl: form.videoUrl || null,
            seoTitle: seo.seoTitle,
            seoDescription: seo.seoDescription || null,
            focusKeyword: form.focusKeyword || null,
            searchKeywords: form.searchKeywords || null,
            canonicalUrl: seo.canonicalUrl,
            robotsMeta: seo.robotsMeta,
            ogTitle: seo.ogTitle,
            ogDescription: seo.ogDescription || null,
            ogImage: seo.ogImage,
            tagIds: resolveTagIds(form.tags, "en"),
            isFeatured: form.isFeatured,
            isBreaking: form.isBreaking || form.isLive,
            liveExpiresAt,
            liveDurationHours: form.isLive ? liveHours : null,
            ...(publish && mode === "edit" ? { action: "publish" as const } : {}),
          };

      if (mode === "create") {
        const created = await adminFetch<{ id: string }>("/api/articles", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        setMessage(isUr ? "اردو آرٹیکل محفوظ ہو گیا۔" : "English article saved.");
        router.push(`/admin/articles/${created.id}?lang=${locale}`);
      } else if (id) {
        await adminFetch(`/api/articles/${id}`, {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        setMessage(publish ? "Published and saved." : isUr ? "محفوظ ہو گیا۔" : "Saved to database.");
        const refreshed = await adminFetch<Record<string, unknown>>(`/api/articles/${id}`);
        setForm(mapArticleToForm(refreshed));
      }
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    await save(false);
  }

  if (loading) {
    return <p className="text-sm text-slate-500">Loading article…</p>;
  }

  return (
    <div>
      <AdminPageHeader
        title={title}
        description={
          isUr
            ? "روزانہ لکھائی: عنوان، خلاصہ، مواد، کیٹیگری، ٹیگز، تصویر، فوکس کی ورڈ، میٹا۔ باقی SEO خود بنتا ہے۔"
            : "Daily writing: title, summary, body, category, tags, image, focus keyword, meta. Other SEO fields auto-fill."
        }
        actions={
          <Link href={hub} className="text-sm text-slate-600 hover:text-[#1DB954]">
            ← {isUr ? "اردو فہرست" : "English list"}
          </Link>
        }
      />

      {error ? (
        <div className="mb-4 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          {error}
        </div>
      ) : null}
      {message ? (
        <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
          {message}
        </div>
      ) : null}

      <form onSubmit={onSubmit} className="space-y-4">
        {!isUr ? (
          <AdminPanel title="Write article">
            <div className="grid gap-4">
              <FormField label="Title" hint="Required — also drives SEO title, OG title, and slug">
                <TextInput
                  required
                  dir="ltr"
                  value={form.title}
                  onChange={(e) => onTitleChange(e.target.value)}
                />
              </FormField>
              <FormField label="Summary / Excerpt" hint="Shown before Read more; feeds meta & OG description">
                <TextTextarea dir="ltr" value={form.excerpt} onChange={(e) => onExcerptChange(e.target.value)} />
              </FormField>
              <FormField
                label="Article body"
                hint="Clean article writing only — Compose or HTML view of the story. Interactive tools go in the separate HTML/Tool Code panel below."
              >
                <ArticleBodyEditor
                  lang="en"
                  value={form.body}
                  onChange={(next) => set("body", next)}
                />
              </FormField>
              <AdminPanel title="HTML / Tool Code (English)" className="!shadow-none border border-emerald-200 bg-emerald-50/40">
                <div className="grid gap-4">
                  <p className="text-sm text-slate-600">
                    Paste calculator, converter, SEO tool, embed, or custom HTML/CSS/JS here.
                    Visitors see the working tool — not the raw code. Never mixed into the article body.
                  </p>
                  <FormField label="Tool Title" hint="e.g. Currency Converter">
                    <TextInput
                      dir="ltr"
                      value={form.toolTitle}
                      onChange={(e) => set("toolTitle", e.target.value)}
                      placeholder="Currency Converter"
                    />
                  </FormField>
                  <FormField label="HTML / Tool Code" hint="Full HTML document or fragment with CSS/JS">
                    <TextTextarea
                      dir="ltr"
                      rows={12}
                      className="font-mono text-sm"
                      value={form.toolCode}
                      onChange={(e) => set("toolCode", e.target.value)}
                      placeholder={"<!-- Example -->\n<div id=\"tool\">…</div>\n<script>/* your JS */</script>"}
                    />
                  </FormField>
                </div>
              </AdminPanel>
              <FormField label="Category">
                <TextSelect value={form.categoryId} onChange={(e) => set("categoryId", e.target.value)} dir="ltr">
                  <option value="">— Select —</option>
                  {localeCategories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </TextSelect>
              </FormField>
              <FormField label="Tags" hint="Comma-separated">
                <TextInput dir="ltr" value={form.tags} onChange={(e) => set("tags", e.target.value)} />
              </FormField>
              <FormField label="Focus keyword">
                <TextInput
                  dir="ltr"
                  value={form.focusKeyword}
                  onChange={(e) => set("focusKeyword", e.target.value)}
                />
              </FormField>
              <FormField label="Meta description" hint="Optional — defaults to summary">
                <TextTextarea
                  dir="ltr"
                  value={form.seoDescription}
                  onChange={(e) => {
                    seoTouched.current.seoDescription = true;
                    set("seoDescription", e.target.value);
                  }}
                />
              </FormField>
              <div className="rounded-lg border border-slate-200 p-3">
                <p className="mb-3 text-sm font-semibold">Main article image</p>
                <FeaturedImagePicker
                  language="en"
                  featuredImageId={form.featuredImageId}
                  imageUrl={form.imageUrl}
                  imageCaption={form.imageCaption}
                  imageCredit={form.imageCredit}
                  onChange={(next) =>
                    setForm((prev) => ({
                      ...prev,
                      featuredImageId: next.featuredImageId,
                      imageUrl: next.imageUrl,
                      imageCaption: next.imageCaption,
                      imageCredit: next.imageCredit,
                      ...(seoTouched.current.ogImage
                        ? {}
                        : { ogImage: next.imageUrl || prev.ogImage }),
                    }))
                  }
                />
              </div>
            </div>
          </AdminPanel>
        ) : (
          <AdminPanel title="خبر لکھیں">
            <div className="grid gap-4">
              <FormField label="عنوان" urdu hint="ضروری — SEO عنوان، OG اور URL اسی سے بنتے ہیں">
                <TextInput urdu required value={form.titleUr} onChange={(e) => onTitleChange(e.target.value)} />
              </FormField>
              <FormField label="خلاصہ" urdu hint="مزید پڑھیں سے پہلے؛ میٹا/OG تفصیل بھی یہی">
                <TextTextarea urdu value={form.excerptUr} onChange={(e) => onExcerptChange(e.target.value)} />
              </FormField>
              <FormField
                label="مکمل خبر / تجزیہ"
                urdu
                hint="صاف مضمون لکھائی — ٹولز الگ HTML/Tool Code پینل میں جائیں۔"
              >
                <ArticleBodyEditor
                  lang="ur"
                  value={form.bodyUr}
                  onChange={(next) => set("bodyUr", next)}
                />
              </FormField>
              <AdminPanel title="HTML / ٹول کوڈ (اردو)" className="!shadow-none border border-emerald-200 bg-emerald-50/40">
                <div className="grid gap-4" dir="rtl">
                  <p className="text-sm text-slate-600">
                    کیلکولیٹر، کنورٹر، SEO ٹول، ایمبیڈ یا کسٹم HTML/CSS/JS یہاں لگائیں۔
                    وزٹر کو اصل ٹول دکھے گا — خام کوڈ نہیں۔ مضمون کے متن میں نہیں ملے گا۔
                  </p>
                  <FormField label="ٹول کا عنوان" urdu hint="مثلاً کرنسی کنورٹر">
                    <TextInput
                      urdu
                      value={form.toolTitleUr}
                      onChange={(e) => set("toolTitleUr", e.target.value)}
                      placeholder="کرنسی کنورٹر"
                    />
                  </FormField>
                  <FormField label="HTML / ٹول کوڈ" urdu hint="مکمل HTML یا CSS/JS کے ساتھ حصہ">
                    <TextTextarea
                      dir="ltr"
                      rows={12}
                      className="font-mono text-sm"
                      value={form.toolCodeUr}
                      onChange={(e) => set("toolCodeUr", e.target.value)}
                      placeholder={"<!-- Example -->\n<div id=\"tool\">…</div>\n<script>/* your JS */</script>"}
                    />
                  </FormField>
                </div>
              </AdminPanel>
              <FormField label="کیٹیگری" urdu>
                <TextSelect
                  value={form.categoryUrId}
                  onChange={(e) => set("categoryUrId", e.target.value)}
                  dir="rtl"
                  className="font-urdu"
                >
                  <option value="">— منتخب کریں —</option>
                  {localeCategories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.nameUr || c.name}
                    </option>
                  ))}
                </TextSelect>
              </FormField>
              <FormField label="ٹیگز" urdu>
                <TextInput value={form.tagsUr} onChange={(e) => set("tagsUr", e.target.value)} />
              </FormField>
              <FormField label="فوکس کی ورڈ" urdu>
                <TextInput
                  urdu
                  value={form.focusKeywordUr}
                  onChange={(e) => set("focusKeywordUr", e.target.value)}
                />
              </FormField>
              <FormField label="میٹا تفصیل" urdu hint="اختیاری — خالی ہو تو خلاصہ استعمال ہوگا">
                <TextTextarea
                  urdu
                  value={form.seoDescriptionUr}
                  onChange={(e) => {
                    seoTouched.current.seoDescription = true;
                    set("seoDescriptionUr", e.target.value);
                  }}
                />
              </FormField>
              <div className="rounded-lg border border-slate-200 p-3">
                <p className="mb-3 text-sm font-semibold">مرکزی تصویر</p>
                <FeaturedImagePicker
                  language="ur"
                  featuredImageId={form.featuredImageUrId}
                  imageUrl={form.imageUrlUr}
                  imageCaption={form.imageCaptionUr}
                  imageCredit={form.imageCreditUr}
                  onChange={(next) =>
                    setForm((prev) => ({
                      ...prev,
                      featuredImageUrId: next.featuredImageId,
                      imageUrlUr: next.imageUrl,
                      imageCaptionUr: next.imageCaption,
                      imageCreditUr: next.imageCredit,
                      ...(seoTouched.current.ogImage
                        ? {}
                        : { ogImageUr: next.imageUrl || prev.ogImageUr }),
                    }))
                  }
                />
              </div>
            </div>
          </AdminPanel>
        )}

        <AdminPanel title={isUr ? "شائع / بریکنگ / لائیو" : "Publish / Featured / Breaking / Live"}>
          <div className="grid gap-4 md:grid-cols-3">
            <FormField label="Status">
              <TextSelect value={form.status} onChange={(e) => set("status", e.target.value)}>
                {ARTICLE_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </TextSelect>
            </FormField>
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={form.isFeatured}
                onChange={(e) => set("isFeatured", e.target.checked)}
              />
              {isUr ? "فیچرڈ آرٹیکل" : "Featured article"}
            </label>
            <label className="flex items-center gap-2 text-sm font-semibold text-slate-800">
              <input
                type="checkbox"
                checked={form.isBreaking}
                onChange={(e) => set("isBreaking", e.target.checked)}
              />
              {isUr ? "بریکنگ نیوز" : "Breaking news"}
            </label>
            <label className="flex items-center gap-2 text-sm font-semibold text-slate-800">
              <input
                type="checkbox"
                checked={form.isLive}
                onChange={(e) => set("isLive", e.target.checked)}
              />
              {isUr ? "لائیو کوریج" : "Live coverage"}
            </label>
            {form.isLive ? (
              <FormField label={isUr ? "لائیو مدت (گھنٹے)" : "LIVE duration"}>
                <TextSelect
                  value={form.liveDurationHours}
                  onChange={(e) => set("liveDurationHours", e.target.value)}
                >
                  <option value="1">1 hour</option>
                  <option value="2">2 hours</option>
                  <option value="3">3 hours</option>
                </TextSelect>
              </FormField>
            ) : null}
          </div>
          <p className="mt-3 text-xs text-slate-500">
            {isUr
              ? "پرائورٹی خود فیچرڈ/بریکنگ/لائیو سے سیٹ ہوتی ہے — عام خبر کے لیے دستی فیلڈ نہیں۔"
              : "Priority is set automatically from Featured / Breaking / Live — no manual priority for normal articles."}
          </p>
        </AdminPanel>

        <AdminPanel title={isUr ? "خودکار SEO (پیش نظارہ)" : "Automatic SEO (preview)"}>
          <dl className="grid gap-2 text-sm text-slate-700 sm:grid-cols-2">
            <div>
              <dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                SEO title / H1
              </dt>
              <dd className="mt-0.5 break-words">{autoPreview.seoTitle || "—"}</dd>
            </div>
            <div>
              <dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">URL / Slug</dt>
              <dd className="mt-0.5 break-all font-mono text-xs" dir="ltr">
                /{autoPreview.slug || "—"}
              </dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                Meta / OG description
              </dt>
              <dd className="mt-0.5 break-words">{autoPreview.seoDescription || "—"}</dd>
            </div>
            <div>
              <dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">OG title</dt>
              <dd className="mt-0.5 break-words">{autoPreview.ogTitle || "—"}</dd>
            </div>
            <div>
              <dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">OG image</dt>
              <dd className="mt-0.5 break-all font-mono text-xs" dir="ltr">
                {autoPreview.ogImage || (isUr ? "مرکزی تصویر سے" : "From main image")}
              </dd>
            </div>
            <div>
              <dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">Robots</dt>
              <dd className="mt-0.5">{autoPreview.robotsMeta}</dd>
            </div>
            <div>
              <dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">Canonical</dt>
              <dd className="mt-0.5 text-xs text-slate-500">
                {autoPreview.canonicalUrl ||
                  (isUr
                    ? "شائع ہونے پر موجودہ آرٹیکل URL سے"
                    : "From article URL when published")}
              </dd>
            </div>
          </dl>

          <button
            type="button"
            onClick={() => setShowAdvancedSeo((v) => !v)}
            className="mt-4 text-sm font-semibold text-[#1DB954] hover:underline"
          >
            {showAdvancedSeo
              ? isUr
                ? "▲ ایڈوانسڈ SEO چھپائیں"
                : "▲ Hide advanced SEO"
              : isUr
                ? "▼ ایڈوانسڈ SEO (دستی اووررائیڈ)"
                : "▼ Advanced SEO (manual override)"}
          </button>

          {showAdvancedSeo ? (
            <div className="mt-4 grid gap-4 border-t border-slate-100 pt-4 md:grid-cols-2">
              <FormField label={isUr ? "پرما لنک / URL" : "Permalink / Slug"}>
                <TextInput
                  dir="ltr"
                  value={isUr ? form.slugUr || form.slug : form.slug}
                  onChange={(e) => {
                    slugTouched.current = true;
                    const v = e.target.value;
                    if (isUr) {
                      set("slugUr", v);
                      set("slug", v);
                    } else {
                      set("slug", v);
                    }
                  }}
                />
              </FormField>
              <FormField label={isUr ? "SEO عنوان" : "SEO title"}>
                <TextInput
                  urdu={isUr}
                  value={isUr ? form.seoTitleUr : form.seoTitle}
                  onChange={(e) => {
                    seoTouched.current.seoTitle = true;
                    set(isUr ? "seoTitleUr" : "seoTitle", e.target.value);
                  }}
                />
              </FormField>
              <FormField label="OG title">
                <TextInput
                  urdu={isUr}
                  value={isUr ? form.ogTitleUr : form.ogTitle}
                  onChange={(e) => {
                    seoTouched.current.ogTitle = true;
                    set(isUr ? "ogTitleUr" : "ogTitle", e.target.value);
                  }}
                />
              </FormField>
              <FormField label="OG image URL">
                <TextInput
                  dir="ltr"
                  value={isUr ? form.ogImageUr : form.ogImage}
                  onChange={(e) => {
                    seoTouched.current.ogImage = true;
                    set(isUr ? "ogImageUr" : "ogImage", e.target.value);
                  }}
                />
              </FormField>
              <FormField label="OG description" className="md:col-span-2">
                <TextTextarea
                  urdu={isUr}
                  value={isUr ? form.ogDescriptionUr : form.ogDescription}
                  onChange={(e) => {
                    seoTouched.current.ogDescription = true;
                    set(isUr ? "ogDescriptionUr" : "ogDescription", e.target.value);
                  }}
                />
              </FormField>
              <FormField label="Canonical URL">
                <TextInput
                  dir="ltr"
                  value={form.canonicalUrl}
                  onChange={(e) => {
                    seoTouched.current.canonical = true;
                    set("canonicalUrl", e.target.value);
                  }}
                  placeholder="Leave blank = article URL"
                />
              </FormField>
              <FormField label="Robots meta">
                <TextInput
                  dir="ltr"
                  value={form.robotsMeta}
                  onChange={(e) => {
                    seoTouched.current.robots = true;
                    set("robotsMeta", e.target.value);
                  }}
                  placeholder="index,follow"
                />
              </FormField>
              <FormField label={isUr ? "اضافی سرچ کی ورڈز" : "Extra search keywords"} className="md:col-span-2">
                <TextInput
                  urdu={isUr}
                  value={isUr ? form.searchKeywordsUr : form.searchKeywords}
                  onChange={(e) => set(isUr ? "searchKeywordsUr" : "searchKeywords", e.target.value)}
                />
              </FormField>
              <FormField label={isUr ? "ویڈیو URL" : "Video URL"} className="md:col-span-2">
                <TextInput
                  dir="ltr"
                  type="url"
                  value={isUr ? form.videoUrlUr : form.videoUrl}
                  onChange={(e) => set(isUr ? "videoUrlUr" : "videoUrl", e.target.value)}
                />
              </FormField>
            </div>
          ) : null}
        </AdminPanel>

        <div className="flex flex-wrap gap-3">
          <button
            type="submit"
            disabled={saving}
            className="rounded-md bg-[#1DB954] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#159A45] disabled:opacity-60"
          >
            {saving ? "…" : isUr ? "محفوظ کریں" : "Save to database"}
          </button>
          <button
            type="button"
            disabled={saving}
            onClick={() => void save(true)}
            className="rounded-md border border-[#1DB954] bg-white px-5 py-2.5 text-sm font-semibold text-[#1DB954] hover:bg-emerald-50 disabled:opacity-60"
          >
            {isUr ? "محفوظ + شائع" : "Save & Publish"}
          </button>
        </div>
      </form>
    </div>
  );
}
