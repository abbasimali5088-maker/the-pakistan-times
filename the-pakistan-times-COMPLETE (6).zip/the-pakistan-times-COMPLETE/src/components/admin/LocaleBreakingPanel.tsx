"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { DataTable } from "@/components/admin/DataTable";
import { FormField, TextInput, TextSelect } from "@/components/admin/FormField";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { ConfirmButton } from "@/components/admin/ConfirmButton";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";
import type { ArticleLocale } from "@/components/admin/article-locale";

type Breaking = {
  id: string;
  headline: string;
  headlineUr?: string | null;
  priority?: number;
  status?: string;
  articleId?: string | null;
  startAt?: string | null;
  endAt?: string | null;
};

const empty = {
  headline: "",
  headlineUr: "",
  priority: "1",
  status: "draft",
  articleId: "",
  startAt: "",
  endAt: "",
};

export default function LocaleBreakingPanel({ locale }: { locale?: ArticleLocale }) {
  const isUr = locale === "ur";
  const isEn = locale === "en";
  const localeMode = Boolean(locale);
  const [rows, setRows] = useState<Breaking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(empty);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminFetch<{ items?: Breaking[] }>("/api/breaking", {
        allowNotFound: true,
      });
      const items = data?.items || [];
      // Locale hubs only show rows owned by that locale.
      // UR-only creates store Urdu in both headline + headlineUr (DB NOT NULL),
      // so EN must exclude any row that has headlineUr filled.
      if (isUr) {
        setRows(items.filter((r) => Boolean(r.headlineUr?.trim())));
      } else if (isEn) {
        setRows(
          items.filter(
            (r) => Boolean(r.headline?.trim()) && r.headline !== "—" && !r.headlineUr?.trim(),
          ),
        );
      } else {
        setRows(items);
      }
    } catch (err) {
      setRows([]);
      setError(err instanceof AdminApiError ? err.message : "Failed to load breaking news");
    } finally {
      setLoading(false);
    }
  }, [isEn, isUr]);

  useEffect(() => {
    void load();
  }, [load]);

  function setField(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function startEdit(row: Breaking) {
    setEditingId(row.id);
    setForm({
      headline: row.headline || "",
      headlineUr: row.headlineUr || "",
      priority: String(row.priority ?? 1),
      status: row.status || "draft",
      articleId: row.articleId || "",
      startAt: row.startAt ? String(row.startAt).slice(0, 16) : "",
      endAt: row.endAt ? String(row.endAt).slice(0, 16) : "",
    });
    setNotice(null);
  }

  function resetForm() {
    setEditingId(null);
    setForm(empty);
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const headline = form.headline.trim();
      const headlineUr = form.headlineUr.trim();

      if (isUr) {
        if (!headlineUr) throw new Error("اردو عنوان ضروری ہے");
      } else if (isEn) {
        if (!headline) throw new Error("English headline required");
      } else {
        if (!headline) throw new Error("English headline required");
        if (!headlineUr) throw new Error("اردو عنوان ضروری ہے");
      }

      // Locale-strict payload — never cross-write the other language from this hub.
      const payload = isUr
        ? {
            headline: headlineUr,
            headlineUr,
            priority: Number(form.priority) || 1,
            status: form.status,
            articleId: form.articleId.trim() || null,
            startAt: form.startAt ? new Date(form.startAt).toISOString() : null,
            endAt: form.endAt ? new Date(form.endAt).toISOString() : null,
            locale: "ur",
          }
        : isEn
          ? {
              headline,
              headlineUr: null,
              priority: Number(form.priority) || 1,
              status: form.status,
              articleId: form.articleId.trim() || null,
              startAt: form.startAt ? new Date(form.startAt).toISOString() : null,
              endAt: form.endAt ? new Date(form.endAt).toISOString() : null,
              locale: "en",
            }
          : {
              headline,
              headlineUr,
              priority: Number(form.priority) || 1,
              status: form.status,
              articleId: form.articleId.trim() || null,
              startAt: form.startAt ? new Date(form.startAt).toISOString() : null,
              endAt: form.endAt ? new Date(form.endAt).toISOString() : null,
            };

      if (editingId) {
        await adminFetch(`/api/breaking/${editingId}`, {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        setNotice(isUr ? "اردو بریکنگ محفوظ" : "English breaking saved");
      } else {
        await adminFetch("/api/breaking", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        setNotice(isUr ? "اردو بریکنگ بن گئی" : "English breaking created");
      }
      resetForm();
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError || err instanceof Error ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    try {
      await adminFetch(`/api/breaking/${id}`, { method: "DELETE" });
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Delete failed");
    }
  }

  return (
    <div>
      {!localeMode ? (
        <AdminPageHeader
          title="Breaking news"
          description="Use Articles English or Articles اردو hubs for locale-only breaking."
        />
      ) : (
        <p className="mb-3 text-sm text-slate-600">
          {isUr
            ? "صرف اردو ہیڈ لائن — English Headline یہاں نہیں ہے۔"
            : "English headline only — no Urdu title field in this workspace."}
        </p>
      )}

      {error ? (
        <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          {error}
        </div>
      ) : null}
      {notice ? (
        <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-900">
          {notice}
        </div>
      ) : null}

      <AdminPanel title={editingId ? "Edit breaking" : "Create breaking"} className="mb-4">
        <form onSubmit={onSubmit} className="space-y-4">
          {isUr || !localeMode ? (
            isUr ? (
              <div className="rounded-lg border border-emerald-200 bg-emerald-50/60 p-3">
                <FormField label="عنوان (اردو)">
                  <TextInput
                    required
                    dir="rtl"
                    value={form.headlineUr}
                    onChange={(e) => setField("headlineUr", e.target.value)}
                    placeholder="بریکنگ: قومی اسمبلی کا اجلاس"
                  />
                </FormField>
              </div>
            ) : (
              <>
                <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3">
                  <FormField label="Headline (EN)">
                    <TextInput
                      required
                      dir="ltr"
                      value={form.headline}
                      onChange={(e) => setField("headline", e.target.value)}
                      placeholder="Breaking: National Assembly session"
                    />
                  </FormField>
                </div>
                <div className="rounded-lg border border-emerald-200 bg-emerald-50/60 p-3">
                  <FormField label="عنوان (اردو)">
                    <TextInput
                      required
                      dir="rtl"
                      value={form.headlineUr}
                      onChange={(e) => setField("headlineUr", e.target.value)}
                      placeholder="بریکنگ: قومی اسمبلی کا اجلاس"
                    />
                  </FormField>
                </div>
              </>
            )
          ) : (
            <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3">
              <FormField label="Headline (EN)">
                <TextInput
                  required
                  dir="ltr"
                  value={form.headline}
                  onChange={(e) => setField("headline", e.target.value)}
                  placeholder="Breaking: National Assembly session"
                />
              </FormField>
            </div>
          )}

          <div className="grid gap-3 sm:grid-cols-2">
            <FormField label="Priority">
              <TextInput
                type="number"
                value={form.priority}
                onChange={(e) => setField("priority", e.target.value)}
              />
            </FormField>
            <FormField label="Status">
              <TextSelect value={form.status} onChange={(e) => setField("status", e.target.value)}>
                <option value="draft">draft</option>
                <option value="active">active</option>
                <option value="expired">expired</option>
              </TextSelect>
            </FormField>
          </div>
          <FormField label="Linked article ID (optional)">
            <TextInput
              dir="ltr"
              value={form.articleId}
              onChange={(e) => setField("articleId", e.target.value)}
              placeholder="leave empty if none"
            />
          </FormField>
          <div className="grid gap-3 sm:grid-cols-2">
            <FormField label="Start (optional)">
              <TextInput
                type="datetime-local"
                value={form.startAt}
                onChange={(e) => setField("startAt", e.target.value)}
              />
            </FormField>
            <FormField label="End (optional)">
              <TextInput
                type="datetime-local"
                value={form.endAt}
                onChange={(e) => setField("endAt", e.target.value)}
              />
            </FormField>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="submit"
              disabled={busy}
              className="rounded-md bg-[#1DB954] px-4 py-2 text-sm font-medium text-white hover:bg-[#159A45] disabled:opacity-60"
            >
              {busy ? "…" : editingId ? "Save" : "Create"}
            </button>
            {editingId ? (
              <button
                type="button"
                onClick={resetForm}
                className="rounded-md border border-slate-200 px-4 py-2 text-sm"
              >
                Cancel
              </button>
            ) : null}
          </div>
        </form>
      </AdminPanel>

      {loading ? (
        <p className="text-sm text-slate-500">Loading…</p>
      ) : (
        <DataTable
          rows={rows}
          rowKey={(r) => r.id}
          empty="No breaking items yet."
          columns={[
            {
              key: "headline",
              header: isUr ? "عنوان (اردو)" : "Headline (EN)",
              render: (r) => (
                <div
                  className="max-w-[18rem] whitespace-normal break-words text-sm"
                  dir={isUr ? "rtl" : "ltr"}
                >
                  {isUr ? r.headlineUr || "—" : r.headline}
                </div>
              ),
            },
            { key: "priority", header: "Priority", render: (r) => r.priority ?? "—" },
            { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
            {
              key: "actions",
              header: "Actions",
              render: (r) => (
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => startEdit(r)}
                    className="text-sm text-[#1DB954] hover:underline"
                  >
                    Edit
                  </button>
                  <ConfirmButton label="Delete" confirmLabel="Delete?" onConfirm={() => remove(r.id)} />
                </div>
              ),
            },
          ]}
        />
      )}
    </div>
  );
}
