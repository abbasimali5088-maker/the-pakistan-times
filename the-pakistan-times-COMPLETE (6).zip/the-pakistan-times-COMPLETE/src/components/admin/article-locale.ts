export type ArticleLocale = "en" | "ur";
