"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Code2, Link2, Pencil, X } from "lucide-react";
import { cn } from "@/lib/utils";

type Mode = "compose" | "html";

type LinkDraft = {
  text: string;
  url: string;
  newWindow: boolean;
  nofollow: boolean;
  /** When editing an existing <a> in compose mode */
  editingAnchor: HTMLAnchorElement | null;
};

const EMPTY_LINK: LinkDraft = {
  text: "",
  url: "",
  newWindow: true,
  nofollow: false,
  editingAnchor: null,
};

function looksLikeHtml(s: string) {
  return /<[a-z][\s\S]*>/i.test(s || "");
}

/** Soft-normalize plain text for visual display without mutating storage until user edits. */
function toVisualHtml(raw: string) {
  const text = (raw || "").trim();
  if (!text) return "";
  if (looksLikeHtml(text)) return text;
  return text
    .split(/\n{2,}/)
    .map((b) => b.trim())
    .filter(Boolean)
    .map((block) => {
      const lines = block.split("\n");
      if (lines.length === 1 && /^##\s+/.test(lines[0])) {
        return `<h2>${escapeText(lines[0].replace(/^##\s+/, ""))}</h2>`;
      }
      return `<p>${lines.map(escapeText).join("<br/>")}</p>`;
    })
    .join("");
}

function escapeText(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function buildAnchorHtml(draft: LinkDraft) {
  const href = draft.url.trim();
  const text = draft.text.trim() || href;
  if (!href) return "";
  const attrs: string[] = [`href="${href.replace(/"/g, "&quot;")}"`];
  const relParts: string[] = [];
  if (draft.newWindow) {
    attrs.push('target="_blank"');
    relParts.push("noopener", "noreferrer");
  }
  if (draft.nofollow) relParts.push("nofollow");
  if (relParts.length) attrs.push(`rel="${[...new Set(relParts)].join(" ")}"`);
  return `<a ${attrs.join(" ")}>${escapeText(text)}</a>`;
}

/**
 * Blogger-style Article Body editor:
 * - Compose (Visual) view ↔ HTML view, one synchronized source
 * - Link dialog: display text, URL, new window, nofollow
 * Used by both English and Urdu Article Editors.
 */
export function ArticleBodyEditor({
  value,
  onChange,
  lang,
  className,
}: {
  value: string;
  onChange: (next: string) => void;
  lang: "en" | "ur";
  className?: string;
}) {
  const isUr = lang === "ur";
  const [mode, setMode] = useState<Mode>("compose");
  const [modeMenuOpen, setModeMenuOpen] = useState(false);
  const [linkOpen, setLinkOpen] = useState(false);
  const [linkDraft, setLinkDraft] = useState<LinkDraft>(EMPTY_LINK);
  const [selectedLinkUrl, setSelectedLinkUrl] = useState<string | null>(null);
  const [asReadMore, setAsReadMore] = useState(false);

  const visualRef = useRef<HTMLDivElement>(null);
  const htmlRef = useRef<HTMLTextAreaElement>(null);
  const savedRange = useRef<Range | null>(null);
  const lastExternal = useRef(value);
  const suppressVisualSync = useRef(false);

  const labels = isUr
    ? {
        compose: "کمپوز ویو",
        html: "HTML ویو",
        composeHint: "ویژوئل — تصاویر، عنوانات، لنکس نظر آئیں",
        htmlHint: "اصل HTML کوڈ — ایڈٹ / پیسٹ / ری پلیس",
        bold: "موٹا",
        italic: "ترچھا",
        link: "لنک",
        readMore: "ریڈ مور لنک",
        linkTitle: "لنک بنائیں / ایڈٹ کریں",
        textLabel: "دکھانے والا متن",
        urlLabel: "لنک پیسٹ کریں یا تلاش کریں",
        newWindow: "نیا ونڈو میں کھولیں",
        nofollow: "rel=nofollow شامل کریں",
        apply: "APPLY",
        cancel: "منسوخ",
        readMorePrefix: "مزید پڑھیں:",
        placeholder: "یہاں مضمون لکھیں — ٹولز الگ HTML/Tool Code پینل میں لگائیں",
      }
    : {
        compose: "Compose view",
        html: "HTML view",
        composeHint: "Visual — headings, links, formatting (not tools)",
        htmlHint: "Article HTML only — interactive tools use the Tool Code panel",
        bold: "Bold",
        italic: "Italic",
        link: "Link",
        readMore: "Read more link",
        linkTitle: "Edit link",
        textLabel: "Text to display",
        urlLabel: "Paste or search for a link",
        newWindow: "Open this link in a new window",
        nofollow: "Add 'rel=nofollow' attribute",
        apply: "APPLY",
        cancel: "Cancel",
        readMorePrefix: "Read more:",
        placeholder: "Write the article here — put tools in the separate HTML/Tool Code panel",
      };

  /** Push HTML from visual editor to parent (single source of truth). */
  const commitVisual = useCallback(() => {
    const el = visualRef.current;
    if (!el) return;
    suppressVisualSync.current = true;
    const html = el.innerHTML;
    // Treat empty visual as empty string
    const next = html === "<br>" || html === "<div><br></div>" ? "" : html;
    lastExternal.current = next;
    onChange(next);
    requestAnimationFrame(() => {
      suppressVisualSync.current = false;
    });
  }, [onChange]);

  /** Keep visual DOM in sync when value changes from outside (load article / HTML mode). */
  useEffect(() => {
    if (suppressVisualSync.current) return;
    if (mode !== "compose") {
      lastExternal.current = value;
      return;
    }
    const el = visualRef.current;
    if (!el) return;
    if (value === lastExternal.current && el.innerHTML) return;
    lastExternal.current = value;
    const html = toVisualHtml(value);
    if (el.innerHTML !== html) {
      el.innerHTML = html || "";
    }
  }, [value, mode]);

  function switchMode(next: Mode) {
    setModeMenuOpen(false);
    if (next === mode) return;
    if (mode === "compose" && next === "html") {
      // Flush visual → value before showing HTML
      commitVisual();
    }
    if (mode === "html" && next === "compose") {
      // value already updated from textarea; effect will paint visual
      lastExternal.current = "";
    }
    setMode(next);
    setSelectedLinkUrl(null);
  }

  function saveSelection() {
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) {
      savedRange.current = sel.getRangeAt(0).cloneRange();
    }
  }

  function restoreSelection() {
    const range = savedRange.current;
    const el = visualRef.current;
    if (!range || !el) return;
    const sel = window.getSelection();
    if (!sel) return;
    sel.removeAllRanges();
    sel.addRange(range);
    el.focus();
  }

  function exec(cmd: string) {
    visualRef.current?.focus();
    document.execCommand(cmd, false);
    commitVisual();
  }

  function openLinkDialog(opts?: { readMore?: boolean }) {
    setAsReadMore(Boolean(opts?.readMore));
    if (mode === "compose") {
      saveSelection();
      const sel = window.getSelection();
      let text = sel?.toString() || "";
      let url = "";
      let editingAnchor: HTMLAnchorElement | null = null;
      let newWindow = true;
      let nofollow = false;

      const anchor =
        (sel?.anchorNode?.parentElement?.closest?.("a") as HTMLAnchorElement | null) ||
        (sel?.focusNode?.parentElement?.closest?.("a") as HTMLAnchorElement | null) ||
        null;
      if (anchor && visualRef.current?.contains(anchor)) {
        editingAnchor = anchor;
        text = anchor.textContent || text;
        url = anchor.getAttribute("href") || "";
        newWindow = anchor.target === "_blank";
        nofollow = (anchor.getAttribute("rel") || "").includes("nofollow");
      }

      setLinkDraft({
        text,
        url,
        newWindow,
        nofollow,
        editingAnchor,
      });
    } else {
      const ta = htmlRef.current;
      const selected = ta
        ? ta.value.slice(ta.selectionStart, ta.selectionEnd)
        : "";
      setLinkDraft({
        ...EMPTY_LINK,
        text: selected,
        newWindow: true,
      });
    }
    setLinkOpen(true);
  }

  function closeLinkDialog() {
    setLinkOpen(false);
    setLinkDraft(EMPTY_LINK);
    setAsReadMore(false);
  }

  function applyLink() {
    const html = buildAnchorHtml(linkDraft);
    if (!html) {
      closeLinkDialog();
      return;
    }

    if (mode === "html") {
      const ta = htmlRef.current;
      if (!ta) {
        onChange((value || "") + html);
      } else {
        const start = ta.selectionStart;
        const end = ta.selectionEnd;
        const next = ta.value.slice(0, start) + html + ta.value.slice(end);
        onChange(next);
        requestAnimationFrame(() => {
          ta.focus();
          const pos = start + html.length;
          ta.setSelectionRange(pos, pos);
        });
      }
      closeLinkDialog();
      return;
    }

    const el = visualRef.current;
    if (!el) return;
    el.focus();

    if (asReadMore && !linkDraft.editingAnchor) {
      const block = `<p><strong>${escapeText(labels.readMorePrefix)}</strong> ${html}</p>`;
      restoreSelection();
      const ok = document.execCommand("insertHTML", false, block);
      if (!ok) el.innerHTML = (el.innerHTML || "") + block;
      commitVisual();
      closeLinkDialog();
      return;
    }

    if (linkDraft.editingAnchor && el.contains(linkDraft.editingAnchor)) {
      const a = linkDraft.editingAnchor;
      a.href = linkDraft.url.trim();
      a.textContent = linkDraft.text.trim() || linkDraft.url.trim();
      if (linkDraft.newWindow) {
        a.target = "_blank";
      } else {
        a.removeAttribute("target");
      }
      const relParts: string[] = [];
      if (linkDraft.newWindow) relParts.push("noopener", "noreferrer");
      if (linkDraft.nofollow) relParts.push("nofollow");
      if (relParts.length) a.setAttribute("rel", [...new Set(relParts)].join(" "));
      else a.removeAttribute("rel");
      commitVisual();
    } else {
      restoreSelection();
      const ok = document.execCommand("insertHTML", false, html);
      if (!ok) el.innerHTML = (el.innerHTML || "") + html;
      commitVisual();
    }

    closeLinkDialog();
  }

  function insertReadMoreBlock() {
    openLinkDialog({ readMore: true });
  }

  function onVisualClick(e: React.MouseEvent<HTMLDivElement>) {
    const t = e.target as HTMLElement;
    const a = t.closest?.("a") as HTMLAnchorElement | null;
    if (a && visualRef.current?.contains(a)) {
      setSelectedLinkUrl(a.href);
    } else {
      setSelectedLinkUrl(null);
    }
  }

  function onVisualKeyUp() {
    const sel = window.getSelection();
    const a =
      (sel?.anchorNode?.parentElement?.closest?.("a") as HTMLAnchorElement | null) || null;
    if (a && visualRef.current?.contains(a)) setSelectedLinkUrl(a.href);
    else setSelectedLinkUrl(null);
  }

  return (
    <div className={cn("overflow-hidden rounded-md border border-slate-300 bg-white shadow-sm", className)}>
      {/* Toolbar — Blogger-like */}
      <div className="flex flex-wrap items-center gap-1 border-b border-slate-200 bg-slate-50 px-2 py-1.5">
        <div className="relative">
          <button
            type="button"
            onClick={() => setModeMenuOpen((o) => !o)}
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-100"
          >
            {mode === "compose" ? (
              <Pencil className="h-3.5 w-3.5" />
            ) : (
              <Code2 className="h-3.5 w-3.5" />
            )}
            {mode === "compose" ? labels.compose : labels.html}
            <span className="text-slate-400">▾</span>
          </button>
          {modeMenuOpen ? (
            <div className="absolute start-0 z-30 mt-1 min-w-[180px] rounded-md border border-slate-200 bg-white py-1 shadow-lg">
              <button
                type="button"
                className={cn(
                  "flex w-full items-center gap-2 px-3 py-2 text-start text-sm hover:bg-slate-50",
                  mode === "html" && "bg-emerald-50 font-semibold text-[#1DB954]",
                )}
                onClick={() => switchMode("html")}
              >
                <Code2 className="h-4 w-4" />
                {labels.html}
              </button>
              <button
                type="button"
                className={cn(
                  "flex w-full items-center gap-2 px-3 py-2 text-start text-sm hover:bg-slate-50",
                  mode === "compose" && "bg-emerald-50 font-semibold text-[#1DB954]",
                )}
                onClick={() => switchMode("compose")}
              >
                <Pencil className="h-4 w-4" />
                {labels.compose}
              </button>
            </div>
          ) : null}
        </div>

        <span className="mx-1 hidden h-5 w-px bg-slate-300 sm:block" />

        {mode === "compose" ? (
          <>
            <button
              type="button"
              title={labels.bold}
              className="rounded px-2 py-1 text-sm font-bold hover:bg-slate-200"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => exec("bold")}
            >
              B
            </button>
            <button
              type="button"
              title={labels.italic}
              className="rounded px-2 py-1 text-sm italic hover:bg-slate-200"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => exec("italic")}
            >
              I
            </button>
            <button
              type="button"
              title={labels.link}
              className="inline-flex items-center gap-1 rounded px-2 py-1 text-sm hover:bg-slate-200"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => openLinkDialog()}
            >
              <Link2 className="h-3.5 w-3.5" />
              {labels.link}
            </button>
            <button
              type="button"
              title={labels.readMore}
              className="rounded px-2 py-1 text-xs font-semibold text-[#1DB954] hover:bg-emerald-50"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => insertReadMoreBlock()}
            >
              {labels.readMore}
            </button>
          </>
        ) : (
          <button
            type="button"
            title={labels.link}
            className="inline-flex items-center gap-1 rounded px-2 py-1 text-sm hover:bg-slate-200"
            onClick={() => openLinkDialog()}
          >
            <Link2 className="h-3.5 w-3.5" />
            {labels.link}
          </button>
        )}

        <span className="ms-auto text-[11px] text-slate-500">
          {mode === "compose" ? labels.composeHint : labels.htmlHint}
        </span>
      </div>

      {selectedLinkUrl && mode === "compose" ? (
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 bg-amber-50 px-3 py-1.5 text-xs text-slate-700">
          <span className="max-w-[min(420px,70vw)] truncate font-mono" dir="ltr">
            {selectedLinkUrl}
          </span>
          <button
            type="button"
            className="font-semibold text-[#1DB954] underline"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => openLinkDialog()}
          >
            {isUr ? "ایڈٹ" : "Edit"}
          </button>
          <button
            type="button"
            className="font-semibold text-red-600 underline"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => {
              const sel = window.getSelection();
              const a =
                (sel?.anchorNode?.parentElement?.closest?.("a") as HTMLAnchorElement | null) ||
                null;
              if (a && visualRef.current?.contains(a)) {
                const text = document.createTextNode(a.textContent || "");
                a.replaceWith(text);
                commitVisual();
              }
              setSelectedLinkUrl(null);
            }}
          >
            {isUr ? "لنک ہٹائیں" : "Remove link"}
          </button>
        </div>
      ) : null}

      {mode === "compose" ? (
        <div
          ref={visualRef}
          role="textbox"
          aria-multiline
          contentEditable
          suppressContentEditableWarning
          dir={isUr ? "rtl" : "ltr"}
          data-placeholder={labels.placeholder}
          className={cn(
            "article-body-compose min-h-[280px] max-h-[640px] overflow-y-auto px-4 py-3 text-base leading-relaxed text-slate-900 outline-none focus:bg-white",
            isUr && "font-urdu text-right",
            "[&:empty]:before:pointer-events-none [&:empty]:before:text-slate-400 [&:empty]:before:content-[attr(data-placeholder)]",
            "[&_a]:font-semibold [&_a]:text-[#1DB954] [&_a]:underline",
            "[&_h2]:mb-2 [&_h2]:mt-4 [&_h2]:text-xl [&_h2]:font-bold",
            "[&_h3]:mb-2 [&_h3]:mt-3 [&_h3]:text-lg [&_h3]:font-bold",
            "[&_img]:my-3 [&_img]:max-h-[420px] [&_img]:max-w-full [&_img]:rounded",
            "[&_iframe]:my-3 [&_iframe]:max-w-full",
            "[&_p]:mb-3",
          )}
          onInput={commitVisual}
          onBlur={commitVisual}
          onClick={onVisualClick}
          onKeyUp={onVisualKeyUp}
        />
      ) : (
        <textarea
          ref={htmlRef}
          dir="ltr"
          spellCheck={false}
          className="min-h-[280px] max-h-[640px] w-full resize-y border-0 bg-[#0f172a] px-4 py-3 font-mono text-[13px] leading-relaxed text-emerald-100 outline-none"
          value={value}
          onChange={(e) => {
            lastExternal.current = e.target.value;
            onChange(e.target.value);
          }}
          placeholder={"<!-- HTML source of this article body -->\n<p>...</p>"}
        />
      )}

      {/* Link modal — Blogger style */}
      {linkOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div
            className="w-full max-w-md rounded-lg border border-slate-200 bg-white p-5 shadow-xl"
            role="dialog"
            aria-modal
            aria-label={labels.linkTitle}
          >
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-base font-semibold text-slate-900">{labels.linkTitle}</h3>
              <button
                type="button"
                className="rounded p-1 text-slate-500 hover:bg-slate-100"
                onClick={() => closeLinkDialog()}
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <label className="mb-3 block text-sm">
              <span className="mb-1 block font-medium text-slate-700">{labels.textLabel}</span>
              <input
                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
                dir={isUr ? "rtl" : "ltr"}
                value={linkDraft.text}
                onChange={(e) => setLinkDraft((d) => ({ ...d, text: e.target.value }))}
                placeholder={isUr ? "لنک کا عنوان" : "Link title / anchor text"}
              />
            </label>

            <label className="mb-3 block text-sm">
              <span className="mb-1 block font-medium text-slate-700">{labels.urlLabel}</span>
              <input
                className="w-full rounded-md border border-slate-300 px-3 py-2 font-mono text-sm"
                dir="ltr"
                value={linkDraft.url}
                onChange={(e) => setLinkDraft((d) => ({ ...d, url: e.target.value }))}
                placeholder="https://www.thepakistantimes.live/…"
              />
            </label>

            <label className="mb-2 flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={linkDraft.newWindow}
                onChange={(e) => setLinkDraft((d) => ({ ...d, newWindow: e.target.checked }))}
              />
              {labels.newWindow}
            </label>
            <label className="mb-5 flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={linkDraft.nofollow}
                onChange={(e) => setLinkDraft((d) => ({ ...d, nofollow: e.target.checked }))}
              />
              {labels.nofollow}
            </label>

            {asReadMore ? (
              <p className="mb-3 rounded-md bg-emerald-50 px-3 py-2 text-xs text-emerald-900">
                {isUr
                  ? "APPLY پر «مزید پڑھیں: عنوان» کے ساتھ اندرونی/بیرونی لنک لگے گا — ویوز بڑھانے کے لیے۔"
                  : "APPLY inserts “Read more: Title” with your internal/external URL — drives next-article clicks."}
              </p>
            ) : null}

            <div className="flex justify-end gap-2">
              <button
                type="button"
                className="rounded-md border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                onClick={() => closeLinkDialog()}
              >
                {labels.cancel}
              </button>
              <button
                type="button"
                className="rounded-md bg-[#1DB954] px-5 py-2 text-sm font-bold text-white hover:bg-[#159A45]"
                onClick={() => applyLink()}
              >
                {labels.apply}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
