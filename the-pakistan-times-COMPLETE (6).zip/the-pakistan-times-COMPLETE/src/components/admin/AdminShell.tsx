"use client";

import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { adminFetch } from "@/lib/admin-fetch";
import {
  LayoutDashboard,
  Newspaper,
  FolderTree,
  Tags,
  Users,
  Image,
  Video,
  Images,
  MessageSquare,
  Search,
  CornerDownRight,
  AlertTriangle,
  Menu,
  LayoutTemplate,
  FileText,
  Megaphone,
  Mail,
  BarChart3,
  HelpCircle,
  UserCog,
  Shield,
  LineChart,
  Bell,
  Settings,
  Coins,
  DatabaseBackup,
  Clock,
  ScrollText,
  BookOpen,
  LogOut,
  PanelLeftClose,
  PanelLeft,
  X,
  KeyRound,
  Eye,
} from "lucide-react";

export type AdminUser = {
  id: string;
  email: string;
  name?: string;
  username?: string;
};

type AdminWorkspace = "en" | "ur" | "shared";

type NavItem = {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  /** Which admin workspace shows this item */
  workspace: AdminWorkspace | "all";
};

const NAV: NavItem[] = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard, workspace: "all" },
  { href: "/admin/articles/en", label: "English Articles", icon: Newspaper, workspace: "en" },
  { href: "/admin/categories?lang=en", label: "English Categories", icon: FolderTree, workspace: "en" },
  { href: "/admin/tags?lang=en", label: "English Tags", icon: Tags, workspace: "en" },
  { href: "/admin/media?lang=en", label: "English Media / Images", icon: Image, workspace: "en" },
  { href: "/admin/videos?lang=en", label: "English Videos", icon: Video, workspace: "en" },
  { href: "/admin/seo?lang=en", label: "English SEO", icon: Search, workspace: "en" },
  { href: "/admin/articles/en?tab=breaking", label: "English Breaking", icon: Megaphone, workspace: "en" },
  { href: "/admin/articles/en?tab=live", label: "English Live", icon: Eye, workspace: "en" },
  { href: "/admin/articles/ur", label: "اردو آرٹیکلز", icon: Newspaper, workspace: "ur" },
  { href: "/admin/categories?lang=ur", label: "اردو کیٹیگریز", icon: FolderTree, workspace: "ur" },
  { href: "/admin/tags?lang=ur", label: "اردو ٹیگز", icon: Tags, workspace: "ur" },
  { href: "/admin/media?lang=ur", label: "اردو میڈیا / تصاویر", icon: Image, workspace: "ur" },
  { href: "/admin/videos?lang=ur", label: "اردو ویڈیوز", icon: Video, workspace: "ur" },
  { href: "/admin/seo?lang=ur", label: "اردو SEO", icon: Search, workspace: "ur" },
  { href: "/admin/articles/ur?tab=breaking", label: "اردو بریکنگ", icon: Megaphone, workspace: "ur" },
  { href: "/admin/articles/ur?tab=live", label: "اردو لائیو", icon: Eye, workspace: "ur" },
  { href: "/admin/views", label: "Views", icon: Eye, workspace: "shared" },
  { href: "/admin/authors", label: "Authors", icon: Users, workspace: "shared" },
  { href: "/admin/galleries", label: "Galleries", icon: Images, workspace: "shared" },
  { href: "/admin/comments", label: "Comments", icon: MessageSquare, workspace: "shared" },
  { href: "/admin/redirects", label: "Redirects", icon: CornerDownRight, workspace: "shared" },
  { href: "/admin/notfound", label: "404", icon: AlertTriangle, workspace: "shared" },
  { href: "/admin/menus", label: "Menus", icon: Menu, workspace: "shared" },
  { href: "/admin/homepage", label: "Homepage", icon: LayoutTemplate, workspace: "shared" },
  { href: "/admin/pages", label: "Pages", icon: FileText, workspace: "shared" },
  { href: "/admin/ads", label: "Ads", icon: Megaphone, workspace: "shared" },
  { href: "/admin/newsletter", label: "Newsletter", icon: Mail, workspace: "shared" },
  { href: "/admin/polls", label: "Polls", icon: BarChart3, workspace: "shared" },
  { href: "/admin/quizzes", label: "Quizzes", icon: HelpCircle, workspace: "shared" },
  { href: "/admin/users", label: "Users", icon: UserCog, workspace: "shared" },
  { href: "/admin/roles", label: "Roles", icon: Shield, workspace: "shared" },
  { href: "/admin/analytics", label: "Analytics", icon: LineChart, workspace: "shared" },
  { href: "/admin/notifications", label: "Notifications", icon: Bell, workspace: "shared" },
  { href: "/admin/settings", label: "Settings", icon: Settings, workspace: "shared" },
  { href: "/admin/account", label: "Password", icon: KeyRound, workspace: "shared" },
  { href: "/admin/rates", label: "Rates", icon: Coins, workspace: "shared" },
  { href: "/admin/backup", label: "Backup", icon: DatabaseBackup, workspace: "shared" },
  { href: "/admin/jobs", label: "Jobs", icon: Clock, workspace: "shared" },
  { href: "/admin/audit", label: "Audit", icon: ScrollText, workspace: "shared" },
  { href: "/admin/docs", label: "API Docs", icon: BookOpen, workspace: "shared" },
];

const WORKSPACE_KEY = "pt_admin_workspace";

function detectWorkspace(pathname: string, search: string): "en" | "ur" {
  if (pathname.startsWith("/admin/articles/ur")) return "ur";
  if (pathname.startsWith("/admin/articles/en")) return "en";
  if (pathname.includes("/articles/") && search.includes("lang=ur")) return "ur";
  if (pathname.includes("/articles/") && search.includes("lang=en")) return "en";
  if (search.includes("lang=ur")) return "ur";
  if (search.includes("lang=en")) return "en";
  if (typeof window !== "undefined") {
    const saved = window.localStorage.getItem(WORKSPACE_KEY);
    if (saved === "ur" || saved === "en") return saved;
  }
  return "en";
}

function isActive(pathname: string, search: string, href: string) {
  const [path, query = ""] = href.split("?");
  if (path === "/admin") return pathname === "/admin";

  if (path === "/admin/articles/en") {
    const onEn =
      pathname === "/admin/articles/en" ||
      pathname.startsWith("/admin/articles/en/") ||
      (pathname.startsWith("/admin/articles/") &&
        !pathname.startsWith("/admin/articles/ur") &&
        (search.includes("lang=en") || pathname.match(/\/admin\/articles\/[^/?]+$/)));
    if (!onEn) return false;
    if (query.includes("tab=breaking")) return search.includes("tab=breaking");
    if (query.includes("tab=live")) return search.includes("tab=live");
    return !search.includes("tab=breaking") && !search.includes("tab=live");
  }

  if (path === "/admin/articles/ur") {
    const onUr =
      pathname === "/admin/articles/ur" || pathname.startsWith("/admin/articles/ur/");
    if (!onUr && !(pathname.startsWith("/admin/articles/") && search.includes("lang=ur"))) {
      return false;
    }
    if (!onUr && pathname.startsWith("/admin/articles/") && search.includes("lang=ur")) {
      if (query.includes("tab=")) return false;
      return true;
    }
    if (query.includes("tab=breaking")) return search.includes("tab=breaking");
    if (query.includes("tab=live")) return search.includes("tab=live");
    return !search.includes("tab=breaking") && !search.includes("tab=live");
  }

  if (pathname !== path && !pathname.startsWith(`${path}/`)) return false;
  if (!query) return true;
  const params = new URLSearchParams(query);
  const current = new URLSearchParams(search.startsWith("?") ? search.slice(1) : search);
  for (const [k, v] of params.entries()) {
    if (current.get(k) !== v) return false;
  }
  return true;
}

type AdminShellProps = {
  user: AdminUser;
  children: ReactNode;
};

export function AdminShell({ user, children }: AdminShellProps) {
  const pathname = usePathname();
  const router = useRouter();
  const searchParams = useSearchParams();
  const search = searchParams.toString();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const [workspace, setWorkspace] = useState<"en" | "ur">(() =>
    detectWorkspace(pathname, search),
  );

  useEffect(() => {
    const next = detectWorkspace(pathname, search);
    setWorkspace(next);
    try {
      window.localStorage.setItem(WORKSPACE_KEY, next);
    } catch {
      /* ignore */
    }
  }, [pathname, search]);

  function switchWorkspace(next: "en" | "ur") {
    setWorkspace(next);
    try {
      window.localStorage.setItem(WORKSPACE_KEY, next);
    } catch {
      /* ignore */
    }
    router.push(next === "ur" ? "/admin/articles/ur" : "/admin/articles/en");
  }

  async function logout() {
    setLoggingOut(true);
    try {
      await adminFetch("/api/auth", { method: "DELETE" });
    } catch {
      /* still leave */
    }
    router.replace("/admin/login");
    router.refresh();
  }

  const visibleNav = useMemo(
    () =>
      NAV.filter(
        (item) =>
          item.workspace === "all" ||
          item.workspace === "shared" ||
          item.workspace === workspace,
      ),
    [workspace],
  );

  const nav = (
    <nav className="flex flex-1 flex-col gap-0.5 overflow-y-auto px-2 py-3">
      {visibleNav.map((item) => {
        const Icon = item.icon;
        const active = isActive(pathname, search, item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={() => setMobileOpen(false)}
            title={item.label}
            className={cn(
              "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition",
              active
                ? "bg-[#1DB954] text-white"
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
              collapsed && "justify-center px-2",
            )}
          >
            <Icon className="h-4 w-4 shrink-0" />
            {!collapsed || mobileOpen ? <span>{item.label}</span> : null}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      {mobileOpen ? (
        <button
          type="button"
          aria-label="Close menu"
          className="fixed inset-0 z-40 bg-black/40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      ) : null}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex flex-col border-r border-slate-200 bg-white transition-all",
          collapsed ? "w-[68px]" : "w-64",
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        )}
      >
        <div className="flex h-14 items-center justify-between gap-2 border-b border-slate-200 px-3">
          {!collapsed || mobileOpen ? (
            <div className="min-w-0">
              <p className="truncate font-urdu text-base font-semibold text-[#1DB954]" dir="rtl">
                دی پاکستان ٹائمز
              </p>
              <p className="text-[11px] uppercase tracking-wide text-slate-500">Admin</p>
            </div>
          ) : (
            <span className="mx-auto text-sm font-bold text-[#1DB954]">PT</span>
          )}
          <button
            type="button"
            className="rounded p-1.5 text-slate-500 hover:bg-slate-100 lg:hidden"
            onClick={() => setMobileOpen(false)}
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {(!collapsed || mobileOpen) && (
          <div className="grid grid-cols-2 gap-1 border-b border-slate-200 p-2">
            <button
              type="button"
              onClick={() => switchWorkspace("en")}
              className={cn(
                "rounded-md px-2 py-2 text-xs font-bold transition",
                workspace === "en"
                  ? "bg-[#1DB954] text-white"
                  : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
              )}
            >
              English Admin
            </button>
            <button
              type="button"
              onClick={() => switchWorkspace("ur")}
              className={cn(
                "rounded-md px-2 py-2 text-xs font-bold transition",
                workspace === "ur"
                  ? "bg-[#1DB954] text-white"
                  : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
              )}
              dir="rtl"
            >
              Urdu Admin
            </button>
          </div>
        )}

        {(!collapsed || mobileOpen) && (
          <p
            className={cn(
              "mx-2 mt-2 rounded-md px-2 py-1.5 text-[11px] font-medium",
              workspace === "ur"
                ? "bg-emerald-50 text-emerald-900"
                : "bg-sky-50 text-sky-900",
            )}
          >
            {workspace === "ur"
              ? "اردو ورک اسپیس — صرف اردو مواد"
              : "English workspace — English content only"}
          </p>
        )}

        {nav}

        <div className="border-t border-slate-200 p-3">
          {(!collapsed || mobileOpen) && (
            <p className="mb-2 truncate text-xs text-slate-500">{user.email}</p>
          )}
          <button
            type="button"
            disabled={loggingOut}
            onClick={logout}
            className={cn(
              "flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-slate-600 hover:bg-slate-100",
              collapsed && !mobileOpen && "justify-center px-2",
            )}
          >
            <LogOut className="h-4 w-4" />
            {(!collapsed || mobileOpen) && <span>{loggingOut ? "Signing out…" : "Logout"}</span>}
          </button>
        </div>
      </aside>

      <div className={cn("transition-[padding]", collapsed ? "lg:pl-[68px]" : "lg:pl-64")}>
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-slate-200 bg-white/95 px-4 backdrop-blur">
          <button
            type="button"
            className="rounded-md border border-slate-200 p-2 text-slate-600 hover:bg-slate-50 lg:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-4 w-4" />
          </button>
          <button
            type="button"
            className="hidden rounded-md border border-slate-200 p-2 text-slate-600 hover:bg-slate-50 lg:inline-flex"
            onClick={() => setCollapsed((v) => !v)}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {collapsed ? <PanelLeft className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-slate-800">
              {user.name || user.username || "Editor"}
              <span className="ms-2 text-xs font-semibold text-[#1DB954]">
                {workspace === "ur" ? "· Urdu Admin" : "· English Admin"}
              </span>
            </p>
          </div>
          <Link
            href={workspace === "ur" ? "/?lang=ur" : "/?lang=en"}
            className="text-xs font-medium text-[#1DB954] hover:underline"
            target="_blank"
          >
            View {workspace === "ur" ? "Urdu" : "English"} site
          </Link>
        </header>
        <main className="p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}

export function AdminPageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <h1 className="text-xl font-semibold text-slate-900 md:text-2xl">{title}</h1>
        {description ? <p className="mt-1 text-sm text-slate-500">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function AdminPanel({
  children,
  className,
  title,
  description,
}: {
  children: ReactNode;
  className?: string;
  title?: string;
  description?: string;
}) {
  return (
    <section className={cn("rounded-lg border border-slate-200 bg-white p-4 shadow-sm md:p-5", className)}>
      {title ? <h2 className="mb-1 text-sm font-semibold text-slate-800">{title}</h2> : null}
      {description ? <p className="mb-3 text-xs text-slate-500">{description}</p> : null}
      {title ? <div className={description ? "mb-1" : "mb-4"} /> : null}
      {children}
    </section>
  );
}
