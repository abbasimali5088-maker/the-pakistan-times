"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { AdminPageHeader } from "@/components/admin/AdminShell";
import type { ArticleLocale } from "@/components/admin/article-locale";
import ArticlesClient from "@/app/admin/articles/ArticlesClient";
import LocaleBreakingPanel from "@/components/admin/LocaleBreakingPanel";
import LocaleLivePanel from "@/components/admin/LocaleLivePanel";

const TABS = [
  { id: "articles", en: "Articles", ur: "آرٹیکلز" },
  { id: "breaking", en: "Breaking", ur: "بریکنگ" },
  { id: "live", en: "Live", ur: "لائیو" },
] as const;

export function LocaleArticlesHub({ locale }: { locale: ArticleLocale }) {
  const searchParams = useSearchParams();
  const tabParam = searchParams.get("tab");
  const tab =
    tabParam === "breaking" || tabParam === "live" || tabParam === "articles"
      ? tabParam
      : "articles";
  const isUr = locale === "ur";
  const base = `/admin/articles/${locale}`;

  return (
    <div>
      <AdminPageHeader
        title={isUr ? "آرٹیکل اردو" : "Articles English"}
        description={
          isUr
            ? "اردو سسٹم الگ — آرٹیکل، بریکنگ، لائیو سب یہاں (A–Z سیٹنگز)۔"
            : "English system separate — Articles, Breaking, Live all here (A–Z settings)."
        }
      />

      <div className="mb-4 flex flex-wrap gap-2">
        {TABS.map((t) => {
          const active = tab === t.id;
          const href = t.id === "articles" ? base : `${base}?tab=${t.id}`;
          return (
            <Link
              key={t.id}
              href={href}
              className={`rounded-md px-4 py-2 text-sm font-semibold ${
                active
                  ? "bg-[#1DB954] text-white"
                  : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
              }`}
            >
              {isUr ? t.ur : t.en}
            </Link>
          );
        })}
      </div>

      <div
        className={`mb-4 rounded-md border px-3 py-2 text-sm ${
          isUr
            ? "border-emerald-200 bg-emerald-50 text-emerald-900"
            : "border-sky-200 bg-sky-50 text-sky-900"
        }`}
      >
        {isUr
          ? "یہ صرف اردو ورک اسپیس ہے۔ عنوان، URL، تصویر، SEO، بریکنگ، لائیو — سب اردو۔"
          : "English workspace only. Title, URL, image, SEO, Breaking, Live — all English."}
      </div>

      {tab === "articles" ? <ArticlesClient locale={locale} /> : null}
      {tab === "breaking" ? <LocaleBreakingPanel locale={locale} /> : null}
      {tab === "live" ? <LocaleLivePanel locale={locale} /> : null}
    </div>
  );
}
