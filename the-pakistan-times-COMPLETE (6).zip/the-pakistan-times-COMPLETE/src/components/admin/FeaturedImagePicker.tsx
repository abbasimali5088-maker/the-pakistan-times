"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { FormField, TextInput } from "@/components/admin/FormField";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";

type MediaItem = {
  id: string;
  url: string;
  alt?: string | null;
  caption?: string | null;
  credit?: string | null;
  language?: string | null;
};

function filenameFromUrl(url: string) {
  try {
    const path = new URL(url).pathname;
    const base = path.split("/").filter(Boolean).pop() || "image.jpg";
    return base.includes(".") ? base : `${base}.jpg`;
  } catch {
    return `image-${Date.now()}.jpg`;
  }
}

export function FeaturedImagePicker({
  language,
  featuredImageId,
  imageUrl,
  imageCaption,
  imageCredit,
  onChange,
}: {
  /** Strict gallery locale — EN and UR libraries never mix */
  language: "en" | "ur";
  featuredImageId: string;
  imageUrl: string;
  imageCaption: string;
  imageCredit: string;
  onChange: (next: {
    featuredImageId: string;
    imageUrl: string;
    imageCaption: string;
    imageCredit: string;
  }) => void;
}) {
  const [library, setLibrary] = useState<MediaItem[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [urlDraft, setUrlDraft] = useState(imageUrl);
  const isUr = language === "ur";
  const label = isUr ? "اردو" : "English";

  useEffect(() => {
    setUrlDraft(imageUrl);
  }, [imageUrl]);

  const loadLibrary = useCallback(async () => {
    try {
      const data = await adminFetch<{ items?: MediaItem[] }>(
        `/api/media?pageSize=48&language=${language}`,
        { allowNotFound: true },
      );
      setLibrary(data?.items || []);
    } catch {
      /* ignore */
    }
  }, [language]);

  useEffect(() => {
    void loadLibrary();
  }, [loadLibrary]);

  async function attachUrl(url: string, alt?: string) {
    const clean = url.trim();
    if (!clean) return;
    setBusy(true);
    setError(null);
    try {
      const created = await adminFetch<MediaItem>("/api/media", {
        method: "POST",
        body: JSON.stringify({
          filename: filenameFromUrl(clean),
          url: clean,
          alt: alt || imageCaption || null,
          caption: imageCaption || null,
          credit: imageCredit || null,
          type: "image",
          language,
        }),
      });
      onChange({
        featuredImageId: created.id,
        imageUrl: created.url,
        imageCaption: imageCaption || created.caption || "",
        imageCredit: imageCredit || created.credit || "",
      });
      await loadLibrary();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Image save failed");
    } finally {
      setBusy(false);
    }
  }

  async function onAddUrl(e: FormEvent) {
    e.preventDefault();
    await attachUrl(urlDraft);
  }

  async function onFile(file: File | null) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError(isUr ? "صرف تصویر فائل لگائیں" : "Image files only (JPG / PNG / WebP)");
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      setError(isUr ? "فائل 4MB سے چھوٹی رکھیں، یا URL لگائیں" : "Max 4MB — or paste an image URL");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ""));
        reader.onerror = () => reject(new Error("read failed"));
        reader.readAsDataURL(file);
      });
      await attachUrl(dataUrl, file.name);
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  }

  function clearImage() {
    onChange({
      featuredImageId: "",
      imageUrl: "",
      imageCaption: "",
      imageCredit: "",
    });
    setUrlDraft("");
  }

  return (
    <div className="grid gap-4" dir={isUr ? "rtl" : "ltr"}>
      <p className="rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-900">
        {isUr
          ? "یہ صرف اردو گیلری ہے — انگریزی تصاویر یہاں نہیں دکھیں گی۔"
          : "English gallery only — Urdu images never appear here."}
      </p>

      {error ? (
        <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          {error}
        </p>
      ) : null}

      {imageUrl ? (
        <div className="overflow-hidden rounded-lg border border-slate-200 bg-slate-50">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={imageUrl} alt={imageCaption || label} className="max-h-64 w-full object-cover" />
          <div className="flex items-center justify-between gap-2 px-3 py-2 text-xs text-slate-600">
            <span dir="ltr" className="truncate">
              {featuredImageId ? `ID: ${featuredImageId}` : "URL"} · {language.toUpperCase()}
            </span>
            <button
              type="button"
              onClick={clearImage}
              className="shrink-0 rounded border border-slate-300 bg-white px-2 py-1 font-medium hover:bg-slate-100"
            >
              {isUr ? "ہٹائیں" : "Remove"}
            </button>
          </div>
        </div>
      ) : (
        <p className="rounded-md border border-dashed border-slate-300 bg-slate-50 px-3 py-6 text-center text-sm text-slate-500">
          {isUr ? "ابھی کوئی اردو امیج نہیں" : "No English featured image yet"}
        </p>
      )}

      <form onSubmit={onAddUrl} className="grid gap-3 md:grid-cols-[1fr_auto]">
        <FormField
          label={isUr ? "اردو امیج URL" : "English image URL"}
          hint={isUr ? "صرف اردو گیلری میں محفوظ ہوگی" : "Saved only into the English gallery"}
        >
          <TextInput
            type="url"
            dir="ltr"
            value={urlDraft}
            onChange={(e) => setUrlDraft(e.target.value)}
            placeholder="https://…"
          />
        </FormField>
        <div className="flex items-end">
          <button
            type="submit"
            disabled={busy || !urlDraft.trim()}
            className="w-full rounded-md bg-[#1DB954] px-4 py-2 text-sm font-medium text-white hover:bg-[#159A45] disabled:opacity-60 md:w-auto"
          >
            {busy ? "…" : isUr ? "امیج لگائیں" : "Attach image"}
          </button>
        </div>
      </form>

      <FormField
        label={isUr ? "اردو امیج اپلوڈ" : "Upload English image"}
        hint="JPG/PNG/WebP · max 4MB"
      >
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          disabled={busy}
          onChange={(e) => void onFile(e.target.files?.[0] || null)}
          className="block w-full text-sm text-slate-700 file:me-3 file:rounded-md file:border-0 file:bg-[#1DB954] file:px-3 file:py-2 file:text-sm file:font-medium file:text-white"
        />
      </FormField>

      <div className="grid gap-4 md:grid-cols-2">
        <FormField label={isUr ? "کیپشن (اردو)" : "Caption (EN)"}>
          <TextInput
            value={imageCaption}
            onChange={(e) =>
              onChange({
                featuredImageId,
                imageUrl,
                imageCaption: e.target.value,
                imageCredit,
              })
            }
          />
        </FormField>
        <FormField label={isUr ? "کریڈٹ (اردو)" : "Credit (EN)"}>
          <TextInput
            value={imageCredit}
            onChange={(e) =>
              onChange({
                featuredImageId,
                imageUrl,
                imageCaption,
                imageCredit: e.target.value,
              })
            }
          />
        </FormField>
      </div>

      {library.length > 0 ? (
        <div>
          <p className="mb-2 text-sm font-medium text-slate-700">
            {isUr ? "اردو میڈیا گیلری" : "English media gallery"}
          </p>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-6">
            {library.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() =>
                  onChange({
                    featuredImageId: item.id,
                    imageUrl: item.url,
                    imageCaption: imageCaption || item.caption || "",
                    imageCredit: imageCredit || item.credit || "",
                  })
                }
                className={`overflow-hidden rounded border ${
                  featuredImageId === item.id
                    ? "border-[#1DB954] ring-2 ring-[#1DB954]/40"
                    : "border-slate-200 hover:border-[#1DB954]"
                }`}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.url} alt={item.alt || ""} className="aspect-square w-full object-cover" />
              </button>
            ))}
          </div>
        </div>
      ) : (
        <p className="text-xs text-slate-500">
          {isUr ? "اردو گیلری خالی ہے — اوپر سے اپلوڈ کریں۔" : "English gallery is empty — upload above."}
        </p>
      )}
    </div>
  );
}
