import Link from "next/link";
import type { Lang } from "@/lib/language";
import { pickText } from "@/lib/language";
import type { PublicArticle } from "@/lib/public-types";

export function AppStoryCard({
  article,
  lang,
  featured = false,
}: {
  article: PublicArticle;
  lang: Lang;
  featured?: boolean;
}) {
  const title = pickText(lang, article.titleUr, article.titleEn || article.title, "");
  const href = `/${article.slug}`;
  const img = article.image?.url;

  if (featured) {
    return (
      <Link href={href} className="group relative block overflow-hidden rounded-2xl bg-[#141414]">
        {img ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={img}
            alt=""
            className="aspect-[16/10] w-full object-cover opacity-90 transition group-active:scale-[1.02]"
          />
        ) : (
          <div className="aspect-[16/10] bg-[#1DB954]/30" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-4 text-white">
          <p className="text-[11px] font-bold uppercase tracking-wide text-white/80">
            {lang === "ur" ? "اہم خبر" : "Top story"}
          </p>
          <h2 className="mt-1 text-xl font-bold leading-snug">{title}</h2>
        </div>
      </Link>
    );
  }

  return (
    <Link
      href={href}
      className="flex gap-3 border-b border-[var(--line)] py-3 active:bg-black/5"
    >
      <div className="min-w-0 flex-1">
        <h3 className="text-[15px] font-bold leading-snug text-[var(--ink)]">{title}</h3>
        {article.category?.nameEn || article.category?.name || article.category?.nameUr ? (
          <p className="mt-1 text-[11px] font-semibold text-[#1DB954]">
            {pickText(
              lang,
              article.category?.nameUr,
              article.category?.nameEn || article.category?.name,
              "",
            )}
          </p>
        ) : null}
      </div>
      {img ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={img}
          alt=""
          className="h-[4.5rem] w-[4.5rem] shrink-0 rounded-lg object-cover"
        />
      ) : (
        <div className="h-[4.5rem] w-[4.5rem] shrink-0 rounded-lg bg-[#1DB954]/15" />
      )}
    </Link>
  );
}
