"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

/**
 * Small non-blocking install chip (only on /app).
 * No auto popup — it was covering QR / news and close was broken.
 */
export function InstallAppBanner() {
  const pathname = usePathname() || "";
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    try {
      if (localStorage.getItem("pt_install_chip_off") === "1") setDismissed(true);
    } catch {
      /* ignore */
    }

    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      ("standalone" in navigator &&
        (navigator as Navigator & { standalone?: boolean }).standalone === true);
    if (standalone) {
      setInstalled(true);
      return;
    }

    const onBip = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onBip);
    window.addEventListener("appinstalled", () => setInstalled(true));
    return () => window.removeEventListener("beforeinstallprompt", onBip);
  }, []);

  // Only on /app — get-app page already has QR/instructions
  if (!pathname.startsWith("/app") || pathname.startsWith("/admin") || installed || dismissed) {
    return null;
  }

  async function installNative() {
    if (!deferred) return;
    try {
      await deferred.prompt();
      await deferred.userChoice;
      setDeferred(null);
    } catch {
      /* ignore */
    }
  }

  function dismiss() {
    setDismissed(true);
    try {
      localStorage.setItem("pt_install_chip_off", "1");
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-[4.75rem] z-40 flex justify-center px-3">
      <div className="pointer-events-auto flex max-w-md items-center gap-2 rounded-full border border-[var(--line)] bg-white/95 px-3 py-2 text-sm shadow-lg backdrop-blur">
        {deferred ? (
          <button
            type="button"
            onClick={() => void installNative()}
            className="rounded-full bg-[#1DB954] px-3 py-1.5 text-xs font-bold text-white"
          >
            Install
          </button>
        ) : (
          <Link
            href="/get-app"
            className="rounded-full bg-[#1DB954] px-3 py-1.5 text-xs font-bold text-white"
          >
            فون پر لے جائیں
          </Link>
        )}
        <span className="text-xs text-[var(--muted)]">ایپ</span>
        <button
          type="button"
          onClick={dismiss}
          className="ms-1 rounded-full px-2 py-1 text-xs font-bold text-[var(--muted)]"
          aria-label="بند کریں"
        >
          ✕
        </button>
      </div>
    </div>
  );
}
