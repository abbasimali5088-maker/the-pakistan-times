"use client";

import { useEffect, useState } from "react";

/** Registers SW early and retries — required for Chrome install. */
export function PwaRegister() {
  const [status, setStatus] = useState<string>("");

  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
      setStatus("no-sw");
      return;
    }

    let cancelled = false;

    async function register() {
      try {
        const reg = await navigator.serviceWorker.register("/sw.js", {
          scope: "/",
          updateViaCache: "none",
        });
        await reg.update().catch(() => {});
        if (!cancelled) setStatus("ok");
      } catch (err) {
        if (!cancelled) setStatus("fail");
        console.warn("[PWA] SW register failed", err);
        // retry once
        window.setTimeout(() => {
          navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => {});
        }, 2000);
      }
    }

    void register();
    return () => {
      cancelled = true;
    };
  }, []);

  // Hidden status for debugging in DevTools / screen readers
  return (
    <span className="sr-only" data-pwa-sw={status} aria-hidden>
      pwa-{status || "pending"}
    </span>
  );
}
