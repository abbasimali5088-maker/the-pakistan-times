"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Newspaper, Radio, Search, Clapperboard } from "lucide-react";

const TABS: Array<{
  href: string;
  label: string;
  labelEn: string;
  icon: typeof Home;
  exact?: boolean;
}> = [
  { href: "/app", label: "ہوم", labelEn: "Home", icon: Home, exact: true },
  { href: "/app/latest", label: "تازہ", labelEn: "Latest", icon: Newspaper },
  { href: "/app/live", label: "لائیو", labelEn: "Live", icon: Radio },
  { href: "/app/videos", label: "ویڈیو", labelEn: "Videos", icon: Clapperboard },
  { href: "/app/search", label: "تلاش", labelEn: "Search", icon: Search },
];

export function AppBottomNav({ lang = "ur" }: { lang?: "ur" | "en" }) {
  const pathname = usePathname() || "/app";

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-50 border-t border-white/15 bg-[#1DB954] pb-[env(safe-area-inset-bottom)] text-white"
      aria-label={lang === "ur" ? "ایپ مینو" : "App menu"}
    >
      <ul className="mx-auto flex max-w-lg items-stretch justify-between px-1">
        {TABS.map((tab) => {
          const active = tab.exact
            ? pathname === tab.href
            : pathname === tab.href || pathname.startsWith(`${tab.href}/`);
          const Icon = tab.icon;
          return (
            <li key={tab.href} className="flex-1">
              <Link
                href={tab.href}
                className={`flex flex-col items-center gap-0.5 px-1 py-2 text-[11px] font-semibold transition ${
                  active ? "text-white" : "text-white/65"
                }`}
                aria-current={active ? "page" : undefined}
              >
                <Icon className="h-5 w-5" strokeWidth={active ? 2.5 : 2} />
                <span>{lang === "en" ? tab.labelEn : tab.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
