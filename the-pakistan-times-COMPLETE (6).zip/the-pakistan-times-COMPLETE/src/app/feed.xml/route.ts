import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { resolveHostProfile } from "@/lib/site-host";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function xmlEscape(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

export async function GET(req: NextRequest) {
  const host = req.headers.get("x-forwarded-host") || req.headers.get("host");
  const profile = resolveHostProfile(host);
  const base = profile.siteUrl;
  const lang = profile.locked ? profile.lang : "ur";
  const now = new Date();

  const articles = await prisma.article.findMany({
    where: {
      deletedAt: null,
      status: "published",
      language: lang,
      OR: [{ publishAt: null }, { publishAt: { lte: now } }],
    },
    orderBy: { publishedAt: "desc" },
    take: 50,
    select: {
      title: true,
      titleUr: true,
      slug: true,
      excerpt: true,
      excerptUr: true,
      publishedAt: true,
      updatedAt: true,
      language: true,
    },
  });

  const items = articles
    .map((a) => {
      const title =
        lang === "ur" ? a.titleUr || a.title : a.title || a.titleUr || "";
      const description =
        lang === "ur" ? a.excerptUr || a.excerpt || "" : a.excerpt || a.excerptUr || "";
      const link = `${base}/${a.slug}`;
      const pubDate = (a.publishedAt || a.updatedAt || now).toUTCString();
      return `<item>
<title>${xmlEscape(title)}</title>
<link>${xmlEscape(link)}</link>
<guid isPermaLink="true">${xmlEscape(link)}</guid>
<pubDate>${pubDate}</pubDate>
<description>${xmlEscape(description)}</description>
</item>`;
    })
    .join("\n");

  const channelTitle = lang === "ur" ? "دی پاکستان ٹائمز اردو" : "The Pakistan Times";
  const channelDesc =
    lang === "ur"
      ? "تازہ ترین خبریں — دی پاکستان ٹائمز اردو"
      : "Latest news — The Pakistan Times";

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
<channel>
<title>${xmlEscape(channelTitle)}</title>
<link>${xmlEscape(base)}</link>
<description>${xmlEscape(channelDesc)}</description>
<language>${lang}</language>
<lastBuildDate>${now.toUTCString()}</lastBuildDate>
${items}
</channel>
</rss>`;

  return new NextResponse(xml, {
    status: 200,
    headers: {
      "Content-Type": "application/rss+xml; charset=utf-8",
      "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600",
    },
  });
}
