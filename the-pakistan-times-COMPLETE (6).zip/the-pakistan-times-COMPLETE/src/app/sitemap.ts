import type { MetadataRoute } from "next";
import { headers } from "next/headers";
import { prisma } from "@/lib/db";
import { resolveHostProfile } from "@/lib/site-host";

export const dynamic = "force-dynamic";

async function resolveBaseAndLang() {
  const h = await headers();
  const host = h.get("x-site-host") || h.get("x-forwarded-host") || h.get("host");
  const profile = resolveHostProfile(host);
  const fromHeader = h.get("x-site-url");
  return {
    base: (fromHeader || profile.siteUrl).replace(/\/$/, ""),
    lang: profile.locked ? profile.lang : null,
  };
}

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const { base, lang } = await resolveBaseAndLang();
  const now = new Date();

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: base, lastModified: now, changeFrequency: "hourly", priority: 1 },
    { url: `${base}/latest`, lastModified: now, changeFrequency: "hourly", priority: 0.9 },
    { url: `${base}/breaking`, lastModified: now, changeFrequency: "hourly", priority: 0.9 },
    { url: `${base}/live`, lastModified: now, changeFrequency: "hourly", priority: 0.8 },
    { url: `${base}/videos`, lastModified: now, changeFrequency: "daily", priority: 0.7 },
    { url: `${base}/galleries`, lastModified: now, changeFrequency: "daily", priority: 0.7 },
    { url: `${base}/search`, lastModified: now, changeFrequency: "weekly", priority: 0.3 },
    { url: `${base}/feed.xml`, lastModified: now, changeFrequency: "hourly", priority: 0.5 },
    { url: `${base}/about`, lastModified: now, changeFrequency: "monthly", priority: 0.4 },
    { url: `${base}/contact`, lastModified: now, changeFrequency: "monthly", priority: 0.4 },
    { url: `${base}/privacy`, lastModified: now, changeFrequency: "yearly", priority: 0.2 },
    { url: `${base}/terms`, lastModified: now, changeFrequency: "yearly", priority: 0.2 },
    { url: `${base}/disclaimer`, lastModified: now, changeFrequency: "yearly", priority: 0.2 },
    { url: `${base}/editorial-policy`, lastModified: now, changeFrequency: "yearly", priority: 0.2 },
    { url: `${base}/corrections`, lastModified: now, changeFrequency: "yearly", priority: 0.2 },
  ];

  try {
    const [articles, categories, authors, pages, videos, galleries, live] = await Promise.all([
      prisma.article.findMany({
        where: {
          deletedAt: null,
          status: "published",
          OR: [{ publishAt: null }, { publishAt: { lte: now } }],
          ...(lang ? { language: lang } : {}),
        },
        select: { slug: true, updatedAt: true, publishedAt: true, language: true },
        orderBy: { publishedAt: "desc" },
        take: 5000,
      }),
      prisma.category.findMany({
        where: {
          status: "active",
          ...(lang ? { language: lang } : {}),
        },
        select: { slug: true, updatedAt: true },
      }),
      prisma.author.findMany({
        where: { status: "active" },
        select: { slug: true, updatedAt: true },
      }),
      prisma.staticPage.findMany({
        where: { status: "published" },
        select: { slug: true, updatedAt: true },
      }),
      prisma.video
        .findMany({
          where: { status: { in: ["published", "active"] } },
          select: { slug: true, updatedAt: true },
          take: 2000,
        })
        .catch(() => [] as Array<{ slug: string; updatedAt: Date }>),
      prisma.gallery
        .findMany({
          where: { status: { in: ["published", "active"] } },
          select: { slug: true, updatedAt: true },
          take: 2000,
        })
        .catch(() => [] as Array<{ slug: string; updatedAt: Date }>),
      prisma.liveStory
        .findMany({
          where: { status: { in: ["live", "published", "active"] } },
          select: { slug: true, updatedAt: true },
          take: 500,
        })
        .catch(() => [] as Array<{ slug: string; updatedAt: Date }>),
    ]);

    const pagePath = (slug: string) => {
      const map: Record<string, string> = {
        about: "/about",
        contact: "/contact",
        privacy: "/privacy",
        terms: "/terms",
        disclaimer: "/disclaimer",
        "editorial-policy": "/editorial-policy",
        "corrections-policy": "/corrections",
      };
      return map[slug] || `/${slug}`;
    };

    return [
      ...staticRoutes,
      ...articles.map((a) => ({
        url: `${base}/${a.slug}`,
        lastModified: a.updatedAt || a.publishedAt || now,
        changeFrequency: "daily" as const,
        priority: 0.8,
      })),
      ...categories.map((c) => ({
        url: `${base}/category/${c.slug}`,
        lastModified: c.updatedAt,
        changeFrequency: "daily" as const,
        priority: 0.6,
      })),
      ...authors.map((a) => ({
        url: `${base}/author/${a.slug}`,
        lastModified: a.updatedAt,
        changeFrequency: "weekly" as const,
        priority: 0.5,
      })),
      ...pages.map((p) => ({
        url: `${base}${pagePath(p.slug)}`,
        lastModified: p.updatedAt,
        changeFrequency: "monthly" as const,
        priority: 0.4,
      })),
      ...videos.map((v) => ({
        url: `${base}/videos/${v.slug}`,
        lastModified: v.updatedAt,
        changeFrequency: "weekly" as const,
        priority: 0.55,
      })),
      ...galleries.map((g) => ({
        url: `${base}/galleries/${g.slug}`,
        lastModified: g.updatedAt,
        changeFrequency: "weekly" as const,
        priority: 0.55,
      })),
      ...live.map((s) => ({
        url: `${base}/live/${s.slug}`,
        lastModified: s.updatedAt,
        changeFrequency: "hourly" as const,
        priority: 0.7,
      })),
    ];
  } catch {
    return staticRoutes;
  }
}
