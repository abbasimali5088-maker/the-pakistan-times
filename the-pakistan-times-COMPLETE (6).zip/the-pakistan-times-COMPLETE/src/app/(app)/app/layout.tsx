import type { Metadata, Viewport } from "next";
import Link from "next/link";
import { AppBottomNav } from "@/components/app/AppBottomNav";
import { getRequestLang } from "@/lib/language-server";
import { brandName } from "@/lib/language";

export const dynamic = "force-dynamic";

export const viewport: Viewport = {
  themeColor: "#1DB954",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export async function generateMetadata(): Promise<Metadata> {
  const lang = await getRequestLang();
  const brand = brandName(lang);
  return {
    title: { absolute: `${brand} App` },
    description:
      lang === "ur"
        ? "دی پاکستان ٹائمز موبائل ایپ — تازہ خبریں، لائیو، ویڈیوز"
        : "The Pakistan Times mobile app — news, live, videos",
    appleWebApp: {
      capable: true,
      title: brand,
      statusBarStyle: "black-translucent",
    },
    other: {
      "mobile-web-app-capable": "yes",
    },
  };
}

export default async function MobileAppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const lang = await getRequestLang();

  return (
    <div
      className="app-shell min-h-screen bg-[var(--paper)] pb-24"
      dir={lang === "ur" ? "rtl" : "ltr"}
    >
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#1DB954] px-4 py-3 text-white">
        <div className="mx-auto flex max-w-lg items-center justify-between gap-3">
          <div>
            <p className="text-lg font-black tracking-tight">
              {lang === "ur" ? "دی پاکستان ٹائمز" : "The Pakistan Times"}
            </p>
            <p className="text-[11px] text-white/75">
              {lang === "ur" ? "نیوز ایپ" : "News app"}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Link
              href="/get-app"
              className="rounded-full bg-white px-3 py-1.5 text-[11px] font-bold text-[#1DB954]"
            >
              {lang === "ur" ? "QR / فون" : "QR / Phone"}
            </Link>
            <Link
              href="/"
              className="rounded-full border border-white/30 px-3 py-1.5 text-[11px] font-semibold text-white/90"
            >
              {lang === "ur" ? "ویب" : "Web"}
            </Link>
          </div>
        </div>
      </header>
      <div className="mx-auto max-w-lg px-3 pt-3">{children}</div>
      <AppBottomNav lang={lang} />
    </div>
  );
}
