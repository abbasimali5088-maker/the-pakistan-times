import Link from "next/link";
import { EmptyState } from "@/components/public/EmptyState";
import { LiveStreamBlock } from "@/components/public/LiveStreamBlock";
import { getRequestLang } from "@/lib/language-server";
import { getLiveFeed } from "@/lib/public-api";

export default async function AppLivePage() {
  const lang = await getRequestLang();
  const articles = await getLiveFeed({ language: lang, take: 20 });

  if (!articles.length) {
    return (
      <EmptyState
        lang={lang}
        title={lang === "ur" ? "ابھی لائیو کوریج نہیں" : "No live coverage yet"}
      />
    );
  }

  return (
    <div className="space-y-3">
      <h1 className="text-xl font-black text-[var(--ink)]">
        {lang === "ur" ? "لائیو" : "Live"}
      </h1>
      <LiveStreamBlock articles={articles} lang={lang} />
      <Link href="/live" className="block text-center text-sm font-semibold text-[var(--accent)]">
        {lang === "ur" ? "تمام لائیو ›" : "All live ›"}
      </Link>
    </div>
  );
}
