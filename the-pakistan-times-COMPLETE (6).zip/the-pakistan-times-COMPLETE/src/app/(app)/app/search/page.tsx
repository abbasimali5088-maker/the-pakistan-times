"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

export default function AppSearchPage() {
  const router = useRouter();
  const [q, setQ] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const query = q.trim();
    if (!query) return;
    router.push(`/search?q=${encodeURIComponent(query)}`);
  }

  return (
    <div className="space-y-4" dir="rtl">
      <h1 className="text-xl font-black text-[var(--ink)]">تلاش / Search</h1>
      <form onSubmit={onSubmit} className="flex gap-2">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="خبر تلاش کریں…"
          className="flex-1 rounded-xl border border-[var(--line)] bg-white px-4 py-3 text-sm outline-none focus:border-[#1DB954]"
        />
        <button
          type="submit"
          className="rounded-xl bg-[#1DB954] px-4 py-3 text-sm font-bold text-white"
        >
          تلاش
        </button>
      </form>
      <p className="text-sm text-[var(--muted)]">
        BBC/Geo کی طرح فون پر تلاش کریں — نتائج ویب سائٹ سرچ پر کھلیں گے۔
      </p>
    </div>
  );
}
