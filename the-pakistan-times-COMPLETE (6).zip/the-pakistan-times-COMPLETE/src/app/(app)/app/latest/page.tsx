import { AppStoryCard } from "@/components/app/AppStoryCard";
import { EmptyState } from "@/components/public/EmptyState";
import { getRequestLang } from "@/lib/language-server";
import { getArticles } from "@/lib/public-api";

export default async function AppLatestPage() {
  const lang = await getRequestLang();
  const latest = await getArticles({ language: lang, page: 1, pageSize: 30 });

  if (!latest.items.length) {
    return <EmptyState lang={lang} title={lang === "ur" ? "ابھی خبریں نہیں" : "No stories yet"} />;
  }

  return (
    <div>
      <h1 className="mb-2 text-xl font-black text-[var(--ink)]">
        {lang === "ur" ? "تازہ ترین خبریں" : "Latest news"}
      </h1>
      {latest.items.map((a) => (
        <AppStoryCard key={a.id} article={a} lang={lang} />
      ))}
    </div>
  );
}
