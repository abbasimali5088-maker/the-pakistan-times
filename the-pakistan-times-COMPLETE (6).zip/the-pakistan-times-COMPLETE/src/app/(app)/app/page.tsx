import Link from "next/link";
import { AppStoryCard } from "@/components/app/AppStoryCard";
import { EmptyState } from "@/components/public/EmptyState";
import { LiveStreamBlock } from "@/components/public/LiveStreamBlock";
import { pickText } from "@/lib/language";
import { getRequestLang } from "@/lib/language-server";
import {
  getArticles,
  getBreaking,
  getCategories,
  getHomepage,
  getLiveFeed,
} from "@/lib/public-api";
import type { PublicArticle } from "@/lib/public-types";

export default async function AppHomePage() {
  const lang = await getRequestLang();
  const [homepage, latest, breaking, categories, liveArticles] = await Promise.all([
    getHomepage({ language: lang }),
    getArticles({ language: lang, page: 1, pageSize: 20 }),
    getBreaking(lang),
    getCategories({ language: lang }),
    getLiveFeed({ language: lang, take: 4 }),
  ]);

  const top =
    (homepage.blocks || [])
      .filter((b) => b.sectionKey === "top_story" && b.article)
      .map((b) => b.article!)[0] ||
    latest.items.find((a) => a.isFeatured && a.priority !== "live") ||
    latest.items.find((a) => a.priority !== "live") ||
    null;

  const liveIds = new Set(liveArticles.map((a) => a.id));
  const rest = latest.items
    .filter((a) => a.id !== top?.id && !liveIds.has(a.id))
    .slice(0, 16);
  const cats = (categories || [])
    .filter((c) => !(c as { parentId?: string | null }).parentId)
    .slice(0, 8);

  if (!top && rest.length === 0 && liveArticles.length === 0) {
    return <EmptyState lang={lang} title={lang === "ur" ? "ابھی خبریں نہیں" : "No stories yet"} />;
  }

  return (
    <div className="space-y-4">
      <LiveStreamBlock articles={liveArticles} lang={lang} />

      {breaking?.length ? (
        <div className="overflow-hidden rounded-xl bg-[#fff8f0] px-3 py-2">
          <p className="mb-1 text-[11px] font-bold uppercase text-[#1DB954]">
            {lang === "ur" ? "بریکنگ" : "Breaking"}
          </p>
          <p className="line-clamp-2 text-sm font-semibold text-[var(--ink)]">
            {pickText(
              lang,
              breaking[0].headlineUr,
              breaking[0].headlineEn || breaking[0].headline,
              "",
            )}
          </p>
        </div>
      ) : null}

      {top ? <AppStoryCard article={top as PublicArticle} lang={lang} featured /> : null}

      <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
        {cats.map((c) => (
          <Link
            key={c.id}
            href={`/category/${c.slug}`}
            className="shrink-0 rounded-full bg-white px-3 py-1.5 text-xs font-bold text-[var(--ink)] shadow-sm ring-1 ring-[var(--line)]"
          >
            {lang === "ur" ? c.nameUr || c.name : c.nameEn || c.name}
          </Link>
        ))}
      </div>

      <section>
        <h2 className="mb-1 text-sm font-bold text-[var(--muted)]">
          {lang === "ur" ? "تازہ ترین" : "Latest"}
        </h2>
        <div>
          {rest.map((a) => (
            <AppStoryCard key={a.id} article={a} lang={lang} />
          ))}
        </div>
      </section>
    </div>
  );
}
