import Link from "next/link";
import { EmptyState } from "@/components/public/EmptyState";
import { getRequestLang } from "@/lib/language-server";
import { getVideos } from "@/lib/public-api";

export default async function AppVideosPage() {
  const lang = await getRequestLang();
  const data = await getVideos({ page: 1 });
  const items = data.items || [];

  if (!items.length) {
    return <EmptyState lang={lang} title={lang === "ur" ? "ابھی ویڈیوز نہیں" : "No videos yet"} />;
  }

  return (
    <div className="space-y-3">
      <h1 className="text-xl font-black text-[var(--ink)]">
        {lang === "ur" ? "ویڈیوز" : "Videos"}
      </h1>
      <div className="grid gap-3">
        {items.map((v) => (
          <Link
            key={v.id}
            href={`/videos/${v.slug}`}
            className="overflow-hidden rounded-2xl border border-[var(--line)] bg-white shadow-sm"
          >
            {v.thumbnail ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={v.thumbnail} alt="" className="aspect-video w-full object-cover" />
            ) : (
              <div className="aspect-video bg-[#1DB954]/20" />
            )}
            <div className="p-3">
              <h2 className="text-sm font-bold leading-snug text-[var(--ink)]">{v.title}</h2>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
