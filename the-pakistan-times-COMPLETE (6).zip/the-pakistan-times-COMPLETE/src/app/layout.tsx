import type { Metadata, Viewport } from "next";
import { Suspense } from "react";
import { Noto_Nastaliq_Urdu, Source_Serif_4, Source_Sans_3 } from "next/font/google";
import { cookies, headers } from "next/headers";
import { Analytics } from "@vercel/analytics/react";
import { SpeedInsights } from "@vercel/speed-insights/next";
import "./globals.css";
import { BRAND } from "@/lib/constants";
import { isLang, LANG_COOKIE, normalizeLang } from "@/lib/language";
import { prisma } from "@/lib/db";
import { GtmNoscript, SiteIntegrations } from "@/components/public/SiteIntegrations";
import { PageViewTracker } from "@/components/public/PageViewTracker";
import { PwaRegister } from "@/components/app/PwaRegister";
import { resolveHostProfile, englishSiteUrl, urduSiteUrl } from "@/lib/site-host";

const notoNastaliq = Noto_Nastaliq_Urdu({
  subsets: ["arabic"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-noto-nastaliq",
  display: "swap",
});

const sourceSerif = Source_Serif_4({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-source-serif",
  display: "swap",
});

const sourceSans = Source_Sans_3({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-source-sans",
  display: "swap",
});

const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL ||
  (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "http://127.0.0.1:4355");

async function loadIntegrations(lang: "ur" | "en") {
  try {
    const rows = await prisma.setting.findMany({
      where: {
        group: "integrations",
        key: {
          in: [
            "gaMeasurementId",
            "gaMeasurementIdUr",
            "gaMeasurementIdEn",
            "gtmContainerId",
            "searchConsoleVerification",
            "searchConsoleVerificationUr",
            "searchConsoleVerificationEn",
          ],
        },
      },
    });
    const map: Record<string, string> = {};
    for (const r of rows) map[r.key] = r.value || "";

    const gscPreferred =
      lang === "en"
        ? map.searchConsoleVerificationEn || map.searchConsoleVerification
        : map.searchConsoleVerificationUr || map.searchConsoleVerification;
    const gaPreferred =
      lang === "en"
        ? map.gaMeasurementIdEn || map.gaMeasurementId
        : map.gaMeasurementIdUr || map.gaMeasurementId;
    const gsc = (gscPreferred || "").trim();
    const ga = (gaPreferred || "").trim();
    const gtm = (map.gtmContainerId || "").trim();

    // Ignore placeholder / test values so they don't break Search Console / GA
    const gscOk =
      gsc.length >= 20 &&
      !/ready-for-owner|test|placeholder|example|verify123/i.test(gsc);
    const gaOk = /^G-[A-Z0-9]+$/i.test(ga) && !/SAVEDOK|TEST|XXXX/i.test(ga);
    const gtmOk = /^GTM-[A-Z0-9]+$/i.test(gtm);

    return {
      gaId: gaOk ? ga : "",
      gtmId: gtmOk ? gtm : "",
      searchConsoleVerification: gscOk ? gsc : "",
    };
  } catch {
    return { gaId: "", gtmId: "", searchConsoleVerification: "" };
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const h = await headers();
  const host = h.get("x-site-host") || h.get("x-forwarded-host") || h.get("host");
  const profile = resolveHostProfile(host);
  const jar = await cookies();
  const headerLang = h.get("x-lang");
  // Preview/unlocked hosts must follow ?lang= / cookie — not always Urdu defaults.
  const lang =
    profile.locked && isLang(profile.lang)
      ? profile.lang
      : isLang(headerLang)
        ? headerLang
        : normalizeLang(jar.get(LANG_COOKIE)?.value);
  const integrations = await loadIntegrations(lang === "en" ? "en" : "ur");
  const isEn = lang === "en";
  const base = (h.get("x-site-url") || profile.siteUrl || siteUrl).replace(/\/$/, "");
  const brand = isEn ? BRAND.en : BRAND.ur;
  const description = isEn
    ? "Latest news from Pakistan and the world — The Pakistan Times"
    : "پاکستان اور دنیا کی تازہ ترین خبریں، تجزیے اور لائیو کوریج";

  return {
    title: {
      default: brand,
      template: `%s | ${brand}`,
    },
    description,
    applicationName: brand,
    manifest: "/manifest.webmanifest",
    metadataBase: new URL(base),
    alternates: {
      canonical: "/",
      languages: {
        en: `${englishSiteUrl()}/`,
        ur: `${urduSiteUrl()}/`,
        "x-default": `${isEn ? englishSiteUrl() : urduSiteUrl()}/`,
      },
      types: {
        "application/rss+xml": [
          {
            url: "/feed.xml",
            title: isEn ? "The Pakistan Times RSS" : "دی پاکستان ٹائمز RSS",
          },
        ],
      },
    },
    openGraph: {
      title: brand,
      description,
      siteName: brand,
      locale: isEn ? "en_US" : "ur_PK",
      type: "website",
      url: base,
    },
    twitter: {
      title: brand,
      description,
    },
    icons: {
      icon: [
        { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
        { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
      ],
      apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    },
    verification: integrations.searchConsoleVerification
      ? { google: integrations.searchConsoleVerification }
      : undefined,
  };
}

export const viewport: Viewport = {
  themeColor: BRAND.accent,
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const h = await headers();
  const path = h.get("x-pathname") || h.get("x-invoke-path") || "";
  const isAdmin = path.startsWith("/admin") || h.get("x-url")?.includes("/admin");
  const jar = await cookies();
  const headerLang = h.get("x-lang");
  const lang = isAdmin
    ? "en"
    : normalizeLang(headerLang || jar.get(LANG_COOKIE)?.value);
  const dir = lang === "ur" ? "rtl" : "ltr";
  const integrations = isAdmin ? null : await loadIntegrations(lang === "en" ? "en" : "ur");

  return (
    <html
      lang={lang}
      dir={dir}
      className={`${notoNastaliq.variable} ${sourceSerif.variable} ${sourceSans.variable}`}
      suppressHydrationWarning
    >
      <head>
        {/* Sets data-theme before paint so there's no light→dark flash.
            Inline + self-invoking so it runs before hydration; wrapped in
            try/catch so a blocked localStorage (private browsing) never
            breaks page render. */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem("pt-theme");if(t==="dark"||t==="light"){document.documentElement.setAttribute("data-theme",t);}}catch(e){}})();`,
          }}
        />
      </head>
      <body className="antialiased" suppressHydrationWarning>
        {integrations ? <GtmNoscript gtmId={integrations.gtmId} /> : null}
        {children}
        {!isAdmin ? <PwaRegister /> : null}
        {integrations ? (
          <SiteIntegrations gaId={integrations.gaId} gtmId={integrations.gtmId} />
        ) : null}
        {!isAdmin ? (
          <Suspense fallback={null}>
            <PageViewTracker />
          </Suspense>
        ) : null}
        <Analytics />
        <SpeedInsights />
      </body>
    </html>
  );
}
