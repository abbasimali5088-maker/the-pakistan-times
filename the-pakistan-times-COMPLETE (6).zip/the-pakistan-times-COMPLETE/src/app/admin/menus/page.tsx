"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { FormField, TextInput, TextSelect } from "@/components/admin/FormField";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";

type MenuItem = {
  id?: string;
  label: string;
  labelUr?: string | null;
  url: string;
  sortOrder?: number;
  status?: string;
};

type Menu = {
  id: string;
  name: string;
  location?: string;
  status?: string;
  items?: MenuItem[];
};

const emptyItem = (): MenuItem => ({
  label: "",
  labelUr: "",
  url: "/",
  sortOrder: 0,
  status: "active",
});

export default function MenusPage() {
  const [menus, setMenus] = useState<Menu[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [active, setActive] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [name, setName] = useState("");
  const [location, setLocation] = useState("main");
  const [status, setStatus] = useState("active");
  const [items, setItems] = useState<MenuItem[]>([]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminFetch<{ items?: Menu[] } | Menu[]>("/api/menus", {
        allowNotFound: true,
      });
      if (!data) {
        setMenus([]);
        setError("Menus API not available yet.");
      } else {
        const list = Array.isArray(data) ? data : data.items || [];
        setMenus(list);
        setActive((prev) => prev || list[0]?.id || null);
      }
    } catch (err) {
      setMenus([]);
      setError(err instanceof AdminApiError ? err.message : "Failed to load menus");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const current = menus.find((m) => m.id === active);
    if (!current) {
      setName("");
      setLocation("main");
      setStatus("active");
      setItems([]);
      return;
    }
    setName(current.name);
    setLocation(current.location || "main");
    setStatus(current.status || "active");
    setItems(
      (current.items || []).map((it) => ({
        id: it.id,
        label: it.label,
        labelUr: it.labelUr || "",
        url: it.url,
        sortOrder: it.sortOrder ?? 0,
        status: it.status || "active",
      })),
    );
  }, [active, menus]);

  function updateItem(index: number, patch: Partial<MenuItem>) {
    setItems((prev) => prev.map((it, i) => (i === index ? { ...it, ...patch } : it)));
  }

  async function onSave(e: FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      setError("Menu name required");
      return;
    }
    setBusy(true);
    setError(null);
    setNotice(null);
    const payload = {
      id: active || undefined,
      name: name.trim(),
      location,
      status,
      items: items
        .filter((it) => it.label.trim() && it.url.trim())
        .map((it, idx) => ({
          label: it.label.trim(),
          labelUr: it.labelUr?.trim() || null,
          url: it.url.trim(),
          sortOrder: it.sortOrder ?? idx,
          status: it.status || "active",
        })),
    };
    try {
      if (active) {
        await adminFetch("/api/menus", {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        setNotice("Menu updated.");
      } else {
        const created = await adminFetch<Menu>("/api/menus", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        setNotice("Menu created.");
        setActive(created.id);
      }
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function onDeleteMenu() {
    if (!active) return;
    if (!window.confirm("Delete this menu and all its items?")) return;
    setBusy(true);
    setError(null);
    try {
      await adminFetch(`/api/menus?id=${encodeURIComponent(active)}`, { method: "DELETE" });
      setActive(null);
      setNotice("Menu deleted.");
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <AdminPageHeader
        title="Menus"
        description="Edit navigation — changes appear on the public site header."
        actions={
          <button
            type="button"
            onClick={() => {
              setActive(null);
              setName("");
              setLocation("main");
              setStatus("active");
              setItems([emptyItem()]);
            }}
            className="rounded-md bg-[#1DB954] px-3 py-2 text-sm font-medium text-white hover:bg-[#159A45]"
          >
            New menu
          </button>
        }
      />

      {error ? (
        <div className="mb-4 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          {error}
        </div>
      ) : null}
      {notice ? (
        <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
          {notice}
        </div>
      ) : null}

      {loading ? (
        <p className="text-sm text-slate-500">Loading…</p>
      ) : (
        <div className="grid gap-4 lg:grid-cols-[220px_1fr]">
          <AdminPanel title="Menus">
            <ul className="space-y-1">
              {menus.length === 0 ? (
                <li className="text-sm text-slate-500">No menus.</li>
              ) : (
                menus.map((m) => (
                  <li key={m.id}>
                    <button
                      type="button"
                      onClick={() => setActive(m.id)}
                      className={`w-full rounded-md px-3 py-2 text-left text-sm ${
                        active === m.id
                          ? "bg-[#1DB954] text-white"
                          : "text-slate-700 hover:bg-slate-100"
                      }`}
                    >
                      {m.name}
                      <span className="mt-0.5 block text-[11px] opacity-80">
                        {m.location || "main"}
                      </span>
                    </button>
                  </li>
                ))
              )}
            </ul>
          </AdminPanel>

          <form onSubmit={onSave} className="space-y-4">
            <AdminPanel title={active ? "Edit menu" : "Create menu"}>
              <div className="grid gap-3 md:grid-cols-3">
                <FormField label="Name">
                  <TextInput required value={name} onChange={(e) => setName(e.target.value)} />
                </FormField>
                <FormField label="Location">
                  <TextSelect value={location} onChange={(e) => setLocation(e.target.value)}>
                    <option value="main">main</option>
                    <option value="footer">footer</option>
                    <option value="mobile">mobile</option>
                  </TextSelect>
                </FormField>
                <FormField label="Status">
                  <TextSelect value={status} onChange={(e) => setStatus(e.target.value)}>
                    <option value="active">active</option>
                    <option value="draft">draft</option>
                  </TextSelect>
                </FormField>
              </div>
            </AdminPanel>

            <AdminPanel title="Items">
              <div className="mb-3 space-y-3">
                {items.map((it, index) => (
                  <div
                    key={it.id || `new-${index}`}
                    className="grid gap-2 rounded-md border border-slate-200 p-3 md:grid-cols-[1fr_1fr_1fr_auto]"
                  >
                    <TextInput
                      required
                      placeholder="Label EN"
                      value={it.label}
                      onChange={(e) => updateItem(index, { label: e.target.value })}
                    />
                    <TextInput
                      placeholder="لیبل اردو"
                      value={it.labelUr || ""}
                      onChange={(e) => updateItem(index, { labelUr: e.target.value })}
                    />
                    <TextInput
                      required
                      placeholder="/path"
                      value={it.url}
                      onChange={(e) => updateItem(index, { url: e.target.value })}
                    />
                    <button
                      type="button"
                      onClick={() => setItems((prev) => prev.filter((_, i) => i !== index))}
                      className="rounded border border-red-200 px-2 py-1 text-xs text-red-700"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={() => setItems((prev) => [...prev, emptyItem()])}
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
              >
                + Add item
              </button>
            </AdminPanel>

            <div className="flex flex-wrap gap-2">
              <button
                type="submit"
                disabled={busy}
                className="rounded-md bg-[#1DB954] px-4 py-2 text-sm font-medium text-white disabled:opacity-60"
              >
                {busy ? "Saving…" : "Save menu"}
              </button>
              {active ? (
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void onDeleteMenu()}
                  className="rounded-md border border-red-200 px-4 py-2 text-sm font-medium text-red-700"
                >
                  Delete menu
                </button>
              ) : null}
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
