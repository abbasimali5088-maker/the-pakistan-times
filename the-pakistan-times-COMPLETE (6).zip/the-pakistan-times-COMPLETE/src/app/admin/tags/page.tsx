"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { DataTable } from "@/components/admin/DataTable";
import { FormField, TextInput, TextTextarea } from "@/components/admin/FormField";
import { ConfirmButton } from "@/components/admin/ConfirmButton";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";

type LangTab = "en" | "ur";

type Tag = {
  id: string;
  name: string;
  nameUr?: string | null;
  slug: string;
  language?: string | null;
  description?: string | null;
  usageCount?: number;
};

const empty = (lang: LangTab) => ({
  name: "",
  slug: "",
  description: "",
  language: lang,
});

export default function TagsPage() {
  const searchParams = useSearchParams();
  const langParam = searchParams.get("lang");
  const [tab, setTab] = useState<LangTab>(langParam === "ur" ? "ur" : "en");
  const [rows, setRows] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(() => empty(langParam === "ur" ? "ur" : "en"));

  useEffect(() => {
    const next = langParam === "ur" ? "ur" : langParam === "en" ? "en" : null;
    if (next && next !== tab) {
      setTab(next);
      setEditingId(null);
      setForm(empty(next));
    }
  }, [langParam, tab]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminFetch<{ items?: Tag[] }>(`/api/tags?language=${tab}`, {
        allowNotFound: true,
      });
      setRows(data?.items || []);
    } catch (err) {
      setRows([]);
      setError(err instanceof AdminApiError ? err.message : "Failed to load tags");
    } finally {
      setLoading(false);
    }
  }, [tab]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    setForm(empty(tab));
    setEditingId(null);
  }, [tab]);

  const filtered = useMemo(
    () => rows.filter((r) => (r.language || "en") === tab),
    [rows, tab],
  );

  function setField(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function startEdit(row: Tag) {
    setEditingId(row.id);
    const isUr = (row.language || "en") === "ur";
    setForm({
      name: isUr ? row.nameUr || row.name : row.name,
      slug: row.slug,
      description: row.description || "",
      language: tab,
    });
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const name = form.name.trim();
      if (!name) throw new Error(tab === "ur" ? "اردو نام ضروری" : "English name required");
      const payload =
        tab === "ur"
          ? { name, nameUr: name, slug: form.slug || undefined, description: form.description || null, language: "ur" }
          : { name, nameUr: null, slug: form.slug || undefined, description: form.description || null, language: "en" };
      if (editingId) {
        await adminFetch(`/api/tags/${editingId}`, { method: "PATCH", body: JSON.stringify(payload) });
      } else {
        await adminFetch("/api/tags", { method: "POST", body: JSON.stringify(payload) });
      }
      setNotice(tab === "ur" ? "اردو ٹیگ محفوظ" : "English tag saved");
      setEditingId(null);
      setForm(empty(tab));
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    try {
      await adminFetch(`/api/tags/${id}`, { method: "DELETE" });
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Delete failed");
    }
  }

  const isUr = tab === "ur";

  return (
    <div>
      <AdminPageHeader
        title="Tags"
        description="English اور اردو ٹیگز الگ لائبریریز — آرٹیکل ایڈیٹر میں الگ الگ چنتے ہیں۔"
      />
      <div className="mb-4 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setTab("en")}
          className={`rounded-md px-4 py-2 text-sm font-semibold ${tab === "en" ? "bg-[#1DB954] text-white" : "border bg-white"}`}
        >
          ① English tags
        </button>
        <button
          type="button"
          onClick={() => setTab("ur")}
          className={`rounded-md px-4 py-2 text-sm font-semibold ${tab === "ur" ? "bg-[#1DB954] text-white" : "border bg-white"}`}
        >
          ② اردو ٹیگز
        </button>
      </div>

      {error ? (
        <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm">{error}</div>
      ) : null}
      {notice ? (
        <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm">{notice}</div>
      ) : null}

      <AdminPanel title={isUr ? "اردو ٹیگ" : "English tag"} className="mb-4">
        <form onSubmit={onSubmit} className="space-y-3">
          <FormField label={isUr ? "نام (اردو)" : "Name (EN)"}>
            <TextInput
              required
              dir={isUr ? "rtl" : "ltr"}
              value={form.name}
              onChange={(e) => setField("name", e.target.value)}
            />
          </FormField>
          <FormField label="Slug">
            <TextInput dir="ltr" value={form.slug} onChange={(e) => setField("slug", e.target.value)} />
          </FormField>
          <FormField label="Description">
            <TextTextarea
              dir={isUr ? "rtl" : "ltr"}
              value={form.description}
              onChange={(e) => setField("description", e.target.value)}
            />
          </FormField>
          <button
            type="submit"
            disabled={busy}
            className="rounded-md bg-[#1DB954] px-4 py-2 text-sm font-medium text-white disabled:opacity-60"
          >
            {busy ? "…" : editingId ? "Save" : "Create"}
          </button>
        </form>
      </AdminPanel>

      {loading ? (
        <p className="text-sm text-slate-500">Loading…</p>
      ) : (
        <DataTable
          rows={filtered}
          rowKey={(r) => r.id}
          empty={isUr ? "کوئی اردو ٹیگ نہیں" : "No English tags yet"}
          columns={[
            {
              key: "name",
              header: isUr ? "نام" : "Name",
              render: (r) => (isUr ? r.nameUr || r.name : r.name),
            },
            { key: "slug", header: "Slug", render: (r) => r.slug },
            { key: "usage", header: "Usage", render: (r) => r.usageCount ?? 0 },
            {
              key: "actions",
              header: "",
              render: (r) => (
                <div className="flex gap-2">
                  <button type="button" className="text-sm text-[#1DB954]" onClick={() => startEdit(r)}>
                    Edit
                  </button>
                  <ConfirmButton label="Delete" confirmLabel="Delete?" onConfirm={() => remove(r.id)} />
                </div>
              ),
            },
          ]}
        />
      )}
    </div>
  );
}
