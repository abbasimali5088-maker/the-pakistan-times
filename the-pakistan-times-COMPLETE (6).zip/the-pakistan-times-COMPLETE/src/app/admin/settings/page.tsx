"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { FormField, TextInput, TextTextarea } from "@/components/admin/FormField";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";
import {
  SETTING_GROUPS,
  defaultSettingsMap,
  emptySettingsMap,
  normalizeSettingsMap,
  type SettingsMap,
} from "@/lib/site-settings";

/** Deep-merge defaults so new theme/security keys are never blanked by shallow spread. */
function mergeSettings(raw: SettingsMap): SettingsMap {
  const defaults = defaultSettingsMap();
  const incoming = normalizeSettingsMap(raw);
  const merged = emptySettingsMap();
  for (const g of Object.keys(merged)) {
    merged[g] = { ...(defaults[g] || {}), ...(incoming[g] || {}) };
    for (const [k, v] of Object.entries(merged[g])) {
      if (!String(v || "").trim() && defaults[g]?.[k]) {
        merged[g][k] = defaults[g][k];
      }
    }
  }
  return merged;
}

export default function SettingsPage() {
  const [values, setValues] = useState<SettingsMap>(emptySettingsMap());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [activeTab, setActiveTab] = useState(SETTING_GROUPS[0]?.key || "general");

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminFetch<{
        settings?: SettingsMap;
        items?: Array<{ group: string; key: string; value: string }>;
      }>("/api/settings");

      if (data?.settings) {
        setValues(mergeSettings(data.settings));
      } else if (data?.items) {
        const map: SettingsMap = {};
        for (const row of data.items) {
          map[row.group] ||= {};
          map[row.group][row.key] = row.value;
        }
        setValues(mergeSettings(map));
      } else {
        setValues(defaultSettingsMap());
      }
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Failed to load settings");
      setValues(defaultSettingsMap());
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  function get(group: string, key: string) {
    return values[group]?.[key] ?? "";
  }

  function set(group: string, key: string, value: string) {
    setValues((prev) => ({
      ...prev,
      [group]: { ...(prev[group] || {}), [key]: value },
    }));
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setNotice(null);
    setError(null);
    try {
      // Save ONLY the active tab — prevents wiping Search Console / SEO fields
      const groupKey = activeTab;
      const groupValues = { ...(values[groupKey] || {}) };
      // Never send empty launcher password (keeps previous)
      if (groupKey === "security" && !String(groupValues.launcherPassword || "").trim()) {
        delete groupValues.launcherPassword;
      }
      await adminFetch("/api/settings", {
        method: "PUT",
        body: JSON.stringify({
          settings: { [groupKey]: groupValues },
          allowClear: true,
        }),
      });
      setNotice(
        `Saved: ${SETTING_GROUPS.find((g) => g.key === groupKey)?.title || groupKey}`,
      );
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <p className="text-sm text-slate-500">Loading settings…</p>;

  const activeGroup = SETTING_GROUPS.find((g) => g.key === activeTab) || SETTING_GROUPS[0];

  return (
    <div>
      <AdminPageHeader
        title="Settings"
        description="سائٹ کا نام، سوشل لنکس (Facebook, WhatsApp, X, Instagram…)، تھیم، SEO اور فوٹر — سب یہاں سے بغیر کوڈنگ کے سیٹ کریں۔"
      />

      {error ? (
        <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          {error}
        </div>
      ) : null}
      {notice ? (
        <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
          {notice}
        </div>
      ) : null}

      <div className="mb-4 flex flex-wrap gap-2">
        {SETTING_GROUPS.map((g) => (
          <button
            key={g.key}
            type="button"
            onClick={() => setActiveTab(g.key)}
            className={`rounded-md px-3 py-1.5 text-sm font-medium transition ${
              activeTab === g.key
                ? "bg-[#1DB954] text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            {g.title}
          </button>
        ))}
      </div>

      <form onSubmit={onSubmit} className="space-y-4">
        {activeGroup ? (
          <AdminPanel
            title={activeGroup.title}
            description={
              activeGroup.description
                ? `${activeGroup.titleUr} — ${activeGroup.description}`
                : activeGroup.titleUr
            }
          >
            <div className="grid gap-3 md:grid-cols-2">
              {activeGroup.fields.map((f) => {
                const inputType =
                  f.type === "email" || f.type === "url" || f.type === "tel" || f.type === "password"
                    ? f.type
                    : f.type === "color"
                      ? "text"
                      : "text";
                const current = get(activeGroup.key, f.key);
                return (
                  <FormField
                    key={f.key}
                    label={f.labelUr ? `${f.label} / ${f.labelUr}` : f.label}
                    hint={f.hint}
                    urdu={f.urdu}
                    className={f.type === "textarea" ? "md:col-span-2" : undefined}
                  >
                    {f.type === "textarea" ? (
                      <TextTextarea
                        urdu={f.urdu}
                        value={current}
                        placeholder={f.placeholder}
                        onChange={(e) => set(activeGroup.key, f.key, e.target.value)}
                      />
                    ) : f.type === "toggle" ? (
                      <select
                        id={f.key}
                        value={
                          ["off", "0", "false", "no"].includes(current.trim().toLowerCase())
                            ? "off"
                            : "on"
                        }
                        onChange={(e) => set(activeGroup.key, f.key, e.target.value)}
                        className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
                      >
                        <option value="on">ON — آن</option>
                        <option value="off">OFF — آف</option>
                      </select>
                    ) : (
                      <div className="flex gap-2">
                        {f.type === "color" ? (
                          <input
                            type="color"
                            aria-label={f.label}
                            value={/^#[0-9A-Fa-f]{6}$/.test(current) ? current : "#1DB954"}
                            onChange={(e) => set(activeGroup.key, f.key, e.target.value)}
                            className="h-10 w-12 cursor-pointer rounded border border-slate-300 bg-white p-1"
                          />
                        ) : null}
                        <TextInput
                          type={inputType}
                          urdu={f.urdu}
                          value={current}
                          placeholder={f.placeholder}
                          onChange={(e) => set(activeGroup.key, f.key, e.target.value)}
                          className="flex-1"
                          autoComplete={f.type === "password" ? "new-password" : undefined}
                        />
                      </div>
                    )}
                  </FormField>
                );
              })}
            </div>
          </AdminPanel>
        ) : null}

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="submit"
            disabled={busy}
            className="rounded-md bg-[#1DB954] px-4 py-2 text-sm font-medium text-white hover:bg-[#159A45] disabled:opacity-60"
          >
            {busy ? "Saving…" : `Save “${activeGroup?.title || "tab"}”`}
          </button>
          <p className="text-xs text-slate-500">
            صرف موجودہ ٹیب محفوظ ہوتا ہے — Search Console والی سیٹنگز غلطی سے مٹ نہیں سکتیں۔
          </p>
        </div>
      </form>
    </div>
  );
}
