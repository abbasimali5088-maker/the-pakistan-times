"use client";

import Link from "next/link";
import { FormEvent, useState } from "react";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";
import { FormField, TextInput } from "@/components/admin/FormField";

export default function AdminLoginPage() {
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<"login" | "reset">("login");
  const [notice, setNotice] = useState<string | null>(null);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy) return;

    const form = e.currentTarget;
    const data = new FormData(form);

    if (mode === "reset") {
      const email = String(data.get("email") || "").trim();
      const resetKey = String(data.get("resetKey") || "");
      const newPassword = String(data.get("newPassword") || "");
      setError(null);
      setNotice(null);
      setBusy(true);
      try {
        await adminFetch("/api/auth/password", {
          method: "POST",
          body: JSON.stringify({ email, newPassword, resetKey }),
        });
        setNotice("Password reset ho gaya — ab naya password se Sign in karein.");
        setMode("login");
        form.reset();
        const emailInput = form.elements.namedItem("email") as HTMLInputElement | null;
        if (emailInput) emailInput.value = email;
      } catch (err) {
        setError(
          err instanceof AdminApiError
            ? err.message
            : err instanceof Error
              ? err.message
              : "Reset failed",
        );
      } finally {
        setBusy(false);
      }
      return;
    }

    const email = String(data.get("email") || "").trim();
    const password = String(data.get("password") || "");
    if (!email || !password) {
      setError("ای میل اور پاس ورڈ دونوں لکھیں / Email and password required");
      return;
    }

    setError(null);
    setBusy(true);
    try {
      await adminFetch("/api/auth", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      // Hard navigation so middleware sees the new cookie immediately
      window.location.href = "/admin";
    } catch (err) {
      const msg =
        err instanceof AdminApiError
          ? err.message
          : err instanceof Error
            ? err.message
            : "Login failed";
      setError(msg);
      setBusy(false);
    }
  }

  return (
    <div
      className="relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-100 px-4"
      dir="ltr"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 opacity-40"
        style={{
          background:
            "radial-gradient(ellipse at top left, rgba(11,122,59,0.18), transparent 50%), radial-gradient(ellipse at bottom right, rgba(20,20,20,0.06), transparent 45%)",
        }}
      />
      <div className="relative z-10 w-full max-w-md rounded-xl border border-slate-200 bg-white p-8 shadow-sm">
        <div className="mb-6 text-center">
          <p className="font-urdu text-2xl font-semibold text-[#1DB954]" dir="rtl">
            دی پاکستان ٹائمز — بیک اینڈ
          </p>
          <h1 className="mt-2 text-lg font-semibold text-slate-900">
            {mode === "login" ? "Admin login" : "Forgot / Reset password"}
          </h1>
        </div>

        {notice ? (
          <p className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
            {notice}
          </p>
        ) : null}

        <form onSubmit={onSubmit} className="space-y-4" method="post" action="#" noValidate>
          <FormField label="Email">
            <TextInput
              name="email"
              type="email"
              autoComplete="username"
              required
              placeholder="admin@…"
            />
          </FormField>

          {mode === "login" ? (
            <FormField label="Password">
              <TextInput
                name="password"
                type="password"
                autoComplete="current-password"
                required
                placeholder="Password"
              />
            </FormField>
          ) : (
            <>
              <FormField
                label="Owner reset key"
                hint="Vercel / server env: OWNER_RESET_KEY (never share publicly)"
              >
                <TextInput name="resetKey" type="password" required />
              </FormField>
              <FormField label="New password (min 8)">
                <TextInput
                  name="newPassword"
                  type="password"
                  autoComplete="new-password"
                  required
                  minLength={8}
                />
              </FormField>
            </>
          )}

          {error ? (
            <p
              role="alert"
              className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700"
            >
              {error}
            </p>
          ) : null}

          <button
            id="admin-signin"
            type="submit"
            disabled={busy}
            className="relative z-20 w-full cursor-pointer rounded-md bg-[#1DB954] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#159A45] disabled:cursor-wait disabled:opacity-60"
          >
            {busy
              ? mode === "login"
                ? "Signing in…"
                : "Saving…"
              : mode === "login"
                ? "Sign in / داخل ہوں"
                : "Reset password"}
          </button>
        </form>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-sm">
          <button
            type="button"
            className="font-semibold text-[#1DB954] underline"
            onClick={() => {
              setMode(mode === "login" ? "reset" : "login");
              setError(null);
              setNotice(null);
            }}
          >
            {mode === "login" ? "Forgot / Change password?" : "← Back to login"}
          </button>
          <Link className="text-slate-500 underline" href="/">
            ← Site
          </Link>
        </div>
      </div>
    </div>
  );
}
