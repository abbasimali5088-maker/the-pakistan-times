"use client";

import Link from "next/link";
import { FormEvent, useCallback, useEffect, useState } from "react";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { DataTable } from "@/components/admin/DataTable";
import { FormField, TextInput, TextSelect, TextTextarea } from "@/components/admin/FormField";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";

type QuizQuestion = {
  question: string;
  options: string[];
  correctIndex: number;
  explanation?: string | null;
};

type Quiz = {
  id: string;
  title: string;
  description?: string | null;
  status?: string;
  questions?: QuizQuestion[];
};

export default function QuizzesPage() {
  const [rows, setRows] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("draft");
  const [questions, setQuestions] = useState<QuizQuestion[]>([
    { question: "", options: ["", ""], correctIndex: 0, explanation: "" },
  ]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminFetch<{ items?: Quiz[] } | Quiz[]>("/api/quizzes", {
        allowNotFound: true,
      });
      setRows(Array.isArray(data) ? data : data?.items || []);
    } catch (err) {
      setRows([]);
      setError(err instanceof AdminApiError ? err.message : "Failed to load quizzes");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  function resetForm() {
    setEditingId(null);
    setTitle("");
    setDescription("");
    setStatus("draft");
    setQuestions([{ question: "", options: ["", ""], correctIndex: 0, explanation: "" }]);
  }

  async function startEdit(id: string) {
    setBusy(true);
    setError(null);
    try {
      const quiz = await adminFetch<Quiz>(`/api/quizzes/${id}`);
      setEditingId(quiz.id);
      setTitle(quiz.title);
      setDescription(quiz.description || "");
      setStatus(quiz.status || "draft");
      setQuestions(
        quiz.questions?.length
          ? quiz.questions.map((q) => ({
              question: q.question,
              options: q.options?.length >= 2 ? q.options : ["", ""],
              correctIndex: q.correctIndex ?? 0,
              explanation: q.explanation || "",
            }))
          : [{ question: "", options: ["", ""], correctIndex: 0, explanation: "" }],
      );
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Failed to load quiz");
    } finally {
      setBusy(false);
    }
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    const cleanQuestions = questions
      .map((q) => ({
        question: q.question.trim(),
        options: q.options.map((o) => o.trim()).filter(Boolean),
        correctIndex: q.correctIndex,
        explanation: q.explanation?.trim() || null,
      }))
      .filter((q) => q.question && q.options.length >= 2);

    const payload = {
      title: title.trim(),
      description: description.trim() || null,
      status,
      questions: cleanQuestions,
    };

    try {
      if (editingId) {
        await adminFetch(`/api/quizzes/${editingId}`, {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        setNotice("Quiz updated.");
      } else {
        const created = await adminFetch<Quiz>("/api/quizzes", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        setNotice("Quiz created.");
        setEditingId(created.id);
      }
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function onDelete(id: string) {
    if (!window.confirm("Delete this quiz?")) return;
    try {
      await adminFetch(`/api/quizzes/${id}`, { method: "DELETE" });
      if (editingId === id) resetForm();
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Delete failed");
    }
  }

  return (
    <div>
      <AdminPageHeader
        title="Quizzes"
        description="Create quizzes with questions and correct answers."
        actions={
          <button
            type="button"
            onClick={resetForm}
            className="rounded-md bg-[#1DB954] px-3 py-2 text-sm font-medium text-white"
          >
            New quiz
          </button>
        }
      />

      {error ? (
        <div className="mb-4 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          {error}
        </div>
      ) : null}
      {notice ? (
        <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
          {notice}
        </div>
      ) : null}

      <form onSubmit={onSubmit} className="mb-6 space-y-4">
        <AdminPanel title={editingId ? "Edit quiz" : "Create quiz"}>
          <div className="grid gap-3">
            <FormField label="Title">
              <TextInput required value={title} onChange={(e) => setTitle(e.target.value)} />
            </FormField>
            <FormField label="Description">
              <TextTextarea value={description} onChange={(e) => setDescription(e.target.value)} />
            </FormField>
            <FormField label="Status">
              <TextSelect value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="draft">draft</option>
                <option value="published">published</option>
                <option value="archived">archived</option>
              </TextSelect>
            </FormField>
          </div>
        </AdminPanel>

        <AdminPanel title="Questions">
          <div className="space-y-4">
            {questions.map((q, qi) => (
              <div key={qi} className="rounded-md border border-slate-200 p-3">
                <FormField label={`Question ${qi + 1}`}>
                  <TextInput
                    required
                    value={q.question}
                    onChange={(e) =>
                      setQuestions((prev) =>
                        prev.map((item, i) =>
                          i === qi ? { ...item, question: e.target.value } : item,
                        ),
                      )
                    }
                  />
                </FormField>
                <div className="mt-2 grid gap-2 md:grid-cols-2">
                  {q.options.map((opt, oi) => (
                    <label key={oi} className="flex items-center gap-2 text-sm">
                      <input
                        type="radio"
                        name={`correct-${qi}`}
                        checked={q.correctIndex === oi}
                        onChange={() =>
                          setQuestions((prev) =>
                            prev.map((item, i) =>
                              i === qi ? { ...item, correctIndex: oi } : item,
                            ),
                          )
                        }
                      />
                      <TextInput
                        required
                        value={opt}
                        placeholder={`Option ${oi + 1}`}
                        onChange={(e) =>
                          setQuestions((prev) =>
                            prev.map((item, i) =>
                              i === qi
                                ? {
                                    ...item,
                                    options: item.options.map((o, j) =>
                                      j === oi ? e.target.value : o,
                                    ),
                                  }
                                : item,
                            ),
                          )
                        }
                      />
                    </label>
                  ))}
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  <button
                    type="button"
                    className="rounded border px-2 py-1 text-xs"
                    onClick={() =>
                      setQuestions((prev) =>
                        prev.map((item, i) =>
                          i === qi ? { ...item, options: [...item.options, ""] } : item,
                        ),
                      )
                    }
                  >
                    + Option
                  </button>
                  <button
                    type="button"
                    className="rounded border border-red-200 px-2 py-1 text-xs text-red-700"
                    onClick={() => setQuestions((prev) => prev.filter((_, i) => i !== qi))}
                  >
                    Remove question
                  </button>
                </div>
              </div>
            ))}
            <button
              type="button"
              onClick={() =>
                setQuestions((prev) => [
                  ...prev,
                  { question: "", options: ["", ""], correctIndex: 0, explanation: "" },
                ])
              }
              className="rounded-md border border-slate-300 px-3 py-2 text-sm"
            >
              + Add question
            </button>
          </div>
        </AdminPanel>

        <button
          type="submit"
          disabled={busy}
          className="rounded-md bg-[#1DB954] px-4 py-2 text-sm font-medium text-white disabled:opacity-60"
        >
          {busy ? "Saving…" : "Save quiz"}
        </button>
      </form>

      <DataTable
        loading={loading}
        error={null}
        rows={rows}
        rowKey={(r) => r.id}
        empty="No quizzes yet."
        columns={[
          {
            key: "title",
            header: "Title",
            render: (r) => (
              <button
                type="button"
                className="font-medium text-[#1DB954] hover:underline"
                onClick={() => void startEdit(r.id)}
              >
                {r.title}
              </button>
            ),
          },
          { key: "description", header: "Description", render: (r) => r.description || "—" },
          { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
          {
            key: "actions",
            header: "",
            render: (r) => (
              <div className="flex gap-2">
                <button
                  type="button"
                  className="rounded border px-2 py-1 text-xs"
                  onClick={() => void startEdit(r.id)}
                >
                  Edit
                </button>
                <button
                  type="button"
                  className="rounded border border-red-200 px-2 py-1 text-xs text-red-700"
                  onClick={() => void onDelete(r.id)}
                >
                  Delete
                </button>
              </div>
            ),
          },
        ]}
      />
      <p className="mt-3 text-xs text-slate-500">
        Tip: mark the radio next to the correct option.{" "}
        <Link href="/admin" className="text-[#1DB954] hover:underline">
          Dashboard
        </Link>
      </p>
    </div>
  );
}
