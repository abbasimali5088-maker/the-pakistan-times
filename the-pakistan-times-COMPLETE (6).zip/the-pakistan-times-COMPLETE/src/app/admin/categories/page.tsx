"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { DataTable } from "@/components/admin/DataTable";
import { FormField, TextInput, TextSelect, TextTextarea } from "@/components/admin/FormField";
import { FeaturedImagePicker } from "@/components/admin/FeaturedImagePicker";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { ConfirmButton } from "@/components/admin/ConfirmButton";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";

type LangTab = "en" | "ur";

type Category = {
  id: string;
  name: string;
  nameUr?: string | null;
  slug: string;
  language?: string | null;
  description?: string | null;
  descriptionUr?: string | null;
  imageId?: string | null;
  imageUrId?: string | null;
  imageUrl?: string | null;
  imageUrlUr?: string | null;
  seoTitle?: string | null;
  seoDescription?: string | null;
  seoTitleUr?: string | null;
  seoDescriptionUr?: string | null;
  status?: string;
  sortOrder?: number;
  _count?: { articles?: number };
};

const emptyForm = (lang: LangTab) => ({
  name: "",
  slug: "",
  description: "",
  imageId: "",
  imageUrl: "",
  seoTitle: "",
  seoDescription: "",
  status: "active",
  sortOrder: "0",
  language: lang,
});

export default function CategoriesPage() {
  const searchParams = useSearchParams();
  const langParam = searchParams.get("lang");
  const [tab, setTab] = useState<LangTab>(langParam === "ur" ? "ur" : "en");
  const [rows, setRows] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(() => emptyForm(langParam === "ur" ? "ur" : "en"));

  useEffect(() => {
    const next = langParam === "ur" ? "ur" : langParam === "en" ? "en" : null;
    if (next && next !== tab) {
      setTab(next);
      setEditingId(null);
      setForm(emptyForm(next));
    }
  }, [langParam, tab]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminFetch<{ items?: Category[] }>(
        `/api/categories?language=${tab}`,
        { allowNotFound: true },
      );
      setRows(data?.items || []);
    } catch (err) {
      setRows([]);
      setError(err instanceof AdminApiError ? err.message : "Failed to load categories");
    } finally {
      setLoading(false);
    }
  }, [tab]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    setForm(emptyForm(tab));
    setEditingId(null);
    setNotice(null);
  }, [tab]);

  const filtered = useMemo(
    () => rows.filter((r) => (r.language || "en") === tab),
    [rows, tab],
  );

  function setField(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function startEdit(row: Category) {
    setEditingId(row.id);
    const isUr = (row.language || "en") === "ur";
    setForm({
      name: isUr ? row.nameUr || row.name || "" : row.name || "",
      slug: row.slug || "",
      description: isUr ? row.descriptionUr || "" : row.description || "",
      imageId: isUr ? row.imageUrId || "" : row.imageId || "",
      imageUrl: isUr ? row.imageUrlUr || "" : row.imageUrl || "",
      seoTitle: isUr ? row.seoTitleUr || "" : row.seoTitle || "",
      seoDescription: isUr ? row.seoDescriptionUr || "" : row.seoDescription || "",
      status: row.status || "active",
      sortOrder: String(row.sortOrder ?? 0),
      language: (row.language === "ur" ? "ur" : "en") as LangTab,
    });
    setNotice(null);
  }

  function resetForm() {
    setEditingId(null);
    setForm(emptyForm(tab));
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const name = form.name.trim();
      if (!name) throw new Error(tab === "ur" ? "اردو نام ضروری ہے" : "English name required");

      const payload =
        tab === "ur"
          ? {
              name,
              nameUr: name,
              slug: form.slug.trim() || undefined,
              description: null,
              descriptionUr: form.description.trim() || null,
              language: "ur",
              imageId: null,
              imageUrId: form.imageId.trim() || null,
              seoTitle: null,
              seoDescription: null,
              seoTitleUr: form.seoTitle.trim() || null,
              seoDescriptionUr: form.seoDescription.trim() || null,
              status: form.status,
              sortOrder: Number(form.sortOrder) || 0,
            }
          : {
              name,
              nameUr: null,
              slug: form.slug.trim() || undefined,
              description: form.description.trim() || null,
              descriptionUr: null,
              language: "en",
              imageId: form.imageId.trim() || null,
              imageUrId: null,
              seoTitle: form.seoTitle.trim() || null,
              seoDescription: form.seoDescription.trim() || null,
              seoTitleUr: null,
              seoDescriptionUr: null,
              status: form.status,
              sortOrder: Number(form.sortOrder) || 0,
            };

      if (editingId) {
        await adminFetch(`/api/categories/${editingId}`, {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        setNotice(tab === "ur" ? "اردو کیٹیگری محفوظ ہو گئی" : "English category saved");
      } else {
        await adminFetch("/api/categories", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        setNotice(tab === "ur" ? "اردو کیٹیگری بن گئی" : "English category created");
      }
      resetForm();
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError || err instanceof Error ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    try {
      await adminFetch(`/api/categories/${id}`, { method: "DELETE" });
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Delete failed");
    }
  }

  async function mirrorEnglishToUrdu() {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const enData = await adminFetch<{ items?: Category[] }>("/api/categories?language=en", {
        allowNotFound: true,
      });
      const enRows = enData?.items || [];
      const urData = await adminFetch<{ items?: Category[] }>("/api/categories?language=ur", {
        allowNotFound: true,
      });
      const existingUrSlugs = new Set((urData?.items || []).map((r) => r.slug));
      let created = 0;
      for (const row of enRows) {
        const slug = `${row.slug}-ur`;
        if (existingUrSlugs.has(slug) || existingUrSlugs.has(row.slug)) continue;
        const name = row.nameUr || row.name;
        await adminFetch("/api/categories", {
          method: "POST",
          body: JSON.stringify({
            name,
            nameUr: name,
            slug,
            descriptionUr: row.descriptionUr || row.description || null,
            language: "ur",
            status: row.status || "active",
            sortOrder: row.sortOrder ?? 0,
          }),
        });
        created += 1;
      }
      setTab("ur");
      setNotice(
        created > 0
          ? `${created} اردو کیٹیگریز بن گئیں (English سے الگ)`
          : "اردو کیٹیگریز پہلے سے موجود ہیں — نئی کچھ نہیں بنی۔",
      );
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError || err instanceof Error ? err.message : "Mirror failed");
    } finally {
      setBusy(false);
    }
  }

  const isUr = tab === "ur";

  return (
    <div>
      <AdminPageHeader
        title="Categories"
        description="English اور Urdu کیٹیگریز الگ الگ — فرنٹ اینڈ کی طرح الگ سسٹم۔"
      />

      <div className="mb-4 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setTab("en")}
          className={`rounded-md px-4 py-2 text-sm font-semibold ${
            tab === "en" ? "bg-[#1DB954] text-white" : "border border-slate-200 bg-white text-slate-700"
          }`}
        >
          ① English categories
        </button>
        <button
          type="button"
          onClick={() => setTab("ur")}
          className={`rounded-md px-4 py-2 text-sm font-semibold ${
            tab === "ur" ? "bg-[#1DB954] text-white" : "border border-slate-200 bg-white text-slate-700"
          }`}
        >
          ② اردو کیٹیگریز
        </button>
      </div>

      <div
        className={`mb-4 rounded-md border px-3 py-2 text-sm ${
          isUr
            ? "border-emerald-200 bg-emerald-50 text-emerald-900"
            : "border-sky-200 bg-sky-50 text-sky-900"
        }`}
      >
        {isUr
          ? "یہ صرف اردو فرنٹ کے لیے ہے۔ نام، تفصیل، تصویر، SEO — سب اردو۔ English فیلڈز یہاں نہیں ملیں گے۔"
          : "This is English-only. Name, description, image, SEO — English. Urdu fields are on the other tab."}
      </div>

      {isUr && filtered.length === 0 && !loading ? (
        <div className="mb-4 rounded-md border border-dashed border-emerald-300 bg-white px-3 py-3 text-sm">
          <p className="mb-2 text-emerald-900">
            ابھی اردو کیٹیگریز خالی ہیں۔ نئی بنائیں، یا English سے الگ اردو کاپیاں بنائیں۔
          </p>
          <button
            type="button"
            disabled={busy}
            onClick={() => void mirrorEnglishToUrdu()}
            className="rounded-md bg-[#1DB954] px-3 py-1.5 text-sm font-medium text-white hover:bg-[#159A45] disabled:opacity-60"
          >
            {busy ? "…" : "English → اردو کیٹیگریز بنائیں"}
          </button>
        </div>
      ) : null}

      {error ? (
        <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          {error}
        </div>
      ) : null}
      {notice ? (
        <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-900">
          {notice}
        </div>
      ) : null}

      <AdminPanel title={editingId ? (isUr ? "اردو کیٹیگری ترمیم" : "Edit English category") : isUr ? "نئی اردو کیٹیگری" : "Create English category"} className="mb-4">
        <form onSubmit={onSubmit} className="space-y-3">
          <FormField label={isUr ? "نام (اردو)" : "Name (EN)"}>
            <TextInput
              required
              dir={isUr ? "rtl" : "ltr"}
              value={form.name}
              onChange={(e) => setField("name", e.target.value)}
              placeholder={isUr ? "پاکستان" : "Pakistan"}
            />
          </FormField>
          <FormField label="Slug / URL" hint={isUr ? "مثلاً pakistan-ur — الگ URL" : "e.g. pakistan — separate URL"}>
            <TextInput
              dir="ltr"
              value={form.slug}
              onChange={(e) => setField("slug", e.target.value)}
              placeholder={isUr ? "pakistan-ur" : "pakistan"}
            />
          </FormField>
          <FormField label={isUr ? "تفصیل (اردو)" : "Description (EN)"}>
            <TextTextarea
              dir={isUr ? "rtl" : "ltr"}
              value={form.description}
              onChange={(e) => setField("description", e.target.value)}
            />
          </FormField>

          <FeaturedImagePicker
            language={tab}
            featuredImageId={form.imageId}
            imageUrl={form.imageUrl}
            imageCaption=""
            imageCredit=""
            onChange={(next) => {
              setForm((prev) => ({
                ...prev,
                imageId: next.featuredImageId,
                imageUrl: next.imageUrl,
              }));
            }}
          />

          <FormField label={isUr ? "SEO H1 / عنوان (اردو)" : "SEO H1 / Title (EN)"}>
            <TextInput
              dir={isUr ? "rtl" : "ltr"}
              value={form.seoTitle}
              onChange={(e) => setField("seoTitle", e.target.value)}
              placeholder={isUr ? "کیٹیگری کا H1" : "Category H1"}
            />
          </FormField>
          <FormField label={isUr ? "SEO تفصیل / H2 نوٹ (اردو)" : "SEO description / H2 note (EN)"}>
            <TextTextarea
              dir={isUr ? "rtl" : "ltr"}
              value={form.seoDescription}
              onChange={(e) => setField("seoDescription", e.target.value)}
            />
          </FormField>

          <div className="grid gap-3 sm:grid-cols-2">
            <FormField label="Status">
              <TextSelect value={form.status} onChange={(e) => setField("status", e.target.value)}>
                <option value="active">active</option>
                <option value="inactive">inactive</option>
              </TextSelect>
            </FormField>
            <FormField label="Sort order">
              <TextInput
                type="number"
                value={form.sortOrder}
                onChange={(e) => setField("sortOrder", e.target.value)}
              />
            </FormField>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="submit"
              disabled={busy}
              className="rounded-md bg-[#1DB954] px-4 py-2 text-sm font-medium text-white hover:bg-[#159A45] disabled:opacity-60"
            >
              {busy ? "…" : editingId ? "Save" : "Create"}
            </button>
            {editingId ? (
              <button
                type="button"
                onClick={resetForm}
                className="rounded-md border border-slate-200 px-4 py-2 text-sm text-slate-700"
              >
                Cancel
              </button>
            ) : null}
          </div>
        </form>
      </AdminPanel>

      {loading ? (
        <p className="text-sm text-slate-500">Loading…</p>
      ) : (
        <DataTable
          rows={filtered}
          rowKey={(r) => r.id}
          empty={
            isUr
              ? "ابھی کوئی اردو کیٹیگری نہیں — اوپر سے بنائیں۔"
              : "No English categories yet — create one above."
          }
          columns={[
            {
              key: "name",
              header: isUr ? "نام (اردو)" : "Name (EN)",
              render: (r) => (isUr ? r.nameUr || r.name : r.name),
            },
            { key: "slug", header: "URL slug", render: (r) => r.slug },
            {
              key: "image",
              header: "Image",
              render: (r) =>
                isUr
                  ? r.imageUrId
                    ? "✓"
                    : "—"
                  : r.imageId
                    ? "✓"
                    : "—",
            },
            {
              key: "seo",
              header: "SEO H1",
              render: (r) =>
                (isUr ? r.seoTitleUr : r.seoTitle) || "—",
            },
            {
              key: "status",
              header: "Status",
              render: (r) => <StatusBadge status={r.status} />,
            },
            {
              key: "actions",
              header: "Actions",
              render: (r) => (
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => startEdit(r)}
                    className="text-sm text-[#1DB954] hover:underline"
                  >
                    Edit
                  </button>
                  <ConfirmButton
                    label="Delete"
                    confirmLabel="Delete?"
                    onConfirm={() => remove(r.id)}
                    className="text-sm text-red-600 hover:underline"
                  />
                </div>
              ),
            },
          ]}
        />
      )}
    </div>
  );
}
