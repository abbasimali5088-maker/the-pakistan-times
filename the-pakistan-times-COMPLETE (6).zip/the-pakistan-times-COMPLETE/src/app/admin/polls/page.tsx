"use client";

import { ResourceCrudPage } from "@/components/admin/ResourceCrudPage";
import { StatusBadge } from "@/components/admin/StatusBadge";

type PollOption = { id?: string; label: string };
type Poll = {
  id: string;
  question: string;
  status?: string;
  options?: PollOption[] | string;
};

export default function PollsPage() {
  return (
    <ResourceCrudPage<Poll>
      title="Polls"
      description="Reader polls — at least 2 options required."
      endpoint="/api/polls"
      defaults={{ status: "draft", options: "" }}
      mapItems={(data) => {
        const raw = Array.isArray(data)
          ? data
          : data && typeof data === "object" && Array.isArray((data as { items?: unknown }).items)
            ? ((data as { items: Poll[] }).items)
            : [];
        return raw.map((p) => ({
          ...p,
          options: Array.isArray(p.options)
            ? p.options.map((o: PollOption | string) => (typeof o === "string" ? o : o.label)).join(", ")
            : typeof p.options === "string"
              ? p.options
              : "",
        }));
      }}
      fields={[
        { name: "question", label: "Question", required: true, type: "textarea" },
        {
          name: "status",
          label: "Status",
          type: "select",
          options: [
            { value: "draft", label: "draft" },
            { value: "active", label: "active" },
            { value: "closed", label: "closed" },
          ],
        },
        {
          name: "options",
          label: "Options",
          hint: "Comma-separated labels (min 2). Editing options resets votes.",
          placeholder: "Yes, No, Maybe",
          required: true,
        },
      ]}
      toPayload={(values) => {
        const options = String(values.options || "")
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean)
          .map((label) => ({ label }));
        return {
          question: values.question,
          status: values.status,
          options,
        };
      }}
      columns={[
        { key: "question", header: "Question", render: (r) => r.question },
        {
          key: "options",
          header: "Options",
          render: (r) => (typeof r.options === "string" ? r.options : "—"),
        },
        { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
      ]}
    />
  );
}
