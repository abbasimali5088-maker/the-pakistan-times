"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { DataTable } from "@/components/admin/DataTable";
import { FormField, TextInput, TextSelect } from "@/components/admin/FormField";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";
import { formatDate } from "@/lib/utils";

type MediaItem = {
  id: string;
  url: string;
  alt?: string | null;
  caption?: string | null;
  mimeType?: string | null;
  language?: string | null;
  createdAt?: string;
};

export default function MediaPage() {
  const searchParams = useSearchParams();
  const langParam = searchParams.get("lang");
  const [lang, setLang] = useState<"en" | "ur">(langParam === "ur" ? "ur" : "en");
  const [rows, setRows] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [url, setUrl] = useState("");
  const [alt, setAlt] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (langParam === "ur" || langParam === "en") setLang(langParam);
  }, [langParam]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminFetch<{ items?: MediaItem[] } | MediaItem[]>(
        `/api/media?language=${lang}&pageSize=100`,
        { allowNotFound: true },
      );
      if (!data) {
        setRows([]);
        setError("Media API not available yet.");
      } else {
        setRows(Array.isArray(data) ? data : data.items || []);
      }
    } catch (err) {
      setRows([]);
      setError(err instanceof AdminApiError ? err.message : "Failed to load media");
    } finally {
      setLoading(false);
    }
  }, [lang]);

  useEffect(() => {
    void load();
  }, [load]);

  async function onAdd(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const filename = (() => {
        try {
          const base = new URL(url).pathname.split("/").filter(Boolean).pop() || "image.jpg";
          return base.includes(".") ? base : `${base}.jpg`;
        } catch {
          return `image-${Date.now()}.jpg`;
        }
      })();
      await adminFetch("/api/media", {
        method: "POST",
        body: JSON.stringify({
          filename,
          url,
          alt: alt || null,
          type: "image",
          language: lang,
        }),
      });
      setUrl("");
      setAlt("");
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Failed to add media");
    } finally {
      setBusy(false);
    }
  }

  async function onDelete(id: string) {
    if (!window.confirm("Delete this media item?")) return;
    setBusy(true);
    setError(null);
    try {
      await adminFetch(`/api/media/${id}`, { method: "DELETE" });
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <AdminPageHeader
        title="Media galleries"
        description="English and Urdu image libraries are completely separate — never mixed."
      />

      <div className="mb-4 flex gap-2">
        <button
          type="button"
          onClick={() => setLang("en")}
          className={`rounded-md px-4 py-2 text-sm font-semibold ${
            lang === "en" ? "bg-[#1DB954] text-white" : "border border-slate-300 bg-white"
          }`}
        >
          English gallery
        </button>
        <button
          type="button"
          onClick={() => setLang("ur")}
          className={`rounded-md px-4 py-2 text-sm font-semibold ${
            lang === "ur" ? "bg-[#1DB954] text-white" : "border border-slate-300 bg-white"
          }`}
        >
          اردو گیلری
        </button>
      </div>

      <AdminPanel
        title={lang === "ur" ? "اردو گیلری میں شامل کریں" : "Add to English gallery"}
        className="mb-4"
      >
        <form onSubmit={onAdd} className="grid gap-3 md:grid-cols-2">
          <FormField label="URL" className="md:col-span-2">
            <TextInput
              type="url"
              required
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://…"
            />
          </FormField>
          <FormField label="Alt text">
            <TextInput value={alt} onChange={(e) => setAlt(e.target.value)} />
          </FormField>
          <FormField label="Gallery">
            <TextSelect value={lang} onChange={(e) => setLang(e.target.value as "en" | "ur")}>
              <option value="en">English</option>
              <option value="ur">Urdu</option>
            </TextSelect>
          </FormField>
          <div className="flex items-end md:col-span-2">
            <button
              type="submit"
              disabled={busy}
              className="rounded-md bg-[#1DB954] px-4 py-2 text-sm font-medium text-white hover:bg-[#159A45] disabled:opacity-60"
            >
              {busy ? "Adding…" : `Add to ${lang === "ur" ? "Urdu" : "English"} gallery`}
            </button>
          </div>
        </form>
      </AdminPanel>

      <DataTable
        loading={loading}
        error={error}
        rows={rows}
        rowKey={(r) => r.id}
        empty={lang === "ur" ? "اردو گیلری خالی ہے。" : "English gallery is empty."}
        columns={[
          {
            key: "preview",
            header: "Preview",
            render: (r) =>
              r.url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={r.url} alt={r.alt || ""} className="h-12 w-16 rounded object-cover" />
              ) : (
                "—"
              ),
          },
          {
            key: "id",
            header: "Media ID",
            render: (r) => <code className="text-xs">{r.id}</code>,
          },
          {
            key: "url",
            header: "URL",
            render: (r) => (
              <a href={r.url} target="_blank" rel="noreferrer" className="text-[#1DB954] hover:underline">
                {r.url.slice(0, 48)}…
              </a>
            ),
          },
          {
            key: "lang",
            header: "Lang",
            render: (r) => (r.language || lang).toUpperCase(),
          },
          { key: "alt", header: "Alt", render: (r) => r.alt || "—" },
          {
            key: "created",
            header: "Added",
            render: (r) => formatDate(r.createdAt) || "—",
          },
          {
            key: "actions",
            header: "",
            render: (r) => (
              <button
                type="button"
                disabled={busy}
                onClick={() => void onDelete(r.id)}
                className="rounded border border-red-200 px-2 py-1 text-xs font-medium text-red-700 hover:bg-red-50 disabled:opacity-60"
              >
                Delete
              </button>
            ),
          },
        ]}
      />
    </div>
  );
}
