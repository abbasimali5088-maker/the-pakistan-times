"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { DataTable } from "@/components/admin/DataTable";
import { FormField, TextInput, TextSelect, TextTextarea } from "@/components/admin/FormField";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { ConfirmButton } from "@/components/admin/ConfirmButton";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";

type LangTab = "en" | "ur";

type StaticPageRow = {
  id: string;
  title: string;
  titleUr?: string | null;
  slug: string;
  body?: string;
  bodyUr?: string | null;
  status?: string;
  seoTitle?: string | null;
  seoDescription?: string | null;
  seoTitleUr?: string | null;
  seoDescriptionUr?: string | null;
};

const emptyForm = () => ({
  title: "",
  titleUr: "",
  slug: "",
  body: "",
  bodyUr: "",
  status: "published",
  seoTitle: "",
  seoDescription: "",
  seoTitleUr: "",
  seoDescriptionUr: "",
});

export default function PagesAdminPage() {
  const [tab, setTab] = useState<LangTab>("en");
  const [rows, setRows] = useState<StaticPageRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminFetch<{ items?: StaticPageRow[] }>("/api/pages", {
        allowNotFound: true,
      });
      setRows(data?.items || []);
    } catch (err) {
      setRows([]);
      setError(err instanceof AdminApiError ? err.message : "Failed to load pages");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  function setField(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function startEdit(row: StaticPageRow) {
    setEditingId(row.id);
    setForm({
      title: row.title || "",
      titleUr: row.titleUr || "",
      slug: row.slug || "",
      body: row.body || "",
      bodyUr: row.bodyUr || "",
      status: row.status || "published",
      seoTitle: row.seoTitle || "",
      seoDescription: row.seoDescription || "",
      seoTitleUr: row.seoTitleUr || "",
      seoDescriptionUr: row.seoDescriptionUr || "",
    });
    setNotice(null);
    setError(null);
  }

  function resetForm() {
    setEditingId(null);
    setForm(emptyForm());
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      if (tab === "ur") {
        if (!form.titleUr.trim()) throw new Error("اردو عنوان ضروری ہے");
        if (!form.bodyUr.trim()) throw new Error("اردو متن ضروری ہے");
      } else {
        if (!form.title.trim()) throw new Error("English title is required");
        if (!form.body.trim()) throw new Error("English body is required");
      }

      // Locale-tab payload: only write the active language fields.
      const payload =
        tab === "ur"
          ? {
              title: editingId ? undefined : form.titleUr.trim(),
              titleUr: form.titleUr.trim(),
              slug: editingId ? undefined : form.slug.trim() || form.titleUr.trim(),
              body: editingId ? undefined : form.bodyUr.trim(),
              bodyUr: form.bodyUr.trim(),
              status: form.status,
              seoTitleUr: form.seoTitleUr.trim() || null,
              seoDescriptionUr: form.seoDescriptionUr.trim() || null,
              locale: "ur" as const,
            }
          : {
              title: form.title.trim(),
              titleUr: editingId ? undefined : null,
              slug: form.slug.trim() || undefined,
              body: form.body,
              bodyUr: editingId ? undefined : null,
              status: form.status,
              seoTitle: form.seoTitle.trim() || null,
              seoDescription: form.seoDescription.trim() || null,
              locale: "en" as const,
            };

      if (editingId) {
        await adminFetch(`/api/pages/${editingId}`, {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        setNotice(tab === "ur" ? "اردو صفحہ محفوظ ہو گیا" : "English page saved");
      } else {
        await adminFetch("/api/pages", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        setNotice(tab === "ur" ? "اردو صفحہ بن گیا" : "English page created");
      }
      resetForm();
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError || err instanceof Error ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    try {
      await adminFetch(`/api/pages/${id}`, { method: "DELETE" });
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Delete failed");
    }
  }

  const isUr = tab === "ur";

  return (
    <div>
      <AdminPageHeader
        title="Pages"
        description="Legal / system pages — English and Urdu forms are separate. Switch tab to edit that language only."
      />

      <div className="mb-4 flex gap-2">
        <button
          type="button"
          onClick={() => {
            setTab("en");
            resetForm();
          }}
          className={`rounded-sm px-4 py-2 text-sm font-semibold ${
            tab === "en"
              ? "bg-[var(--accent)] text-white"
              : "border border-[var(--line)] bg-white text-[var(--ink)]"
          }`}
        >
          ① English pages
        </button>
        <button
          type="button"
          onClick={() => {
            setTab("ur");
            resetForm();
          }}
          className={`rounded-sm px-4 py-2 text-sm font-semibold ${
            tab === "ur"
              ? "bg-[var(--accent)] text-white"
              : "border border-[var(--line)] bg-white text-[var(--ink)]"
          }`}
          dir="rtl"
        >
          ② اردو صفحات
        </button>
      </div>

      <div
        className={`mb-4 rounded-md border px-3 py-2 text-sm ${
          isUr
            ? "border-emerald-200 bg-emerald-50 text-emerald-900"
            : "border-sky-200 bg-sky-50 text-sky-900"
        }`}
      >
        {isUr
          ? "یہ صرف اردو فارم ہے — عنوان، متن، SEO سب اردو۔ English فیلڈز یہاں نہیں ہیں۔"
          : "English-only form — title, body, SEO. Urdu fields are on the اردو tab."}
      </div>

      <AdminPanel title={editingId ? (isUr ? "اردو صفحہ ترمیم" : "Edit English page") : isUr ? "نیا اردو صفحہ" : "Create English page"}>
        <form onSubmit={onSubmit} className="space-y-4">
          {editingId ? (
            <p className="text-sm text-[var(--muted)]">
              Editing <code className="rounded bg-[var(--surface)] px-1">{form.slug || editingId}</code>
              {" · "}
              <button type="button" className="underline" onClick={resetForm}>
                Cancel
              </button>
            </p>
          ) : null}

          {tab === "en" ? (
            <>
              <FormField label="Title (English)">
                <TextInput
                  value={form.title}
                  onChange={(e) => setField("title", e.target.value)}
                  required
                />
              </FormField>
              <FormField label="Slug" hint="URL path shared across languages when both exist">
                <TextInput
                  value={form.slug}
                  onChange={(e) => setField("slug", e.target.value)}
                  disabled={Boolean(editingId)}
                />
              </FormField>
              <FormField label="Body (English)">
                <TextTextarea
                  value={form.body}
                  onChange={(e) => setField("body", e.target.value)}
                  rows={12}
                  required
                />
              </FormField>
              <FormField label="SEO title (EN)">
                <TextInput value={form.seoTitle} onChange={(e) => setField("seoTitle", e.target.value)} />
              </FormField>
              <FormField label="SEO description (EN)">
                <TextTextarea
                  value={form.seoDescription}
                  onChange={(e) => setField("seoDescription", e.target.value)}
                  rows={3}
                />
              </FormField>
            </>
          ) : (
            <div dir="rtl">
              <FormField label="عنوان (اردو)" urdu>
                <TextInput
                  urdu
                  required
                  value={form.titleUr}
                  onChange={(e) => setField("titleUr", e.target.value)}
                />
              </FormField>
              {!editingId ? (
                <FormField label="Slug / URL" urdu>
                  <TextInput
                    dir="ltr"
                    value={form.slug}
                    onChange={(e) => setField("slug", e.target.value)}
                    placeholder="privacy"
                  />
                </FormField>
              ) : null}
              <FormField label="متن (اردو)" urdu>
                <TextTextarea
                  urdu
                  required
                  value={form.bodyUr}
                  onChange={(e) => setField("bodyUr", e.target.value)}
                  rows={12}
                />
              </FormField>
              <FormField label="SEO عنوان (اردو)" urdu>
                <TextInput
                  urdu
                  value={form.seoTitleUr}
                  onChange={(e) => setField("seoTitleUr", e.target.value)}
                />
              </FormField>
              <FormField label="SEO تفصیل (اردو)" urdu>
                <TextTextarea
                  urdu
                  value={form.seoDescriptionUr}
                  onChange={(e) => setField("seoDescriptionUr", e.target.value)}
                  rows={3}
                />
              </FormField>
            </div>
          )}

          <FormField label="Status">
            <TextSelect
              value={form.status}
              onChange={(e) => setField("status", e.target.value)}
            >
              <option value="draft">draft</option>
              <option value="published">published</option>
            </TextSelect>
          </FormField>

          {error ? <p className="text-sm text-red-600">{error}</p> : null}
          {notice ? <p className="text-sm text-[var(--accent)]">{notice}</p> : null}

          <button
            type="submit"
            disabled={busy}
            className="rounded-sm bg-[var(--accent)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
          >
            {busy ? "Saving…" : editingId ? "Save page" : isUr ? "اردو صفحہ بنائیں" : "Create page"}
          </button>
        </form>
      </AdminPanel>

      <AdminPanel className="mt-6" title={isUr ? "اردو صفحات" : "English pages"}>
        <DataTable
          loading={loading}
          empty={isUr ? "ابھی کوئی اردو صفحہ نہیں — اوپر سے بنائیں۔" : "No pages yet."}
          rowKey={(r) => r.id}
          columns={[
            {
              key: "title",
              header: tab === "ur" ? "عنوان" : "Title",
              render: (r: StaticPageRow) =>
                tab === "ur" ? (
                  r.titleUr?.trim() ? (
                    <span dir="rtl">{r.titleUr}</span>
                  ) : (
                    <span className="font-semibold text-amber-700">خالی ✗</span>
                  )
                ) : (
                  r.title
                ),
            },
            { key: "slug", header: "Slug", render: (r: StaticPageRow) => r.slug },
            {
              key: "status",
              header: "Status",
              render: (r: StaticPageRow) => <StatusBadge status={r.status} />,
            },
            {
              key: "actions",
              header: "",
              render: (r: StaticPageRow) => (
                <div className="flex gap-2">
                  <button
                    type="button"
                    className="text-sm underline"
                    onClick={() => startEdit(r)}
                  >
                    Edit
                  </button>
                  <ConfirmButton
                    label="Delete"
                    confirmLabel="Confirm delete"
                    onConfirm={() => void remove(r.id)}
                  />
                </div>
              ),
            },
          ]}
          rows={
            isUr
              ? rows.filter((r) => Boolean(r.titleUr?.trim()) || Boolean(r.bodyUr?.trim()))
              : rows
          }
        />
      </AdminPanel>
    </div>
  );
}
