"use client";

import { Suspense, useEffect, useState, type ReactNode } from "react";
import { usePathname } from "next/navigation";
import { AdminShell, type AdminUser } from "@/components/admin/AdminShell";
import { adminFetch } from "@/lib/admin-fetch";

function UrduFontLink() {
  return (
    // eslint-disable-next-line @next/next/no-page-custom-font
    <link
      href="https://fonts.googleapis.com/css2?family=Noto+Nastaliq+Urdu:wght@400;600;700&display=swap"
      rel="stylesheet"
    />
  );
}

export default function AdminLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const isLogin = pathname === "/admin/login";
  const [user, setUser] = useState<AdminUser | null>(null);
  const [checking, setChecking] = useState(!isLogin);

  useEffect(() => {
    if (isLogin) {
      setChecking(false);
      return;
    }

    let cancelled = false;
    setChecking(true);

    (async () => {
      try {
        const data = await adminFetch<{ user: AdminUser }>("/api/auth");
        if (!cancelled) setUser(data.user);
      } catch {
        if (cancelled) return;
        window.location.assign("/admin/login");
        return;
      } finally {
        if (!cancelled) setChecking(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [isLogin, pathname]);

  if (isLogin) {
    return (
      <>
        <UrduFontLink />
        {children}
      </>
    );
  }

  if (checking || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-100 text-sm text-slate-500">
        Checking session…
      </div>
    );
  }

  return (
    <>
      <UrduFontLink />
      <Suspense
        fallback={
          <div className="flex min-h-screen items-center justify-center bg-slate-100 text-sm text-slate-500">
            Loading admin…
          </div>
        }
      >
        <AdminShell user={user}>{children}</AdminShell>
      </Suspense>
    </>
  );
}
