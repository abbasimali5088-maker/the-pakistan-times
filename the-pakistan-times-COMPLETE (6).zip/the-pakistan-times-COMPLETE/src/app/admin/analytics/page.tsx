"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { StatCard } from "@/components/admin/StatCard";
import { DataTable } from "@/components/admin/DataTable";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";
import { formatDate } from "@/lib/utils";
import type { NamedCount } from "@/lib/analytics-ua";

type ArticleHit = {
  articleId?: string | null;
  count?: number;
  article?: {
    id: string;
    title: string;
    titleUr?: string | null;
    slug: string;
    viewCount?: number;
    language?: string | null;
  } | null;
};

type ArticleRow = {
  id: string;
  title: string;
  titleUr?: string | null;
  slug: string;
  viewCount: number;
  language?: string | null;
  status?: string;
};

type AnalyticsPayload = {
  language?: string;
  property?: string;
  totals?: Record<string, number | string>;
  stats?: Record<string, number | string>;
  audience?: {
    countries?: NamedCount[];
    channels?: NamedCount[];
    referrers?: NamedCount[];
  };
  events?: Array<{
    id: string;
    eventType: string;
    path?: string | null;
    articleId?: string | null;
    createdAt?: string;
  }>;
  items?: Array<{
    id: string;
    eventType: string;
    path?: string | null;
    articleId?: string | null;
    createdAt?: string;
  }>;
  topArticles?: ArticleHit[];
  articlesByViews?: ArticleRow[];
  days?: number;
};

export default function AnalyticsPage() {
  const [langTab, setLangTab] = useState<"ur" | "en">("ur");
  const [data, setData] = useState<AnalyticsPayload>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminFetch<AnalyticsPayload>(
        `/api/analytics?days=7&language=${langTab}`,
        { allowNotFound: true },
      );
      if (!res) {
        setError("Analytics API not available yet.");
        setData({});
      } else {
        setData(res);
      }
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Failed to load analytics");
      setData({});
    } finally {
      setLoading(false);
    }
  }, [langTab]);

  useEffect(() => {
    void load();
  }, [load]);

  const stats = { ...(data.totals || {}), ...(data.stats || {}) };
  const events = data.events || data.items || [];
  const topPeriod = data.topArticles || [];
  const byLifetimeViews = data.articlesByViews || [];
  const channels = data.audience?.channels || data.audience?.referrers || [];
  const countries = data.audience?.countries || [];

  return (
    <div>
      <AdminPageHeader
        title="Analytics"
        description={
          langTab === "ur"
            ? "اردو پراپرٹی — صرف اردو آرٹیکل اینالیٹکس (12h unique views)"
            : "English property — English article analytics only (12h unique views)"
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        {(
          [
            { id: "ur" as const, label: "اردو / Urdu" },
            { id: "en" as const, label: "English" },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setLangTab(t.id)}
            className={`rounded-md px-4 py-2 text-sm font-semibold ${
              langTab === t.id
                ? "bg-[#1DB954] text-white"
                : "border border-slate-200 bg-white text-slate-700"
            }`}
          >
            {t.label}
          </button>
        ))}
        <button
          type="button"
          onClick={() => void load()}
          className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 hover:bg-slate-50"
        >
          Refresh
        </button>
        {data.property ? (
          <span className="text-xs text-slate-500" dir="ltr">
            Property: {data.property}
          </span>
        ) : null}
      </div>

      {error ? (
        <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          {error}
        </div>
      ) : null}

      <div className="mb-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {Object.keys(stats).length
          ? Object.entries(stats)
              .filter(([k]) => k !== "days")
              .map(([k, v]) => (
                <StatCard key={k} label={k.replace(/_/g, " ")} value={v} />
              ))
          : ["Page views", "Article views", "Total events"].map((l) => (
              <StatCard key={l} label={l} value={loading ? "…" : "—"} />
            ))}
      </div>

      <AdminPanel title="Traffic channels (Google · FB · IG · WA · Blogger · Backend)" className="mb-6">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {channels.length === 0 && loading ? (
            <p className="col-span-full text-sm text-slate-400">Loading…</p>
          ) : (
            channels.map((ch) => (
              <div key={ch.name} className="rounded-lg border border-slate-100 bg-slate-50 px-3 py-2">
                <p className="text-xs font-semibold text-slate-500">{ch.name}</p>
                <p className="text-xl font-bold tabular-nums text-[#1DB954]">{ch.count}</p>
              </div>
            ))
          )}
        </div>
      </AdminPanel>

      <AdminPanel title="Countries" className="mb-6">
        {countries.length === 0 ? (
          <p className="text-sm text-slate-400">
            ابھی کنٹری ڈیٹا نہیں — ویوز آئیں گے تو یہاں دکھے گا
          </p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {countries.map((c) => (
              <li key={c.name} className="flex justify-between py-2 text-sm">
                <span>{c.name}</span>
                <span className="font-semibold tabular-nums">{c.count}</span>
              </li>
            ))}
          </ul>
        )}
      </AdminPanel>

      <AdminPanel title="Views per article (lifetime viewCount)" className="mb-6">
        <DataTable
          loading={loading}
          rows={byLifetimeViews}
          rowKey={(r) => r.id}
          empty={
            langTab === "ur"
              ? "ابھی کوئی اردو آرٹیکل ویو نہیں۔"
              : "No English article views yet. Open a published English article on the public site."
          }
          columns={[
            {
              key: "title",
              header: "Article",
              render: (r) => (
                <div>
                  <div className="font-medium">
                    {r.language === "ur" ? r.titleUr || r.title : r.title || r.titleUr}
                  </div>
                  <div className="text-xs text-slate-500" dir="ltr">
                    /{r.slug}
                  </div>
                </div>
              ),
            },
            {
              key: "lang",
              header: "Lang",
              render: (r) => r.language || "—",
            },
            {
              key: "views",
              header: "Views",
              render: (r) => (
                <span className="font-semibold text-[#1DB954]">{r.viewCount}</span>
              ),
            },
            {
              key: "open",
              header: "",
              render: (r) => (
                <Link href={`/${r.slug}`} className="text-sm text-[#1DB954] underline" target="_blank">
                  View
                </Link>
              ),
            },
          ]}
        />
      </AdminPanel>

      <AdminPanel title="Top articles (last 7 days — unique article_view events)" className="mb-6">
        <DataTable
          loading={loading}
          rows={topPeriod}
          rowKey={(r) => r.articleId || Math.random().toString()}
          empty="No article views in this period."
          columns={[
            {
              key: "title",
              header: "Article",
              render: (r) =>
                r.article ? (
                  <div>
                    <div className="font-medium">
                      {r.article.language === "ur"
                        ? r.article.titleUr || r.article.title
                        : r.article.title || r.article.titleUr}
                    </div>
                    <div className="text-xs text-slate-500" dir="ltr">
                      /{r.article.slug}
                    </div>
                  </div>
                ) : (
                  r.articleId || "—"
                ),
            },
            {
              key: "period",
              header: "Views (7d)",
              render: (r) => r.count ?? "—",
            },
            {
              key: "life",
              header: "Lifetime",
              render: (r) => r.article?.viewCount ?? "—",
            },
          ]}
        />
      </AdminPanel>

      <AdminPanel title="Recent events">
        <DataTable
          loading={loading}
          rows={events}
          rowKey={(r) => r.id}
          empty="No analytics events."
          columns={[
            { key: "type", header: "Event", render: (r) => r.eventType },
            { key: "path", header: "Path", render: (r) => r.path || "—" },
            {
              key: "article",
              header: "Article ID",
              render: (r) => r.articleId || "—",
            },
            {
              key: "when",
              header: "When",
              render: (r) => formatDate(r.createdAt) || "—",
            },
          ]}
        />
      </AdminPanel>
    </div>
  );
}
