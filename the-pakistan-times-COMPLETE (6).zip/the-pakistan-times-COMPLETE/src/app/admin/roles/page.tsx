"use client";

import { useCallback, useEffect, useState } from "react";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { DataTable } from "@/components/admin/DataTable";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";

type Role = {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  isSystem?: boolean;
};

/** Roles API is read-only — list system roles (no fake create/edit). */
export default function RolesPage() {
  const [rows, setRows] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminFetch<{ items?: Role[] } | Role[]>("/api/roles", { allowNotFound: true });
      if (!data) {
        setRows([]);
        setError("Roles API not available.");
      } else {
        setRows(Array.isArray(data) ? data : data.items || []);
      }
    } catch (err) {
      setRows([]);
      setError(err instanceof AdminApiError ? err.message : "Failed to load roles");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div>
      <AdminPageHeader
        title="Roles"
        description="System roles (read-only). Permissions are managed in the database seed."
      />
      <AdminPanel title="Role list" className="mb-4">
        <p className="text-sm text-slate-600">
          Creating or editing roles from the UI is disabled. Contact the developer to change permission bundles.
        </p>
      </AdminPanel>
      <DataTable
        loading={loading}
        error={error}
        rows={rows}
        rowKey={(r) => r.id}
        empty="No roles found."
        columns={[
          { key: "name", header: "Name", render: (r) => r.name },
          { key: "slug", header: "Slug", render: (r) => r.slug },
          { key: "description", header: "Description", render: (r) => r.description || "—" },
          {
            key: "system",
            header: "System",
            render: (r) => (r.isSystem ? "Yes" : "No"),
          },
        ]}
      />
    </div>
  );
}
