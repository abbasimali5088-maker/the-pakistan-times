"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Eye, MessageCircle, RefreshCw, Users } from "lucide-react";
import { AdminPageHeader } from "@/components/admin/AdminShell";
import { AudienceDonutCard, ViewsLineChart } from "@/components/admin/ViewsCharts";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";
import { formatDate } from "@/lib/utils";
import type { NamedCount } from "@/lib/analytics-ua";

type PostRow = {
  id: string;
  title: string;
  titleUr?: string | null;
  slug: string;
  language?: string | null;
  viewCount?: number;
  status?: string;
  publishedAt?: string | null;
  authorName?: string;
  comments?: number;
  thumb?: string | null;
};

type LatestPost = PostRow & {
  daily?: Array<{ date: string; count: number }>;
};

type ViewsPayload = {
  days?: number;
  summary?: {
    allTime?: number;
    today?: number;
    yesterday?: number;
    thisMonth?: number;
    lastMonth?: number;
    posts?: number;
    comments?: number;
    periodViews?: number;
  };
  audience?: {
    countries?: NamedCount[];
    browsers?: NamedCount[];
    operatingSystems?: NamedCount[];
    referrers?: NamedCount[];
    channels?: NamedCount[];
    referrerUrls?: NamedCount[];
  };
  dailySeries?: Array<{ date: string; count: number }>;
  posts?: PostRow[];
  latestPost?: LatestPost | null;
  totals?: Record<string, number | string>;
};

const DAY_OPTIONS = [
  { id: 7, label: "Last 7 days" },
  { id: 30, label: "Last 30 days" },
  { id: 90, label: "Last 90 days" },
] as const;

function displayTitle(p: PostRow) {
  if (p.language === "ur") return p.titleUr || p.title;
  return p.title || p.titleUr || "Untitled";
}

function StatRow({
  label,
  value,
  icon,
}: {
  label: string;
  value: number | string;
  icon?: "eye" | "users" | "posts" | "comments";
}) {
  const Icon =
    icon === "users"
      ? Users
      : icon === "comments"
        ? MessageCircle
        : Eye;
  return (
    <div className="flex items-center justify-between border-b border-slate-100 py-3 last:border-0">
      <span className="text-sm text-slate-600">{label}</span>
      <span className="flex items-center gap-2 text-base font-semibold tabular-nums text-slate-900">
        {value}
        <Icon className="h-4 w-4 text-slate-400" aria-hidden />
      </span>
    </div>
  );
}

export default function AdminViewsPage() {
  const [days, setDays] = useState(7);
  const [langTab, setLangTab] = useState<"ur" | "en">("ur");
  const [data, setData] = useState<ViewsPayload>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminFetch<ViewsPayload>(
        `/api/analytics?days=${days}&language=${langTab}`,
        { allowNotFound: true },
      );
      setData(res || {});
      if (!res) setError("Views API not available");
    } catch (err) {
      setData({});
      setError(err instanceof AdminApiError ? err.message : "Views load failed");
    } finally {
      setLoading(false);
    }
  }, [days, langTab]);

  useEffect(() => {
    void load();
  }, [load]);

  const summary = data.summary || {};
  const audience = data.audience || {};
  const posts = data.posts || [];
  const series = data.dailySeries || [];
  const latest = data.latestPost;

  const overviewRows = useMemo(
    () => {
      const s = data.summary || {};
      return [
        { label: "All Time", value: s.allTime ?? 0 },
        { label: "Today", value: s.today ?? 0 },
        { label: "Yesterday", value: s.yesterday ?? 0 },
        { label: "This Month", value: s.thisMonth ?? 0 },
        { label: "Last Month", value: s.lastMonth ?? 0 },
      ];
    },
    [data.summary],
  );

  return (
    <div className="pb-10">
      <AdminPageHeader
        title="Views"
        description={
          langTab === "ur"
            ? "اردو پراپرٹی — صرف اردو آرٹیکل ویوز (لائیو ڈیٹا، Google سے لنک نہیں؛ زیرو سے شروع)"
            : "English property — English article views only (live data, not Google-linked; starts at zero)"
        }
      />

      {error ? (
        <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          {error}
        </div>
      ) : null}

      <div className="mb-4 flex flex-wrap items-center gap-2">
        {(
          [
            { id: "ur" as const, label: "اردو / Urdu" },
            { id: "en" as const, label: "English" },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setLangTab(t.id)}
            className={`rounded-md px-4 py-2 text-sm font-semibold ${
              langTab === t.id
                ? "bg-[#1DB954] text-white"
                : "border border-slate-200 bg-white text-slate-700"
            }`}
          >
            {t.label}
          </button>
        ))}
        <button
          type="button"
          onClick={() => void load()}
          className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 hover:bg-slate-50"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
        <select
          value={days}
          onChange={(e) => setDays(Number(e.target.value))}
          className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm"
        >
          {DAY_OPTIONS.map((o) => (
            <option key={o.id} value={o.id}>
              {o.label}
            </option>
          ))}
        </select>
      </div>

      <div className="mb-6 grid gap-4 lg:grid-cols-3">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm lg:col-span-1">
          <div className="mb-2 flex flex-wrap gap-4 text-sm text-slate-600">
            <span className="inline-flex items-center gap-1.5">
              <Users className="h-4 w-4" /> {summary.posts ?? 0} posts
            </span>
            <span className="inline-flex items-center gap-1.5">
              <MessageCircle className="h-4 w-4" /> {summary.comments ?? 0} comments
            </span>
          </div>
          {overviewRows.map((r) => (
            <StatRow key={r.label} label={r.label} value={loading ? "…" : r.value} />
          ))}
        </div>

        <div className="lg:col-span-2">
          <ViewsLineChart
            title={`Site views · last ${days} days`}
            series={series}
            height={200}
          />
          <div className="mt-2 flex items-center gap-4 px-1 text-sm text-slate-600">
            <span className="inline-flex items-center gap-1.5 font-semibold text-slate-900">
              <Eye className="h-4 w-4 text-slate-400" />
              {loading ? "…" : summary.periodViews ?? 0}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <MessageCircle className="h-4 w-4 text-slate-400" />
              {summary.comments ?? 0}
            </span>
          </div>
        </div>
      </div>

      {latest ? (
        <div className="mb-6 grid gap-4 lg:grid-cols-2">
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
              Latest post
            </p>
            <div className="flex gap-3">
              <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-md bg-slate-100">
                {latest.thumb ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={latest.thumb} alt="" className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full items-center justify-center text-xs text-slate-400">
                    —
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <Link
                  href={`/admin/articles/${latest.id}?lang=${latest.language === "en" ? "en" : "ur"}`}
                  className="line-clamp-2 font-semibold text-slate-900 hover:text-[#1DB954]"
                >
                  {displayTitle(latest)}
                </Link>
                <p className="mt-1 text-xs text-slate-500">
                  by {latest.authorName || "The Pakistan Times"}
                  {latest.publishedAt ? ` · ${formatDate(latest.publishedAt)}` : ""}
                </p>
                <p className="mt-2 inline-flex items-center gap-1.5 text-sm font-semibold text-slate-800">
                  <Eye className="h-4 w-4 text-slate-400" />
                  Views {latest.viewCount ?? 0}
                </p>
              </div>
            </div>
          </div>
          <div>
            <ViewsLineChart
              title="Views"
              series={latest.daily || []}
              height={160}
            />
            <div className="mt-1 flex gap-4 px-1 text-sm text-slate-600">
              <span className="inline-flex items-center gap-1 font-semibold">
                <Eye className="h-4 w-4 text-slate-400" /> {latest.viewCount ?? 0}
              </span>
              <span className="inline-flex items-center gap-1">
                <MessageCircle className="h-4 w-4 text-slate-400" /> {latest.comments ?? 0}
              </span>
            </div>
          </div>
        </div>
      ) : null}

      <div className="mb-6 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-4 py-3">
          <h2 className="text-base font-semibold text-slate-800">Posts</h2>
        </div>
        <ul className="divide-y divide-slate-100">
          {loading ? (
            <li className="px-4 py-8 text-center text-sm text-slate-400">Loading…</li>
          ) : posts.length === 0 ? (
            <li className="px-4 py-8 text-center text-sm text-slate-400">
              ابھی کوئی آرٹیکل نہیں
            </li>
          ) : (
            posts.map((p) => (
              <li key={p.id} className="flex items-center gap-3 px-4 py-3">
                <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded bg-slate-100">
                  {p.thumb ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={p.thumb} alt="" className="h-full w-full object-cover" />
                  ) : null}
                </div>
                <div className="min-w-0 flex-1">
                  <Link
                    href={`/admin/articles/${p.id}?lang=${p.language === "en" ? "en" : "ur"}`}
                    className="line-clamp-1 font-medium text-slate-900 hover:text-[#1DB954]"
                  >
                    {displayTitle(p)}
                  </Link>
                  <p className="text-xs text-slate-500">
                    Posted by {p.authorName || "The Pakistan Times"}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-1.5 text-sm font-semibold tabular-nums text-slate-800">
                  {p.viewCount ?? 0}
                  <Eye className="h-4 w-4 text-slate-400" />
                </div>
              </li>
            ))
          )}
        </ul>
      </div>

      <h2 className="mb-3 text-lg font-semibold text-slate-900">
        {langTab === "ur" ? "ٹریفک چینلز · کہاں سے ویوز آئے" : "Traffic channels · where views came from"}
      </h2>
      <p className="mb-3 text-sm text-slate-600">
        {langTab === "ur"
          ? "گوگل، فیس بک، انسٹاگرام، واٹس ایپ، بلاگر، بیک اینڈ — ایک ویو بھی آئے تو یہاں دکھے گا۔"
          : "Google, Facebook, Instagram, WhatsApp, Blogger, Backend — even one view shows here."}
      </p>
      <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {(audience.channels || audience.referrers || []).map((ch) => (
          <div
            key={ch.name}
            className="rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm"
          >
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{ch.name}</p>
            <p className="mt-1 text-2xl font-bold tabular-nums text-[#1DB954]">{loading ? "…" : ch.count}</p>
          </div>
        ))}
      </div>

      <h2 className="mb-3 text-lg font-semibold text-slate-900">Audience</h2>
      <div className="mb-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <AudienceDonutCard
          title="Top Locations (countries)"
          items={audience.countries || []}
          empty="ابھی کنٹری ڈیٹا نہیں — ویوز آئیں گے تو پاکستان وغیرہ یہاں دکھے گا"
        />
        <AudienceDonutCard
          title="Traffic channels"
          items={audience.channels || audience.referrers || []}
        />
        <AudienceDonutCard
          title="Pageviews by Browsers"
          items={audience.browsers || []}
        />
        <AudienceDonutCard
          title="Pageviews by Operating Systems"
          items={audience.operatingSystems || []}
        />
      </div>

      <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-4 py-3">
          <h2 className="text-base font-semibold text-slate-800">Top Referrer URLs</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-4 py-2 font-semibold">Entry</th>
                <th className="px-4 py-2 text-right font-semibold">Pageviews</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(audience.referrerUrls || []).length === 0 ? (
                <tr>
                  <td colSpan={2} className="px-4 py-8 text-center text-slate-400">
                    No referrer data yet
                  </td>
                </tr>
              ) : (
                (audience.referrerUrls || []).map((r) => (
                  <tr key={r.name}>
                    <td className="max-w-[420px] truncate px-4 py-2.5 text-slate-700" dir="ltr">
                      {r.name}
                    </td>
                    <td className="px-4 py-2.5 text-right font-semibold tabular-nums text-slate-900">
                      {r.count}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
