"use client";

import { Suspense } from "react";
import { ArticleEditor } from "@/components/admin/ArticleEditor";

function EditArticleInner() {
  return <ArticleEditor mode="edit" />;
}

export default function EditArticlePage() {
  return (
    <Suspense fallback={<p className="text-sm text-slate-500">Loading…</p>}>
      <EditArticleInner />
    </Suspense>
  );
}
