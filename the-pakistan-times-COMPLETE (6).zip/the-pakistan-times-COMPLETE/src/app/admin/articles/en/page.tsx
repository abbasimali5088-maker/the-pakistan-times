import { Suspense } from "react";
import { LocaleArticlesHub } from "@/components/admin/LocaleArticlesHub";

export default function EnglishArticlesHubPage() {
  return (
    <Suspense fallback={<p className="text-sm text-slate-500">Loading…</p>}>
      <LocaleArticlesHub locale="en" />
    </Suspense>
  );
}
