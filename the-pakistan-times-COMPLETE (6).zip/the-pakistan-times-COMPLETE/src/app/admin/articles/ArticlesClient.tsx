"use client";

import Link from "next/link";
import { FormEvent, useCallback, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { DataTable } from "@/components/admin/DataTable";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { FormField, TextInput, TextSelect } from "@/components/admin/FormField";
import { ARTICLE_STATUSES } from "@/lib/constants";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";
import { formatDate } from "@/lib/utils";
import type { ArticleLocale } from "@/components/admin/article-locale";

type ArticleRow = {
  id: string;
  title: string;
  titleEn?: string;
  titleUr?: string | null;
  slug: string;
  status: string;
  priority?: string;
  language?: string | null;
  isBreaking?: boolean;
  publishedAt?: string | null;
  updatedAt?: string;
  viewCount?: number;
  category?: { name: string } | null;
};

export default function ArticlesClient({ locale = "ur" }: { locale?: ArticleLocale }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [status, setStatus] = useState(searchParams.get("status") || "");
  const [q, setQ] = useState(searchParams.get("q") || "");
  const [rows, setRows] = useState<ArticleRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [total, setTotal] = useState(0);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const isUr = locale === "ur";
  const base = `/admin/articles/${locale}`;

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const params = new URLSearchParams();
    if (status) params.set("status", status);
    if (q) params.set("q", q);
    params.set("language", locale);
    params.set("pageSize", "50");
    try {
      const data = await adminFetch<{ items: ArticleRow[]; total?: number }>(
        `/api/articles?${params}`,
        { allowNotFound: true },
      );
      if (!data) {
        setRows([]);
        setError("Articles API not available yet.");
      } else {
        setRows(data.items || []);
        setTotal(data.total ?? data.items?.length ?? 0);
      }
    } catch (err) {
      setRows([]);
      setError(err instanceof AdminApiError ? err.message : "Failed to load articles");
    } finally {
      setLoading(false);
    }
  }, [status, q, locale]);

  useEffect(() => {
    void load();
  }, [load]);

  function onFilter(e: FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (status) params.set("status", status);
    if (q) params.set("q", q);
    router.replace(`${base}${params.toString() ? `?${params}` : ""}`);
    void load();
  }

  async function onDelete(id: string, title: string) {
    if (!window.confirm(`Delete article?\n\n${title}`)) return;
    setDeletingId(id);
    setError(null);
    try {
      await adminFetch(`/api/articles/${id}`, { method: "DELETE" });
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Delete failed");
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-slate-600">
          {total
            ? isUr
              ? `${total} اردو آرٹیکلز`
              : `${total} English articles`
            : isUr
              ? "اردو آرٹیکلز"
              : "English articles"}
        </p>
        <Link
          href={`/admin/articles/new?lang=${locale}`}
          className="rounded-md bg-[#1DB954] px-3 py-2 text-sm font-medium text-white hover:bg-[#159A45]"
        >
          {isUr ? "+ نیا اردو آرٹیکل" : "+ New English article"}
        </Link>
      </div>

      <form
        onSubmit={onFilter}
        className="mb-4 flex flex-col gap-3 rounded-lg border border-slate-200 bg-white p-4 shadow-sm sm:flex-row sm:items-end"
      >
        <FormField label="Status" className="sm:w-48">
          <TextSelect value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All</option>
            {ARTICLE_STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </TextSelect>
        </FormField>
        <FormField label="Search" className="flex-1">
          <TextInput
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={isUr ? "عنوان…" : "Title…"}
          />
        </FormField>
        <button
          type="submit"
          className="rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
        >
          Filter
        </button>
      </form>

      <DataTable
        loading={loading}
        error={error}
        rows={rows}
        rowKey={(r) => r.id}
        empty={isUr ? "ابھی کوئی اردو آرٹیکل نہیں۔" : "No English articles yet."}
        columns={[
          {
            key: "title",
            header: isUr ? "عنوان" : "Title",
            render: (r) => (
              <div>
                <Link
                  href={`/admin/articles/${r.id}?lang=${locale}`}
                  className="font-medium text-[#1DB954] hover:underline"
                >
                  {isUr ? r.titleUr || r.title : r.titleEn || r.title}
                </Link>
                <p className="text-xs text-slate-400">/{r.slug}</p>
              </div>
            ),
          },
          {
            key: "flags",
            header: "Type",
            render: (r) => (
              <span className="text-xs text-slate-600">
                {r.isBreaking ? (isUr ? "بریکنگ" : "Breaking") : isUr ? "عام" : "Normal"}
              </span>
            ),
          },
          {
            key: "category",
            header: isUr ? "کیٹیگری" : "Category",
            render: (r) => r.category?.name || "—",
          },
          {
            key: "status",
            header: "Status",
            render: (r) => <StatusBadge status={r.status} />,
          },
          {
            key: "views",
            header: isUr ? "ویوز" : "Views",
            render: (r) => (
              <span className="font-semibold text-[#1DB954]">{r.viewCount ?? 0}</span>
            ),
          },
          {
            key: "updated",
            header: "Updated",
            render: (r) => formatDate(r.updatedAt || r.publishedAt) || "—",
          },
          {
            key: "actions",
            header: "Actions",
            render: (r) => (
              <div className="flex flex-wrap gap-2">
                <Link
                  href={`/admin/articles/${r.id}?lang=${locale}`}
                  className="rounded border border-slate-300 px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  Edit
                </Link>
                <button
                  type="button"
                  disabled={deletingId === r.id}
                  onClick={() =>
                    void onDelete(r.id, isUr ? r.titleUr || r.title : r.titleEn || r.title)
                  }
                  className="rounded border border-red-200 px-2 py-1 text-xs font-medium text-red-700 hover:bg-red-50 disabled:opacity-60"
                >
                  {deletingId === r.id ? "…" : "Delete"}
                </button>
              </div>
            ),
          },
        ]}
      />
    </div>
  );
}
