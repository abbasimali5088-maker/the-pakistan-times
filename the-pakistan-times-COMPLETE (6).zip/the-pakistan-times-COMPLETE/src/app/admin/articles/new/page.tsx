"use client";

import { Suspense } from "react";
import { ArticleEditor } from "@/components/admin/ArticleEditor";

function NewArticleInner() {
  return <ArticleEditor mode="create" />;
}

export default function NewArticlePage() {
  return (
    <Suspense fallback={<p className="text-sm text-slate-500">Loading…</p>}>
      <NewArticleInner />
    </Suspense>
  );
}
