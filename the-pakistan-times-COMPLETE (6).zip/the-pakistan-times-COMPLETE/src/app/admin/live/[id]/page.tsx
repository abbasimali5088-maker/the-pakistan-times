"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { DataTable } from "@/components/admin/DataTable";
import { FormField, TextSelect, TextTextarea } from "@/components/admin/FormField";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { ConfirmButton } from "@/components/admin/ConfirmButton";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";
import { formatDate } from "@/lib/utils";

type LiveUpdate = {
  id: string;
  body: string;
  bodyUr?: string | null;
  type?: string;
  status?: string;
  isPinned?: boolean;
  publishedAt?: string;
};

type LiveStory = {
  id: string;
  title: string;
  titleUr?: string | null;
  slug: string;
  status?: string;
  updates?: LiveUpdate[];
};

export default function LiveStoryDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [story, setStory] = useState<LiveStory | null>(null);
  const [updates, setUpdates] = useState<LiveUpdate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [body, setBody] = useState("");
  const [bodyUr, setBodyUr] = useState("");
  const [type, setType] = useState("text");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminFetch<LiveStory>(`/api/live/${id}`, { allowNotFound: true });
      if (!data) {
        setError("Live story API not available yet.");
        setStory(null);
        setUpdates([]);
      } else {
        setStory(data);
        setUpdates(data.updates || []);
      }
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Failed to load live story");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  async function addUpdate(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (!body.trim()) throw new Error("English update body required");
      if (!bodyUr.trim()) throw new Error("اردو اپ ڈیٹ ضروری ہے");
      await adminFetch(`/api/live/${id}/updates`, {
        method: "POST",
        body: JSON.stringify({
          body: body.trim(),
          bodyUr: bodyUr.trim(),
          type,
          status: "published",
        }),
      });
      setBody("");
      setBodyUr("");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to post update");
    } finally {
      setBusy(false);
    }
  }

  async function removeUpdate(updateId: string) {
    try {
      await adminFetch(`/api/live/${id}/updates?updateId=${encodeURIComponent(updateId)}`, {
        method: "DELETE",
      });
      await load();
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Delete failed");
    }
  }

  if (loading) return <p className="text-sm text-slate-500">Loading…</p>;

  return (
    <div>
      <AdminPageHeader
        title={story?.title || "Live story"}
        description={
          story
            ? `${story.slug}${story.titleUr ? ` · ${story.titleUr}` : ""} — updates need EN + UR`
            : "Rolling updates"
        }
        actions={
          <Link href="/admin/live" className="text-sm text-slate-600 hover:text-[#1DB954]">
            ← All live stories
          </Link>
        }
      />

      {error ? (
        <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          {error}
        </div>
      ) : null}

      {story ? <StatusBadge status={story.status} className="mb-4" /> : null}

      <AdminPanel title="Post update (EN + UR)" className="mb-4">
        <form onSubmit={addUpdate} className="space-y-3">
          <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3">
            <FormField label="Update body (EN)">
              <TextTextarea required dir="ltr" value={body} onChange={(e) => setBody(e.target.value)} />
            </FormField>
          </div>
          <div className="rounded-lg border border-emerald-200 bg-emerald-50/60 p-3">
            <FormField label="اپ ڈیٹ (اردو)">
              <TextTextarea
                required
                dir="rtl"
                value={bodyUr}
                onChange={(e) => setBodyUr(e.target.value)}
              />
            </FormField>
          </div>
          <FormField label="Type" className="max-w-xs">
            <TextSelect value={type} onChange={(e) => setType(e.target.value)}>
              <option value="text">text</option>
              <option value="image">image</option>
              <option value="quote">quote</option>
              <option value="video">video</option>
            </TextSelect>
          </FormField>
          <button
            type="submit"
            disabled={busy}
            className="rounded-md bg-[#1DB954] px-4 py-2 text-sm font-medium text-white hover:bg-[#159A45] disabled:opacity-60"
          >
            {busy ? "Posting…" : "Post EN + UR update"}
          </button>
        </form>
      </AdminPanel>

      <DataTable
        rows={updates}
        rowKey={(r) => r.id}
        empty="No updates yet."
        columns={[
          {
            key: "body",
            header: "EN",
            render: (r) => <p className="max-w-md whitespace-pre-wrap text-sm">{r.body}</p>,
          },
          {
            key: "bodyUr",
            header: "اردو",
            render: (r) =>
              r.bodyUr?.trim() ? (
                <p className="max-w-md whitespace-pre-wrap text-sm" dir="rtl">
                  {r.bodyUr}
                </p>
              ) : (
                <span className="font-semibold text-amber-700">خالی ✗</span>
              ),
          },
          { key: "type", header: "Type", render: (r) => r.type || "text" },
          { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
          {
            key: "when",
            header: "When",
            render: (r) => formatDate(r.publishedAt, "en-GB"),
          },
          {
            key: "actions",
            header: "",
            render: (r) => (
              <ConfirmButton label="Delete" confirmLabel="Delete?" onConfirm={() => removeUpdate(r.id)} />
            ),
          },
        ]}
      />
    </div>
  );
}
