import { redirect } from "next/navigation";

/** Live moved inside Articles EN / Articles UR hubs. */
export default function LiveRedirectPage() {
  redirect("/admin/articles/ur?tab=live");
}
