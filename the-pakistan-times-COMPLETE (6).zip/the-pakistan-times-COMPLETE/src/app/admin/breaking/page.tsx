import { redirect } from "next/navigation";

/** Breaking moved inside Articles EN / Articles UR hubs. */
export default function BreakingRedirectPage() {
  redirect("/admin/articles/ur?tab=breaking");
}
