"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { AdminPageHeader, AdminPanel } from "@/components/admin/AdminShell";
import { adminFetch, AdminApiError } from "@/lib/admin-fetch";

const SITE_UR = "https://urdu.thepakistantimes.live";
const SITE_EN = "https://www.thepakistantimes.live";
const SITE_FALLBACK = "https://the-pakistan-times-live.vercel.app";

function extractVerificationCode(raw: string) {
  const trimmed = raw.trim();
  const fromAttr = trimmed.match(/content=["']([^"']+)["']/i);
  if (fromAttr?.[1]) return fromAttr[1].trim();
  return trimmed.replace(/^google-site-verification=/i, "").trim();
}

type SavedSnapshot = {
  gscUr: string;
  gscEn: string;
  gscLegacy: string;
  gaUr: string;
  gaEn: string;
  gaLegacy: string;
  gtm: string;
  domainUr: string;
  domainEn: string;
  index: string;
  perf: string;
};

export default function SeoPage() {
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [gscUr, setGscUr] = useState("");
  const [gscEn, setGscEn] = useState("");
  const [gscLegacy, setGscLegacy] = useState("");
  const [gaUr, setGaUr] = useState("");
  const [gaEn, setGaEn] = useState("");
  const [gaLegacy, setGaLegacy] = useState("");
  const [gtmInput, setGtmInput] = useState("");
  const [domainUr, setDomainUr] = useState(SITE_UR);
  const [domainEn, setDomainEn] = useState(SITE_EN);
  const [indexHomepage, setIndexHomepage] = useState("on");
  const [performanceNote, setPerformanceNote] = useState("");
  const [saved, setSaved] = useState<SavedSnapshot | null>(null);

  const applyFromSettings = useCallback((settings?: Record<string, Record<string, string>>) => {
    const integ = settings?.integrations || {};
    const seo = settings?.seo || {};
    const snap: SavedSnapshot = {
      gscUr: integ.searchConsoleVerificationUr || "",
      gscEn: integ.searchConsoleVerificationEn || "",
      gscLegacy: integ.searchConsoleVerification || "",
      gaUr: integ.gaMeasurementIdUr || "",
      gaEn: integ.gaMeasurementIdEn || "",
      gaLegacy: integ.gaMeasurementId || "",
      gtm: integ.gtmContainerId || "",
      domainUr: seo.ownerDomainUr || SITE_UR,
      domainEn: seo.ownerDomainEn || SITE_EN,
      index: seo.indexHomepage || "on",
      perf: seo.performanceNote || "",
    };
    setGscUr(snap.gscUr);
    setGscEn(snap.gscEn);
    setGscLegacy(snap.gscLegacy);
    setGaUr(snap.gaUr);
    setGaEn(snap.gaEn);
    setGaLegacy(snap.gaLegacy);
    setGtmInput(snap.gtm);
    setDomainUr(snap.domainUr);
    setDomainEn(snap.domainEn);
    setIndexHomepage(snap.index);
    setPerformanceNote(snap.perf);
    setSaved(snap);
    return snap;
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const settingsData = await adminFetch<{
        settings?: Record<string, Record<string, string>>;
      }>("/api/settings");
      applyFromSettings(settingsData?.settings);
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Load failed");
    } finally {
      setLoading(false);
    }
  }, [applyFromSettings]);

  useEffect(() => {
    void load();
  }, [load]);

  async function doSave() {
    if (busy) return;
    setBusy(true);
    setNotice(null);
    setError(null);
    try {
      const codeUr = extractVerificationCode(gscUr);
      const codeEn = extractVerificationCode(gscEn);
      const codeLegacy = extractVerificationCode(gscLegacy);
      const ur = domainUr.trim() || SITE_UR;
      const en = domainEn.trim() || SITE_EN;
      const index = indexHomepage.trim() || "on";
      const perf = performanceNote.trim();

      const data = await adminFetch<{
        settings?: Record<string, Record<string, string>>;
        saved?: number;
      }>("/api/settings", {
        method: "PUT",
        body: JSON.stringify({
          allowClear: true,
          settings: [
            { group: "integrations", key: "searchConsoleVerificationUr", value: codeUr },
            { group: "integrations", key: "searchConsoleVerificationEn", value: codeEn },
            { group: "integrations", key: "searchConsoleVerification", value: codeLegacy },
            { group: "integrations", key: "gaMeasurementIdUr", value: gaUr.trim() },
            { group: "integrations", key: "gaMeasurementIdEn", value: gaEn.trim() },
            { group: "integrations", key: "gaMeasurementId", value: gaLegacy.trim() },
            { group: "integrations", key: "gtmContainerId", value: gtmInput.trim() },
            { group: "seo", key: "ownerDomainUr", value: ur },
            { group: "seo", key: "ownerDomainEn", value: en },
            { group: "seo", key: "ownerDomain", value: en || ur || SITE_FALLBACK },
            { group: "seo", key: "indexHomepage", value: index },
            { group: "seo", key: "performanceNote", value: perf },
          ],
        }),
      });

      const snap = applyFromSettings(data?.settings);
      const verify = await adminFetch<{
        settings?: Record<string, Record<string, string>>;
      }>("/api/settings");
      const verified = applyFromSettings(verify?.settings);

      setNotice(
        `✓ محفوظ — اردو GSC: ${verified?.gscUr ? "ہے" : "خالی"} · انگلش GSC: ${verified?.gscEn ? "ہے" : "خالی"} · Domains: ${verified?.domainUr || "—"} / ${verified?.domainEn || "—"}`,
      );
      setSaved(verified || snap);
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : "Save failed — دوبارہ لاگ اِن کریں");
    } finally {
      setBusy(false);
    }
  }

  if (loading) {
    return <p className="text-sm text-slate-500">Loading settings…</p>;
  }

  return (
    <div className="space-y-6">
      <AdminPageHeader
        title="Search Console · اردو + English الگ"
        description="اردو ڈومین اور انگلش ڈومین الگ Search Console پراپرٹیز — نیچے الگ کوڈ اور ڈومین لکھیں، پھر SAVE۔"
      />

      {error ? (
        <div className="rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          {error}
        </div>
      ) : null}
      {notice ? (
        <div className="rounded-md border border-emerald-300 bg-emerald-50 px-4 py-3 text-base font-semibold text-emerald-900">
          {notice}
        </div>
      ) : null}

      <AdminPanel title="① اردو Search Console property">
        <p className="mb-3 text-sm text-slate-600" dir="rtl">
          صرف اردو سائٹ — Google Search Console میں الگ پراپرٹی بنائیں اور verification یہاں پیسٹ کریں۔
        </p>
        <label className="mb-3 block text-sm">
          <span className="mb-1 block font-medium text-slate-700">Urdu domain</span>
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            dir="ltr"
            value={domainUr}
            onChange={(e) => setDomainUr(e.target.value)}
            placeholder={SITE_UR}
          />
        </label>
        <label className="mb-3 block text-sm">
          <span className="mb-1 block font-medium text-slate-700">Urdu GSC verification code</span>
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            dir="ltr"
            value={gscUr}
            onChange={(e) => setGscUr(e.target.value)}
            placeholder="Google verification code یا پورا meta tag (اردو)"
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1 block font-medium text-slate-700">GA4 — Urdu (optional)</span>
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            dir="ltr"
            value={gaUr}
            onChange={(e) => setGaUr(e.target.value)}
            placeholder="G-XXXXXXXXXX"
          />
        </label>
      </AdminPanel>

      <AdminPanel title="② English Search Console property">
        <p className="mb-3 text-sm text-slate-600">
          English site only — separate GSC property for www. Paste its verification code here.
        </p>
        <label className="mb-3 block text-sm">
          <span className="mb-1 block font-medium text-slate-700">English domain</span>
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            dir="ltr"
            value={domainEn}
            onChange={(e) => setDomainEn(e.target.value)}
            placeholder={SITE_EN}
          />
        </label>
        <label className="mb-3 block text-sm">
          <span className="mb-1 block font-medium text-slate-700">English GSC verification code</span>
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            dir="ltr"
            value={gscEn}
            onChange={(e) => setGscEn(e.target.value)}
            placeholder="Google verification code or full meta tag (English)"
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1 block font-medium text-slate-700">GA4 — English (optional)</span>
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            dir="ltr"
            value={gaEn}
            onChange={(e) => setGaEn(e.target.value)}
            placeholder="G-XXXXXXXXXX"
          />
        </label>
      </AdminPanel>

      <AdminPanel title="③ Shared / fallback + Index">
        <div className="grid gap-3 md:grid-cols-2">
          <label className="block text-sm">
            <span className="mb-1 block font-medium text-slate-700">Legacy GSC (fallback)</span>
            <input
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
              dir="ltr"
              value={gscLegacy}
              onChange={(e) => setGscLegacy(e.target.value)}
              placeholder="Used only if EN/UR codes empty"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1 block font-medium text-slate-700">Legacy GA4 (fallback)</span>
            <input
              className="w-full rounded-md border border-slate-300 px-3 py-2"
              dir="ltr"
              value={gaLegacy}
              onChange={(e) => setGaLegacy(e.target.value)}
              placeholder="G-XXXXXXXXXX"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1 block font-medium text-slate-700">GTM (optional)</span>
            <input
              className="w-full rounded-md border border-slate-300 px-3 py-2"
              dir="ltr"
              value={gtmInput}
              onChange={(e) => setGtmInput(e.target.value)}
              placeholder="GTM-XXXXXXX"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1 block font-medium text-slate-700">Index homepage (on/off)</span>
            <input
              className="w-full rounded-md border border-slate-300 px-3 py-2"
              dir="ltr"
              value={indexHomepage}
              onChange={(e) => setIndexHomepage(e.target.value)}
              placeholder="on"
            />
          </label>
        </div>
        <label className="mt-3 block text-sm">
          <span className="mb-1 block font-medium text-slate-700">Performance note</span>
          <textarea
            className="min-h-[80px] w-full rounded-md border border-slate-300 px-3 py-2"
            value={performanceNote}
            onChange={(e) => setPerformanceNote(e.target.value)}
            placeholder="Vercel Speed Insights active"
          />
        </label>
      </AdminPanel>

      <button
        type="button"
        disabled={busy}
        onClick={() => void doSave()}
        className="w-full rounded-xl bg-[#1DB954] px-6 py-4 text-lg font-bold text-white shadow hover:bg-[#159A45] disabled:opacity-60 sm:w-auto"
      >
        {busy ? "Saving… محفوظ ہو رہا ہے" : "SAVE — اردو + انگلش محفوظ کریں"}
      </button>

      {saved ? (
        <AdminPanel title="Database میں اب یہ محفوظ ہے">
          <ul className="space-y-1 font-mono text-xs text-slate-700" dir="ltr">
            <li>GSC Urdu: {saved.gscUr || "— empty —"}</li>
            <li>GSC English: {saved.gscEn || "— empty —"}</li>
            <li>Domain Urdu: {saved.domainUr || "—"}</li>
            <li>Domain English: {saved.domainEn || "—"}</li>
            <li>GA Urdu: {saved.gaUr || "—"}</li>
            <li>GA English: {saved.gaEn || "—"}</li>
            <li>GTM: {saved.gtm || "—"}</li>
            <li>Index: {saved.index || "—"}</li>
          </ul>
          <button
            type="button"
            className="mt-3 text-sm font-semibold text-[#1DB954] underline"
            onClick={() => void load()}
          >
            Refresh from DB
          </button>
        </AdminPanel>
      ) : null}

      <p className="text-sm text-slate-600" dir="rtl">
        Sitemaps:{" "}
        <a className="text-[#1DB954] underline" href={`${SITE_UR}/sitemap.xml`} target="_blank" rel="noreferrer">
          اردو
        </a>
        {" · "}
        <a className="text-[#1DB954] underline" href={`${SITE_EN}/sitemap.xml`} target="_blank" rel="noreferrer">
          English
        </a>
        {" · "}
        <Link href="/admin" className="text-[#1DB954] underline">
          Dashboard
        </Link>
      </p>
    </div>
  );
}
