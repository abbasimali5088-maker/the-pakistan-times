import { headers } from "next/headers";
import { BreakingNewsBar } from "@/components/public/BreakingNewsBar";
import { Footer } from "@/components/public/Footer";
import { Header } from "@/components/public/Header";
import { PushOptIn } from "@/components/public/PushOptIn";
import { RatesBar } from "@/components/public/RatesBar";
import { getSettingMap } from "@/lib/content";
import { getBreaking, getCategories, getMenus, absoluteUrl } from "@/lib/public-api";
import { brandName } from "@/lib/language";
import { getRequestHostProfile, getRequestLang } from "@/lib/language-server";
import {
  defaultRatesMap,
  normalizeRatesMap,
  ratesToPublicItems,
  RATES_GROUP,
} from "@/lib/market-rates";
import type { BreakingItem, MenuPayload, PublicCategory } from "@/lib/public-types";
import { SOCIAL_LINK_KEYS, normalizeSettingsMap, isSettingOn, RATE_VISIBILITY_KEYS } from "@/lib/site-settings";

export const dynamic = "force-dynamic";

export default async function PublicLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const h = await headers();
  const headerLang = h.get("x-lang");
  const url = h.get("x-url") || h.get("referer") || "";
  let searchLang: string | undefined;
  try {
    if (url) searchLang = new URL(url).searchParams.get("lang") || undefined;
  } catch {
    searchLang = undefined;
  }
  const lang = await getRequestLang({
    lang: searchLang || headerLang || undefined,
  });
  const profile = await getRequestHostProfile();

  let menu: MenuPayload | null = null;
  let categories: PublicCategory[] = [];
  let breaking: BreakingItem[] = [];
  let rawSettings: Record<string, Record<string, string>> = {};

  try {
    [menu, categories, breaking, rawSettings] = await Promise.all([
      getMenus("main"),
      getCategories({ language: lang }),
      getBreaking(lang),
      getSettingMap(),
    ]);
  } catch {
    menu = null;
    categories = [];
    breaking = [];
    rawSettings = {};
  }

  const settings = normalizeSettingsMap(rawSettings);

  const showRatesBar = isSettingOn(settings.theme?.showRatesBar, true);
  const showBreakingBar = isSettingOn(settings.theme?.showBreakingBar, true);
  const showBreakingLocale =
    lang === "ur"
      ? isSettingOn(settings.features?.showBreakingUr, true)
      : isSettingOn(settings.features?.showBreakingEn, true);

  const rateMap = normalizeRatesMap({
    ...defaultRatesMap(),
    ...(rawSettings[RATES_GROUP] || {}),
  });

  const enabledRateKeys = new Set<string>(
    RATE_VISIBILITY_KEYS.filter((r) => isSettingOn(settings.theme?.[r.key], true)).map(
      (r) => r.rateKey,
    ),
  );
  // Stored rates only — live sync is cron / Admin → Rates (avoids DB pool crashes)
  const rateItems = showRatesBar
    ? ratesToPublicItems(rateMap).filter((item) => enabledRateKeys.has(item.key))
    : [];

  const social: Record<string, string> = {};
  for (const key of SOCIAL_LINK_KEYS) {
    const val = settings.social?.[key]?.trim();
    if (val) social[key] = val;
  }

  const topCategories = (categories || []).filter((c) => {
    const parentId = (c as { parentId?: string | null }).parentId;
    return !parentId;
  });

  const accent = settings.theme?.accentColor?.trim();
  const customCss = settings.theme?.customCss?.trim();
  // Keep deep/soft/masthead in sync when Settings override --accent
  const accentStyle = accent
    ? ({
        ["--accent" as string]: accent,
        ["--masthead-red" as string]: accent,
      } as React.CSSProperties)
    : undefined;

  return (
    <div className="site-shell" style={accentStyle}>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "NewsMediaOrganization",
            name: brandName(lang),
            url: absoluteUrl("/"),
            logo: absoluteUrl("/icon-512.png"),
          }),
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebSite",
            name: brandName(lang),
            url: absoluteUrl("/"),
            potentialAction: {
              "@type": "SearchAction",
              target: `${absoluteUrl("/search")}?q={search_term_string}`,
              "query-input": "required name=search_term_string",
            },
          }),
        }}
      />
      {customCss ? <style dangerouslySetInnerHTML={{ __html: customCss }} /> : null}
      <Header
        lang={lang}
        menuItems={menu?.items || []}
        categories={topCategories}
        taglineUr={settings.general?.taglineUr}
        taglineEn={settings.general?.taglineEn}
        social={social}
        langLocked={profile.locked}
        alternateUrl={profile.alternate?.siteUrl || null}
        alternateLabel={profile.alternate?.label || null}
      />
      {showRatesBar ? (
        <RatesBar
          lang={lang}
          items={rateItems}
          updatedLabel={rateMap.updatedLabel}
          updatedLabelUr={rateMap.updatedLabelUr}
        />
      ) : null}
      {showBreakingBar && showBreakingLocale ? (
        <BreakingNewsBar lang={lang} items={breaking || []} />
      ) : null}
      <main className="site-main">{children}</main>
      <Footer
        lang={lang}
        site={{
          aboutUr: settings.footer?.aboutUr,
          aboutEn: settings.footer?.aboutEn,
          copyrightUr: settings.footer?.copyrightUr,
          copyrightEn: settings.footer?.copyrightEn,
          contactEmail: settings.general?.contactEmail,
          contactPhone: settings.general?.contactPhone,
          social,
        }}
      />
      <PushOptIn lang={lang} />
    </div>
  );
}
