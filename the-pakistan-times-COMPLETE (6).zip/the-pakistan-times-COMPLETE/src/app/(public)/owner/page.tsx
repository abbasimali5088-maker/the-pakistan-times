import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";

export const metadata: Metadata = {
  title: "Owner",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

/**
 * Former public owner hub leaked launcher/admin passwords.
 * Now requires an authenticated admin session — no secrets on this page.
 */
export default async function OwnerHubPage() {
  const user = await getSessionUser();
  if (!user) {
    redirect("/admin/login?next=/admin");
  }
  redirect("/admin");
}
