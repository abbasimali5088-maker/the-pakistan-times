import type { Metadata } from "next";
import { AdSlot } from "@/components/public/AdSlot";
import { CategorySection } from "@/components/public/CategorySection";
import { EmptyState } from "@/components/public/EmptyState";
import { FeaturedStory } from "@/components/public/FeaturedStory";
import { GalleryCard } from "@/components/public/GalleryCard";
import { LiveStreamBlock } from "@/components/public/LiveStreamBlock";
import { MostRead } from "@/components/public/MostRead";
import { PollWidget } from "@/components/public/PollWidget";
import { QuizWidget } from "@/components/public/QuizWidget";
import { SocialMediaGrid } from "@/components/public/SocialMediaGrid";
import { VideoCard } from "@/components/public/VideoCard";
import { WhatsAppPromo } from "@/components/public/WhatsAppPromo";
import { getSettingMap } from "@/lib/content";
import { brandName, pickText } from "@/lib/language";
import { getRequestLang } from "@/lib/language-server";
import {
  getActivePoll,
  getArticles,
  getCategories,
  getGalleries,
  getHomepage,
  getLiveFeed,
  getPublishedQuiz,
  getVideos,
} from "@/lib/public-api";
import type { PublicArticle } from "@/lib/public-types";
import { isSettingOn, normalizeSettingsMap, SOCIAL_LINK_KEYS } from "@/lib/site-settings";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const lang = await getRequestLang();
  const brand = brandName(lang);
  const settings = normalizeSettingsMap(await getSettingMap().catch(() => ({})));
  const title =
    pickText(lang, settings.headings?.h1HomeUr, settings.headings?.h1HomeEn, "") || brand;
  const description =
    pickText(
      lang,
      settings.seo?.defaultDescriptionUr || settings.seo?.defaultDescription,
      settings.seo?.defaultDescriptionEn || settings.seo?.defaultDescription,
      "",
    ) ||
    (lang === "ur"
      ? "پاکستان اور دنیا کی تازہ ترین خبریں، تجزیے اور لائیو کوریج"
      : "Latest news, analysis and live coverage from Pakistan and the world");
  return {
    title: { absolute: title },
    description,
    alternates: { canonical: "/" },
    openGraph: {
      title,
      description,
      url: "/",
      type: "website",
    },
  };
}

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ lang?: string }>;
}) {
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const settings = normalizeSettingsMap(await getSettingMap().catch(() => ({})));

  const showCategories = isSettingOn(settings.features?.showCategorySections, true);
  const showVideos = isSettingOn(settings.features?.showVideos, true);
  const showGalleries = isSettingOn(settings.features?.showGalleries, true);
  const showMostRead = isSettingOn(settings.features?.showMostRead, true);
  const showAds = isSettingOn(settings.features?.showAds, true);
  const showPolls = isSettingOn(settings.features?.showPolls, true);
  const showQuizzes = isSettingOn(settings.features?.showQuizzes, true);

  const [homepage, latest, categories, videos, galleries, liveArticles, activePoll, publishedQuiz] =
    await Promise.all([
      getHomepage({ language: lang }),
      getArticles({ page: 1, pageSize: 48, language: lang }),
      getCategories({ language: lang }),
      showVideos
        ? getVideos({ page: 1 })
        : Promise.resolve({ items: [] as Awaited<ReturnType<typeof getVideos>>["items"] }),
      showGalleries
        ? getGalleries({ page: 1 })
        : Promise.resolve({ items: [] as Awaited<ReturnType<typeof getGalleries>>["items"] }),
      getLiveFeed({ language: lang, take: 6 }),
      showPolls ? getActivePoll() : Promise.resolve(null),
      showQuizzes ? getPublishedQuiz() : Promise.resolve(null),
    ]);

  const blocks = homepage.blocks || [];
  const topFromBlocks = blocks
    .filter((b) => b.sectionKey === "top_story" && b.article)
    .map((b) => b.article!) as PublicArticle[];
  const secondaryFromBlocks = blocks
    .filter((b) => b.sectionKey === "secondary" && b.article)
    .map((b) => b.article!) as PublicArticle[];

  const nonLive = latest.items.filter((a) => a.priority !== "live");
  // Hide QA/e2e fixtures from the public lead so real imported news can surface.
  const isFixtureSlug = (slug: string) =>
    /^(e2e-|audit-|prod-en-verify|prod-ur-verify|live-probe|editor-payload|with-category-)/i.test(
      slug || "",
    );
  const publicNews = nonLive.filter((a) => !isFixtureSlug(a.slug));
  const leadPool = publicNews.length > 0 ? publicNews : nonLive;

  const featured =
    topFromBlocks.find((a) => a.priority !== "live" && a.language === lang) ||
    leadPool.find((a) => a.isFeatured) ||
    leadPool[0] ||
    null;
  const sideStories =
    secondaryFromBlocks.filter((a) => a.language === lang && a.id !== featured?.id).length > 0
      ? secondaryFromBlocks.filter((a) => a.language === lang && a.id !== featured?.id).slice(0, 5)
      : leadPool.filter((a) => a.id !== featured?.id).slice(0, 5);

  const featuredId = featured?.id;
  const latestRail = leadPool.filter((a) => a.id !== featuredId).slice(0, 5);

  const topCategories = showCategories
    ? categories.filter((c) => !(c as { parentId?: string | null }).parentId).slice(0, 6)
    : [];

  const categorySections = (
    await Promise.all(
      topCategories.map(async (cat) => {
        const articles = await getArticles({ category: cat.slug, pageSize: 8, language: lang });
        // Keep category rails filled — only skip the single featured lead, not every used id.
        const items = articles.items
          .filter((a) => a.id !== featuredId && a.priority !== "live")
          .slice(0, 5);
        return {
          category: cat,
          articles: items,
          title: lang === "ur" ? cat.nameUr || cat.name : cat.nameEn || cat.name,
        };
      }),
    )
  ).filter((s) => s.articles.length > 0);

  const mostRead = [...leadPool]
    .sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0))
    .slice(0, 6);

  const hasContent =
    liveArticles.length > 0 ||
    featured ||
    latestRail.length > 0 ||
    categorySections.some((s) => s.articles.length) ||
    videos.items.length ||
    galleries.items.length;

  const latestHeading =
    pickText(lang, settings.headings?.h2LatestUr, settings.headings?.h2LatestEn, "") ||
    (lang === "ur" ? "تازہ ترین" : "Latest");

  const videosHeading =
    pickText(lang, settings.headings?.h2VideosUr, settings.headings?.h2VideosEn, "") ||
    (lang === "ur" ? "ویڈیوز" : "Videos");
  const galleriesHeading =
    pickText(lang, settings.headings?.h2GalleriesUr, settings.headings?.h2GalleriesEn, "") ||
    (lang === "ur" ? "تصویری گیلریز" : "Galleries");
  const mostReadHeading =
    pickText(lang, settings.headings?.h2MostReadUr, settings.headings?.h2MostReadEn, "") ||
    (lang === "ur" ? "سب سے زیادہ پڑھی گئیں" : "Most read");

  const social: Record<string, string> = {};
  for (const key of SOCIAL_LINK_KEYS) {
    const val = settings.social?.[key]?.trim();
    if (val) social[key] = val;
  }

  return (
    <div>
      {/* BBC: LIVE stories at the top of the written news stream */}
      <LiveStreamBlock articles={liveArticles} lang={lang} />

      {showAds ? <AdSlot unitKey="homepage_top" lang={lang} /> : null}

      <FeaturedStory article={featured} sideStories={sideStories.slice(0, 5)} lang={lang} />

      {!hasContent ? <EmptyState lang={lang} /> : null}

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(240px,300px)] lg:gap-10">
        <div className="min-w-0">
          {/* Always show a Latest rail so uncategorized imports (e.g. Blogger EN) are visible */}
          {latestRail.length > 0 ? (
            <CategorySection
              title={latestHeading}
              href="/latest"
              articles={latestRail}
              lang={lang}
            />
          ) : null}

          {categorySections.map(({ category, articles, title }, idx) => (
            <div key={category.id}>
              <CategorySection
                title={title}
                href={`/category/${category.slug}`}
                articles={articles}
                lang={lang}
              />
              {idx === 0 ? <WhatsAppPromo lang={lang} href={social.whatsapp} /> : null}
              {idx === 0 && showAds ? (
                <AdSlot unitKey="homepage_mid" lang={lang} fallbackUnitKeys={["homepage_top"]} />
              ) : null}
            </div>
          ))}

          {categorySections.length === 0 ? (
            <WhatsAppPromo lang={lang} href={social.whatsapp} />
          ) : null}

          {showVideos && videos.items.length > 0 ? (
            <section className="mb-12 fade-in">
              <h2 className="section-title">{videosHeading}</h2>
              <div className="grid gap-6 sm:grid-cols-2">
                {videos.items.slice(0, 2).map((v) => (
                  <VideoCard key={v.id} video={v} lang={lang} />
                ))}
              </div>
            </section>
          ) : null}

          {showGalleries && galleries.items.length > 0 ? (
            <section className="mb-8 fade-in">
              <h2 className="section-title">{galleriesHeading}</h2>
              <div className="grid gap-6 sm:grid-cols-2">
                {galleries.items.slice(0, 2).map((g) => (
                  <GalleryCard key={g.id} gallery={g} lang={lang} />
                ))}
              </div>
            </section>
          ) : null}

          <SocialMediaGrid lang={lang} social={social} />
        </div>

        <aside className="min-w-0 space-y-6">
          {showAds ? <AdSlot unitKey="homepage_sidebar" lang={lang} /> : null}
          {showMostRead ? (
            <MostRead articles={mostRead} lang={lang} heading={mostReadHeading} />
          ) : null}
          {showPolls && activePoll ? <PollWidget poll={activePoll} lang={lang} /> : null}
          {showQuizzes && publishedQuiz ? <QuizWidget quiz={publishedQuiz} lang={lang} /> : null}
        </aside>
      </div>
    </div>
  );
}
