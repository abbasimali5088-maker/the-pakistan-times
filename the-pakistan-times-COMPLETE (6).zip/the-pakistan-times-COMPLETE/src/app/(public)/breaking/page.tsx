import type { Metadata } from "next";
import Link from "next/link";
import { EmptyState } from "@/components/public/EmptyState";
import { getSettingMap } from "@/lib/content";
import { pickText } from "@/lib/language";
import { getRequestLang } from "@/lib/language-server";
import { getArticles, getBreaking } from "@/lib/public-api";
import { normalizeSettingsMap } from "@/lib/site-settings";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  searchParams,
}: {
  searchParams: Promise<{ lang?: string }>;
}): Promise<Metadata> {
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const settings = normalizeSettingsMap(await getSettingMap().catch(() => ({})));
  const title =
    pickText(lang, settings.headings?.h2BreakingUr, settings.headings?.h2BreakingEn, "") ||
    (lang === "ur" ? "بریکنگ نیوز" : "Breaking news");
  return { title, description: title };
}

export default async function BreakingPage({
  searchParams,
}: {
  searchParams: Promise<{ lang?: string }>;
}) {
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const settings = normalizeSettingsMap(await getSettingMap().catch(() => ({})));
  const heading =
    pickText(lang, settings.headings?.h2BreakingUr, settings.headings?.h2BreakingEn, "") ||
    (lang === "ur" ? "بریکنگ نیوز" : "Breaking news");

  let items = await getBreaking(lang);

  if (!items.length) {
    const articles = await getArticles({ language: lang, pageSize: 20 });
    items = articles.items
      .filter((a) => a.isBreaking || a.priority === "breaking")
      .map((a) => ({
        id: a.id,
        headline: a.titleEn || a.title,
        headlineUr: a.titleUr || null,
        headlineEn: a.titleEn || a.title,
        href: `/${a.slug}`,
        article: a,
      }));
  }

  const visible = items.filter((item) => {
    if (lang === "ur") return Boolean((item.headlineUr || "").trim());
    return Boolean((item.headlineEn || item.headline || "").trim()) && !(item.headlineUr || "").trim();
  });

  return (
    <div>
      <h1 className="section-title">{heading}</h1>
      {visible.length === 0 ? (
        <EmptyState lang={lang} />
      ) : (
        <ul className="divide-y divide-[var(--line)] border border-[var(--line)] bg-[var(--surface)]">
          {visible.map((item) => {
            const text = pickText(lang, item.headlineUr, item.headlineEn || item.headline, "");
            const href = item.href || (item.article?.slug ? `/${item.article.slug}` : "/breaking");
            return (
              <li key={item.id}>
                <Link
                  href={href}
                  className="block px-4 py-4 text-lg hover:bg-[var(--accent-soft)] hover:text-[var(--accent-deep)]"
                >
                  {text}
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
