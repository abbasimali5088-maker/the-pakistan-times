import Link from "next/link";
import { EmptyState } from "@/components/public/EmptyState";
import { LiveStreamBlock } from "@/components/public/LiveStreamBlock";
import { getSettingMap } from "@/lib/content";
import { englishOnly, pickText, urduOnly } from "@/lib/language";
import { getRequestLang } from "@/lib/language-server";
import { getLiveFeed, getLiveStories } from "@/lib/public-api";
import { isSettingOn, normalizeSettingsMap } from "@/lib/site-settings";

export const dynamic = "force-dynamic";

export default async function LiveIndexPage({
  searchParams,
}: {
  searchParams: Promise<{ lang?: string }>;
}) {
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const settings = normalizeSettingsMap(await getSettingMap().catch(() => ({})));
  const enabled = isSettingOn(settings.features?.showLive, true);

  // Primary: articles marked Live for THIS language only (never mix EN/UR).
  const liveArticles = enabled ? await getLiveFeed({ language: lang, take: 30 }) : [];

  // Secondary: legacy LiveStory rows — language-filtered (no DB language column).
  const stories =
    enabled && liveArticles.length === 0
      ? await getLiveStories({ language: lang })
      : [];

  const heading =
    pickText(lang, settings.headings?.h2LiveUr, settings.headings?.h2LiveEn, "") ||
    (lang === "ur" ? "لائیو" : "Live");

  return (
    <div>
      <h1 className="section-title">{heading}</h1>
      {!enabled ? (
        <EmptyState lang={lang} />
      ) : liveArticles.length > 0 ? (
        <LiveStreamBlock articles={liveArticles} lang={lang} />
      ) : stories.length === 0 ? (
        <EmptyState lang={lang} />
      ) : (
        <div className="grid gap-4">
          {stories.map((story) => {
            const title = pickText(
              lang,
              urduOnly(story.titleUr),
              englishOnly(story.titleEn || story.title),
              "",
            );
            const description = pickText(
              lang,
              urduOnly(story.descriptionUr),
              englishOnly(story.description),
              "",
            );
            if (!title.trim()) return null;
            return (
              <Link
                key={story.id}
                href={`/live/${story.slug}`}
                className="block border border-[var(--line)] bg-[var(--surface)] p-5 hover:border-[var(--accent)]"
              >
                <div className="mb-2 flex items-center gap-2">
                  <span className="ui-sans inline-flex items-center gap-1 text-xs font-bold uppercase text-[var(--accent-deep)]">
                    <span className="h-2 w-2 animate-pulse rounded-full bg-[var(--accent)]" />
                    {lang === "ur" ? "لائیو" : "Live"}
                  </span>
                </div>
                <h2 className="text-2xl text-[var(--ink)]">{title}</h2>
                {description ? <p className="mt-2 text-[var(--muted)]">{description}</p> : null}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
