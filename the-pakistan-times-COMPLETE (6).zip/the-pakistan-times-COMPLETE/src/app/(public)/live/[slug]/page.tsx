import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { EmptyState } from "@/components/public/EmptyState";
import { pickText } from "@/lib/language";
import { getRequestLang } from "@/lib/language-server";
import { getLiveStory } from "@/lib/public-api";
import { formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ lang?: string }>;
};

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { slug } = await params;
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const story = await getLiveStory(slug, { language: lang });
  const title = pickText(lang, story?.titleUr, story?.titleEn || story?.title, "") || "Live";
  return { title };
}

export default async function LiveStoryPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const story = await getLiveStory(slug, { language: lang });
  if (!story) notFound();

  const locale = lang === "ur" ? "ur-PK" : "en-GB";
  const title = pickText(lang, story.titleUr, story.titleEn || story.title, "");
  const description = pickText(lang, story.descriptionUr, story.description, "");
  const updates = (story.updates || []).filter((u) =>
    Boolean(pickText(lang, u.bodyUr, u.body, "").trim()),
  );

  return (
    <div className="mx-auto max-w-3xl">
      <p className="ui-sans mb-2 inline-flex items-center gap-2 text-xs font-bold uppercase text-[var(--accent-deep)]">
        <span className="h-2 w-2 animate-pulse rounded-full bg-[var(--accent)]" />
        Live
      </p>
      <h1 className="mb-3 text-3xl sm:text-4xl">{title}</h1>
      {description ? <p className="mb-8 text-[var(--muted)]">{description}</p> : null}

      {updates.length === 0 ? (
        <EmptyState lang={lang} />
      ) : (
        <ol className="space-y-5 border-s-2 border-[var(--accent)] ps-5">
          {updates.map((update) => {
            const body = pickText(lang, update.bodyUr, update.body, "");
            const quote = pickText(lang, update.quoteUr, update.quote, "");
            return (
              <li key={update.id} className="relative">
                <span className="absolute -start-[1.6rem] top-1.5 h-3 w-3 rounded-full bg-[var(--accent)]" />
                <p className="meta mb-1">{formatDate(update.publishedAt, locale)}</p>
                <div className="border border-[var(--line)] bg-white/70 p-4">
                  {update.isImportant ? (
                    <p className="ui-sans mb-2 text-xs font-bold uppercase text-[var(--accent)]">
                      {lang === "ur" ? "اہم" : "Important"}
                    </p>
                  ) : null}
                  <p className="text-lg leading-relaxed">{body}</p>
                  {quote ? (
                    <blockquote className="mt-3 border-s-4 border-[var(--ink)] ps-3 italic text-[var(--muted)]">
                      {quote}
                    </blockquote>
                  ) : null}
                </div>
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}
