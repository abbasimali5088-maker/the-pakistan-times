import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { AuthorCard } from "@/components/public/AuthorCard";
import { EmptyState } from "@/components/public/EmptyState";
import { LoadMoreArticles } from "@/components/public/LoadMoreArticles";
import { getRequestLang } from "@/lib/language-server";
import { absoluteUrl, getArticles, getAuthor } from "@/lib/public-api";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ page?: string; lang?: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const author = await getAuthor(slug);
  return { title: author?.name || "Author" };
}

export default async function AuthorPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const page = Math.max(1, Number(sp.page || 1));
  const author = await getAuthor(slug);
  if (!author) notFound();

  const data = await getArticles({ language: lang, authorId: author.id, page, pageSize: 12 });

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: author.name,
    url: absoluteUrl(`/author/${slug}`),
    ...(author.photoUrl ? { image: author.photoUrl } : {}),
    ...(author.bio ? { description: author.bio } : {}),
    ...(author.position ? { jobTitle: author.position } : {}),
    sameAs: [author.website, author.twitter, author.facebook, author.linkedin].filter(
      (v): v is string => !!v,
    ),
  };

  return (
    <div>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <AuthorCard author={author} lang={lang} />
      <h2 className="section-title mt-8">
        {lang === "ur" ? "مضامین" : "Articles"}
      </h2>
      {data.items.length === 0 ? (
        <EmptyState lang={lang} />
      ) : (
        <LoadMoreArticles
          lang={lang}
          initialItems={data.items}
          initialPage={data.page || page}
          totalPages={data.totalPages || 1}
          authorId={author.id}
        />
      )}
    </div>
  );
}
