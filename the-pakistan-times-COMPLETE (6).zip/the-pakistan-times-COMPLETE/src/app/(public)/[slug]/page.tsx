import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArticleBody } from "@/components/public/ArticleBody";
import { ArticleCard } from "@/components/public/ArticleCard";
import { ArticleToolBlock } from "@/components/public/ArticleToolBlock";
import { ArticleVideo } from "@/components/public/ArticleVideo";
import { AdSlot } from "@/components/public/AdSlot";
import { ArticleViewTracker } from "@/components/public/ArticleViewTracker";
import { Comments } from "@/components/public/Comments";
import { CoverImage } from "@/components/public/CoverImage";
import { PollWidget } from "@/components/public/PollWidget";
import { QuizWidget } from "@/components/public/QuizWidget";
import { SocialMediaGrid } from "@/components/public/SocialMediaGrid";
import { TimeBadge } from "@/components/public/TimeBadge";
import { WhatsAppPromo } from "@/components/public/WhatsAppPromo";
import { getSettingMap } from "@/lib/content";
import { brandName, localizeArticle } from "@/lib/language";
import { getRequestHostProfile, getRequestLang } from "@/lib/language-server";
import {
  absoluteUrl,
  absoluteUrlAsync,
  getActivePoll,
  getArticle,
  getArticles,
  getPublishedQuiz,
} from "@/lib/public-api";
import { isSettingOn, normalizeSettingsMap } from "@/lib/site-settings";
import { englishSiteUrl, urduSiteUrl } from "@/lib/site-host";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ lang?: string; text?: string }>;
};

function parseRobots(raw?: string | null): Metadata["robots"] | undefined {
  if (!raw?.trim()) return undefined;
  const lower = raw.toLowerCase();
  return {
    index: !lower.includes("noindex"),
    follow: !lower.includes("nofollow"),
  };
}

function readingMinutes(html?: string | null, excerpt?: string | null) {
  const text = `${excerpt || ""} ${html || ""}`.replace(/<[^>]+>/g, " ");
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 180));
}

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { slug } = await params;
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const profile = await getRequestHostProfile();
  const article = await getArticle(slug, { language: lang });
  if (!article) return { title: "Not found" };
  const a = localizeArticle(article, lang);
  const title = a.displaySeoTitle || a.displayTitle;
  const description = a.displaySeoDescription || a.displayExcerpt || undefined;
  const base = await absoluteUrlAsync(`/${article.slug}`);
  const canonical = article.seo?.canonical || base;
  const ogImage = a.displayOgImage || undefined;

  const languages: Record<string, string> = {};
  // Only advertise hreflang for the language this article actually belongs to
  // (no invented cross-language pairings).
  if (article.language === "ur") {
    languages.ur = `${urduSiteUrl()}/${article.slug}`;
    languages["x-default"] = languages.ur;
  } else if (article.language === "en") {
    languages.en = `${englishSiteUrl()}/${article.slug}`;
    languages["x-default"] = languages.en;
  } else {
    languages[lang] = canonical;
    languages["x-default"] = canonical;
  }

  return {
    title,
    description,
    alternates: {
      canonical,
      languages: Object.keys(languages).length ? languages : undefined,
    },
    robots: parseRobots(article.seo?.robots),
    openGraph: {
      title: a.displayOgTitle || title,
      description: a.displayOgDescription || description,
      images: ogImage ? [ogImage] : undefined,
      type: "article",
      locale: profile.ogLocale,
      siteName: profile.brandName,
      url: canonical,
    },
    twitter: {
      card: ogImage ? "summary_large_image" : "summary",
      title: a.displayOgTitle || title,
      description: a.displayOgDescription || description,
      images: ogImage ? [ogImage] : undefined,
    },
  };
}

export default async function ArticlePage({ params, searchParams }: Props) {
  const { slug } = await params;
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const textOnly = sp.text === "1" || sp.text === "true";
  const article = await getArticle(slug, { language: lang });
  if (!article) notFound();

  const a = localizeArticle(article, lang);
  const url = await absoluteUrlAsync(`/${article.slug}`);
  const brand = brandName(lang);
  const settings = normalizeSettingsMap(await getSettingMap().catch(() => ({})));
  const showAds = isSettingOn(settings.features?.showAds, true);
  const showPolls = isSettingOn(settings.features?.showPolls, true);
  const showQuizzes = isSettingOn(settings.features?.showQuizzes, true);
  const [activePoll, publishedQuiz] = await Promise.all([
    showPolls ? getActivePoll() : Promise.resolve(null),
    showQuizzes ? getPublishedQuiz() : Promise.resolve(null),
  ]);
  const social: Record<string, string> = {};
  for (const [k, v] of Object.entries(settings.social || {})) {
    if (v?.trim()) social[k] = v.trim();
  }
  const mins = readingMinutes(a.displayBody, a.displayExcerpt);

  const related =
    article.relations?.map((r) => r.article).filter(Boolean) ||
    (
      await getArticles({
        category: a.displayCategorySlug || article.category?.slug,
        pageSize: 4,
        language: lang,
      })
    ).items.filter((x) => x.id !== article.id).slice(0, 3);

  const logoUrl = await absoluteUrlAsync("/icon-512.png");
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": article.seo?.schemaType || "NewsArticle",
    headline: a.displayTitle,
    datePublished: article.publishedAt,
    dateModified: article.updatedAt,
    description: a.displaySeoDescription || a.displayExcerpt,
    image: a.displayImage?.url ? [a.displayImage.url] : undefined,
    inLanguage: lang === "ur" ? "ur" : "en",
    author: article.author
      ? { "@type": "Person", name: article.author.name }
      : { "@type": "Organization", name: brand },
    publisher: {
      "@type": "NewsMediaOrganization",
      name: brand,
      logo: {
        "@type": "ImageObject",
        url: logoUrl,
      },
    },
    mainEntityOfPage: url,
  };

  const breadcrumbLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: brand, item: absoluteUrl("/") },
      ...(a.displayCategory && a.displayCategorySlug
        ? [
            {
              "@type": "ListItem",
              position: 2,
              name: a.displayCategory,
              item: absoluteUrl(`/category/${a.displayCategorySlug}`),
            },
          ]
        : []),
      {
        "@type": "ListItem",
        position: a.displayCategory ? 3 : 2,
        name: a.displayTitle,
        item: url,
      },
    ],
  };

  const textModeHref = textOnly ? `/${article.slug}` : `/${article.slug}?text=1`;

  return (
    <div className="fade-in mx-auto w-full max-w-3xl bg-[var(--paper)] px-0">
      <article
        className="article-reading w-full min-w-0 bg-[var(--paper)] text-[var(--ink)]"
      >
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbLd) }}
        />
        <ArticleViewTracker articleId={article.id} slug={article.slug} />

        {/* Theme-green top rule fused to relative-time badge (no gap) */}
        <div className="mb-4 border-t-[3px] border-[var(--accent)]">
          <TimeBadge
            value={article.publishedAt || article.publishAt}
            lang={lang}
            className="-mt-px"
          />
        </div>

        {article.priority === "live" ? (
          <p className="ui-sans mb-3 inline-flex items-center gap-2.5 text-sm font-black uppercase tracking-wide text-[var(--accent-deep)]">
            <span className="live-beacon live-beacon--lg" aria-hidden>
              <span className="live-beacon__ping" />
              <span className="live-beacon__dot" />
            </span>
            {lang === "ur" ? "لائیو کوریج" : "Live coverage"}
          </p>
        ) : null}

        <h1 className="mb-4 break-words text-[1.45rem] font-bold leading-[1.45] text-[#141414] sm:text-[1.65rem] sm:text-4xl">
          {a.displayTitle}
        </h1>

        {showAds ? <AdSlot unitKey="article_top" lang={lang} /> : null}

        {!textOnly && a.displayImage?.url ? (
          <figure className="mb-5">
            <div className="relative aspect-[16/9] overflow-hidden bg-[#f5f5f5]">
              <CoverImage
                src={a.displayImage.url}
                alt={a.displayImage.alt || a.displayTitle}
                fill
                priority
                className="object-cover"
                sizes="(max-width:768px) 100vw, 768px"
              />
            </div>
            {(a.displayImageCaption || a.displayImageCredit) && (
              <figcaption className="meta mt-2 border border-[#e8e8e8] bg-[#fafafa] px-3 py-2 text-[var(--muted)]">
                {[a.displayImageCaption, a.displayImageCredit].filter(Boolean).join(" — ")}
              </figcaption>
            )}
          </figure>
        ) : null}

        <div className="meta mb-6 space-y-1 border-b border-[#eee] pb-4">
          {article.author ? (
            <p>
              <Link
                href={`/author/${article.author.slug}`}
                className="font-bold text-[var(--ink)] hover:text-[var(--accent)]"
              >
                {article.author.name}
              </Link>
              <span className="ms-2 text-[var(--muted)]">{brand}</span>
            </p>
          ) : (
            <p className="font-semibold text-[var(--ink)]">{brand}</p>
          )}
          <p className="text-[var(--muted)]">
            {lang === "ur" ? `مطالعے کا وقت: ${mins} منٹ` : `${mins} min read`}
            <span className="mx-2">·</span>
            <Link
              href={textModeHref}
              className="ui-sans text-sm font-semibold text-[var(--accent)] underline underline-offset-2"
            >
              {textOnly
                ? lang === "ur"
                  ? "تصویر والا ورژن ›"
                  : "View with images ›"
                : lang === "ur"
                  ? "صرف تحریر ›"
                  : "Text only ›"}
            </Link>
          </p>
        </div>

        {!textOnly ? <ArticleVideo url={a.displayVideoUrl} title={a.displayTitle} /> : null}

        <ArticleBody
          lang={lang}
          html={a.displayBody}
          excerpt={a.displayExcerpt}
          textOnly={textOnly}
          featuredImageUrl={a.displayImage?.url}
        />

        {!textOnly ? (
          <ArticleToolBlock
            lang={lang}
            title={a.displayToolTitle}
            code={a.displayToolCode}
          />
        ) : null}

        {showAds ? <AdSlot unitKey="article_bottom" lang={lang} /> : null}
        {showPolls && activePoll ? <PollWidget poll={activePoll} lang={lang} /> : null}
        {showQuizzes && publishedQuiz ? <QuizWidget quiz={publishedQuiz} lang={lang} /> : null}

        {a.displayTags && a.displayTags.length > 0 ? (
          <div className="ui-sans mt-8 flex flex-wrap gap-2">
            {a.displayTags.map((tag) => (
              <Link
                key={tag.id}
                href={`/tag/${tag.slug}`}
                className="border border-[var(--line)] bg-[var(--surface)] px-3 py-1 text-sm hover:border-[var(--accent)]"
              >
                #{tag.nameUr && lang === "ur" ? tag.nameUr : tag.name}
              </Link>
            ))}
          </div>
        ) : null}

        {/* Share-this-story row removed — keep only WhatsApp subscribe CTA */}
        <WhatsAppPromo lang={lang} href={social.whatsapp} />
        <SocialMediaGrid lang={lang} social={social} />

        <Comments articleId={article.id} lang={lang} />

        {related.length > 0 ? (
          <section className="mt-12 border-t border-[var(--line)] pt-8">
            <h2 className="section-title">
              {lang === "ur" ? "مزید پڑھیں / متعلقہ خبریں" : "Read more / Related"}
            </h2>
            <div className="grid gap-5 sm:grid-cols-3">
              {related.slice(0, 3).map((item) => (
                <ArticleCard key={item.id} article={item} lang={lang} variant="small" />
              ))}
            </div>
          </section>
        ) : null}
      </article>
    </div>
  );
}
