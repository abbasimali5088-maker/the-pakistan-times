import type { Metadata } from "next";
import { EmptyState } from "@/components/public/EmptyState";
import { LiveStreamBlock } from "@/components/public/LiveStreamBlock";
import { LoadMoreArticles } from "@/components/public/LoadMoreArticles";
import { getRequestLang } from "@/lib/language-server";
import { getArticles, getLiveFeed } from "@/lib/public-api";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Latest news",
  description: "Latest headlines from The Pakistan Times",
};

export default async function LatestPage({
  searchParams,
}: {
  searchParams: Promise<{ page?: string; lang?: string }>;
}) {
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const page = Math.max(1, Number(sp.page || 1));
  const [data, liveArticles] = await Promise.all([
    getArticles({ page, pageSize: 12, language: lang }),
    page === 1 ? getLiveFeed({ language: lang, take: 6 }) : Promise.resolve([]),
  ]);

  const liveIds = new Set(liveArticles.map((a) => a.id));
  const items = data.items.filter((a) => !liveIds.has(a.id));

  return (
    <div>
      <h1 className="section-title">{lang === "ur" ? "تازہ ترین" : "Latest"}</h1>
      {page === 1 ? <LiveStreamBlock articles={liveArticles} lang={lang} /> : null}
      {items.length === 0 && liveArticles.length === 0 ? (
        <EmptyState lang={lang} />
      ) : (
        <>
          <LoadMoreArticles
            lang={lang}
            initialItems={items}
            initialPage={data.page || page}
            totalPages={data.totalPages || 1}
          />
        </>
      )}
    </div>
  );
}
