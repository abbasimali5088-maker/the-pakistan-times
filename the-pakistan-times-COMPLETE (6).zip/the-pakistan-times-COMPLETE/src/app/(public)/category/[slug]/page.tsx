import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { AdSlot } from "@/components/public/AdSlot";
import { EmptyState } from "@/components/public/EmptyState";
import { LoadMoreArticles } from "@/components/public/LoadMoreArticles";
import { getSettingMap } from "@/lib/content";
import { pickText } from "@/lib/language";
import { getRequestLang } from "@/lib/language-server";
import { absoluteUrl, getArticles, getCategory } from "@/lib/public-api";
import { isSettingOn, normalizeSettingsMap } from "@/lib/site-settings";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ page?: string; lang?: string }>;
};

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { slug } = await params;
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const cat = await getCategory(slug, lang);
  if (!cat) return { title: "Category" };
  return {
    title: pickText(lang, cat.nameUr, cat.nameEn || cat.name, ""),
  };
}

export default async function CategoryPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const sp = await searchParams;
  const lang = await getRequestLang(sp);
  const page = Math.max(1, Number(sp.page || 1));
  const category = await getCategory(slug, lang);
  if (!category) notFound();

  const settings = normalizeSettingsMap(await getSettingMap().catch(() => ({})));
  const showAds = isSettingOn(settings.features?.showAds, true);

  const data = await getArticles({ category: slug, language: lang, page, pageSize: 12 });
  const title = pickText(lang, category.nameUr, category.nameEn || category.name, "");

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: title,
    url: absoluteUrl(`/category/${slug}`),
    inLanguage: lang === "ur" ? "ur" : "en",
    isPartOf: { "@type": "WebSite", url: absoluteUrl("/") },
    mainEntity: {
      "@type": "ItemList",
      itemListElement: data.items.slice(0, 12).map((article, i) => ({
        "@type": "ListItem",
        position: i + 1,
        url: absoluteUrl(`/${article.slug}`),
        name: article.title,
      })),
    },
  };

  return (
    <div className="min-w-0">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <h1 className="section-title break-words">{title}</h1>
      {showAds ? <AdSlot unitKey="category_top" lang={lang} /> : null}
      {data.items.length === 0 ? (
        <EmptyState lang={lang} />
      ) : (
        <LoadMoreArticles
          lang={lang}
          initialItems={data.items}
          initialPage={data.page || page}
          totalPages={data.totalPages || 1}
          category={slug}
        />
      )}
    </div>
  );
}
