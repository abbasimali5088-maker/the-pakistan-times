import type { MetadataRoute } from "next";
import { headers } from "next/headers";
import { prisma } from "@/lib/db";
import { resolveHostProfile } from "@/lib/site-host";

export const dynamic = "force-dynamic";

async function siteUrl() {
  const h = await headers();
  const fromHeader = h.get("x-site-url");
  if (fromHeader) return fromHeader.replace(/\/$/, "");
  const host = h.get("x-site-host") || h.get("x-forwarded-host") || h.get("host");
  return resolveHostProfile(host).siteUrl;
}

const DEFAULT_DISALLOW = [
  "/admin/",
  "/api/",
  "/owner",
  "/open",
  "/download",
  "/file",
  "/backend",
  "/panel",
  "/system",
];

async function defaultRobots(): Promise<MetadataRoute.Robots> {
  const base = await siteUrl();
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: DEFAULT_DISALLOW,
    },
    sitemap: `${base}/sitemap.xml`,
  };
}

export default async function robots(): Promise<MetadataRoute.Robots> {
  try {
    const setting = await prisma.setting.findFirst({
      where: { group: "seo", key: "robots_txt" },
    });

    if (!setting?.value) return defaultRobots();

    const lines = setting.value.split("\n").map((l) => l.trim());
    const disallow: string[] = [];
    const allow: string[] = [];
    for (const line of lines) {
      const lower = line.toLowerCase();
      if (lower.startsWith("disallow:")) {
        const path = line.slice(line.indexOf(":") + 1).trim();
        if (path) disallow.push(path);
      } else if (lower.startsWith("allow:")) {
        const path = line.slice(line.indexOf(":") + 1).trim();
        if (path) allow.push(path);
      }
    }
    const base = await siteUrl();
    return {
      rules: {
        userAgent: "*",
        allow: allow.length ? allow : "/",
        disallow: disallow.length ? disallow : DEFAULT_DISALLOW,
      },
      sitemap: `${base}/sitemap.xml`,
    };
  } catch {
    return defaultRobots();
  }
}
