import type { Metadata, Viewport } from "next";
import { PwaRegister } from "@/components/app/PwaRegister";

export const metadata: Metadata = {
  title: { absolute: "ایپ فون پر — دی پاکستان ٹائمز" },
  description: "QR اسکین یا WhatsApp — فون پر ایپ انسٹال کریں",
  robots: { index: true, follow: true },
  appleWebApp: { capable: true, title: "Pakistan Times", statusBarStyle: "default" },
};

export const viewport: Viewport = {
  themeColor: "#1DB954",
  width: "device-width",
  initialScale: 1,
};

/** No news header / rates / footer — install page only */
export default function BareGetAppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-[#f3efe6]" dir="rtl">
      <PwaRegister />
      {children}
    </div>
  );
}
