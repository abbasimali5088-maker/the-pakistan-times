import Link from "next/link";

const SITE = "https://the-pakistan-times-live.vercel.app";
const APP_URL = `${SITE}/app`;
const WA = `https://wa.me/?text=${encodeURIComponent(`دی پاکستان ٹائمز ایپ:\n${APP_URL}`)}`;

export default function GetAppPage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-lg flex-col px-4 py-8">
      <header className="mb-6 text-center">
        <p className="text-sm font-bold text-[#1DB954]">دی پاکستان ٹائمز</p>
        <h1 className="mt-1 text-2xl font-black text-[#141414]">فون پر ایپ ایسے لگائیں</h1>
        <p className="mt-2 text-sm leading-7 text-[#5c5c5c]">
          لپ‌ٹاپ پر Install نہیں ہوتی۔ نیچے QR فون سے اسکین کرو — یا WhatsApp بھیجو۔
        </p>
      </header>

      <section className="rounded-3xl border-2 border-[#1DB954] bg-white p-5 text-center shadow-md">
        <p className="mb-3 text-base font-black text-[#1DB954]">① فون کا کیمرہ یہاں لگائیں</p>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/qr-app.png"
          alt="QR code"
          width={280}
          height={280}
          className="mx-auto rounded-2xl border border-[#d7d2c8] bg-white p-3"
        />
        <p className="mt-3 break-all font-mono text-[11px] text-[#141414]" dir="ltr">
          {APP_URL}
        </p>
      </section>

      <a
        href={WA}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-4 block rounded-2xl bg-[#25D366] px-4 py-4 text-center text-lg font-black text-white shadow"
      >
        ② WhatsApp سے اپنے فون پر بھیجیں
      </a>

      <section className="mt-5 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-[#d7d2c8]">
        <p className="mb-2 font-bold text-[#141414]">③ فون پر لنک کھلنے کے بعد:</p>
        <div className="space-y-3 text-sm leading-7 text-[#2a2a2a]">
          <p>
            <strong className="text-[#1DB954]">Android:</strong> Chrome → اوپر ⋮ →{" "}
            <strong>Install app</strong> یا Add to Home screen
          </p>
          <p>
            <strong className="text-[#1DB954]">iPhone:</strong> Safari → Share (□↑) →{" "}
            <strong>Add to Home Screen</strong>
          </p>
        </div>
      </section>

      <div className="mt-6 flex flex-col gap-2">
        <Link
          href="/app"
          className="rounded-2xl border-2 border-[#1DB954] bg-white px-4 py-3 text-center text-base font-bold text-[#1DB954]"
        >
          ایپ پہلے دیکھیں (بغیر انسٹال)
        </Link>
        <Link href="/" className="py-2 text-center text-sm font-semibold text-[#5c5c5c] underline">
          ← ویب سائٹ
        </Link>
      </div>
    </main>
  );
}
