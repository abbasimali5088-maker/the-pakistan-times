import { redirect } from "next/navigation";

/** Open Front+Backend in browser (works on mobile — no file download). */
export default function FilePage() {
  redirect("/open");
}
