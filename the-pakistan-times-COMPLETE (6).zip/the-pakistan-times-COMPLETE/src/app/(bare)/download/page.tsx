"use client";

import Link from "next/link";
import { useState, type CSSProperties } from "react";

const SITE = "https://the-pakistan-times-live.vercel.app";

type FileKey = "both" | "front" | "back" | "zip" | "complete";

const FILES: {
  key: FileKey;
  name: string;
  title: string;
  sub: string;
  bg: string;
}[] = [
  {
    key: "both",
    name: "PT-FRONT-BACKEND.html",
    title: "① دونوں — FRONT + BACKEND",
    sub: "موبائل + لیپ ٹاپ · فرنٹ اور بیک اینڈ ایک فائل",
    bg: "#1DB954",
  },
  {
    key: "front",
    name: "PT-FRONTEND.html",
    title: "② صرف FRONTEND",
    sub: "پبلک سائٹ",
    bg: "#159A45",
  },
  {
    key: "back",
    name: "PT-BACKEND.html",
    title: "③ صرف BACKEND",
    sub: "ایڈمن لاگ اِن — لازمی شامل",
    bg: "#111",
  },
  {
    key: "zip",
    name: "PT-FRONT-BACKEND-files.zip",
    title: "④ Front+Back ZIP (HTML فائلیں)",
    sub: "تیوں فائلیں ایک ZIP میں — Backend سمیت",
    bg: "#0a7a3a",
  },
  {
    key: "complete",
    name: "the-pakistan-times-COMPLETE.zip",
    title: "⑤ مکمل پروجیکٹ ZIP (Code)",
    sub: "Front + Back + Admin + تمام changes · ~10MB",
    bg: "#064e2a",
  },
];

/**
 * Mobile-safe: prefer navigating to the API URL (Content-Disposition
 * attachment). Blob download as secondary for desktop.
 */
async function saveFile(key: FileKey, filename: string) {
  const apiUrl = `/api/download-links?file=${key}`;
  // Direct navigation is the most reliable on mobile browsers
  const a = document.createElement("a");
  a.href = apiUrl;
  a.download = filename;
  a.rel = "noopener";
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  a.remove();

  // Also try blob save (desktop / some Android browsers)
  try {
    const res = await fetch(apiUrl, { cache: "no-store" });
    if (!res.ok) throw new Error("download failed");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a2 = document.createElement("a");
    a2.href = url;
    a2.download = filename;
    a2.rel = "noopener";
    document.body.appendChild(a2);
    a2.click();
    a2.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  } catch {
    // First <a> click already fired — enough for most phones
  }
}

export default function DownloadProjectPage() {
  const [busy, setBusy] = useState<FileKey | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  async function onDownload(key: FileKey, filename: string) {
    setBusy(key);
    setMsg(null);
    try {
      await saveFile(key, filename);
      setMsg(`${filename} ڈاؤن لوڈ شروع — Downloads / Files چیک کریں`);
    } catch {
      window.location.href = `/api/download-links?file=${key}`;
      setMsg("ڈاؤن لوڈ شروع… اگر نہ آئے تو Files ایپ دیکھیں");
    } finally {
      setBusy(null);
    }
  }

  return (
    <main
      dir="rtl"
      style={{
        minHeight: "100vh",
        display: "grid",
        placeItems: "center",
        padding: 24,
        background: "linear-gradient(160deg,rgba(29,185,84,.12),transparent 50%),#fff8f0",
        fontFamily: '"Segoe UI", Tahoma, sans-serif',
      }}
    >
      <div
        style={{
          width: "min(520px,100%)",
          background: "#fff",
          border: "2px solid #1DB954",
          borderRadius: 18,
          padding: "28px 22px",
          boxShadow: "0 14px 42px rgba(0,0,0,.08)",
          textAlign: "center",
        }}
      >
        <h1 style={{ margin: "0 0 8px", color: "#1db954", fontSize: "1.5rem" }}>
          Front + Backend فائلیں
        </h1>
        <p style={{ margin: "0 0 20px", color: "#555", lineHeight: 1.7 }}>
          بٹن دبائیں — فائل فون/لیپ ٹاپ پر محفوظ ہوگی
          <br />
          <strong style={{ color: "#0a7a3a" }}>Backend ہمیشہ شامل ہے</strong>
        </p>

        {msg ? (
          <p
            style={{
              margin: "0 0 14px",
              padding: "10px 12px",
              borderRadius: 10,
              background: "#e8f9ef",
              color: "#0f6b35",
              fontSize: 14,
              fontWeight: 700,
            }}
          >
            {msg}
          </p>
        ) : null}

        {FILES.map((f) => (
          <div key={f.key} style={{ marginBottom: 12 }}>
            <button
              type="button"
              disabled={busy !== null}
              onClick={() => void onDownload(f.key, f.name)}
              style={{
                ...btn(f.bg),
                border: 0,
                cursor: busy ? "wait" : "pointer",
                opacity: busy && busy !== f.key ? 0.55 : 1,
                WebkitTapHighlightColor: "transparent",
                marginBottom: 6,
              }}
            >
              {busy === f.key ? "ڈاؤن لوڈ ہو رہا ہے…" : f.title}
              <span style={sub}>{f.sub}</span>
            </button>
            {/* Direct link fallback — always works even if JS blob fails */}
            <a
              href={`/api/download-links?file=${f.key}`}
              download={f.name}
              style={{
                display: "block",
                fontSize: 12,
                color: "#0a7a3a",
                fontWeight: 700,
                textDecoration: "underline",
              }}
            >
              سیدھا لنک: {f.name}
            </a>
          </div>
        ))}

        <div
          style={{
            marginTop: 8,
            padding: "14px 12px",
            borderRadius: 12,
            background: "#f4f4f4",
            textAlign: "right",
            fontSize: 13,
            color: "#444",
            lineHeight: 1.75,
          }}
        >
          <strong style={{ color: "#1db954" }}>موبائل:</strong>
          <br />
          ① سبز بٹن ① — FRONT + BACKEND
          <br />
          ② یا بٹن ④ — ZIP (Front + Back دونوں)
          <br />
          ③ Downloads / Files میں فائل کھولیں
        </div>

        <p
          style={{
            margin: "18px 0 0",
            fontSize: 13,
            color: "#666",
            lineHeight: 1.7,
            wordBreak: "break-all",
            direction: "ltr",
            textAlign: "left",
          }}
        >
          Front: {SITE}/
          <br />
          Back: {SITE}/admin/login
          <br />
          Hub: {SITE}/open
          <br />
          API both: {SITE}/api/download-links?file=both
          <br />
          API zip: {SITE}/api/download-links?file=zip
          <br />
          API complete: {SITE}/api/download-links?file=complete
        </p>

        <p style={{ marginTop: 16 }}>
          <Link href="/open" style={{ color: "#1db954", fontWeight: 700 }}>
            /open — ابھی کھولیں
          </Link>
          {" · "}
          <Link href="/" style={{ color: "#1db954" }}>
            ← سائٹ
          </Link>
        </p>
      </div>
    </main>
  );
}

function btn(bg: string): CSSProperties {
  return {
    display: "block",
    width: "100%",
    boxSizing: "border-box",
    padding: "16px 18px",
    borderRadius: 14,
    background: bg,
    color: "#fff",
    fontWeight: 800,
    fontSize: "1.08rem",
    textDecoration: "none",
    marginBottom: 12,
    textAlign: "center",
  };
}

const sub: CSSProperties = {
  display: "block",
  fontSize: ".85rem",
  fontWeight: 600,
  marginTop: 6,
  opacity: 0.95,
};
