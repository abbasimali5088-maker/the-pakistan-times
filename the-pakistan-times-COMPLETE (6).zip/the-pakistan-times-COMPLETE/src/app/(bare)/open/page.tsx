"use client";

import Link from "next/link";
import { FormEvent, useEffect, useState, type CSSProperties } from "react";

const SITE = "https://the-pakistan-times-live.vercel.app";
const FRONT = `${SITE}/`;
const BACKEND = `${SITE}/admin/login`;
const BACKEND_ALT = `${SITE}/backend`;

/**
 * Mobile/Laptop Front + Backend hub.
 * Password verified server-side via /api/launcher/verify — never embedded in HTML.
 */
export default function OpenLauncherPage() {
  const [unlocked, setUnlocked] = useState(false);
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    try {
      if (sessionStorage.getItem("pt_ok") === "1") setUnlocked(true);
    } catch {
      /* ignore */
    }
  }, []);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    try {
      const res = await fetch("/api/launcher/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pw }),
      });
      const json = await res.json();
      if (!res.ok || json.success === false) {
        throw new Error(json.error || "fail");
      }
      try {
        sessionStorage.setItem("pt_ok", "1");
      } catch {
        /* ignore */
      }
      setUnlocked(true);
      setPw("");
    } catch {
      setErr("پاس ورڈ غلط ہے — یا launcher پاس ورڈ ابھی سیٹ نہیں (Admin → Settings)");
      setPw("");
    } finally {
      setBusy(false);
    }
  }

  const btnBase: CSSProperties = {
    display: "block",
    width: "100%",
    padding: 18,
    borderRadius: 14,
    fontWeight: 800,
    fontSize: "1.1rem",
    textDecoration: "none",
    color: "#fff",
    marginBottom: 12,
    textAlign: "center",
    boxSizing: "border-box",
    WebkitTapHighlightColor: "transparent",
  };

  return (
    <div
      dir="rtl"
      style={{
        margin: 0,
        minHeight: "100vh",
        display: "grid",
        placeItems: "center",
        padding: 24,
        background: "linear-gradient(160deg,rgba(11,122,59,.14),transparent 45%),#fff8f0",
        fontFamily: '"Segoe UI", Tahoma, sans-serif',
        color: "#1a1a1a",
      }}
    >
      <div
        style={{
          width: "min(480px,100%)",
          background: "#fff",
          border: "1px solid #e7e0d6",
          borderRadius: 18,
          padding: "28px 22px",
          textAlign: "center",
          boxShadow: "0 14px 42px rgba(0,0,0,.08)",
        }}
      >
        {!unlocked ? (
          <>
            <h1 style={{ margin: "0 0 8px", color: "#1db954", fontSize: "1.45rem" }}>
              Front + Backend
            </h1>
            <p style={{ color: "#555", lineHeight: 1.85, margin: "0 0 14px", fontSize: ".95rem" }}>
              پاس ورڈ لکھیں — پھر فرنٹ اور بیک اینڈ دونوں کھلیں گے۔
              <br />
              <span style={{ fontSize: ".85rem" }}>
                (Launcher پاس ورڈ Admin → Settings میں سیٹ کریں — ایڈمن پاس ورڈ الگ رکھیں)
              </span>
            </p>
            <p style={{ color: "#0f6b35", fontSize: ".9rem", minHeight: "1.2em", margin: "0 0 8px" }}>
              {err}
            </p>
            <form onSubmit={onSubmit}>
              <input
                type="password"
                value={pw}
                onChange={(e) => setPw(e.target.value)}
                inputMode="text"
                autoComplete="off"
                spellCheck={false}
                placeholder="Launcher password"
                dir="ltr"
                style={{
                  width: "100%",
                  padding: 14,
                  border: "1px solid #ddd",
                  borderRadius: 12,
                  fontSize: 16,
                  textAlign: "center",
                  margin: "0 0 10px",
                  boxSizing: "border-box",
                }}
              />
              <button
                type="submit"
                disabled={busy}
                style={{
                  ...btnBase,
                  background: "#1db954",
                  border: 0,
                  cursor: busy ? "wait" : "pointer",
                  opacity: busy ? 0.7 : 1,
                }}
              >
                {busy ? "…" : "کھولیں — Front + Backend"}
              </button>
            </form>
            <p style={{ marginTop: 12, color: "#666", fontSize: ".85rem" }}>
              سیدھا ایڈمن:{" "}
              <a href={BACKEND} style={{ color: "#1db954", fontWeight: 700 }}>
                /admin/login
              </a>
            </p>
          </>
        ) : (
          <>
            <h1 style={{ margin: "0 0 8px", color: "#1db954", fontSize: "1.45rem" }}>
              فرنٹ + بیک اینڈ تیار
            </h1>
            <p style={{ color: "#555", lineHeight: 1.85, margin: "0 0 14px", fontSize: ".95rem" }}>
              موبائل پر الگ الگ بٹن دبائیں۔ لیپ ٹاپ پر دونوں کھول سکتے ہیں۔
            </p>
            <a href={FRONT} style={{ ...btnBase, background: "#1db954" }}>
              ① FRONT — فرنٹ سائٹ
            </a>
            <a href={BACKEND} style={{ ...btnBase, background: "#111" }}>
              ② BACKEND — ایڈمن لاگ اِن
            </a>
            <a
              href={BACKEND_ALT}
              style={{ ...btnBase, background: "#1e3a5f", fontSize: "1rem", padding: 14 }}
            >
              ② بیک اینڈ دوبارہ (/backend)
            </a>
            <Link
              href="/download"
              style={{ ...btnBase, background: "#159A45", fontSize: "1rem", padding: 14 }}
            >
              ③ فائلیں ڈاؤن لوڈ — FRONT + BACKEND
            </Link>
            <p style={{ marginTop: 14, color: "#666", fontSize: ".85rem", lineHeight: 1.6 }}>
              ایڈمن پاس ورڈ یہاں نہیں دکھایا جاتا — Admin → Account سے تبدیل کریں۔
            </p>
          </>
        )}
      </div>
    </div>
  );
}
