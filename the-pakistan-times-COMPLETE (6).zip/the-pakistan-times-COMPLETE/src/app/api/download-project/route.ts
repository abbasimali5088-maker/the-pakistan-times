import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Alias → same force-download API as /api/download-links?file=complete
 * (always includes Front + Backend source).
 */
export async function GET() {
  return NextResponse.redirect(
    new URL(
      "/api/download-links?file=complete",
      process.env.NEXT_PUBLIC_SITE_URL || "https://the-pakistan-times-live.vercel.app",
    ),
    302,
  );
}
