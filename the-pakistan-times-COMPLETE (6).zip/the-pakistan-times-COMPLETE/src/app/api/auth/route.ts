import { NextRequest } from "next/server";
import { z } from "zod";
import {
  SESSION_COOKIE,
  AuthError,
  createSession,
  destroySession,
  getSessionUser,
  requireUser,
  verifyPassword,
} from "@/lib/auth";
import { fail, handleApi, ok } from "@/lib/api";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const loginSchema = z.object({
  email: z.string().trim().min(3),
  password: z.string().min(1),
});

function shouldUseSecureCookies(req?: NextRequest) {
  if (process.env.COOKIE_SECURE === "false") return false;
  if (process.env.COOKIE_SECURE === "true") return true;
  // Production / Vercel is always HTTPS — require Secure so browsers keep the session.
  if (process.env.NODE_ENV === "production") return true;
  if (process.env.VERCEL === "1" || process.env.VERCEL === "true") return true;
  const proto = req?.headers.get("x-forwarded-proto");
  if (proto === "https") return true;
  const host = req?.headers.get("host") || "";
  if (host.includes("vercel.app") || host.includes("vercel.sh")) return true;
  const site = process.env.NEXT_PUBLIC_SITE_URL || "";
  return site.startsWith("https://");
}

function cookieOptions(expiresAt: Date, req?: NextRequest) {
  const secure = shouldUseSecureCookies(req);
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure,
    path: "/",
    expires: expiresAt,
  };
}

export async function POST(req: NextRequest) {
  try {
    const body = loginSchema.parse(await req.json());
    const email = body.email.toLowerCase();
    const ip = req.headers.get("x-forwarded-for") || "unknown";
    const userAgent = req.headers.get("user-agent") || undefined;

    const since = new Date(Date.now() - 15 * 60_000);
    let fails = 0;
    try {
      fails = await prisma.loginLog.count({
        where: { email, success: false, createdAt: { gte: since } },
      });
    } catch {
      /* DB pool pressure — don't block login on rate-limit check */
      fails = 0;
    }
    if (fails >= 10) {
      try {
        await prisma.loginLog.create({
          data: { email, success: false, ip, userAgent },
        });
      } catch {
        /* ignore */
      }
      return fail("Too many failed attempts. Try again later.", 429);
    }

    const user = await prisma.user.findFirst({
      where: {
        OR: [{ email }, { email: body.email }],
        deletedAt: null,
      },
    });
    const valid =
      user && user.status === "active"
        ? await verifyPassword(body.password, user.passwordHash)
        : false;

    try {
      await prisma.loginLog.create({
        data: {
          userId: user?.id,
          email,
          success: !!valid,
          ip,
          userAgent,
        },
      });
    } catch {
      /* ignore pool pressure on logging */
    }

    if (!valid || !user) {
      return fail("Invalid credentials", 401);
    }

    const session = await createSession(user.id, { ip, userAgent });

    try {
      await prisma.user.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() },
      });
    } catch {
      /* session still valid even if lastLoginAt update fails */
    }
    try {
      await writeAudit({
        userId: user.id,
        action: "login",
        module: "security",
        ip,
        userAgent,
      });
    } catch {
      /* ignore */
    }

    const res = ok({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        username: user.username,
      },
    });
    res.cookies.set(SESSION_COOKIE, session.jwt, cookieOptions(session.expiresAt, req));
    return res;
  } catch (err) {
    if (err instanceof z.ZodError) {
      return fail("Validation failed", 422, err.flatten());
    }
    if (err instanceof AuthError) return fail(err.message, err.status);
    console.error("[auth/login]", err);
    // Friendlier message when DB is saturated
    const msg = err instanceof Error ? err.message : "Login failed";
    if (/too many connections|P2037|PrismaClientInitialization/i.test(msg)) {
      return fail("Server busy — 10 second baad dubara try karein", 503);
    }
    return fail(msg, 500);
  }
}

export async function DELETE(req: NextRequest) {
  return handleApi(async () => {
    const user = await getSessionUser();
    const token = (await (await import("next/headers")).cookies()).get(SESSION_COOKIE)?.value;
    if (token) {
      try {
        const { payload } = await (
          await import("jose")
        ).jwtVerify(
          token,
          new TextEncoder().encode(
            process.env.JWT_SECRET ||
              (process.env.NODE_ENV === "production" || process.env.VERCEL === "1"
                ? ""
                : "dev-secret-local-only"),
          ),
        );
        await destroySession(String(payload.sid || ""));
      } catch {
        /* ignore */
      }
    }
    const res = ok({ ok: true });
    res.cookies.set(SESSION_COOKIE, "", {
      httpOnly: true,
      path: "/",
      expires: new Date(0),
      sameSite: "lax",
      secure: shouldUseSecureCookies(req),
    });
    if (user) {
      await writeAudit({ userId: user.id, action: "logout", module: "security" });
    }
    return res;
  });
}

export async function GET() {
  return handleApi(async () => {
    const user = await requireUser();
    const { permissions: _set, permissionsList, ...rest } = user;
    void _set;
    return {
      user: {
        ...rest,
        permissions: permissionsList,
      },
    };
  });
}
