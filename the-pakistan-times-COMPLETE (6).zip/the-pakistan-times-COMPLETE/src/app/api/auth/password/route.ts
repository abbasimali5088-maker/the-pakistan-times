import { NextRequest } from "next/server";
import { z } from "zod";
import {
  AuthError,
  getSessionUser,
  hashPassword,
  requireUser,
  verifyPassword,
} from "@/lib/auth";
import { fail, handleApi, ok } from "@/lib/api";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const changeSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8),
});

const resetSchema = z.object({
  email: z.string().trim().min(3),
  newPassword: z.string().min(8),
  resetKey: z.string().min(4),
});

function ownerResetKey() {
  // Never fall back to ADMIN_PASSWORD — reset key must be a dedicated env secret.
  return (process.env.OWNER_RESET_KEY || "").trim();
}

/** Logged-in user: change password with current password. */
export async function PUT(req: NextRequest) {
  return handleApi(async () => {
    const user = await requireUser();
    const body = changeSchema.parse(await req.json());
    const row = await prisma.user.findUnique({ where: { id: user.id } });
    if (!row) throw new AuthError("User not found", 404);
    const valid = await verifyPassword(body.currentPassword, row.passwordHash);
    if (!valid) throw new AuthError("Current password is wrong", 401);
    const passwordHash = await hashPassword(body.newPassword);
    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash },
    });
    await writeAudit({
      userId: user.id,
      action: "change_password",
      module: "security",
    });
    return { ok: true };
  });
}

/**
 * Owner reset without login — needs OWNER_RESET_KEY from server env.
 * This is the "forgot password" path for a single-owner newsroom.
 */
export async function POST(req: NextRequest) {
  try {
    const body = resetSchema.parse(await req.json());
    const key = ownerResetKey();
    if (!key || body.resetKey.trim() !== key) {
      return fail("Reset key wrong — set OWNER_RESET_KEY in server env", 403);
    }
    const email = body.email.trim().toLowerCase();
    const user = await prisma.user.findFirst({
      where: { email, deletedAt: null },
    });
    if (!user) return fail("User not found", 404);
    const passwordHash = await hashPassword(body.newPassword);
    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash, status: "active" },
    });
    await prisma.loginLog.deleteMany({
      where: { email, success: false, createdAt: { gte: new Date(Date.now() - 60 * 60_000) } },
    });
    await writeAudit({
      userId: user.id,
      action: "reset_password",
      module: "security",
    });
    return ok({ ok: true, email: user.email });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return fail("Validation failed — password min 8 characters", 422, err.flatten());
    }
    console.error("[auth/password]", err);
    return fail(err instanceof Error ? err.message : "Reset failed", 500);
  }
}

export async function GET() {
  return handleApi(async () => {
    const user = await getSessionUser();
    return { loggedIn: !!user, email: user?.email || null };
  });
}
