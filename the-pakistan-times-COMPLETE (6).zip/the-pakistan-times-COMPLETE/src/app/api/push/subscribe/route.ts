import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";

const subscribeSchema = z.object({
  endpoint: z.string().url(),
  keys: z.object({
    p256dh: z.string().min(1),
    auth: z.string().min(1),
  }),
  lang: z.enum(["en", "ur"]).optional(),
});

// Public route (no auth): any visitor who opts in from the browser can
// register their own push subscription for breaking-news alerts.
export async function POST(req: NextRequest) {
  try {
    const body = subscribeSchema.parse(await req.json());
    await prisma.pushSubscription.upsert({
      where: { endpoint: body.endpoint },
      create: {
        endpoint: body.endpoint,
        p256dh: body.keys.p256dh,
        auth: body.keys.auth,
        lang: body.lang || "en",
      },
      update: {
        p256dh: body.keys.p256dh,
        auth: body.keys.auth,
        lang: body.lang || "en",
      },
    });
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ ok: false, error: "Invalid subscription payload" }, { status: 422 });
    }
    console.error("[POST /api/push/subscribe]", err);
    return NextResponse.json({ ok: false, error: "Failed to save subscription" }, { status: 500 });
  }
}

const unsubscribeSchema = z.object({ endpoint: z.string().url() });

export async function DELETE(req: NextRequest) {
  try {
    const body = unsubscribeSchema.parse(await req.json());
    await prisma.pushSubscription.deleteMany({ where: { endpoint: body.endpoint } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ ok: false, error: "Invalid payload" }, { status: 422 });
    }
    console.error("[DELETE /api/push/subscribe]", err);
    return NextResponse.json({ ok: false, error: "Failed to remove subscription" }, { status: 500 });
  }
}
