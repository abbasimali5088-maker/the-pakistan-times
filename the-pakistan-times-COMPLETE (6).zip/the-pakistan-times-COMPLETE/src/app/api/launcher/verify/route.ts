import { NextRequest } from "next/server";
import { z } from "zod";
import { handleApi, HttpError } from "@/lib/api";
import { getSettingMap } from "@/lib/content";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Launcher password resolution — NEVER falls back to ADMIN_PASSWORD.
 * Only DB setting or dedicated LAUNCHER_PASSWORD env.
 */
async function resolveLauncherPassword(): Promise<string | null> {
  try {
    const map = await getSettingMap();
    const fromDb = map.security?.launcherPassword?.trim();
    if (fromDb) return fromDb;
  } catch {
    /* ignore */
  }
  const fromEnv = process.env.LAUNCHER_PASSWORD?.trim();
  return fromEnv || null;
}

/** Verify launcher password without embedding it in client JS. */
export async function POST(req: NextRequest) {
  return handleApi(async () => {
    const body = z.object({ password: z.string().min(1) }).parse(await req.json());
    const expected = await resolveLauncherPassword();
    if (!expected) {
      throw new HttpError(
        "Launcher password not configured. Set LAUNCHER_PASSWORD or Admin → Settings.",
        503,
      );
    }
    const typed = body.password.replace(/[\u200e\u200f\ufeff]/g, "").trim();
    if (typed !== expected) throw new HttpError("Invalid password", 401);
    return { ok: true };
  });
}
