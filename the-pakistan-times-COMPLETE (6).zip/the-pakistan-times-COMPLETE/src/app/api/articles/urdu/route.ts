import { NextRequest } from "next/server";
import { z } from "zod";
import { handleApi } from "@/lib/api";
import { requirePermission, can } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { makeSlug, uniqueSlug } from "@/lib/slug";
import { articlePublicInclude, serializeArticle } from "@/lib/content";
import { toArticleHtml } from "@/lib/article-html";
import { nullIfEmpty, filterValidIds } from "@/lib/safe-ids";
import { HttpError } from "@/lib/http-error";

export const runtime = "nodejs";

/**
 * Urdu Articles hub — POST /api/articles/urdu
 * Validates and binds ONLY Urdu fields + categoryUrId.
 * Empty FK strings → null (prevents Prisma P2003 / Internal Server Error).
 */
const urduCreateSchema = z.object({
  titleUr: z.string().trim().min(1, "اردو عنوان ضروری ہے"),
  slugUr: z.string().optional().nullable(),
  excerptUr: z.string().optional().nullable(),
  bodyUr: z.string().optional().nullable(),
  toolTitleUr: z.string().optional().nullable(),
  toolCodeUr: z.string().optional().nullable(),
  categoryUrId: z.string().optional().nullable(),
  featuredImageUrId: z.string().optional().nullable(),
  imageCaptionUr: z.string().optional().nullable(),
  imageCreditUr: z.string().optional().nullable(),
  videoUrlUr: z.string().optional().nullable(),
  seoTitleUr: z.string().optional().nullable(),
  seoDescriptionUr: z.string().optional().nullable(),
  focusKeywordUr: z.string().optional().nullable(),
  searchKeywordsUr: z.string().optional().nullable(),
  ogTitleUr: z.string().optional().nullable(),
  ogDescriptionUr: z.string().optional().nullable(),
  ogImageUr: z.string().optional().nullable(),
  canonicalUrl: z.string().optional().nullable(),
  robotsMeta: z.string().optional().nullable(),
  tagIdsUr: z.array(z.string()).optional(),
  status: z.enum(["draft", "published", "scheduled", "archived"]).optional(),
  priority: z.string().optional(),
  isFeatured: z.boolean().optional(),
  isBreaking: z.boolean().optional(),
  isLive: z.boolean().optional(),
  liveExpiresAt: z.string().optional().nullable(),
  liveDurationHours: z.number().int().min(1).max(3).optional().nullable(),
});

export async function POST(req: NextRequest) {
  return handleApi(async () => {
    try {
      const user = await requirePermission("articles", "create");
      const body = urduCreateSchema.parse(await req.json());

      const status = body.status || "draft";
      if (status === "published" && !can(user, "articles", "publish")) {
        throw new HttpError("Missing publish permission", 403);
      }

      const titleUr = body.titleUr.trim();
      const excerptUr = nullIfEmpty(body.excerptUr);
      if (excerptUr && excerptUr === titleUr) {
        throw new HttpError("اردو خلاصہ عنوان جیسا نہ لکھیں", 422);
      }

      const categoryUrId = nullIfEmpty(body.categoryUrId);
      const featuredImageUrId = nullIfEmpty(body.featuredImageUrId);
      const tagIdsUr = filterValidIds(body.tagIdsUr);

      if (categoryUrId) {
        const cat = await prisma.category.findFirst({
          where: { id: categoryUrId, language: "ur", status: "active" },
          select: { id: true },
        });
        if (!cat) throw new HttpError("Invalid Urdu category", 422);
      }

      if (featuredImageUrId) {
        const media = await prisma.media.findUnique({
          where: { id: featuredImageUrId },
          select: { id: true },
        });
        if (!media) throw new HttpError("Invalid Urdu image", 422);
      }

      let safeTagIdsUr: string[] = [];
      if (tagIdsUr.length) {
        const existing = await prisma.tag.findMany({
          where: { id: { in: tagIdsUr } },
          select: { id: true },
        });
        const valid = new Set(existing.map((t) => t.id));
        safeTagIdsUr = tagIdsUr.filter((id) => valid.has(id));
      }

      const slugSource = nullIfEmpty(body.slugUr) || titleUr;
      const baseSlug = makeSlug(slugSource) || `urdu-${Date.now()}`;
      const existingSlugs = await prisma.article.findMany({
        where: { slug: { startsWith: baseSlug } },
        select: { slug: true },
      });
      const slug = uniqueSlug(
        baseSlug,
        existingSlugs.map((e) => e.slug),
      );

      const isLive = Boolean(body.isLive);
      const isBreaking = Boolean(body.isBreaking) || isLive;
      const priority = isLive
        ? "live"
        : isBreaking
          ? "breaking"
          : body.priority || "normal";

      const liveHours =
        body.liveDurationHours === 2 || body.liveDurationHours === 3
          ? body.liveDurationHours
          : 1;
      const liveExpiresAt = isLive
        ? body.liveExpiresAt
          ? new Date(body.liveExpiresAt)
          : new Date(Date.now() + liveHours * 3_600_000)
        : null;

      const bodyUrHtml = body.bodyUr ? toArticleHtml(body.bodyUr) : body.bodyUr || "";

      const article = await prisma.article.create({
        data: {
          title: titleUr,
          titleUr,
          slug,
          slugUr: slug,
          excerpt: null,
          excerptUr,
          body: "",
          bodyUr: bodyUrHtml,
          toolTitle: null,
          toolCode: null,
          toolTitleUr: nullIfEmpty(body.toolTitleUr),
          toolCodeUr: nullIfEmpty(body.toolCodeUr),
          language: "ur",
          status,
          workflowStep: status === "published" ? "published" : "draft",
          priority,
          liveExpiresAt,
          categoryId: null,
          categoryUrId,
          featuredImageId: null,
          featuredImageUrId,
          imageCaption: null,
          imageCredit: null,
          imageCaptionUr: nullIfEmpty(body.imageCaptionUr),
          imageCreditUr: nullIfEmpty(body.imageCreditUr),
          videoUrl: null,
          videoUrlUr: nullIfEmpty(body.videoUrlUr),
          publishedAt: status === "published" ? new Date() : null,
          publishAt: status === "published" ? new Date() : null,
          seoTitle: null,
          seoDescription: null,
          seoTitleUr: nullIfEmpty(body.seoTitleUr) || titleUr,
          seoDescriptionUr: nullIfEmpty(body.seoDescriptionUr) || excerptUr,
          focusKeyword: null,
          focusKeywordUr: nullIfEmpty(body.focusKeywordUr),
          searchKeywords: null,
          searchKeywordsUr: nullIfEmpty(body.searchKeywordsUr),
          ogTitle: null,
          ogDescription: null,
          ogTitleUr: nullIfEmpty(body.ogTitleUr) || titleUr,
          ogDescriptionUr: nullIfEmpty(body.ogDescriptionUr) || excerptUr,
          ogImage: null,
          ogImageUr: nullIfEmpty(body.ogImageUr),
          canonicalUrl: nullIfEmpty(body.canonicalUrl),
          robotsMeta: nullIfEmpty(body.robotsMeta) || "index,follow",
          schemaType: "NewsArticle",
          isFeatured: Boolean(body.isFeatured),
          isBreaking,
          createdById: user.id,
          updatedById: user.id,
          tags: safeTagIdsUr.length
            ? {
                create: safeTagIdsUr.map((tagId) => ({
                  tagId,
                  locale: "ur",
                })),
              }
            : undefined,
          revisions: {
            create: {
              version: 1,
              title: titleUr,
              body: bodyUrHtml || "",
              excerpt: excerptUr,
              snapshot: JSON.stringify(body),
              note: "Urdu article created",
              userId: user.id,
            },
          },
        },
        include: articlePublicInclude,
      });

      if (safeTagIdsUr.length) {
        await prisma.tag.updateMany({
          where: { id: { in: safeTagIdsUr } },
          data: { usageCount: { increment: 1 } },
        });
      }

      await writeAudit({
        userId: user.id,
        action: "create",
        module: "articles",
        recordId: article.id,
        newValue: {
          language: "ur",
          titleUr: article.titleUr,
          status: article.status,
          categoryUrId: article.categoryUrId,
        },
        ip: req.headers.get("x-forwarded-for"),
        userAgent: req.headers.get("user-agent"),
      });

      return serializeArticle(article);
    } catch (err) {
      if (err instanceof z.ZodError) throw err;
      if (err instanceof HttpError) throw err;
      console.error("[POST /api/articles/urdu]", err);
      throw new HttpError(
        err instanceof Error ? err.message.slice(0, 300) : "Urdu article save failed",
        500,
      );
    }
  });
}
