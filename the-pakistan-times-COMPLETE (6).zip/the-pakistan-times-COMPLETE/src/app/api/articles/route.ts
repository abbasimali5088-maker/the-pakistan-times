import { NextRequest } from "next/server";
import { z } from "zod";
import { handleApi, getPagination } from "@/lib/api";
import { requirePermission, can } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { makeSlug, uniqueSlug } from "@/lib/slug";
import { articlePublicInclude, serializeArticle } from "@/lib/content";
import { enqueueJob } from "@/lib/audit";
import { toArticleHtml, sanitizePublicImageUrl } from "@/lib/article-html";
import { nullIfEmpty, filterValidIds } from "@/lib/safe-ids";
import { HttpError } from "@/lib/http-error";

export const runtime = "nodejs";

const articleSchema = z.object({
  title: z.string().min(1),
  titleUr: z.string().optional().nullable(),
  slug: z.string().optional().nullable(),
  slugUr: z.string().optional().nullable(),
  subtitle: z.string().optional().nullable(),
  excerpt: z.string().optional().nullable(),
  excerptUr: z.string().optional().nullable(),
  body: z.string().optional().nullable(),
  bodyUr: z.string().optional().nullable(),
  toolTitle: z.string().optional().nullable(),
  toolCode: z.string().optional().nullable(),
  toolTitleUr: z.string().optional().nullable(),
  toolCodeUr: z.string().optional().nullable(),
  language: z.string().optional(),
  status: z.string().optional(),
  workflowStep: z.string().optional(),
  priority: z.string().optional(),
  location: z.string().optional().nullable(),
  categoryId: z.string().optional().nullable(),
  categoryUrId: z.string().optional().nullable(),
  authorId: z.string().optional().nullable(),
  featuredImageId: z.string().optional().nullable(),
  featuredImageUrId: z.string().optional().nullable(),
  imageCaption: z.string().optional().nullable(),
  imageCredit: z.string().optional().nullable(),
  imageCaptionUr: z.string().optional().nullable(),
  imageCreditUr: z.string().optional().nullable(),
  videoUrl: z.string().optional().nullable(),
  videoUrlUr: z.string().optional().nullable(),
  publishAt: z.string().optional().nullable(),
  seoTitle: z.string().optional().nullable(),
  seoDescription: z.string().optional().nullable(),
  seoTitleUr: z.string().optional().nullable(),
  seoDescriptionUr: z.string().optional().nullable(),
  focusKeyword: z.string().optional().nullable(),
  focusKeywordUr: z.string().optional().nullable(),
  searchKeywords: z.string().optional().nullable(),
  searchKeywordsUr: z.string().optional().nullable(),
  canonicalUrl: z.string().optional().nullable(),
  robotsMeta: z.string().optional().nullable(),
  ogTitle: z.string().optional().nullable(),
  ogDescription: z.string().optional().nullable(),
  ogTitleUr: z.string().optional().nullable(),
  ogDescriptionUr: z.string().optional().nullable(),
  ogImage: z.string().optional().nullable(),
  ogImageUr: z.string().optional().nullable(),
  schemaType: z.string().optional(),
  tagIds: z.array(z.string()).optional(),
  tagIdsUr: z.array(z.string()).optional(),
  coAuthorIds: z.array(z.string()).optional(),
  isFeatured: z.boolean().optional(),
  isBreaking: z.boolean().optional(),
  liveExpiresAt: z.string().optional().nullable(),
  liveDurationHours: z.number().int().min(1).max(3).optional().nullable(),
  revisionNote: z.string().optional().nullable(),
  siteId: z.string().optional().nullable(),
});

export async function GET(req: NextRequest) {
  return handleApi(async () => {
    const url = new URL(req.url);
    const { page, pageSize, skip, take } = getPagination(url);
    const status = url.searchParams.get("status");
    const category = url.searchParams.get("category");
    const q = url.searchParams.get("q");
    const publicOnly = url.searchParams.get("public") === "1";
    const language = url.searchParams.get("language");
    const priority = url.searchParams.get("priority");
    const authorId = url.searchParams.get("authorId");
    const tag = url.searchParams.get("tag");

    if (!publicOnly) {
      await requirePermission("articles", "read");
    }

    const where: Record<string, unknown> = {
      deletedAt: null,
    };
    if (publicOnly) {
      where.status = "published";
      where.OR = [
        { publishAt: null },
        { publishAt: { lte: new Date() } },
      ];
    } else if (status) {
      where.status = status;
    }
    if (category) {
      where.category = { slug: category };
    }
    if (language) where.language = language;
    if (priority) where.priority = priority;
    if (authorId) where.authorId = authorId;
    if (tag) where.tags = { some: { tag: { slug: tag } } };
    if (q) {
      const searchOr = {
        OR: [
          { title: { contains: q, mode: "insensitive" as const } },
          { titleUr: { contains: q, mode: "insensitive" as const } },
          { excerpt: { contains: q, mode: "insensitive" as const } },
          { excerptUr: { contains: q, mode: "insensitive" as const } },
          { body: { contains: q, mode: "insensitive" as const } },
          { bodyUr: { contains: q, mode: "insensitive" as const } },
          { slug: { contains: q, mode: "insensitive" as const } },
          { focusKeyword: { contains: q, mode: "insensitive" as const } },
        ],
      };
      where.AND = Array.isArray(where.AND)
        ? [...(where.AND as unknown[]), searchOr]
        : [searchOr];
    }

    const [total, rows] = await Promise.all([
      prisma.article.count({ where }),
      prisma.article.findMany({
        where,
        include: articlePublicInclude,
        orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
        skip,
        take,
      }),
    ]);

    return {
      items: rows.map((row) => serializeArticle(row, { lite: true })),
      page,
      pageSize,
      total,
      totalPages: Math.ceil(total / pageSize),
    };
  });
}

export async function POST(req: NextRequest) {
  return handleApi(async () => {
    const user = await requirePermission("articles", "create");
    const body = articleSchema.parse(await req.json());
    const baseSlug = makeSlug(body.slug || body.title);
    const existing = await prisma.article.findMany({
      where: { slug: { startsWith: baseSlug } },
      select: { slug: true },
    });
    const slug = uniqueSlug(
      baseSlug,
      existing.map((e) => e.slug),
    );

    const status = body.status || "draft";
    if (status === "published" && !can(user, "articles", "publish")) {
      throw new Error("Missing publish permission");
    }

    const publishAt = body.publishAt ? new Date(body.publishAt) : null;
    const slugUrBase = body.slugUr?.trim()
      ? makeSlug(body.slugUr)
      : body.titleUr?.trim()
        ? makeSlug(body.titleUr)
        : null;
    const language = body.language === "en" ? "en" : "ur";
    const categoryId = nullIfEmpty(body.categoryId);
    const categoryUrId =
      language === "ur"
        ? nullIfEmpty(body.categoryUrId) || categoryId
        : nullIfEmpty(body.categoryUrId);
    const featuredImageId = nullIfEmpty(body.featuredImageId);
    const featuredImageUrId = nullIfEmpty(body.featuredImageUrId);
    const authorId = nullIfEmpty(body.authorId);
    const siteId = nullIfEmpty(body.siteId);
    const tagIds = filterValidIds(body.tagIds);
    const tagIdsUr = filterValidIds(body.tagIdsUr);

    // Drop invalid FK ids before create (avoid opaque 500)
    async function assertOptionalFk(id: string | null, model: "category" | "media" | "author" | "site", label: string) {
      if (!id) return null;
      const exists =
        model === "category"
          ? await prisma.category.findUnique({ where: { id }, select: { id: true } })
          : model === "media"
            ? await prisma.media.findUnique({ where: { id }, select: { id: true } })
            : model === "author"
              ? await prisma.author.findUnique({ where: { id }, select: { id: true } })
              : await prisma.site.findUnique({ where: { id }, select: { id: true } });
      if (!exists) throw new HttpError(`Invalid ${label}`, 422);
      return id;
    }

    const safeCategoryId = await assertOptionalFk(categoryId, "category", "category");
    const safeCategoryUrId = await assertOptionalFk(categoryUrId, "category", "Urdu category");
    const safeFeaturedImageId = await assertOptionalFk(featuredImageId, "media", "image");
    const safeFeaturedImageUrId = await assertOptionalFk(featuredImageUrId, "media", "Urdu image");
    const safeAuthorId = await assertOptionalFk(authorId, "author", "author");
    const safeSiteId = await assertOptionalFk(siteId, "site", "site");

    const existingTagIds = tagIds.length || tagIdsUr.length
      ? await prisma.tag.findMany({
          where: { id: { in: [...tagIds, ...tagIdsUr] } },
          select: { id: true },
        })
      : [];
    const validTagSet = new Set(existingTagIds.map((t) => t.id));
    const safeTagIds = tagIds.filter((id) => validTagSet.has(id));
    const safeTagIdsUr = tagIdsUr.filter((id) => validTagSet.has(id));

    const tagCreates = [
      ...safeTagIds.map((tagId) => ({ tagId, locale: "en" })),
      ...safeTagIdsUr.map((tagId) => ({ tagId, locale: "ur" })),
    ];
    const article = await prisma.article.create({
      data: {
        title: body.title,
        titleUr: body.titleUr,
        slug,
        slugUr: slugUrBase || null,
        subtitle: body.subtitle,
        excerpt: body.excerpt,
        excerptUr: body.excerptUr,
        body: toArticleHtml(body.body) || body.body || "",
        bodyUr: body.bodyUr ? toArticleHtml(body.bodyUr) : body.bodyUr,
        toolTitle: language === "en" ? body.toolTitle || null : null,
        toolCode: language === "en" ? body.toolCode || null : null,
        toolTitleUr: language === "ur" ? body.toolTitleUr || null : null,
        toolCodeUr: language === "ur" ? body.toolCodeUr || null : null,
        language,
        status,
        workflowStep: body.workflowStep || (status === "published" ? "published" : "draft"),
        priority: body.priority || "normal",
        liveExpiresAt:
          (body.priority || "normal") === "live"
            ? body.liveExpiresAt
              ? new Date(body.liveExpiresAt)
              : new Date(
                  Date.now() +
                    (body.liveDurationHours === 2 || body.liveDurationHours === 3
                      ? body.liveDurationHours
                      : 1) *
                      3_600_000,
                )
            : null,
        location: body.location,
        categoryId: safeCategoryId,
        categoryUrId: language === "en" ? safeCategoryUrId : (safeCategoryUrId || safeCategoryId),
        authorId: safeAuthorId,
        featuredImageId: safeFeaturedImageId,
        featuredImageUrId: safeFeaturedImageUrId,
        imageCaption: body.imageCaption,
        imageCredit: body.imageCredit,
        imageCaptionUr: body.imageCaptionUr,
        imageCreditUr: body.imageCreditUr,
        videoUrl: body.videoUrl || null,
        videoUrlUr: body.videoUrlUr || null,
        publishAt,
        publishedAt: status === "published" ? publishAt || new Date() : null,
        seoTitle: body.seoTitle || body.title,
        seoDescription: body.seoDescription || body.excerpt,
        seoTitleUr: body.seoTitleUr || body.titleUr,
        seoDescriptionUr: body.seoDescriptionUr || body.excerptUr,
        focusKeyword: body.focusKeyword,
        focusKeywordUr: body.focusKeywordUr,
        searchKeywords: body.searchKeywords,
        searchKeywordsUr: body.searchKeywordsUr,
        canonicalUrl: body.canonicalUrl,
        robotsMeta: body.robotsMeta || "index,follow",
        ogTitle: body.ogTitle || body.seoTitle || body.title,
        ogDescription: body.ogDescription || body.seoDescription || body.excerpt,
        ogTitleUr: body.ogTitleUr || body.seoTitleUr || body.titleUr,
        ogDescriptionUr: body.ogDescriptionUr || body.seoDescriptionUr || body.excerptUr,
        ogImage: sanitizePublicImageUrl(body.ogImage),
        ogImageUr: sanitizePublicImageUrl(body.ogImageUr),
        schemaType: body.schemaType || "NewsArticle",
        isFeatured: body.isFeatured || false,
        isBreaking: body.isBreaking || false,
        siteId: safeSiteId,
        createdById: user.id,
        updatedById: user.id,
        tags: tagCreates.length ? { create: tagCreates } : undefined,
        coAuthors: body.coAuthorIds?.length
          ? { create: body.coAuthorIds.map((authorId) => ({ authorId })) }
          : undefined,
        revisions: {
          create: {
            version: 1,
            title: body.title,
            body: body.body || "",
            excerpt: body.excerpt,
            snapshot: JSON.stringify(body),
            note: body.revisionNote || "Created",
            userId: user.id,
          },
        },
      },
      include: articlePublicInclude,
    });

    const allTagIds = [...safeTagIds, ...safeTagIdsUr];
    if (allTagIds.length) {
      await prisma.tag.updateMany({
        where: { id: { in: allTagIds } },
        data: { usageCount: { increment: 1 } },
      });
    }

    if (status === "scheduled" && publishAt) {
      await enqueueJob("publish_article", { articleId: article.id }, publishAt);
    }

    await writeAudit({
      userId: user.id,
      action: "create",
      module: "articles",
      recordId: article.id,
      newValue: { title: article.title, status: article.status },
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    });

    return serializeArticle(article);
  });
}
