import { NextRequest } from "next/server";
import { z } from "zod";
import { handleApi } from "@/lib/api";
import { can, getSessionUser, requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit, enqueueJob } from "@/lib/audit";
import { makeSlug, uniqueSlug } from "@/lib/slug";
import { articlePublicInclude, serializeArticle } from "@/lib/content";
import { toArticleHtml, sanitizePublicImageUrl } from "@/lib/article-html";
import { nullIfEmpty, filterValidIds } from "@/lib/safe-ids";

export const runtime = "nodejs";

const patchSchema = z.object({
  title: z.string().min(1).optional(),
  titleUr: z.string().optional().nullable(),
  slug: z.string().optional().nullable(),
  slugUr: z.string().optional().nullable(),
  subtitle: z.string().optional().nullable(),
  excerpt: z.string().optional().nullable(),
  excerptUr: z.string().optional().nullable(),
  body: z.string().optional().nullable(),
  bodyUr: z.string().optional().nullable(),
  toolTitle: z.string().optional().nullable(),
  toolCode: z.string().optional().nullable(),
  toolTitleUr: z.string().optional().nullable(),
  toolCodeUr: z.string().optional().nullable(),
  language: z.string().optional(),
  status: z.string().optional(),
  workflowStep: z.string().optional(),
  priority: z.string().optional(),
  location: z.string().optional().nullable(),
  categoryId: z.string().optional().nullable(),
  categoryUrId: z.string().optional().nullable(),
  authorId: z.string().optional().nullable(),
  featuredImageId: z.string().optional().nullable(),
  featuredImageUrId: z.string().optional().nullable(),
  imageCaption: z.string().optional().nullable(),
  imageCredit: z.string().optional().nullable(),
  imageCaptionUr: z.string().optional().nullable(),
  imageCreditUr: z.string().optional().nullable(),
  videoUrl: z.string().optional().nullable(),
  videoUrlUr: z.string().optional().nullable(),
  publishAt: z.string().optional().nullable(),
  seoTitle: z.string().optional().nullable(),
  seoDescription: z.string().optional().nullable(),
  seoTitleUr: z.string().optional().nullable(),
  seoDescriptionUr: z.string().optional().nullable(),
  focusKeyword: z.string().optional().nullable(),
  focusKeywordUr: z.string().optional().nullable(),
  searchKeywords: z.string().optional().nullable(),
  searchKeywordsUr: z.string().optional().nullable(),
  canonicalUrl: z.string().optional().nullable(),
  robotsMeta: z.string().optional().nullable(),
  ogTitle: z.string().optional().nullable(),
  ogDescription: z.string().optional().nullable(),
  ogTitleUr: z.string().optional().nullable(),
  ogDescriptionUr: z.string().optional().nullable(),
  ogImage: z.string().optional().nullable(),
  ogImageUr: z.string().optional().nullable(),
  schemaType: z.string().optional(),
  tagIds: z.array(z.string()).optional(),
  tagIdsUr: z.array(z.string()).optional(),
  coAuthorIds: z.array(z.string()).optional(),
  isFeatured: z.boolean().optional(),
  isBreaking: z.boolean().optional(),
  liveExpiresAt: z.string().optional().nullable(),
  liveDurationHours: z.number().int().min(1).max(3).optional().nullable(),
  revisionNote: z.string().optional().nullable(),
  action: z
    .enum([
      "publish",
      "unpublish",
      "archive",
      "restore",
      "approve",
      "reject",
      "schedule",
      "duplicate",
      "restore_revision",
    ])
    .optional(),
  revisionId: z.string().optional(),
});

type Params = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const { id } = await params;
    const article = await prisma.article.findFirst({
      where: {
        OR: [{ id }, { slug: id }],
        deletedAt: null,
      },
      include: {
        ...articlePublicInclude,
        revisions: { orderBy: { version: "desc" }, take: 20 },
        relationsFrom: { include: { toArticle: { include: articlePublicInclude } } },
      },
    });
    if (!article) throw new Error("Article not found");

    const isPublic = article.status === "published";
    if (!isPublic) await requirePermission("articles", "read");

    const staff = await getSessionUser();
    const skipView = Boolean(staff && can(staff, "articles", "read"));

    if (isPublic && !skipView) {
      await prisma.article.update({
        where: { id: article.id },
        data: { viewCount: { increment: 1 } },
      });
      await prisma.analyticsEvent.create({
        data: {
          eventType: "article_view",
          articleId: article.id,
          path: `/${article.slug}`,
        },
      });
    }

    return {
      ...serializeArticle(article),
      revisions: article.revisions,
      relations: article.relationsFrom.map((r) => ({
        type: r.relationType,
        article: serializeArticle(r.toArticle),
      })),
    };
  });
}

export async function PATCH(req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const user = await requirePermission("articles", "update");
    const { id } = await params;
    const body = patchSchema.parse(await req.json());
    const existing = await prisma.article.findFirst({ where: { id, deletedAt: null } });
    if (!existing) throw new Error("Article not found");

    if (body.action === "duplicate") {
      await requirePermission("articles", "create");
      const slug = uniqueSlug(
        `${existing.slug}-copy`,
        (
          await prisma.article.findMany({
            where: { slug: { startsWith: `${existing.slug}-copy` } },
            select: { slug: true },
          })
        ).map((a) => a.slug),
      );
      const copy = await prisma.article.create({
        data: {
          title: `${existing.title} (Copy)`,
          titleUr: existing.titleUr,
          slug,
          subtitle: existing.subtitle,
          excerpt: existing.excerpt,
          excerptUr: existing.excerptUr,
          body: existing.body,
          bodyUr: existing.bodyUr,
          language: existing.language,
          status: "draft",
          workflowStep: "draft",
          priority: existing.priority,
          categoryId: existing.categoryId,
          authorId: existing.authorId,
          featuredImageId: existing.featuredImageId,
          siteId: existing.siteId,
          createdById: user.id,
          updatedById: user.id,
        },
        include: articlePublicInclude,
      });
      return serializeArticle(copy);
    }

    if (body.action === "restore_revision" && body.revisionId) {
      const rev = await prisma.articleRevision.findFirst({
        where: { id: body.revisionId, articleId: existing.id },
      });
      if (!rev) throw new Error("Revision not found");
      const updated = await prisma.article.update({
        where: { id: existing.id },
        data: {
          title: rev.title,
          body: rev.body,
          excerpt: rev.excerpt,
          updatedById: user.id,
        },
        include: articlePublicInclude,
      });
      return serializeArticle(updated);
    }

    let status = body.status ?? existing.status;
    let workflowStep = body.workflowStep ?? existing.workflowStep;
    let publishedAt = existing.publishedAt;
    let archivedAt = existing.archivedAt;
    let unpublishedAt = existing.unpublishedAt;
    const publishAt = body.publishAt ? new Date(body.publishAt) : existing.publishAt;

    switch (body.action) {
      case "publish":
        if (!can(user, "articles", "publish")) throw new Error("Forbidden");
        status = "published";
        workflowStep = "published";
        publishedAt = new Date();
        break;
      case "unpublish":
        status = "unpublished";
        unpublishedAt = new Date();
        break;
      case "archive":
        status = "archived";
        archivedAt = new Date();
        break;
      case "restore":
        status = "draft";
        archivedAt = null;
        break;
      case "approve":
        if (!can(user, "articles", "approve")) throw new Error("Forbidden");
        status = "scheduled";
        workflowStep = "approval";
        break;
      case "reject":
        if (!can(user, "articles", "reject")) throw new Error("Forbidden");
        status = "rejected";
        workflowStep = "review";
        break;
      case "schedule":
        if (!can(user, "articles", "schedule")) throw new Error("Forbidden");
        status = "scheduled";
        workflowStep = "scheduled";
        break;
    }

    // Direct status="published" must also require publish permission
    if (status === "published" && existing.status !== "published") {
      if (!can(user, "articles", "publish")) throw new Error("Forbidden");
      if (!publishedAt) publishedAt = new Date();
      workflowStep = "published";
    }

    if (body.slug && body.slug !== existing.slug) {
      const slug = makeSlug(body.slug);
      const clash = await prisma.article.findFirst({
        where: { slug, NOT: { id: existing.id } },
      });
      if (clash) throw new Error("Slug already exists");
    }

    if (body.tagIds || body.tagIdsUr) {
      const tagIds = filterValidIds(body.tagIds);
      const tagIdsUr = filterValidIds(body.tagIdsUr);
      const found =
        tagIds.length || tagIdsUr.length
          ? await prisma.tag.findMany({
              where: { id: { in: [...tagIds, ...tagIdsUr] } },
              select: { id: true },
            })
          : [];
      const ok = new Set(found.map((t) => t.id));
      await prisma.$transaction(async (tx) => {
        // Only replace the locale(s) present in the payload — never wipe the other language's tags.
        if (body.tagIds !== undefined) {
          await tx.articleTag.deleteMany({
            where: { articleId: existing.id, locale: "en" },
          });
          const enRows = tagIds
            .filter((id) => ok.has(id))
            .map((tagId) => ({ articleId: existing.id, tagId, locale: "en" }));
          if (enRows.length) await tx.articleTag.createMany({ data: enRows });
        }
        if (body.tagIdsUr !== undefined) {
          await tx.articleTag.deleteMany({
            where: { articleId: existing.id, locale: "ur" },
          });
          const urRows = tagIdsUr
            .filter((id) => ok.has(id))
            .map((tagId) => ({ articleId: existing.id, tagId, locale: "ur" }));
          if (urRows.length) await tx.articleTag.createMany({ data: urRows });
        }
      });
    }
    if (body.coAuthorIds) {
      await prisma.articleCoAuthor.deleteMany({ where: { articleId: existing.id } });
      if (body.coAuthorIds.length) {
        await prisma.articleCoAuthor.createMany({
          data: body.coAuthorIds.map((authorId) => ({ articleId: existing.id, authorId })),
        });
      }
    }

    const lastRev = await prisma.articleRevision.findFirst({
      where: { articleId: existing.id },
      orderBy: { version: "desc" },
    });

    const updated = await prisma.article.update({
      where: { id: existing.id },
      data: {
        title: body.title ?? existing.title,
        titleUr: body.titleUr ?? existing.titleUr,
        slug: body.slug ? makeSlug(body.slug) : existing.slug,
        slugUr:
          body.slugUr !== undefined
            ? body.slugUr
              ? makeSlug(body.slugUr)
              : null
            : existing.slugUr,
        subtitle: body.subtitle ?? existing.subtitle,
        excerpt: body.excerpt ?? existing.excerpt,
        excerptUr: body.excerptUr ?? existing.excerptUr,
        body:
          body.body !== undefined ? toArticleHtml(body.body) || body.body || "" : existing.body,
        bodyUr:
          body.bodyUr !== undefined
            ? body.bodyUr
              ? toArticleHtml(body.bodyUr)
              : body.bodyUr
            : existing.bodyUr,
        toolTitle:
          body.toolTitle !== undefined
            ? existing.language === "en"
              ? body.toolTitle
              : existing.toolTitle
            : existing.toolTitle,
        toolCode:
          body.toolCode !== undefined
            ? existing.language === "en"
              ? body.toolCode
              : existing.toolCode
            : existing.toolCode,
        toolTitleUr:
          body.toolTitleUr !== undefined
            ? existing.language === "ur"
              ? body.toolTitleUr
              : existing.toolTitleUr
            : existing.toolTitleUr,
        toolCodeUr:
          body.toolCodeUr !== undefined
            ? existing.language === "ur"
              ? body.toolCodeUr
              : existing.toolCodeUr
            : existing.toolCodeUr,
        language: existing.language, // never flip EN↔UR via PATCH
        status,
        workflowStep,
        priority: body.priority ?? existing.priority,
        liveExpiresAt: (() => {
          const nextPriority = body.priority ?? existing.priority;
          if (nextPriority !== "live") return null;
          if (body.liveExpiresAt) return new Date(body.liveExpiresAt);
          if (body.liveDurationHours === 1 || body.liveDurationHours === 2 || body.liveDurationHours === 3) {
            return new Date(Date.now() + body.liveDurationHours * 3_600_000);
          }
          return existing.liveExpiresAt;
        })(),
        location: body.location ?? existing.location,
        categoryId:
          body.categoryId === undefined ? existing.categoryId : nullIfEmpty(body.categoryId),
        categoryUrId:
          body.categoryUrId === undefined ? existing.categoryUrId : nullIfEmpty(body.categoryUrId),
        authorId: body.authorId === undefined ? existing.authorId : nullIfEmpty(body.authorId),
        featuredImageId:
          body.featuredImageId === undefined
            ? existing.featuredImageId
            : nullIfEmpty(body.featuredImageId),
        featuredImageUrId:
          body.featuredImageUrId === undefined
            ? existing.featuredImageUrId
            : nullIfEmpty(body.featuredImageUrId),
        imageCaption: body.imageCaption ?? existing.imageCaption,
        imageCredit: body.imageCredit ?? existing.imageCredit,
        imageCaptionUr: body.imageCaptionUr ?? existing.imageCaptionUr,
        imageCreditUr: body.imageCreditUr ?? existing.imageCreditUr,
        videoUrl: body.videoUrl === undefined ? existing.videoUrl : body.videoUrl,
        videoUrlUr: body.videoUrlUr === undefined ? existing.videoUrlUr : body.videoUrlUr,
        publishAt,
        publishedAt,
        archivedAt,
        unpublishedAt,
        seoTitle: body.seoTitle ?? existing.seoTitle,
        seoDescription: body.seoDescription ?? existing.seoDescription,
        seoTitleUr: body.seoTitleUr ?? existing.seoTitleUr,
        seoDescriptionUr: body.seoDescriptionUr ?? existing.seoDescriptionUr,
        focusKeyword: body.focusKeyword ?? existing.focusKeyword,
        focusKeywordUr: body.focusKeywordUr ?? existing.focusKeywordUr,
        searchKeywords: body.searchKeywords ?? existing.searchKeywords,
        searchKeywordsUr: body.searchKeywordsUr ?? existing.searchKeywordsUr,
        canonicalUrl: body.canonicalUrl ?? existing.canonicalUrl,
        robotsMeta: body.robotsMeta !== undefined
          ? body.robotsMeta || "index,follow"
          : existing.robotsMeta || "index,follow",
        ogTitle: body.ogTitle ?? existing.ogTitle,
        ogDescription: body.ogDescription ?? existing.ogDescription,
        ogTitleUr: body.ogTitleUr ?? existing.ogTitleUr,
        ogDescriptionUr: body.ogDescriptionUr ?? existing.ogDescriptionUr,
        ogImage:
          body.ogImage !== undefined
            ? sanitizePublicImageUrl(body.ogImage)
            : existing.ogImage,
        ogImageUr:
          body.ogImageUr !== undefined
            ? sanitizePublicImageUrl(body.ogImageUr)
            : existing.ogImageUr,
        schemaType: body.schemaType ?? existing.schemaType,
        isFeatured: body.isFeatured ?? existing.isFeatured,
        isBreaking: body.isBreaking ?? existing.isBreaking,
        updatedById: user.id,
        revisions: {
          create: {
            version: (lastRev?.version || 0) + 1,
            title: body.title ?? existing.title,
            body: body.body ?? existing.body,
            excerpt: body.excerpt ?? existing.excerpt,
            snapshot: JSON.stringify(body),
            note: body.revisionNote || body.action || "Update",
            userId: user.id,
          },
        },
      },
      include: articlePublicInclude,
    });

    if (status === "scheduled" && publishAt) {
      await enqueueJob("publish_article", { articleId: updated.id }, publishAt);
    }

    await writeAudit({
      userId: user.id,
      action: body.action || "update",
      module: "articles",
      recordId: updated.id,
      oldValue: { status: existing.status },
      newValue: { status: updated.status },
    });

    return serializeArticle(updated);
  });
}

export async function DELETE(req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const user = await requirePermission("articles", "delete");
    const { id } = await params;
    const hard = new URL(req.url).searchParams.get("hard") === "1";
    const existing = await prisma.article.findUnique({ where: { id } });
    if (!existing) throw new Error("Article not found");

    if (hard) {
      await prisma.article.delete({ where: { id } });
    } else {
      await prisma.article.update({
        where: { id },
        data: { deletedAt: new Date(), status: "archived", updatedById: user.id },
      });
    }
    await writeAudit({
      userId: user.id,
      action: hard ? "hard_delete" : "delete",
      module: "articles",
      recordId: id,
    });
    return { deleted: true };
  });
}
