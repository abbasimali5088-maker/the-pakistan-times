import { NextRequest } from "next/server";
import { z } from "zod";
import { getPagination, handleApi } from "@/lib/api";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { makeSlug, uniqueSlug } from "@/lib/slug";
import { HttpError } from "@/lib/http-error";

export const runtime = "nodejs";

const pageSchema = z.object({
  title: z.string().optional().nullable(),
  titleUr: z.string().optional().nullable(),
  slug: z.string().optional().nullable(),
  body: z.string().optional().nullable(),
  bodyUr: z.string().optional().nullable(),
  status: z.string().optional(),
  seoTitle: z.string().optional().nullable(),
  seoDescription: z.string().optional().nullable(),
  seoTitleUr: z.string().optional().nullable(),
  seoDescriptionUr: z.string().optional().nullable(),
  locale: z.enum(["en", "ur"]).optional(),
});

export async function GET(req: NextRequest) {
  return handleApi(async () => {
    const url = new URL(req.url);
    const publicOnly = url.searchParams.get("public") === "1";
    const slug = url.searchParams.get("slug");
    if (!publicOnly) await requirePermission("pages", "read");

    if (publicOnly && slug) {
      const item = await prisma.staticPage.findFirst({
        where: { slug, status: "published" },
      });
      if (!item) throw new Error("Page not found");
      return item;
    }

    const { skip, take, page, pageSize } = getPagination(url);
    const where = {
      status: publicOnly ? "published" : url.searchParams.get("status") || undefined,
      slug: slug || undefined,
    };
    const [total, items] = await Promise.all([
      prisma.staticPage.count({ where }),
      prisma.staticPage.findMany({ where, orderBy: { updatedAt: "desc" }, skip, take }),
    ]);
    return { items, total, page, pageSize };
  });
}

export async function POST(req: NextRequest) {
  return handleApi(async () => {
    try {
      const user = await requirePermission("pages", "create");
      const body = pageSchema.parse(await req.json());
      const locale = body.locale;
      const titleUr = (body.titleUr || "").trim() || null;
      const bodyUr = (body.bodyUr || "").trim() || null;
      let title = (body.title || "").trim() || null;
      let pageBody = (body.body || "").trim() || null;

      if (locale === "ur") {
        if (!titleUr) throw new HttpError("اردو عنوان ضروری ہے", 422);
        if (!bodyUr) throw new HttpError("اردو متن ضروری ہے", 422);
        // Shared required columns — seed from Urdu so EN front never invents copy.
        title = title || titleUr;
        pageBody = pageBody || bodyUr;
      } else {
        if (!title) throw new HttpError("English title is required", 422);
        if (!pageBody) throw new HttpError("English body is required", 422);
      }

      const baseSlug = makeSlug(body.slug || title!);
      const existing = await prisma.staticPage.findMany({
        where: { slug: { startsWith: baseSlug } },
        select: { slug: true },
      });
      const slug = uniqueSlug(
        baseSlug,
        existing.map((e) => e.slug),
      );
      const item = await prisma.staticPage.create({
        data: {
          title: title!,
          titleUr: locale === "en" ? null : titleUr,
          slug,
          body: pageBody!,
          bodyUr: locale === "en" ? null : bodyUr,
          status: body.status || "published",
          seoTitle: locale === "ur" ? null : body.seoTitle || null,
          seoDescription: locale === "ur" ? null : body.seoDescription || null,
          seoTitleUr: locale === "en" ? null : body.seoTitleUr || null,
          seoDescriptionUr: locale === "en" ? null : body.seoDescriptionUr || null,
        },
      });
      await writeAudit({ userId: user.id, action: "create", module: "pages", recordId: item.id });
      return item;
    } catch (err) {
      if (err instanceof z.ZodError) throw err;
      if (err instanceof HttpError) throw err;
      console.error("[POST /api/pages]", err);
      throw new HttpError(
        err instanceof Error ? err.message.slice(0, 300) : "Page save failed",
        500,
      );
    }
  });
}
