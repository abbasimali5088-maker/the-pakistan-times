import { NextRequest } from "next/server";
import { z } from "zod";
import { handleApi } from "@/lib/api";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { makeSlug } from "@/lib/slug";
import { HttpError } from "@/lib/http-error";

export const runtime = "nodejs";
type Params = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const { id } = await params;
    const url = new URL(req.url);
    const publicOnly = url.searchParams.get("public") === "1";
    const item = await prisma.staticPage.findFirst({
      where: {
        OR: [{ id }, { slug: id }],
        status: publicOnly ? "published" : undefined,
      },
    });
    if (!item) throw new Error("Page not found");
    if (!publicOnly) await requirePermission("pages", "read");
    return item;
  });
}

export async function PATCH(req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    try {
      const user = await requirePermission("pages", "update");
      const { id } = await params;
      const body = z
        .object({
          title: z.string().optional().nullable(),
          titleUr: z.string().optional().nullable(),
          slug: z.string().optional().nullable(),
          body: z.string().optional().nullable(),
          bodyUr: z.string().optional().nullable(),
          status: z.string().optional(),
          seoTitle: z.string().optional().nullable(),
          seoDescription: z.string().optional().nullable(),
          seoTitleUr: z.string().optional().nullable(),
          seoDescriptionUr: z.string().optional().nullable(),
          locale: z.enum(["en", "ur"]).optional(),
        })
        .parse(await req.json());
      const existing = await prisma.staticPage.findUnique({ where: { id } });
      if (!existing) throw new HttpError("Page not found", 404);

      const locale = body.locale;
      if (locale === "ur") {
        if (body.titleUr !== undefined && !(body.titleUr || "").trim()) {
          throw new HttpError("اردو عنوان ضروری ہے", 422);
        }
        if (body.bodyUr !== undefined && !(body.bodyUr || "").trim()) {
          throw new HttpError("اردو متن ضروری ہے", 422);
        }
      } else if (locale === "en") {
        if (body.title !== undefined && !(body.title || "").trim()) {
          throw new HttpError("English title is required", 422);
        }
        if (body.body !== undefined && !(body.body || "").trim()) {
          throw new HttpError("English body is required", 422);
        }
      }

      const item = await prisma.staticPage.update({
        where: { id },
        data: {
          // Locale hubs only patch their own language fields.
          title:
            locale === "ur"
              ? undefined
              : body.title === undefined
                ? undefined
                : body.title || existing.title,
          titleUr:
            locale === "en"
              ? undefined
              : body.titleUr === undefined
                ? undefined
                : body.titleUr,
          slug: body.slug ? makeSlug(body.slug) : undefined,
          body:
            locale === "ur"
              ? undefined
              : body.body === undefined
                ? undefined
                : body.body || existing.body,
          bodyUr:
            locale === "en"
              ? undefined
              : body.bodyUr === undefined
                ? undefined
                : body.bodyUr,
          status: body.status,
          seoTitle: locale === "ur" ? undefined : body.seoTitle,
          seoDescription: locale === "ur" ? undefined : body.seoDescription,
          seoTitleUr: locale === "en" ? undefined : body.seoTitleUr,
          seoDescriptionUr: locale === "en" ? undefined : body.seoDescriptionUr,
        },
      });
      await writeAudit({ userId: user.id, action: "update", module: "pages", recordId: id });
      return item;
    } catch (err) {
      if (err instanceof z.ZodError) throw err;
      if (err instanceof HttpError) throw err;
      console.error("[PATCH /api/pages/:id]", err);
      throw new HttpError(
        err instanceof Error ? err.message.slice(0, 300) : "Page update failed",
        500,
      );
    }
  });
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const user = await requirePermission("pages", "delete");
    const { id } = await params;
    await prisma.staticPage.delete({ where: { id } });
    await writeAudit({ userId: user.id, action: "delete", module: "pages", recordId: id });
    return { deleted: true };
  });
}
