import { NextRequest } from "next/server";
import { handleApi, getPagination } from "@/lib/api";
import { getLiveFeed } from "@/lib/public-api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Public LIVE feed for the homepage stream.
 * Returns published articles with priority=live (locale-aware).
 */
export async function GET(req: NextRequest) {
  return handleApi(async () => {
    const url = new URL(req.url);
    const language = url.searchParams.get("language") || undefined;
    const { pageSize } = getPagination(url);
    const items = await getLiveFeed({
      language: language === "en" || language === "ur" ? language : undefined,
      take: Math.min(pageSize, 20),
    });
    return { items, total: items.length };
  });
}
