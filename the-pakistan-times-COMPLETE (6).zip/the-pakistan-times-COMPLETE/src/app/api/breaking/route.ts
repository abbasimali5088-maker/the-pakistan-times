import { NextRequest } from "next/server";
import { z } from "zod";
import { getPagination, handleApi } from "@/lib/api";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { nullIfEmpty } from "@/lib/safe-ids";
import { HttpError } from "@/lib/http-error";
import { notifyBreakingSubscribers } from "@/lib/push";

export const runtime = "nodejs";

const createSchema = z.object({
  headline: z.string().optional().nullable(),
  headlineUr: z.string().optional().nullable(),
  priority: z.number().int().optional(),
  status: z.string().optional(),
  startAt: z.string().optional().nullable(),
  endAt: z.string().optional().nullable(),
  articleId: z.string().optional().nullable(),
  authorId: z.string().optional().nullable(),
  locale: z.enum(["en", "ur"]).optional(),
});

export async function GET(req: NextRequest) {
  return handleApi(async () => {
    const url = new URL(req.url);
    const publicOnly = url.searchParams.get("public") === "1";
    if (!publicOnly) await requirePermission("breaking", "read");
    const { skip, take, page, pageSize } = getPagination(url);
    const now = new Date();
    const where = publicOnly
      ? {
          status: "active",
          AND: [
            { OR: [{ startAt: null }, { startAt: { lte: now } }] },
            { OR: [{ endAt: null }, { endAt: { gte: now } }] },
          ],
        }
      : {
          status: url.searchParams.get("status") || undefined,
        };
    const [total, items] = await Promise.all([
      prisma.breakingNews.count({ where }),
      prisma.breakingNews.findMany({
        where,
        include: {
          article: { select: { id: true, title: true, slug: true } },
          approver: { select: { id: true, name: true } },
        },
        orderBy: [{ priority: "desc" }, { createdAt: "desc" }],
        skip,
        take,
      }),
    ]);
    return { items, total, page, pageSize };
  });
}

export async function POST(req: NextRequest) {
  return handleApi(async () => {
    try {
      const user = await requirePermission("breaking", "create");
      const body = createSchema.parse(await req.json());
      const locale = body.locale;
      const headlineUr = nullIfEmpty(body.headlineUr);
      let headline = nullIfEmpty(body.headline);

      if (locale === "ur") {
        if (!headlineUr) throw new HttpError("اردو عنوان ضروری ہے", 422);
        // DB requires headline NOT NULL — store Urdu text in both for UR-only rows
        // so English frontend never shows a fake EN string from this hub.
        headline = headlineUr;
      } else if (locale === "en") {
        if (!headline) throw new HttpError("English headline required", 422);
      } else {
        if (!headline) throw new HttpError("English headline required", 422);
      }

      const articleId = nullIfEmpty(body.articleId);
      const authorId = nullIfEmpty(body.authorId);

      if (articleId) {
        const art = await prisma.article.findUnique({
          where: { id: articleId },
          select: { id: true },
        });
        if (!art) throw new HttpError("Invalid linked article ID", 422);
      }

      const item = await prisma.breakingNews.create({
        data: {
          headline: headline!,
          headlineUr: locale === "en" ? null : headlineUr,
          priority: body.priority ?? 1,
          status: body.status || "draft",
          startAt: body.startAt ? new Date(body.startAt) : null,
          endAt: body.endAt ? new Date(body.endAt) : null,
          articleId,
          authorId,
        },
      });
      await writeAudit({
        userId: user.id,
        action: "create",
        module: "breaking",
        recordId: item.id,
      });
      if (item.status === "active") {
        const isUr = locale === "ur";
        // Link to the /breaking hub rather than a specific article slug —
        // we only have the linked article's ID here, not its slug/language
        // routing, and /breaking always resolves correctly for any reader.
        notifyBreakingSubscribers({
          title: isUr ? "بریکنگ نیوز" : "Breaking News",
          body: item.headline,
          url: "/breaking",
          lang: isUr ? "ur" : "en",
        }).catch((err) => console.error("[push] breaking notify failed:", err));
      }
      return item;
    } catch (err) {
      if (err instanceof z.ZodError) throw err;
      if (err instanceof HttpError) throw err;
      console.error("[POST /api/breaking]", err);
      throw new HttpError(
        err instanceof Error ? err.message.slice(0, 300) : "Breaking save failed",
        500,
      );
    }
  });
}
