import { NextRequest } from "next/server";
import { z } from "zod";
import { handleApi } from "@/lib/api";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { nullIfEmpty } from "@/lib/safe-ids";
import { HttpError } from "@/lib/http-error";
import { notifyBreakingSubscribers } from "@/lib/push";

export const runtime = "nodejs";
type Params = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    await requirePermission("breaking", "read");
    const { id } = await params;
    const item = await prisma.breakingNews.findUnique({
      where: { id },
      include: {
        article: { select: { id: true, title: true, slug: true } },
        approver: { select: { id: true, name: true } },
      },
    });
    if (!item) throw new Error("Breaking news not found");
    return item;
  });
}

export async function PATCH(req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    try {
      const user = await requirePermission("breaking", "update");
      const { id } = await params;
      const body = z
        .object({
          headline: z.string().optional().nullable(),
          headlineUr: z.string().optional().nullable(),
          priority: z.number().int().optional(),
          status: z.string().optional(),
          startAt: z.string().optional().nullable(),
          endAt: z.string().optional().nullable(),
          articleId: z.string().optional().nullable(),
          authorId: z.string().optional().nullable(),
          locale: z.enum(["en", "ur"]).optional(),
          action: z.enum(["activate", "deactivate"]).optional(),
        })
        .parse(await req.json());

      const existing = await prisma.breakingNews.findUnique({ where: { id } });
      if (!existing) throw new HttpError("Breaking news not found", 404);

      let status = body.status ?? existing.status;
      let approverId = existing.approverId;
      if (body.action === "activate") {
        await requirePermission("breaking", "approve");
        status = "active";
        approverId = user.id;
      }
      if (body.action === "deactivate") {
        status = "inactive";
      }

      const locale = body.locale;
      let headline = body.headline === undefined ? undefined : nullIfEmpty(body.headline);
      let headlineUr =
        body.headlineUr === undefined ? undefined : nullIfEmpty(body.headlineUr);

      if (locale === "ur") {
        if (headlineUr !== undefined && !headlineUr) {
          throw new HttpError("اردو عنوان ضروری ہے", 422);
        }
        if (headlineUr) headline = headlineUr;
      } else if (locale === "en") {
        if (headline !== undefined && !headline) {
          throw new HttpError("English headline required", 422);
        }
        if (headline !== undefined) headlineUr = null;
      }

      const articleId =
        body.articleId === undefined ? undefined : nullIfEmpty(body.articleId);
      const authorId =
        body.authorId === undefined ? undefined : nullIfEmpty(body.authorId);

      if (articleId) {
        const art = await prisma.article.findUnique({
          where: { id: articleId },
          select: { id: true },
        });
        if (!art) throw new HttpError("Invalid linked article ID", 422);
      }

      const item = await prisma.breakingNews.update({
        where: { id },
        data: {
          headline: headline === undefined ? undefined : headline || existing.headline,
          headlineUr: headlineUr === undefined ? undefined : headlineUr,
          priority: body.priority,
          status,
          startAt:
            body.startAt === undefined
              ? undefined
              : body.startAt
                ? new Date(body.startAt)
                : null,
          endAt:
            body.endAt === undefined
              ? undefined
              : body.endAt
                ? new Date(body.endAt)
                : null,
          articleId,
          authorId,
          approverId,
        },
      });
      await writeAudit({
        userId: user.id,
        action: body.action || "update",
        module: "breaking",
        recordId: id,
      });
      // Only notify on the transition INTO "active" (i.e. the activate
      // action), never on every plain edit — otherwise editors correcting
      // a typo would re-blast every subscriber.
      if (body.action === "activate") {
        const isUr = !!item.headlineUr && !item.headline?.trim();
        notifyBreakingSubscribers({
          title: isUr ? "بریکنگ نیوز" : "Breaking News",
          body: item.headline,
          url: "/breaking",
          lang: isUr ? "ur" : "en",
        }).catch((err) => console.error("[push] breaking notify failed:", err));
      }
      return item;
    } catch (err) {
      if (err instanceof z.ZodError) throw err;
      if (err instanceof HttpError) throw err;
      console.error("[PATCH /api/breaking/:id]", err);
      throw new HttpError(
        err instanceof Error ? err.message.slice(0, 300) : "Breaking update failed",
        500,
      );
    }
  });
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const user = await requirePermission("breaking", "delete");
    const { id } = await params;
    await prisma.breakingNews.delete({ where: { id } });
    await writeAudit({ userId: user.id, action: "delete", module: "breaking", recordId: id });
    return { deleted: true };
  });
}
