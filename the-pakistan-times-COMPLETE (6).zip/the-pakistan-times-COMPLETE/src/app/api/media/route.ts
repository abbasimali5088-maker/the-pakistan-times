import { NextRequest } from "next/server";
import { z } from "zod";
import { getPagination, handleApi } from "@/lib/api";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { persistMediaUrl } from "@/lib/media-persist";
import { HttpError } from "@/lib/http-error";

export const runtime = "nodejs";

const mediaSchema = z.object({
  filename: z.string().min(1),
  originalName: z.string().optional(),
  path: z.string().optional(),
  url: z.string().min(1),
  mimeType: z.string().optional(),
  size: z.number().int().nonnegative().optional(),
  width: z.number().int().optional().nullable(),
  height: z.number().int().optional().nullable(),
  alt: z.string().optional().nullable(),
  caption: z.string().optional().nullable(),
  credit: z.string().optional().nullable(),
  copyright: z.string().optional().nullable(),
  description: z.string().optional().nullable(),
  type: z.string().optional(),
  language: z.enum(["en", "ur"]).optional(),
  variants: z.string().optional().nullable(),
});

export async function GET(req: NextRequest) {
  return handleApi(async () => {
    const url = new URL(req.url);
    const publicOnly = url.searchParams.get("public") === "1";
    if (!publicOnly) await requirePermission("media", "read");
    const q = url.searchParams.get("q");
    const type = url.searchParams.get("type");
    const language = url.searchParams.get("language");
    const { skip, take, page, pageSize } = getPagination(url);
    const where = {
      deletedAt: null,
      type: type || undefined,
      language: language === "en" || language === "ur" ? language : undefined,
      OR: q
        ? [
            { filename: { contains: q } },
            { originalName: { contains: q } },
            { alt: { contains: q } },
            { caption: { contains: q } },
            { url: { contains: q } },
          ]
        : undefined,
    };
    const [total, items] = await Promise.all([
      prisma.media.count({ where }),
      prisma.media.findMany({
        where,
        include: { uploadedBy: { select: { id: true, name: true } } },
        orderBy: { createdAt: "desc" },
        skip,
        take,
      }),
    ]);
    return { items, total, page, pageSize, language: language || "all" };
  });
}

export async function POST(req: NextRequest) {
  return handleApi(async () => {
    const user = await requirePermission("media", "create");
    const body = mediaSchema.parse(await req.json());
    const filename = body.filename;
    const language = body.language === "ur" ? "ur" : "en";

    // Root-cause fix: never store raw data:image blobs in the DB.
    // Persist them to /public/uploads and keep a stable /uploads/… URL.
    let persisted;
    try {
      persisted = await persistMediaUrl(body.url, filename, body.mimeType);
    } catch (err) {
      throw new HttpError(
        err instanceof Error ? err.message : "Invalid image — upload a file or http(s) URL",
        422,
      );
    }

    const url = persisted.url;
    const mimeType = body.mimeType || persisted.mimeType || guessMime(url, filename);
    const type = body.type || mimeType.split("/")[0] || "image";
    const size = body.size && body.size > 0 ? body.size : persisted.size || 0;

    const item = await prisma.media.create({
      data: {
        filename,
        originalName: body.originalName || filename,
        path: body.path || persisted.path || url,
        url,
        mimeType,
        size,
        width: body.width,
        height: body.height,
        alt: body.alt,
        caption: body.caption,
        credit: body.credit,
        copyright: body.copyright,
        description: body.description,
        type,
        language,
        variants: body.variants,
        uploadedById: user.id,
      },
    });
    await writeAudit({ userId: user.id, action: "create", module: "media", recordId: item.id });
    return item;
  });
}

function guessMime(url: string, filename: string) {
  const name = (filename || url).toLowerCase();
  if (name.endsWith(".png")) return "image/png";
  if (name.endsWith(".jpg") || name.endsWith(".jpeg")) return "image/jpeg";
  if (name.endsWith(".gif")) return "image/gif";
  if (name.endsWith(".webp")) return "image/webp";
  if (name.endsWith(".mp4")) return "video/mp4";
  if (name.endsWith(".mp3")) return "audio/mpeg";
  if (name.endsWith(".pdf")) return "application/pdf";
  return "application/octet-stream";
}
