import { NextRequest } from "next/server";
import { z } from "zod";
import { handleApi, ok } from "@/lib/api";
import { requirePermission } from "@/lib/auth";
import { isDbCapacityError, prisma } from "@/lib/db";
import {
  countryLabel,
  dayKey,
  parseUserAgent,
  referrerChannel,
  referrerUrlKey,
  resolveBrowserOs,
  startOfDay,
  topCounts,
  channelCounts,
  emptyChannelCounts,
  looksLikeUserAgent,
} from "@/lib/analytics-ua";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const UNIQUE_WINDOW_MS = 12 * 60 * 60 * 1000; // 12 hours

function countryFromHeaders(req: NextRequest): string | null {
  const h = req.headers;
  const code =
    h.get("x-vercel-ip-country") ||
    h.get("cf-ipcountry") ||
    h.get("x-country-code") ||
    "";
  const c = code.trim().toUpperCase();
  if (!c || c === "XX" || c === "T1") return null;
  return c.slice(0, 8);
}

function normalizeClientHints(input: {
  device?: string | null;
  browser?: string | null;
}): { device: string | null; browser: string | null; uaRaw: string | null } {
  const deviceIn = input.device?.trim() || null;
  const browserIn = input.browser?.trim() || null;
  const uaRaw = looksLikeUserAgent(deviceIn)
    ? deviceIn
    : looksLikeUserAgent(browserIn)
      ? browserIn
      : null;

  if (uaRaw) {
    const parsed = parseUserAgent(uaRaw);
    // Prefer explicit short labels from client when not a language tag / UA dump
    const browser =
      browserIn && browserIn.length < 40 && !looksLikeUserAgent(browserIn) && !/^[a-z]{2}(-|$)/i.test(browserIn)
        ? browserIn
        : parsed.browser;
    const device =
      deviceIn && deviceIn.length < 40 && !looksLikeUserAgent(deviceIn)
        ? deviceIn
        : parsed.os;
    return { device, browser, uaRaw };
  }

  return {
    device: deviceIn?.slice(0, 80) || null,
    browser: browserIn?.slice(0, 80) || null,
    uaRaw: null,
  };
}

export async function POST(req: NextRequest) {
  try {
    const body = z
      .object({
        eventType: z.string().min(1),
        path: z.string().optional().nullable(),
        articleId: z.string().optional().nullable(),
        referrer: z.string().optional().nullable(),
        country: z.string().optional().nullable(),
        device: z.string().optional().nullable(),
        browser: z.string().optional().nullable(),
        source: z.string().optional().nullable(),
        meta: z.record(z.string(), z.unknown()).optional().nullable(),
      })
      .parse(await req.json());

    const isArticleView =
      body.eventType === "article_view" && Boolean(body.articleId?.trim());
    const articleId = body.articleId?.trim() || null;
    const visitor =
      typeof body.meta?.visitor === "string" ? body.meta.visitor.trim().slice(0, 80) : "";

    const hints = normalizeClientHints({
      device: body.device,
      browser: body.browser,
    });
    const country =
      (body.country?.trim().toUpperCase().slice(0, 8) || null) || countryFromHeaders(req);

    const metaJson = JSON.stringify({
      ...(body.meta || {}),
      visitor: visitor || undefined,
      ua: hints.uaRaw?.slice(0, 220) || undefined,
    });

    if (isArticleView && articleId) {
      const article = await prisma.article.findFirst({
        where: { id: articleId, deletedAt: null, status: "published" },
        select: { id: true },
      });
      if (!article) {
        return ok({ skipped: true, reason: "article_not_found" });
      }

      if (visitor) {
        const since = new Date(Date.now() - UNIQUE_WINDOW_MS);
        const prior = await prisma.analyticsEvent.findFirst({
          where: {
            eventType: "article_view",
            articleId,
            createdAt: { gte: since },
            metaJson: { contains: `"visitor":"${visitor}"` },
          },
          select: { id: true },
        });
        if (prior) {
          return ok({ skipped: true, reason: "duplicate", recorded: false });
        }
      }

      const [item] = await prisma.$transaction([
        prisma.analyticsEvent.create({
          data: {
            eventType: "article_view",
            path: body.path || null,
            articleId,
            referrer: body.referrer?.slice(0, 500) || null,
            country,
            device: hints.device,
            browser: hints.browser,
            source: body.source || "web",
            metaJson,
          },
        }),
        prisma.article.update({
          where: { id: articleId },
          data: { viewCount: { increment: 1 } },
        }),
      ]);

      return ok({ id: item.id, recorded: true });
    }

    const item = await prisma.analyticsEvent.create({
      data: {
        eventType: body.eventType,
        path: body.path,
        articleId,
        referrer: body.referrer?.slice(0, 500) || null,
        country,
        device: hints.device,
        browser: hints.browser,
        source: body.source,
        metaJson: body.meta || hints.uaRaw ? metaJson : null,
      },
    });
    return ok({ id: item.id, recorded: true });
  } catch (err) {
    if (isDbCapacityError(err) || err instanceof z.ZodError) {
      return ok({ skipped: true });
    }
    console.error("[analytics/POST]", err);
    return ok({ skipped: true });
  }
}

export async function GET(req: NextRequest) {
  return handleApi(async () => {
    await requirePermission("analytics", "read");
    const url = new URL(req.url);
    const days = Math.min(90, Math.max(1, Number(url.searchParams.get("days") || 7)));
    const langParam = url.searchParams.get("language");
    const language =
      langParam === "en" || langParam === "ur" ? langParam : null;
    const since = new Date(Date.now() - days * 24 * 60 * 60_000);
    const viewTypes = ["article_view", "pageview"];

    const now = new Date();
    const todayStart = startOfDay(now);
    const yesterdayStart = new Date(todayStart.getTime() - 24 * 60 * 60_000);
    const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
    const lastMonthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 1));
    const lastMonthEnd = monthStart;

    // Language isolation: only count events tied to articles of this language.
    // Pageviews without articleId are excluded when language is set (property-level split).
    const langArticleIds = language
      ? (
          await prisma.article.findMany({
            where: { language, deletedAt: null },
            select: { id: true },
          })
        ).map((a) => a.id)
      : null;

    const eventWhereBase = {
      eventType: { in: viewTypes },
      ...(langArticleIds
        ? { articleId: { in: langArticleIds.length ? langArticleIds : ["__none__"] } }
        : {}),
    };

    const [
      periodEvents,
      allTimeViews,
      todayViews,
      yesterdayViews,
      monthViews,
      lastMonthViews,
      articleViewsPeriod,
      pageViewsPeriod,
      totalEventsPeriod,
      byType,
      topArticles,
      recent,
      topByViewCount,
      postCount,
      commentCount,
      latestArticle,
    ] = await Promise.all([
      prisma.analyticsEvent.findMany({
        where: {
          createdAt: { gte: since },
          ...eventWhereBase,
        },
        select: {
          eventType: true,
          articleId: true,
          referrer: true,
          country: true,
          device: true,
          browser: true,
          createdAt: true,
        },
        orderBy: { createdAt: "asc" },
        take: 20000,
      }),
      prisma.analyticsEvent.count({ where: eventWhereBase }),
      prisma.analyticsEvent.count({
        where: { ...eventWhereBase, createdAt: { gte: todayStart } },
      }),
      prisma.analyticsEvent.count({
        where: {
          ...eventWhereBase,
          createdAt: { gte: yesterdayStart, lt: todayStart },
        },
      }),
      prisma.analyticsEvent.count({
        where: { ...eventWhereBase, createdAt: { gte: monthStart } },
      }),
      prisma.analyticsEvent.count({
        where: {
          ...eventWhereBase,
          createdAt: { gte: lastMonthStart, lt: lastMonthEnd },
        },
      }),
      prisma.analyticsEvent.count({
        where: {
          createdAt: { gte: since },
          eventType: "article_view",
          ...(langArticleIds
            ? { articleId: { in: langArticleIds.length ? langArticleIds : ["__none__"] } }
            : {}),
        },
      }),
      prisma.analyticsEvent.count({
        where: {
          createdAt: { gte: since },
          eventType: "pageview",
          // When language-split, pageviews without article stay out of property totals
          ...(language ? { articleId: { in: ["__none__"] } } : {}),
        },
      }),
      prisma.analyticsEvent.count({
        where: { createdAt: { gte: since }, ...eventWhereBase },
      }),
      prisma.analyticsEvent.groupBy({
        by: ["eventType"],
        where: { createdAt: { gte: since }, ...eventWhereBase },
        _count: { _all: true },
        orderBy: { _count: { eventType: "desc" } },
      }),
      prisma.analyticsEvent.groupBy({
        by: ["articleId"],
        where: {
          createdAt: { gte: since },
          eventType: "article_view",
          articleId: langArticleIds
            ? { in: langArticleIds.length ? langArticleIds : ["__none__"] }
            : { not: null },
        },
        _count: { _all: true },
        orderBy: { _count: { articleId: "desc" } },
        take: 25,
      }),
      prisma.analyticsEvent.findMany({
        where: { createdAt: { gte: since }, ...eventWhereBase },
        orderBy: { createdAt: "desc" },
        take: 40,
      }),
      prisma.article.findMany({
        where: { deletedAt: null, ...(language ? { language } : {}) },
        select: {
          id: true,
          title: true,
          titleUr: true,
          slug: true,
          language: true,
          viewCount: true,
          status: true,
          publishedAt: true,
          updatedAt: true,
          author: { select: { name: true } },
          featuredImage: { select: { url: true } },
          featuredImageUr: { select: { url: true } },
          _count: { select: { comments: true } },
        },
        orderBy: { viewCount: "desc" },
        take: 40,
      }),
      prisma.article.count({
        where: { deletedAt: null, ...(language ? { language } : {}) },
      }),
      language
        ? prisma.comment.count({
            where: { article: { language, deletedAt: null } },
          })
        : prisma.comment.count(),
      prisma.article.findFirst({
        where: {
          deletedAt: null,
          status: "published",
          ...(language ? { language } : {}),
        },
        orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
        select: {
          id: true,
          title: true,
          titleUr: true,
          slug: true,
          language: true,
          viewCount: true,
          publishedAt: true,
          author: { select: { name: true } },
          featuredImage: { select: { url: true } },
          featuredImageUr: { select: { url: true } },
          _count: { select: { comments: true } },
        },
      }),
    ]);

    const countries = new Map<string, number>();
    const browsers = new Map<string, number>();
    const systems = new Map<string, number>();
    const referrers = emptyChannelCounts();
    const referrerUrls = new Map<string, number>();
    const daily = new Map<string, number>();

    // seed empty days
    for (let i = days - 1; i >= 0; i -= 1) {
      const d = new Date(todayStart.getTime() - i * 24 * 60 * 60_000);
      daily.set(dayKey(d), 0);
    }

    for (const e of periodEvents) {
      const { browser, os } = resolveBrowserOs(e);
      browsers.set(browser, (browsers.get(browser) || 0) + 1);
      systems.set(os, (systems.get(os) || 0) + 1);
      countries.set(
        countryLabel(e.country),
        (countries.get(countryLabel(e.country)) || 0) + 1,
      );
      const channel = referrerChannel(e.referrer);
      referrers.set(channel, (referrers.get(channel) || 0) + 1);
      const urlKey = referrerUrlKey(e.referrer);
      referrerUrls.set(urlKey, (referrerUrls.get(urlKey) || 0) + 1);
      const dk = dayKey(e.createdAt);
      if (daily.has(dk)) daily.set(dk, (daily.get(dk) || 0) + 1);
    }

    const dailySeries = [...daily.entries()].map(([date, count]) => ({ date, count }));
    const periodViews = periodEvents.length;

    const articleIds = topArticles.map((t) => t.articleId!).filter(Boolean);
    const articles = articleIds.length
      ? await prisma.article.findMany({
          where: { id: { in: articleIds } },
          select: {
            id: true,
            title: true,
            titleUr: true,
            slug: true,
            viewCount: true,
            language: true,
            featuredImage: { select: { url: true } },
            featuredImageUr: { select: { url: true } },
            author: { select: { name: true } },
          },
        })
      : [];
    const articleMap = Object.fromEntries(articles.map((a) => [a.id, a]));

    const topArticlesMapped = topArticles.map((r) => ({
      articleId: r.articleId,
      count: r._count._all,
      article: r.articleId ? articleMap[r.articleId] || null : null,
    }));

    // Per-article daily for latest post
    let latestDaily: Array<{ date: string; count: number }> = [];
    if (latestArticle) {
      const latestMap = new Map<string, number>();
      for (let i = days - 1; i >= 0; i -= 1) {
        const d = new Date(todayStart.getTime() - i * 24 * 60 * 60_000);
        latestMap.set(dayKey(d), 0);
      }
      for (const e of periodEvents) {
        if (e.articleId === latestArticle.id && e.eventType === "article_view") {
          const dk = dayKey(e.createdAt);
          if (latestMap.has(dk)) latestMap.set(dk, (latestMap.get(dk) || 0) + 1);
        }
      }
      latestDaily = [...latestMap.entries()].map(([date, count]) => ({ date, count }));
    }

    const posts = topByViewCount.map((a) => ({
      id: a.id,
      title: a.title,
      titleUr: a.titleUr,
      slug: a.slug,
      language: a.language,
      viewCount: a.viewCount,
      status: a.status,
      publishedAt: a.publishedAt,
      updatedAt: a.updatedAt,
      authorName: a.author?.name || "The Pakistan Times",
      comments: a._count.comments,
      thumb:
        (a.language === "ur"
          ? a.featuredImageUr?.url
          : a.featuredImage?.url) ||
        a.featuredImage?.url ||
        a.featuredImageUr?.url ||
        null,
    }));

    return {
      days,
      language: language || "all",
      property:
        language === "ur"
          ? "urdu.thepakistantimes.live"
          : language === "en"
            ? "www.thepakistantimes.live"
            : "all",
      totals: {
        page_views: pageViewsPeriod,
        article_views: articleViewsPeriod,
        total_events: totalEventsPeriod,
        period_views: periodViews,
        days,
      },
      stats: {
        page_views: pageViewsPeriod,
        article_views: articleViewsPeriod,
        total_events: totalEventsPeriod,
      },
      summary: {
        allTime: allTimeViews,
        today: todayViews,
        yesterday: yesterdayViews,
        thisMonth: monthViews,
        lastMonth: lastMonthViews,
        posts: postCount,
        comments: commentCount,
        periodViews,
      },
      audience: {
        countries: topCounts(countries, 12),
        browsers: topCounts(browsers, 8),
        operatingSystems: topCounts(systems, 8),
        /** Fixed channels: Google, Facebook, Instagram, WhatsApp, Blogger, … */
        referrers: channelCounts(referrers),
        channels: channelCounts(referrers),
        referrerUrls: topCounts(referrerUrls, 15),
      },
      dailySeries,
      latestPost: latestArticle
        ? {
            id: latestArticle.id,
            title: latestArticle.title,
            titleUr: latestArticle.titleUr,
            slug: latestArticle.slug,
            language: latestArticle.language,
            viewCount: latestArticle.viewCount,
            publishedAt: latestArticle.publishedAt,
            authorName: latestArticle.author?.name || "The Pakistan Times",
            comments: latestArticle._count.comments,
            thumb:
              latestArticle.featuredImage?.url ||
              latestArticle.featuredImageUr?.url ||
              null,
            daily: latestDaily,
          }
        : null,
      posts,
      events: recent,
      items: recent,
      byType: byType.map((r) => ({ eventType: r.eventType, count: r._count._all })),
      topArticles: topArticlesMapped,
      articlesByViews: topByViewCount.map((a) => ({
        id: a.id,
        title: a.title,
        titleUr: a.titleUr,
        slug: a.slug,
        language: a.language,
        viewCount: a.viewCount,
        status: a.status,
      })),
      totalEvents: totalEventsPeriod,
      recent,
    };
  });
}
