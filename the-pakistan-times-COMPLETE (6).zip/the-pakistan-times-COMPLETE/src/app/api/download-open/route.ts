import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Disabled — previously served bookmark HTML that could leak credentials. */
export async function GET() {
  return NextResponse.json({ success: false, error: "Not found" }, { status: 404 });
}
