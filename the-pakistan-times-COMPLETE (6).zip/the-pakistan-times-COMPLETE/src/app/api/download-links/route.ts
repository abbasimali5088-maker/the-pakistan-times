import { NextRequest, NextResponse } from "next/server";
import { createReadStream, existsSync, statSync } from "fs";
import { readFile } from "fs/promises";
import path from "path";
import { Readable } from "stream";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Safe Front / Backend launcher + zip downloads.
 * application/octet-stream + Content-Disposition: attachment so mobile
 * browsers SAVE the file instead of opening it.
 */
const ALLOWED: Record<
  string,
  { file: string; downloadName: string; mime: string }
> = {
  front: {
    file: "FRONTEND.html",
    downloadName: "PT-FRONTEND.html",
    mime: "application/octet-stream",
  },
  frontend: {
    file: "FRONTEND.html",
    downloadName: "PT-FRONTEND.html",
    mime: "application/octet-stream",
  },
  back: {
    file: "BACKEND.html",
    downloadName: "PT-BACKEND.html",
    mime: "application/octet-stream",
  },
  backend: {
    file: "BACKEND.html",
    downloadName: "PT-BACKEND.html",
    mime: "application/octet-stream",
  },
  both: {
    file: "FRONT-BACKEND.html",
    downloadName: "PT-FRONT-BACKEND.html",
    mime: "application/octet-stream",
  },
  all: {
    file: "FRONT-BACKEND.html",
    downloadName: "PT-FRONT-BACKEND.html",
    mime: "application/octet-stream",
  },
  zip: {
    file: "PT-FRONT-BACKEND-files.zip",
    downloadName: "PT-FRONT-BACKEND-files.zip",
    mime: "application/zip",
  },
  files: {
    file: "PT-FRONT-BACKEND-files.zip",
    downloadName: "PT-FRONT-BACKEND-files.zip",
    mime: "application/zip",
  },
  complete: {
    file: "the-pakistan-times-COMPLETE.zip",
    downloadName: "the-pakistan-times-COMPLETE.zip",
    mime: "application/zip",
  },
  project: {
    file: "the-pakistan-times-COMPLETE.zip",
    downloadName: "the-pakistan-times-COMPLETE.zip",
    mime: "application/zip",
  },
};

export async function GET(req: NextRequest) {
  const want = (req.nextUrl.searchParams.get("file") || "both").toLowerCase();
  const entry = ALLOWED[want];
  if (!entry) {
    return NextResponse.json(
      {
        success: false,
        error: "Unknown file. Use ?file=front | back | both | zip | complete",
      },
      { status: 400 },
    );
  }

  const full = path.join(process.cwd(), "public", "download", entry.file);
  if (!existsSync(full)) {
    return NextResponse.json(
      { success: false, error: `File missing: ${entry.file}` },
      { status: 404 },
    );
  }

  try {
    const isZip = entry.mime === "application/zip";
    if (isZip) {
      const size = statSync(full).size;
      const stream = createReadStream(full);
      const webStream = Readable.toWeb(stream) as unknown as ReadableStream;
      return new NextResponse(webStream, {
        status: 200,
        headers: {
          "Content-Type": "application/zip",
          "Content-Length": String(size),
          "Content-Disposition": `attachment; filename="${entry.downloadName}"; filename*=UTF-8''${encodeURIComponent(entry.downloadName)}`,
          "Cache-Control": "no-store, no-cache, must-revalidate",
          "X-Content-Type-Options": "nosniff",
        },
      });
    }

    const html = await readFile(full, "utf8");
    const bytes = Buffer.from(html, "utf8");
    return new NextResponse(bytes, {
      status: 200,
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Length": String(bytes.length),
        "Content-Disposition": `attachment; filename="${entry.downloadName}"; filename*=UTF-8''${encodeURIComponent(entry.downloadName)}`,
        "Cache-Control": "no-store, no-cache, must-revalidate",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch {
    return NextResponse.json({ success: false, error: "Read failed" }, { status: 500 });
  }
}
