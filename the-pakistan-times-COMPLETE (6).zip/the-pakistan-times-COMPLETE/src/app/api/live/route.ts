import { NextRequest } from "next/server";
import { z } from "zod";
import { getPagination, handleApi } from "@/lib/api";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { makeSlug, uniqueSlug } from "@/lib/slug";
import { nullIfEmpty } from "@/lib/safe-ids";
import { HttpError } from "@/lib/http-error";
import { liveStoryMatchesLang } from "@/lib/language";

export const runtime = "nodejs";

const storySchema = z.object({
  title: z.string().optional().nullable(),
  titleUr: z.string().optional().nullable(),
  slug: z.string().optional().nullable(),
  slugUr: z.string().optional().nullable(),
  description: z.string().optional().nullable(),
  descriptionUr: z.string().optional().nullable(),
  authorId: z.string().optional().nullable(),
  categoryId: z.string().optional().nullable(),
  status: z.string().optional(),
  startAt: z.string().optional().nullable(),
  endAt: z.string().optional().nullable(),
  locale: z.enum(["en", "ur"]).optional(),
});

export async function GET(req: NextRequest) {
  return handleApi(async () => {
    const url = new URL(req.url);
    const publicOnly = url.searchParams.get("public") === "1";
    if (!publicOnly) await requirePermission("live", "read");
    const { skip, take, page, pageSize } = getPagination(url);
    const languageParam = url.searchParams.get("language") || url.searchParams.get("locale");
    const language =
      languageParam === "en" || languageParam === "ur" ? languageParam : null;
    const where = {
      status: publicOnly ? "live" : url.searchParams.get("status") || undefined,
    };
    const [totalAll, rawItems] = await Promise.all([
      prisma.liveStory.count({ where }),
      prisma.liveStory.findMany({
        where,
        include: {
          category: true,
          _count: { select: { updates: true } },
        },
        orderBy: { updatedAt: "desc" },
        // When filtering by language we may need more rows before script filter.
        skip: language ? 0 : skip,
        take: language ? Math.min(500, skip + take + 50) : take,
      }),
    ]);

    const filtered = language
      ? rawItems.filter((row) => liveStoryMatchesLang(row, language))
      : rawItems;
    const total = language ? filtered.length : totalAll;
    const items = language ? filtered.slice(skip, skip + take) : filtered;

    return { items, total, page, pageSize };
  });
}

export async function POST(req: NextRequest) {
  return handleApi(async () => {
    try {
      const user = await requirePermission("live", "create");
      const body = storySchema.parse(await req.json());
      const locale = body.locale;
      const titleUr = nullIfEmpty(body.titleUr);
      let title = nullIfEmpty(body.title);

      if (locale === "ur") {
        if (!titleUr) throw new HttpError("اردو عنوان ضروری ہے", 422);
        title = titleUr;
      } else if (locale === "en") {
        if (!title) throw new HttpError("English title required", 422);
      } else {
        if (!title) throw new HttpError("English title required", 422);
      }

      const slugSource = nullIfEmpty(body.slug) || title!;
      const baseSlug = makeSlug(slugSource) || `live-${Date.now()}`;
      const existing = await prisma.liveStory.findMany({
        where: { slug: { startsWith: baseSlug } },
        select: { slug: true },
      });
      const slug = uniqueSlug(
        baseSlug,
        existing.map((e) => e.slug),
      );

      const item = await prisma.liveStory.create({
        data: {
          title: title!,
          titleUr: locale === "en" ? null : titleUr,
          slug,
          slugUr: nullIfEmpty(body.slugUr) ? makeSlug(body.slugUr!) : null,
          description: locale === "ur" ? null : nullIfEmpty(body.description),
          descriptionUr: locale === "en" ? null : nullIfEmpty(body.descriptionUr),
          authorId: nullIfEmpty(body.authorId),
          categoryId: nullIfEmpty(body.categoryId),
          status: body.status || "draft",
          startAt: body.startAt ? new Date(body.startAt) : null,
          endAt: body.endAt ? new Date(body.endAt) : null,
        },
      });
      await writeAudit({ userId: user.id, action: "create", module: "live", recordId: item.id });
      return item;
    } catch (err) {
      if (err instanceof z.ZodError) throw err;
      if (err instanceof HttpError) throw err;
      console.error("[POST /api/live]", err);
      throw new HttpError(
        err instanceof Error ? err.message.slice(0, 300) : "Live story save failed",
        500,
      );
    }
  });
}
