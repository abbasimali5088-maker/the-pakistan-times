import { NextRequest } from "next/server";
import { z } from "zod";
import { handleApi } from "@/lib/api";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { makeSlug } from "@/lib/slug";
import { nullIfEmpty } from "@/lib/safe-ids";
import { HttpError } from "@/lib/http-error";

export const runtime = "nodejs";
type Params = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const { id } = await params;
    const url = new URL(req.url);
    const publicOnly = url.searchParams.get("public") === "1";
    const item = await prisma.liveStory.findFirst({
      where: { OR: [{ id }, { slug: id }] },
      include: {
        category: true,
        updates: {
          where: publicOnly ? { status: "published" } : undefined,
          orderBy: [{ isPinned: "desc" }, { publishedAt: "desc" }],
        },
      },
    });
    if (!item) throw new Error("Live story not found");
    if (publicOnly && item.status !== "live") throw new Error("Live story not found");
    if (!publicOnly) await requirePermission("live", "read");
    return item;
  });
}

export async function PATCH(req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    try {
      const user = await requirePermission("live", "update");
      const { id } = await params;
      const body = z
        .object({
          title: z.string().optional().nullable(),
          titleUr: z.string().optional().nullable(),
          slug: z.string().optional().nullable(),
          slugUr: z.string().optional().nullable(),
          description: z.string().optional().nullable(),
          descriptionUr: z.string().optional().nullable(),
          authorId: z.string().optional().nullable(),
          categoryId: z.string().optional().nullable(),
          status: z.string().optional(),
          startAt: z.string().optional().nullable(),
          endAt: z.string().optional().nullable(),
          locale: z.enum(["en", "ur"]).optional(),
        })
        .parse(await req.json());
      const existing = await prisma.liveStory.findUnique({ where: { id } });
      if (!existing) throw new HttpError("Live story not found", 404);

      const locale = body.locale;
      let title = body.title === undefined ? undefined : nullIfEmpty(body.title);
      let titleUr = body.titleUr === undefined ? undefined : nullIfEmpty(body.titleUr);

      if (locale === "ur") {
        if (titleUr !== undefined && !titleUr) throw new HttpError("اردو عنوان ضروری ہے", 422);
        if (titleUr) title = titleUr;
      } else if (locale === "en") {
        if (title !== undefined && !title) throw new HttpError("English title required", 422);
        if (title !== undefined) titleUr = null;
      }

      const item = await prisma.liveStory.update({
        where: { id },
        data: {
          title: title === undefined ? undefined : title || existing.title,
          titleUr: titleUr === undefined ? undefined : titleUr,
          slug: body.slug ? makeSlug(body.slug) : undefined,
          slugUr:
            body.slugUr === undefined
              ? undefined
              : body.slugUr
                ? makeSlug(body.slugUr)
                : null,
          description:
            body.description === undefined
              ? undefined
              : locale === "ur"
                ? null
                : nullIfEmpty(body.description),
          descriptionUr:
            body.descriptionUr === undefined
              ? undefined
              : locale === "en"
                ? null
                : nullIfEmpty(body.descriptionUr),
          authorId:
            body.authorId === undefined ? undefined : nullIfEmpty(body.authorId),
          categoryId:
            body.categoryId === undefined ? undefined : nullIfEmpty(body.categoryId),
          status: body.status,
          startAt:
            body.startAt === undefined
              ? undefined
              : body.startAt
                ? new Date(body.startAt)
                : null,
          endAt:
            body.endAt === undefined
              ? undefined
              : body.endAt
                ? new Date(body.endAt)
                : null,
        },
      });
      await writeAudit({ userId: user.id, action: "update", module: "live", recordId: id });
      return item;
    } catch (err) {
      if (err instanceof z.ZodError) throw err;
      if (err instanceof HttpError) throw err;
      console.error("[PATCH /api/live/:id]", err);
      throw new HttpError(
        err instanceof Error ? err.message.slice(0, 300) : "Live story update failed",
        500,
      );
    }
  });
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const user = await requirePermission("live", "delete");
    const { id } = await params;
    await prisma.liveStory.delete({ where: { id } });
    await writeAudit({ userId: user.id, action: "delete", module: "live", recordId: id });
    return { deleted: true };
  });
}
