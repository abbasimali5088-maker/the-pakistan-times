import { NextRequest } from "next/server";
import { z } from "zod";
import { handleApi } from "@/lib/api";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { makeSlug } from "@/lib/slug";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  return handleApi(async () => {
    const url = new URL(req.url);
    const publicOnly = url.searchParams.get("public") === "1";
    if (!publicOnly) await requirePermission("categories", "read");
    const parentId = url.searchParams.get("parentId");
    const language = url.searchParams.get("language");
    const items = await prisma.category.findMany({
      where: {
        status: publicOnly ? "active" : undefined,
        parentId: parentId === "null" ? null : parentId || undefined,
        language: language === "en" || language === "ur" ? language : undefined,
      },
      include: {
        children: { orderBy: { sortOrder: "asc" } },
        image: true,
        imageUr: true,
        _count: { select: { articles: true } },
      },
      orderBy: { sortOrder: "asc" },
    });
    return {
      items: items.map((c) => ({
        ...c,
        nameEn: c.name,
        imageUrl: c.image?.url || null,
        imageUrlUr: c.imageUr?.url || null,
        children: (c.children || []).map((ch) => ({ ...ch, nameEn: ch.name })),
      })),
    };
  });
}

export async function POST(req: NextRequest) {
  return handleApi(async () => {
    const user = await requirePermission("categories", "create");
    const body = z
      .object({
        name: z.string().min(1),
        nameUr: z.string().optional().nullable(),
        slug: z.string().optional(),
        description: z.string().optional().nullable(),
        descriptionUr: z.string().optional().nullable(),
        language: z.enum(["en", "ur"]).optional(),
        imageId: z.string().optional().nullable(),
        imageUrId: z.string().optional().nullable(),
        parentId: z.string().optional().nullable(),
        sortOrder: z.number().optional(),
        status: z.string().optional(),
        seoTitle: z.string().optional().nullable(),
        seoDescription: z.string().optional().nullable(),
        seoTitleUr: z.string().optional().nullable(),
        seoDescriptionUr: z.string().optional().nullable(),
        siteId: z.string().optional().nullable(),
      })
      .parse(await req.json());
    const language = body.language === "ur" ? "ur" : "en";
    // Urdu tree: keep name + nameUr in sync so public pickText never mixes locales.
    const nameUr =
      language === "ur" ? body.nameUr || body.name : body.nameUr || null;
    const item = await prisma.category.create({
      data: {
        name: body.name,
        nameUr,
        slug: makeSlug(body.slug || body.name),
        description: language === "en" ? body.description : null,
        descriptionUr: language === "ur" ? body.descriptionUr || body.description : body.descriptionUr,
        language,
        imageId: language === "en" ? body.imageId : null,
        imageUrId: language === "ur" ? body.imageUrId || body.imageId : body.imageUrId,
        parentId: body.parentId,
        sortOrder: body.sortOrder || 0,
        status: body.status || "active",
        seoTitle: language === "en" ? body.seoTitle : null,
        seoDescription: language === "en" ? body.seoDescription : null,
        seoTitleUr: language === "ur" ? body.seoTitleUr || body.seoTitle : body.seoTitleUr,
        seoDescriptionUr:
          language === "ur" ? body.seoDescriptionUr || body.seoDescription : body.seoDescriptionUr,
        siteId: body.siteId,
      },
      include: { image: true, imageUr: true },
    });
    await writeAudit({ userId: user.id, action: "create", module: "categories", recordId: item.id });
    return item;
  });
}
