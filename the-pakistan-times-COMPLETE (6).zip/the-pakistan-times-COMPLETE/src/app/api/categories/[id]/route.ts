import { NextRequest } from "next/server";
import { z } from "zod";
import { handleApi } from "@/lib/api";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { makeSlug } from "@/lib/slug";

export const runtime = "nodejs";
type Params = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const { id } = await params;
    const url = new URL(req.url);
    const publicOnly = url.searchParams.get("public") === "1";
    if (!publicOnly) await requirePermission("categories", "read");
    const item = await prisma.category.findFirst({
      where: {
        OR: [{ id }, { slug: id }],
        ...(publicOnly ? { status: "active" } : {}),
      },
      include: { children: true, parent: true },
    });
    if (!item) throw new Error("Category not found");
    return item;
  });
}

export async function PATCH(req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const user = await requirePermission("categories", "update");
    const { id } = await params;
    const body = z
      .object({
        name: z.string().optional(),
        nameUr: z.string().optional().nullable(),
        slug: z.string().optional(),
        description: z.string().optional().nullable(),
        descriptionUr: z.string().optional().nullable(),
        language: z.enum(["en", "ur"]).optional(),
        imageId: z.string().optional().nullable(),
        imageUrId: z.string().optional().nullable(),
        parentId: z.string().optional().nullable(),
        sortOrder: z.number().optional(),
        status: z.string().optional(),
        seoTitle: z.string().optional().nullable(),
        seoDescription: z.string().optional().nullable(),
        seoTitleUr: z.string().optional().nullable(),
        seoDescriptionUr: z.string().optional().nullable(),
      })
      .parse(await req.json());
    const language = body.language === "ur" ? "ur" : body.language === "en" ? "en" : undefined;
    const item = await prisma.category.update({
      where: { id },
      data: {
        ...body,
        ...(language === "ur" && body.name
          ? { nameUr: body.nameUr || body.name }
          : {}),
        slug: body.slug ? makeSlug(body.slug) : undefined,
      },
      include: { image: true, imageUr: true },
    });
    await writeAudit({ userId: user.id, action: "update", module: "categories", recordId: id });
    return item;
  });
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  return handleApi(async () => {
    const user = await requirePermission("categories", "delete");
    const { id } = await params;
    await prisma.category.delete({ where: { id } });
    await writeAudit({ userId: user.id, action: "delete", module: "categories", recordId: id });
    return { deleted: true };
  });
}
