# Phase 1 audit (historical)

Plain-password localStorage prototype notes are obsolete.

Use Admin → Account / `OWNER_RESET_KEY` for password changes. Do not store credentials in markdown.
