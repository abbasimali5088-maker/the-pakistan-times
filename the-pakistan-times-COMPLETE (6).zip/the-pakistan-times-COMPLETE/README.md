# دی پاکستان ٹائمز اردو — News CMS

Professional **Frontend + Backend + Admin Panel + PostgreSQL + APIs** for **دی پاکستان ٹائمز اردو** / **The Pakistan Times**.

## Stack

- Next.js 15 (App Router) + TypeScript + Tailwind CSS
- Prisma + **PostgreSQL**
- Secure cookie sessions (JWT + hashed session rows)
- Admin at `/admin` · Public site at `/` · API under `/api/*`

## Local development

### 1. PostgreSQL

Create a database, then set `DATABASE_URL` **and** `DIRECT_DATABASE_URL` in `.env` (see `.env.example`). Locally both can be the same Postgres URL.

```bash
# example local DB
createdb pakistan_times
```

### 2. Install & migrate

```bash
cp .env.example .env
# edit DATABASE_URL, DIRECT_DATABASE_URL, JWT_SECRET, ADMIN_* 

npm install
npm run db:deploy
npm run db:seed
npm run dev
```

Open:

- Public: http://127.0.0.1:4355 (or the port printed by `npm run dev`)
- Admin: http://127.0.0.1:4355/admin/login
- Views (EN/UR tabs + traffic channels): `/admin/views`
- Analytics (EN/UR): `/admin/analytics`
- Search Console (separate Urdu + English properties): `/admin/seo`
- Rates admin: `/admin/rates`
- Public rates API: `/api/rates?public=1`
- Health: http://127.0.0.1:4355/api/health
- API docs: http://127.0.0.1:4355/api/docs

### English / Urdu separation

Frontend language buttons open completely separate content systems (articles, categories, tags, images, videos, SEO, breaking, tools).

Admin sidebar has **English Admin** and **Urdu Admin** workspace switches:

- English Admin → English articles, categories, tags, media, SEO, breaking, live
- Urdu Admin → اردو articles, categories, tags, media, SEO, breaking, live

### Article editor

Each article has:

1. **Title + body** — clean writing only (Compose / HTML views stay synchronized)
2. **HTML / Tool Code** — separate **Tool Title** + code editor for calculators, converters, embeds, custom HTML/JS (EN and UR fields are separate). The public site renders the working tool in a sandboxed iframe — visitors never see raw source in the article body.

### Images

Uploads are persisted to `/public/uploads/…`. Oversized `data:` URLs are never stored and never replaced with the site logo. Run `npx tsx scripts/repair-data-media.ts` once if older media still used base64 blobs.

Gold, petrol, diesel and forex rates are edited in **Admin → Rates**.

**Views (admin):** separate tabs for **English** (`www`) and **Urdu** (`urdu.*`) — internal pageview counters only (not Google Search Console). Each language is its own property; Search Console stays separate in Google.

**Mobile app (BBC / Geo style):** see folder `mobile/` (Expo) and page [/app](https://the-pakistan-times-live.vercel.app/app). Run `cd mobile && npm start`, or install the website as a PWA (Add to Home Screen).

**Ticker On/Off (backend only):** Admin → Rates has a master switch plus per-item toggles (petrol, gold, riyal…) and breaking-bar On/Off. The public site has no Off buttons.

**Launcher password:** Admin → Settings → Security — set a dedicated launcher password (separate from admin login), then use `/open`.

**Live auto-update (no paid API key):**
- Free sources: oilprices.pk (fuel), gold-api.com (gold/silver), open.er-api.com (forex)
- Admin button: **Fetch live rates now** → `POST /api/rates?action=sync`
- Vercel Cron every 6 hours → `/api/rates/refresh` (set `CRON_SECRET` in env)
- Background job `refresh_rates` via `npm run jobs:run`

### Scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | Dev server (port 4355) |
| `npm run build` | Generate client + migrate + production build |
| `npm run start` | Production server (port 4355) |
| `npm run db:deploy` | Apply Prisma migrations (`migrate deploy`) |
| `npm run db:seed` | Seed roles, categories, sample news |
| `npm run verify:prod` | Smoke-test DB + auth + APIs against running server |
| `npm run jobs:run` | Process due background jobs |

## Production / Vercel

See **[DEPLOY.md](./DEPLOY.md)** for GitHub → PostgreSQL → Vercel → live URLs.

## Default admin (after seed)

Set via `ADMIN_EMAIL` / `ADMIN_PASSWORD` in env before seeding.  
Change the password immediately after first login.

Re-running seed does **not** overwrite an existing admin password unless `FORCE_ADMIN_PASSWORD=1`.

## Key public URLs (production)

- **Site:** https://the-pakistan-times-live.vercel.app
- Admin: https://the-pakistan-times-live.vercel.app/admin/login
- Front+Backend launcher: https://the-pakistan-times-live.vercel.app/open
- RSS: https://the-pakistan-times-live.vercel.app/feed.xml
- Sitemap: https://the-pakistan-times-live.vercel.app/sitemap.xml
- Robots: https://the-pakistan-times-live.vercel.app/robots.txt

Source-code zip download is **disabled** (security). English and Urdu article systems are separate (content, galleries, SEO, video URLs, category images).

## Domain checklist (before pointing DNS)

1. Rotate `ADMIN_PASSWORD` in the database (Admin → Account, or reset with `OWNER_RESET_KEY`).
2. Set strong `JWT_SECRET`, `OWNER_RESET_KEY`, and optional `LAUNCHER_PASSWORD` in Vercel env.
3. Set dual-site URLs:
   - `NEXT_PUBLIC_URDU_SITE_URL=https://urdu.thepakistantimes.live`
   - `NEXT_PUBLIC_ENGLISH_SITE_URL=https://www.thepakistantimes.live` (hreflang / switcher only — English may stay on Blogger)
   - `NEXT_PUBLIC_SITE_URL=https://urdu.thepakistantimes.live` (when Urdu is the Vercel primary)
4. In Vercel Domains: add **only** `urdu.thepakistantimes.live` until you deliberately migrate English off Blogger.
5. DNS: add **CNAME `urdu` → Vercel**; **do not change** existing `www` / English Blogger DNS.
6. Confirm `/owner` redirects to login and no passwords in public HTML.
7. Submit Urdu host `/sitemap.xml` in Search Console (keep English Blogger SC separate).

See **[URDU_SUBDOMAIN.md](./URDU_SUBDOMAIN.md)** for Takeout ZIP findings and host isolation details.

## License

Private project — All rights reserved.
