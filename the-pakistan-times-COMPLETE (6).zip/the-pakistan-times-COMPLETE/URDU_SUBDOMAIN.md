# Urdu subdomain + Takeout ZIP — findings & setup

## A. ZIP میں کیا ملا (`thpakistantimesurdu.zip`)

**مکمل فہرست — ZIP میں صرف یہ ہے:**

| Path | Approx size | Notes |
|------|-------------|--------|
| `Takeout/archive_browser.html` | ~444 KB uncompressed (~58 KB zip) | Google Takeout **catalog / browser UI only** |

**ZIP میں کل 1 فائل ہے۔**  
کوئی article body نہیں، کوئی `feed.atom` نہیں، کوئی واقعی image/video file نہیں، کوئی posts XML نہیں۔

`archive_browser.html` ایک **فہرست** دکھاتا ہے کہ اصل Takeout میں کیا ہونا چاہیے تھا:

| Catalog claim | Detail |
|---------------|--------|
| Account | `abbasimali5088@gmail.com` |
| Claimed archive size | **732.4 MB** / Products in Archive (1) = Blogger |
| Blog folders named in UI | `پاکستان ٹائمز اردو`, `The pakistan times`, `Pakistan Times  urdu`, ` sports news`, `Urdu Techy By Zafran`, … |
| Mentioned files (not present) | `feed.atom` (×4 blogs), hundreds of `.jpg/.png/.webp` + `.json` sidecars, `settings.csv`, `followers.csv`, `theme-classic.html`, `theme-layouts.xml`, 1× `.mp4` |

**ان فائلوں میں سے کوئی بھی اس ZIP میں موجود نہیں۔**  
یہ incomplete Takeout download ہے (صرف browser HTML، اصل data archive نہیں)۔

**اس ZIP سے 12–14 Urdu articles recover/import نہیں کیے جا سکتے۔ کوئی fake/invented content نہیں بنایا گیا۔**

---

## B. کیا missing ہے

Import کے لیے یہ چاہیے (کم از کم):

1. **`Takeout/Blogger/.../پاکستان ٹائمز اردو/feed.atom`** (یا برابر Atom/XML) — titles, bodies, dates, permalinks  
2. Media files جو posts میں استعمال ہوئی ہوں (images)  
3. Optional: `metadata.json`, settings CSV  

**درست ZIP کی پہچان:** unzip کے بعد `feed.atom` نظر آئے — صرف `archive_browser.html` نہ ہو۔

Re-export: [takeout.google.com](https://takeout.google.com) → **Blogger** → پورا archive download (سب parts) → تصدیق کریں `feed.atom` موجود ہے → وہ ZIP بھیجیں۔

---

## C. Project میں کون سی files (architecture — پہلے سے تیار)

Host isolation پہلے سے موجود ہے (fake data نہیں):

| Area | Files |
|------|--------|
| Host → Urdu/EN profile | `src/lib/site-host.ts` |
| Middleware lock + CORS | `src/middleware.ts` |
| Request lang/profile | `src/lib/language-server.ts` |
| Sitemap per host/lang | `src/app/sitemap.ts` |
| Robots per host | `src/app/robots.ts` |
| RSS per host/lang | `src/app/feed.xml/route.ts` |
| Canonical / hreflang / OG | `src/app/(public)/[slug]/page.tsx`, `src/app/layout.tsx` |
| Env docs | `.env.example`, `README.md`, this file |

**اس ZIP کی وجہ سے کوئی article import change نہیں کیا گیا۔**

---

## D. Database میں کیا change ہوگا

**English rows کو چھونا ضروری نہیں — اور نہیں چھوا گیا۔**

موجودہ schema پہلے سے الگ ہے:

- `Article.language` = `en` \| `ur`  
- `Category.language`, `Media.language`, tags, وغیرہ  

Urdu articles `language: "ur"` سے الگ رہتے ہیں۔  
English (`language: "en"`) محفوظ۔  
Schema destroy / migrate English data کی ضرورت نہیں۔

**نوٹ:** اس Next.js CMS DB میں پہلے سے ~13 published Urdu rows ہیں (admin/test content) — وہ اس Takeout ZIP سے نہیں آئے۔ Blogger کے اصل 12–14 posts تبھی import ہوں گے جب مکمل `feed.atom` والا ZIP ملے۔

---

## E. Urdu subdomain کیسے connect ہوگا (DNS — English مت چھیڑیں)

### اہم حقیقت (live check، Sep 2026)

| Host | اب کیا serve ہو رہا ہے |
|------|-------------------------|
| `https://urdu.thepakistantimes.live/` | **Blogger** (`server: GSE`) |
| `https://www.thepakistantimes.live/` | **Blogger** (`server: GSE`) — ~500 English posts |
| `https://the-pakistan-times-live.vercel.app/` | **یہ Next.js CMS** |

Vercel project پر ابھی **0 custom domains** attached ہیں۔

### صرف Urdu منتقل کریں — English Blogger مت ہلائیں

1. **Vercel → Project → Domains**  
   - صرف add کریں: `urdu.thepakistantimes.live`  
   - **`www.thepakistantimes.live` کو Vercel پر مت لگائیں** جب تک آپ جان بوجھ کر English Blogger سے migrate نہ کرنا چاہیں — ورنہ 500 English articles والی موجودہ site بدل / ٹوٹ سکتی ہے۔

2. **DNS (صرف Urdu record):**

| Type | Name | Value | Action |
|------|------|-------|--------|
| **CNAME** | `urdu` | Vercel جو بتائے (`cname.vercel-dns.com` یا project DNS target) | **نیا / update صرف یہ** |
| `www` / apex | (موجودہ Blogger records) | — | **نہ بدلیں** |

3. **Env (Vercel Production) — اس Next.js project پر:**

```bash
NEXT_PUBLIC_URDU_SITE_URL=https://urdu.thepakistantimes.live
NEXT_PUBLIC_ENGLISH_SITE_URL=https://www.thepakistantimes.live
NEXT_PUBLIC_SITE_URL=https://urdu.thepakistantimes.live
```

`NEXT_PUBLIC_ENGLISH_SITE_URL` صرف **hreflang / language switcher link** کے لیے Blogger English کی طرف اشارہ کرتا ہے — اس سے English DNS تبدیل نہیں ہوتی۔

4. Connect کے بعد: `urdu` host پر یہ Next.js Urdu-only frontend چلے گا؛ `www` Blogger پر English ویسا ہی رہے گا۔

---

## F. SEO کیسے handle ہوگا (Urdu Next.js host پر)

جب `urdu.thepakistantimes.live` → Vercel:

- Canonical base = `https://urdu.thepakistantimes.live`  
- `sitemap.xml` صرف `language=ur` articles  
- `robots.txt` → اسی host کا sitemap  
- `feed.xml` Urdu-filtered  
- OG locale `ur_PK`، `htmlLang=ur`  
- Cross-language `?lang=en` locked host پر strip (duplicate-content protection)  
- EN article slug Urdu host پر **404**  
- Language switcher sibling = `www.thepakistantimes.live` (Blogger EN) — content mix نہیں  

Search Console: Urdu property الگ بنائیں اور `https://urdu.thepakistantimes.live/sitemap.xml` جمع کروائیں۔  
English Blogger Search Console **مت ہٹائیں / مت بدلیں**۔

---

## G. English site محفوظ رہنے کی confirmation

| Guarantee | Status |
|-----------|--------|
| English Blogger DNS / www مت بدلا | **مطلوبہ عمل: صرف `urdu` CNAME** |
| اس ZIP سے کوئی English data overwrite نہیں | ✓ (import ہی نہیں ہوا) |
| CMS میں `language=en` rows اس کام سے delete نہیں | ✓ |
| Urdu host پر English articles auto-show نہیں | ✓ (host lock + language filter) |
| `www` کو Vercel پر attach نہیں کیا | ✓ رکھیں جب تک EN migrate deliberate نہ ہو |

---

## H. Modified project / اگلا قدم

- Architecture اس repo میں تیار ہے (host lock + SEO filters)۔  
- **Live Urdu Blogger crawl مکمل:** `data/blogger-urdu-export/articles.json` میں **15** اصل posts۔  
- Importer: `npx tsx scripts/import-blogger-urdu.ts` — صرف `language=ur`؛ English rows کو نہیں چھوتا۔  
- CMS میں یہ 15 articles import ہو چکے ہیں (canonical = اصل Blogger permalink)۔  
- اگلا: DNS پر صرف `urdu` CNAME → Vercel تاکہ subdomain یہ CMS دکھائے۔

| ضرورت | Status |
|--------|--------|
| `urdu` DNS → Vercel | ابھی Blogger پر ہے — آپ کو CNAME لگانا ہے |
| Env URLs | `.env.example` / README دیکھیں |
| اصل Urdu articles | ✓ crawl + import ہو چکا |

**Guess / fake articles: نہیں۔ English modify: نہیں۔**
