# Final audit notes

Historical audit notes for the old static HTML prototype are obsolete.

Current stack: Next.js + Prisma + JWT sessions + bcrypt.  
Do not document live credentials in this file. Set secrets only via environment variables.
