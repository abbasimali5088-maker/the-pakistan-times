# Play Store — دی پاکستان ٹائمز

یہ فائل Google Play پر اپلوڈ کرنے کے لیے ہے۔

## جو فائلیں بنیں گی

| فائل | استعمال |
|------|---------|
| `*.aab` (Android App Bundle) | **Play Store پر یہی اپلوڈ کریں** |
| `*.apk` | فون پر سیدھا انسٹال / ٹیسٹ |

## ایک بار سیٹ اپ (آپ کے کمپیوٹر پر)

### 1) Expo اکاؤنٹ
https://expo.dev پر مفت اکاؤنٹ بنائیں

### 2) بلڈ (کلاؤڈ — آسان)
```bash
cd mobile
npm install
npx eas-cli login
npx eas build:configure
npx eas build -p android --profile production
```
مکمل ہونے پر AAB ڈاؤن لوڈ لنک ملے گا۔

### 3) Google Play Console
1. https://play.google.com/console → $25 one-time fee
2. Create app → **The Pakistan Times**
3. Package name: `pk.thepakistantimes.app` (تبدیل نہ کریں)
4. Production → Create release → AAB اپلوڈ
5. Store listing:
   - Short description / Full description
   - Icon 512×512
   - Screenshots (فون)
   - Privacy policy: `https://the-pakistan-times-live.vercel.app/privacy`
6. Content rating + Target audience مکمل کریں
7. Send for review

## لوکل بلڈ (اس ریپو میں)

```bash
cd mobile
npm run build:android
```

آؤٹ پٹ:
- `mobile/android/app/build/outputs/bundle/release/app-release.aab`
- `mobile/android/app/build/outputs/apk/release/app-release.apk`

## Signing key (اہم!)

`mobile/credentials/` میں keystore محفوظ رکھیں — کھو گیا تو Play Store اپڈیٹ ناممکن۔
پاس ورڈ: `credentials/keystore.env` (git میں مت ڈالیں)

## BBC جیسا کیوں؟

- الگ Android ایپ (package ID)
- Play Store AAB
- Bottom tabs: Home / Latest / Sections / Live / More
- اردو + English
- لائیو CMS API سے خبریں
