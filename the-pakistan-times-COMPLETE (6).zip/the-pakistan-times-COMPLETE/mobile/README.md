# دی پاکستان ٹائمز — Mobile App (Expo)

BBC / Geo News جیسی موبائل نیوز ایپ۔ یہی لائیو ویب سائٹ اور CMS API استعمال کرتی ہے:

`https://the-pakistan-times-live.vercel.app`

## Features

- Bottom tabs: **Home · Latest · Sections · Live · More**
- Urdu / English switch (RTL)
- Breaking ticker, featured story, category lists
- Live rates (petrol / gold / dollar / riyal)
- Article reader
- Links to website + admin backend

## Run on your phone (fastest)

1. Phone پر **Expo Go** انسٹال کریں (Play Store / App Store)
2. کمپیوٹر پر:

```bash
cd mobile
npm install
npm start
```

3. QR کوڈ اسکین کریں (Expo Go سے)

## Android APK (Play Store والی فائل)

Expo اکاؤنٹ کے ساتھ:

```bash
cd mobile
npx eas-cli login
npx eas build -p android --profile preview
```

`eas.json` پہلے سے تیار ہے۔

## iOS

Mac + Apple Developer اکاؤنٹ درکار:

```bash
npx eas build -p ios
```

## PWA (بغیر سٹور کے فون پر ایپ)

فون براؤزر میں کھولیں:

https://the-pakistan-times-live.vercel.app/app

Chrome مینو → **Install app / Add to Home screen / ہوم اسکرین میں شامل کریں**

ایپ موڈ: نیچے ٹیبز (ہوم · تازہ · لائیو · ویڈیو · تلاش) — BBC/Geo طرز۔

## API

ایپ ان اینڈ پوائنٹس سے پڑھتی ہے:

- `GET /api/articles?public=1`
- `GET /api/categories?public=1`
- `GET /api/breaking?public=1`
- `GET /api/live?public=1`
- `GET /api/rates?public=1`
