/** Live CMS API — same backend as thepakistan-times website */
export const API_BASE = "https://the-pakistan-times-live.vercel.app";
export const SITE_URL = API_BASE;

export type Lang = "ur" | "en";

export type Article = {
  id: string;
  title: string;
  titleUr?: string | null;
  titleEn?: string | null;
  slug: string;
  excerpt?: string | null;
  excerptUr?: string | null;
  excerptEn?: string | null;
  body?: string | null;
  bodyUr?: string | null;
  bodyEn?: string | null;
  publishedAt?: string | null;
  isFeatured?: boolean;
  isBreaking?: boolean;
  priority?: string;
  category?: { name?: string; nameUr?: string | null; nameEn?: string | null; slug?: string } | null;
  author?: { name?: string; slug?: string } | null;
  image?: { url?: string | null; alt?: string | null } | null;
  href?: string;
};

export type Category = {
  id: string;
  name: string;
  nameUr?: string | null;
  nameEn?: string | null;
  slug: string;
  parentId?: string | null;
};

export type BreakingItem = {
  id: string;
  headline: string;
  headlineUr?: string | null;
  headlineEn?: string | null;
  href?: string | null;
  article?: { slug?: string } | null;
};

export type LiveBlog = {
  id: string;
  title: string;
  titleUr?: string | null;
  slug: string;
  status?: string;
};

type Envelope<T> = { success?: boolean; data?: T; error?: string };

async function getJson<T>(path: string): Promise<T> {
  const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
  const res = await fetch(url, {
    headers: { Accept: "application/json" },
  });
  if (!res.ok) throw new Error(`API ${res.status}`);
  const json = (await res.json()) as Envelope<T>;
  if (json && typeof json === "object" && "data" in json) {
    return (json.data ?? json) as T;
  }
  return json as T;
}

export async function fetchArticles(opts: {
  limit?: number;
  category?: string;
  featured?: boolean;
  breaking?: boolean;
} = {}): Promise<Article[]> {
  const q = new URLSearchParams({ public: "1", limit: String(opts.limit ?? 20) });
  if (opts.category) q.set("category", opts.category);
  if (opts.featured) q.set("featured", "1");
  if (opts.breaking) q.set("breaking", "1");
  const data = await getJson<{ items?: Article[] } | Article[]>(`/api/articles?${q}`);
  if (Array.isArray(data)) return data;
  return data.items || [];
}

export async function fetchArticle(slug: string): Promise<Article | null> {
  try {
    const data = await getJson<Article | { item?: Article }>(
      `/api/articles/${encodeURIComponent(slug)}?public=1`,
    );
    if (data && typeof data === "object" && "item" in data) {
      return (data as { item?: Article }).item || null;
    }
    return data as Article;
  } catch {
    const list = await fetchArticles({ limit: 50 });
    return list.find((a) => a.slug === slug) || null;
  }
}

export async function fetchCategories(): Promise<Category[]> {
  const data = await getJson<{ items?: Category[] } | Category[]>(`/api/categories?public=1`);
  if (Array.isArray(data)) return data;
  return data.items || [];
}

export async function fetchBreaking(): Promise<BreakingItem[]> {
  try {
    const data = await getJson<{ items?: BreakingItem[] } | BreakingItem[]>(
      `/api/breaking?public=1`,
    );
    if (Array.isArray(data)) return data;
    return data.items || [];
  } catch {
    return [];
  }
}

export async function fetchLive(): Promise<LiveBlog[]> {
  try {
    const data = await getJson<{ items?: LiveBlog[] } | LiveBlog[]>(`/api/live?public=1`);
    if (Array.isArray(data)) return data;
    return data.items || [];
  } catch {
    return [];
  }
}

export async function fetchRates(): Promise<Record<string, string>> {
  try {
    const data = await getJson<{ rates?: Record<string, string> }>(`/api/rates?public=1`);
    return data.rates || {};
  } catch {
    return {};
  }
}

/** Strict — never mix EN into Urdu view or Urdu into English view. */
export function pickText(lang: Lang, ur?: string | null, en?: string | null, fallback = "") {
  if (lang === "en") return ((en || "").trim() || fallback || "").trim();
  return ((ur || "").trim() || fallback || "").trim();
}

export function stripHtml(html?: string | null) {
  if (!html) return "";
  return html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .trim();
}

export function formatDate(iso?: string | null, lang: Lang = "ur") {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    return d.toLocaleString(lang === "ur" ? "ur-PK" : "en-GB", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return "";
  }
}
