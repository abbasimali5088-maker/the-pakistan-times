import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { Lang } from "./api";

type Ctx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  dir: "rtl" | "ltr";
};

const LanguageContext = createContext<Ctx>({
  lang: "ur",
  setLang: () => {},
  dir: "rtl",
});

const KEY = "pt_app_lang";

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ur");

  useEffect(() => {
    void (async () => {
      try {
        const v = await AsyncStorage.getItem(KEY);
        if (v === "en" || v === "ur") setLangState(v);
      } catch {
        /* ignore */
      }
    })();
  }, []);

  const setLang = (l: Lang) => {
    setLangState(l);
    void AsyncStorage.setItem(KEY, l).catch(() => {});
  };

  const value = useMemo(
    () => ({ lang, setLang, dir: lang === "ur" ? ("rtl" as const) : ("ltr" as const) }),
    [lang],
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  return useContext(LanguageContext);
}
