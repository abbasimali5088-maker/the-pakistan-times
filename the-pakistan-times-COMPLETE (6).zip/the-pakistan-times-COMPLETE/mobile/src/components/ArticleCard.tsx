import { Image } from "expo-image";
import { Link } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { formatDate, pickText, type Article } from "../api";
import { useLanguage } from "../language";
import { colors, spacing } from "../theme";

export function ArticleCard({
  article,
  featured = false,
}: {
  article: Article;
  featured?: boolean;
}) {
  const { lang } = useLanguage();
  const title = pickText(lang, article.titleUr, article.titleEn, article.title);
  const excerpt = pickText(lang, article.excerptUr, article.excerptEn, article.excerpt || "");
  const cat = pickText(
    lang,
    article.category?.nameUr,
    article.category?.nameEn,
    article.category?.name || "",
  );
  const imageUrl = article.image?.url || null;

  return (
    <Link href={`/article/${article.slug}`} asChild>
      <Pressable
        style={StyleSheet.flatten([styles.card, featured && styles.featured])}
        accessibilityRole="link"
      >
        {imageUrl ? (
          <Image
            source={{ uri: imageUrl }}
            style={[styles.image, featured && styles.imageFeatured]}
            contentFit="cover"
            transition={200}
          />
        ) : (
          <View style={[styles.image, styles.imagePlaceholder, featured && styles.imageFeatured]}>
            <Text style={styles.placeholderText}>{lang === "ur" ? "خبر" : "News"}</Text>
          </View>
        )}
        <View style={styles.body}>
          <View style={styles.metaRow}>
            {article.isBreaking || article.priority === "breaking" ? (
              <Text style={styles.breaking}>{lang === "ur" ? "بریکنگ" : "BREAKING"}</Text>
            ) : null}
            {cat ? <Text style={styles.cat}>{cat}</Text> : null}
          </View>
          <Text style={[styles.title, featured && styles.titleFeatured]} numberOfLines={featured ? 3 : 2}>
            {title}
          </Text>
          {excerpt ? (
            <Text style={styles.excerpt} numberOfLines={featured ? 3 : 2}>
              {excerpt}
            </Text>
          ) : null}
          <Text style={styles.date}>{formatDate(article.publishedAt, lang)}</Text>
        </View>
      </Pressable>
    </Link>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: 14,
    overflow: "hidden",
    marginBottom: spacing.md,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.line,
  },
  featured: {
    borderWidth: 0,
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 3,
  },
  image: {
    width: "100%",
    height: 160,
    backgroundColor: colors.greenDeep,
  },
  imageFeatured: {
    height: 210,
  },
  imagePlaceholder: {
    alignItems: "center",
    justifyContent: "center",
  },
  placeholderText: {
    color: colors.white,
    fontWeight: "800",
    fontSize: 18,
  },
  body: {
    padding: spacing.md,
    gap: 6,
  },
  metaRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    alignItems: "center",
  },
  breaking: {
    backgroundColor: colors.danger,
    color: colors.white,
    fontSize: 10,
    fontWeight: "800",
    paddingHorizontal: 8,
    paddingVertical: 3,
    overflow: "hidden",
  },
  cat: {
    color: colors.green,
    fontSize: 11,
    fontWeight: "800",
    textTransform: "uppercase",
  },
  title: {
    color: colors.ink,
    fontSize: 17,
    fontWeight: "800",
    lineHeight: 26,
  },
  titleFeatured: {
    fontSize: 22,
    lineHeight: 32,
  },
  excerpt: {
    color: colors.muted,
    fontSize: 14,
    lineHeight: 22,
  },
  date: {
    color: colors.muted,
    fontSize: 12,
    marginTop: 4,
  },
});
