import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";
import { useLanguage } from "../language";
import { colors, spacing } from "../theme";

export function ScreenHeader({
  title,
  subtitle,
}: {
  title: string;
  subtitle?: string;
}) {
  const { lang, setLang, dir } = useLanguage();
  return (
    <View style={[styles.wrap, { direction: dir }]}>
      <View style={styles.top}>
        <View style={{ flex: 1 }}>
          <Text style={styles.brand}>{lang === "ur" ? "دی پاکستان ٹائمز" : "The Pakistan Times"}</Text>
          <Text style={styles.title}>{title}</Text>
          {subtitle ? <Text style={styles.sub}>{subtitle}</Text> : null}
        </View>
        <View style={styles.lang}>
          <Pressable
            onPress={() => setLang("ur")}
            style={[styles.langBtn, lang === "ur" && styles.langActive]}
          >
            <Text style={[styles.langText, lang === "ur" && styles.langTextActive]}>اردو</Text>
          </Pressable>
          <Pressable
            onPress={() => setLang("en")}
            style={[styles.langBtn, lang === "en" && styles.langActive]}
          >
            <Text style={[styles.langText, lang === "en" && styles.langTextActive]}>EN</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

export function LoadingBlock() {
  return (
    <View style={styles.center}>
      <ActivityIndicator size="large" color={colors.green} />
    </View>
  );
}

export function EmptyBlock({ message }: { message: string }) {
  return (
    <View style={styles.center}>
      <Text style={styles.empty}>{message}</Text>
    </View>
  );
}

export function ErrorBlock({ message, onRetry }: { message: string; onRetry?: () => void }) {
  const { lang } = useLanguage();
  return (
    <View style={styles.center}>
      <Text style={styles.empty}>{message}</Text>
      {onRetry ? (
        <Pressable onPress={onRetry} style={styles.retry}>
          <Text style={styles.retryText}>{lang === "ur" ? "دوبارہ کوشش" : "Retry"}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    backgroundColor: colors.green,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
  },
  top: {
    flexDirection: "row",
    gap: 12,
    alignItems: "flex-start",
  },
  brand: {
    color: "rgba(255,255,255,0.85)",
    fontSize: 12,
    fontWeight: "700",
    marginBottom: 2,
  },
  title: {
    color: colors.white,
    fontSize: 26,
    fontWeight: "900",
  },
  sub: {
    color: "rgba(255,255,255,0.85)",
    fontSize: 13,
    marginTop: 4,
  },
  lang: {
    flexDirection: "row",
    gap: 6,
  },
  langBtn: {
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.45)",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  langActive: {
    backgroundColor: colors.white,
    borderColor: colors.white,
  },
  langText: {
    color: colors.white,
    fontWeight: "800",
    fontSize: 12,
  },
  langTextActive: {
    color: colors.green,
  },
  center: {
    paddingVertical: 48,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  empty: {
    color: colors.muted,
    textAlign: "center",
    paddingHorizontal: 24,
    lineHeight: 22,
  },
  retry: {
    backgroundColor: colors.green,
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 10,
  },
  retryText: {
    color: colors.white,
    fontWeight: "800",
  },
});
