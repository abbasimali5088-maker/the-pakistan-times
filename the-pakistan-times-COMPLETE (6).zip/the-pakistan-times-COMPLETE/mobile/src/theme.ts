export const colors = {
  green: "#1DB954",
  greenDeep: "#159A45",
  ink: "#141414",
  muted: "#5c5c5c",
  paper: "#F7F3EA",
  line: "#d7d2c8",
  white: "#ffffff",
  danger: "#9b1c1c",
  card: "#FFFCFA",
};

export const spacing = {
  xs: 6,
  sm: 10,
  md: 16,
  lg: 22,
  xl: 28,
};
