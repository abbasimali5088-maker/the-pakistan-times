import { Stack, useLocalSearchParams } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { FlatList, StyleSheet } from "react-native";
import { ArticleCard } from "../../src/components/ArticleCard";
import { EmptyBlock, ErrorBlock, LoadingBlock } from "../../src/components/ui";
import { fetchArticles, fetchCategories, pickText, type Article } from "../../src/api";
import { useLanguage } from "../../src/language";
import { colors, spacing } from "../../src/theme";

export default function CategoryScreen() {
  const { slug } = useLocalSearchParams<{ slug: string }>();
  const { lang, dir } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [title, setTitle] = useState(String(slug || ""));
  const [items, setItems] = useState<Article[]>([]);

  const load = useCallback(async () => {
    if (!slug) return;
    setError(null);
    setLoading(true);
    try {
      const [articles, cats] = await Promise.all([
        fetchArticles({ limit: 40, category: String(slug) }),
        fetchCategories(),
      ]);
      const cat = cats.find((c) => c.slug === slug);
      if (cat) setTitle(pickText(lang, cat.nameUr, cat.nameEn, cat.name));
      setItems(articles);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  }, [slug, lang]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <>
      <Stack.Screen options={{ title }} />
      {loading ? (
        <LoadingBlock />
      ) : error ? (
        <ErrorBlock message={error} onRetry={() => void load()} />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[styles.list, { direction: dir as "rtl" | "ltr" }]}
          ListEmptyComponent={
            <EmptyBlock message={lang === "ur" ? "اس زمرے میں خبر نہیں" : "No stories in this section"} />
          }
          renderItem={({ item }) => <ArticleCard article={item} />}
        />
      )}
    </>
  );
}

const styles = StyleSheet.create({
  list: { padding: spacing.md, paddingBottom: 40, backgroundColor: colors.paper, flexGrow: 1 },
});
