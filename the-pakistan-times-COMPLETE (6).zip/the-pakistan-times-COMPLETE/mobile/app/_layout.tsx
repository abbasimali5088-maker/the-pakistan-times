import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { I18nManager } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { LanguageProvider } from "../src/language";
import { colors } from "../src/theme";

// Prefer RTL layout for Urdu-first news app (BBC Urdu style)
try {
  if (!I18nManager.isRTL) {
    I18nManager.allowRTL(true);
  }
} catch {
  /* web ignore */
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <LanguageProvider>
          <StatusBar style="light" />
          <Stack
            screenOptions={{
              headerStyle: { backgroundColor: colors.green },
              headerTintColor: colors.white,
              headerTitleStyle: { fontWeight: "800" },
              contentStyle: { backgroundColor: colors.paper },
            }}
          >
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
            <Stack.Screen
              name="article/[slug]"
              options={{ title: "خبر", headerBackTitle: "واپس" }}
            />
            <Stack.Screen
              name="category/[slug]"
              options={{ title: "زمرہ", headerBackTitle: "واپس" }}
            />
          </Stack>
        </LanguageProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
