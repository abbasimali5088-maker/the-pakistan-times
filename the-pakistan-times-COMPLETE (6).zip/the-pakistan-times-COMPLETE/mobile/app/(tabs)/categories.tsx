import { Link } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { EmptyBlock, ErrorBlock, LoadingBlock, ScreenHeader } from "../../src/components/ui";
import { fetchCategories, pickText, type Category } from "../../src/api";
import { useLanguage } from "../../src/language";
import { colors, spacing } from "../../src/theme";

export default function CategoriesScreen() {
  const { lang, dir } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [items, setItems] = useState<Category[]>([]);

  const load = useCallback(async () => {
    setError(null);
    try {
      const all = await fetchCategories();
      setItems(all.filter((c) => !c.parentId));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScreenHeader
        title={lang === "ur" ? "زمرے" : "Sections"}
        subtitle={lang === "ur" ? "پاکستان، دنیا، کھیل…" : "Pakistan, World, Sports…"}
      />
      {loading ? (
        <LoadingBlock />
      ) : error ? (
        <ErrorBlock message={error} onRetry={() => { setLoading(true); void load(); }} />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[styles.list, { direction: dir as "rtl" | "ltr" }]}
          ListEmptyComponent={
            <EmptyBlock message={lang === "ur" ? "زمرے دستیاب نہیں" : "No categories"} />
          }
          renderItem={({ item }) => (
            <Link href={`/category/${item.slug}`} asChild>
              <Pressable style={styles.row}>
                <Text style={styles.rowText}>
                  {pickText(lang, item.nameUr, item.nameEn, item.name)}
                </Text>
                <Text style={styles.chev}>{dir === "rtl" ? "‹" : "›"}</Text>
              </Pressable>
            </Link>
          )}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.paper },
  list: { padding: spacing.md, paddingBottom: 40, gap: 10 },
  row: {
    backgroundColor: colors.white,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.line,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  rowText: {
    color: colors.ink,
    fontSize: 17,
    fontWeight: "800",
  },
  chev: {
    color: colors.green,
    fontSize: 22,
    fontWeight: "300",
  },
});
