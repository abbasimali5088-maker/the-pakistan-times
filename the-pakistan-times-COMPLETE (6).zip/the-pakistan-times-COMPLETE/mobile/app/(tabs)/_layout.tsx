import { Tabs } from "expo-router";
import { Text } from "react-native";
import { useLanguage } from "../../src/language";
import { colors } from "../../src/theme";

function TabIcon({ label, focused }: { label: string; focused: boolean }) {
  return (
    <Text style={{ fontSize: 16, opacity: focused ? 1 : 0.55, fontWeight: focused ? "900" : "600" }}>
      {label}
    </Text>
  );
}

export default function TabsLayout() {
  const { lang } = useLanguage();
  const t = {
    home: lang === "ur" ? "ہوم" : "Home",
    latest: lang === "ur" ? "تازہ" : "Latest",
    cats: lang === "ur" ? "زمرے" : "Sections",
    live: lang === "ur" ? "لائیو" : "Live",
    more: lang === "ur" ? "مزید" : "More",
  };

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.green,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: {
          backgroundColor: colors.white,
          borderTopColor: colors.line,
          height: 62,
          paddingBottom: 8,
          paddingTop: 6,
        },
        tabBarLabelStyle: { fontWeight: "700", fontSize: 11 },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: t.home,
          tabBarIcon: ({ focused }) => <TabIcon label="ہ" focused={focused} />,
        }}
      />
      <Tabs.Screen
        name="latest"
        options={{
          title: t.latest,
          tabBarIcon: ({ focused }) => <TabIcon label="ت" focused={focused} />,
        }}
      />
      <Tabs.Screen
        name="categories"
        options={{
          title: t.cats,
          tabBarIcon: ({ focused }) => <TabIcon label="ز" focused={focused} />,
        }}
      />
      <Tabs.Screen
        name="live"
        options={{
          title: t.live,
          tabBarIcon: ({ focused }) => <TabIcon label="ل" focused={focused} />,
        }}
      />
      <Tabs.Screen
        name="more"
        options={{
          title: t.more,
          tabBarIcon: ({ focused }) => <TabIcon label="م" focused={focused} />,
        }}
      />
    </Tabs>
  );
}
