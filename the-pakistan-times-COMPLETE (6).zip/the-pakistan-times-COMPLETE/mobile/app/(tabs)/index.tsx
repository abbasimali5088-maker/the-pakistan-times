import { useCallback, useEffect, useState } from "react";
import { RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ArticleCard } from "../../src/components/ArticleCard";
import { EmptyBlock, ErrorBlock, LoadingBlock, ScreenHeader } from "../../src/components/ui";
import { fetchArticles, fetchBreaking, pickText, type Article, type BreakingItem } from "../../src/api";
import { useLanguage } from "../../src/language";
import { colors, spacing } from "../../src/theme";

export default function HomeScreen() {
  const { lang, dir } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [featured, setFeatured] = useState<Article | null>(null);
  const [items, setItems] = useState<Article[]>([]);
  const [breaking, setBreaking] = useState<BreakingItem[]>([]);

  const load = useCallback(async () => {
    setError(null);
    try {
      const [all, br] = await Promise.all([fetchArticles({ limit: 24 }), fetchBreaking()]);
      const feat = all.find((a) => a.isFeatured) || all[0] || null;
      setFeatured(feat);
      setItems(all.filter((a) => a.id !== feat?.id));
      setBreaking(br.slice(0, 8));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScreenHeader
        title={lang === "ur" ? "سرخیاں" : "Top stories"}
        subtitle={lang === "ur" ? "لائیو نیوز ڈیسک" : "Live news desk"}
      />
      {loading ? (
        <LoadingBlock />
      ) : error ? (
        <ErrorBlock
          message={error}
          onRetry={() => {
            setLoading(true);
            void load();
          }}
        />
      ) : (
        <ScrollView
          contentContainerStyle={[styles.content, { direction: dir as "rtl" | "ltr" }]}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                setRefreshing(true);
                void load();
              }}
              tintColor={colors.green}
            />
          }
        >
          {breaking.length > 0 ? (
            <View style={styles.breakingBox}>
              <Text style={styles.breakingLabel}>{lang === "ur" ? "بریکنگ" : "BREAKING"}</Text>
              {breaking.map((b) => (
                <Text key={b.id} style={styles.breakingText} numberOfLines={2}>
                  {pickText(lang, b.headlineUr, b.headlineEn || b.headline, b.headline)}
                </Text>
              ))}
            </View>
          ) : null}

          {featured ? <ArticleCard article={featured} featured /> : <EmptyBlock message={lang === "ur" ? "ابھی کوئی خبر نہیں" : "No stories yet"} />}
          {items.map((a) => (
            <ArticleCard key={a.id} article={a} />
          ))}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.paper },
  content: { padding: spacing.md, paddingBottom: 40 },
  breakingBox: {
    backgroundColor: "#fff5f5",
    borderColor: "#fecaca",
    borderWidth: 1,
    borderRadius: 12,
    padding: spacing.md,
    marginBottom: spacing.md,
    gap: 8,
  },
  breakingLabel: {
    color: colors.danger,
    fontWeight: "900",
    fontSize: 12,
    letterSpacing: 0.5,
  },
  breakingText: {
    color: colors.ink,
    fontSize: 15,
    fontWeight: "700",
    lineHeight: 24,
  },
});
