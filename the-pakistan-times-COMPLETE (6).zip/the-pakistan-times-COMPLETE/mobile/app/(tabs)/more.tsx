import * as WebBrowser from "expo-web-browser";
import { Linking, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ScreenHeader } from "../../src/components/ui";
import { API_BASE } from "../../src/api";
import { useLanguage } from "../../src/language";
import { colors, spacing } from "../../src/theme";

const LINKS = [
  { path: "/", ur: "ویب سائٹ کھولیں", en: "Open website" },
  { path: "/breaking", ur: "بریکنگ نیوز", en: "Breaking news" },
  { path: "/videos", ur: "ویڈیوز", en: "Videos" },
  { path: "/galleries", ur: "تصاویر", en: "Galleries" },
  { path: "/open", ur: "فرنٹ + بیک اینڈ", en: "Front + Backend" },
  { path: "/admin/login", ur: "بیک اینڈ لاگ اِن", en: "Backend login" },
];

export default function MoreScreen() {
  const { lang, dir, setLang } = useLanguage();

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScreenHeader
        title={lang === "ur" ? "مزید" : "More"}
        subtitle={lang === "ur" ? "ایپ سیٹنگز اور لنکس" : "App settings & links"}
      />
      <ScrollView contentContainerStyle={[styles.content, { direction: dir as "rtl" | "ltr" }]}>
        <View style={styles.card}>
          <Text style={styles.h}>{lang === "ur" ? "زبان" : "Language"}</Text>
          <View style={styles.row}>
            <Pressable
              style={[styles.pill, lang === "ur" && styles.pillOn]}
              onPress={() => setLang("ur")}
            >
              <Text style={[styles.pillText, lang === "ur" && styles.pillTextOn]}>اردو</Text>
            </Pressable>
            <Pressable
              style={[styles.pill, lang === "en" && styles.pillOn]}
              onPress={() => setLang("en")}
            >
              <Text style={[styles.pillText, lang === "en" && styles.pillTextOn]}>English</Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.h}>{lang === "ur" ? "فوری لنکس" : "Quick links"}</Text>
          {LINKS.map((l) => (
            <Pressable
              key={l.path}
              style={styles.link}
              onPress={() => void WebBrowser.openBrowserAsync(`${API_BASE}${l.path}`)}
            >
              <Text style={styles.linkText}>{lang === "ur" ? l.ur : l.en}</Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.card}>
          <Text style={styles.h}>{lang === "ur" ? "ایپ کے بارے میں" : "About this app"}</Text>
          <Text style={styles.p}>
            {lang === "ur"
              ? "یہ دی پاکستان ٹائمز کی موبائل ایپ ہے — وہی لائیو ویب سائٹ اور بیک اینڈ سے خبریں آتی ہیں۔ BBC / Geo جیسا نیوز تجربہ: ہوم، تازہ، زمرے، لائیو۔"
              : "Official The Pakistan Times mobile app — powered by the same live website & CMS. BBC/Geo-style tabs: Home, Latest, Sections, Live."}
          </Text>
          <Text style={styles.meta}>
            API: {API_BASE}
          </Text>
          <Pressable onPress={() => void Linking.openURL(API_BASE)}>
            <Text style={styles.site}>{API_BASE.replace("https://", "")}</Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.paper },
  content: { padding: spacing.md, paddingBottom: 48, gap: 14 },
  card: {
    backgroundColor: colors.white,
    borderRadius: 14,
    padding: spacing.md,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.line,
    gap: 10,
  },
  h: { fontWeight: "900", fontSize: 16, color: colors.ink },
  p: { color: colors.muted, lineHeight: 24, fontSize: 14 },
  meta: { color: colors.muted, fontSize: 11, marginTop: 4 },
  site: { color: colors.green, fontWeight: "800", marginTop: 4 },
  row: { flexDirection: "row", gap: 8 },
  pill: {
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 999,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  pillOn: { backgroundColor: colors.green, borderColor: colors.green },
  pillText: { fontWeight: "800", color: colors.ink },
  pillTextOn: { color: colors.white },
  link: {
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.line,
  },
  linkText: { fontSize: 15, fontWeight: "700", color: colors.green },
});
