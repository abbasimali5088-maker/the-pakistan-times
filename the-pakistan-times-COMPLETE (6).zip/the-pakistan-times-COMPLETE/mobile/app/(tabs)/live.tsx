import * as WebBrowser from "expo-web-browser";
import { useCallback, useEffect, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { EmptyBlock, ErrorBlock, LoadingBlock, ScreenHeader } from "../../src/components/ui";
import { API_BASE, fetchLive, fetchRates, pickText, type LiveBlog } from "../../src/api";
import { useLanguage } from "../../src/language";
import { colors, spacing } from "../../src/theme";

export default function LiveScreen() {
  const { lang, dir } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [items, setItems] = useState<LiveBlog[]>([]);
  const [rates, setRates] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    setError(null);
    try {
      const [live, r] = await Promise.all([fetchLive(), fetchRates()]);
      setItems(live);
      setRates(r);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const rateChips = [
    { key: "petrol", ur: "پیٹرول", en: "Petrol" },
    { key: "gold24k", ur: "سونا", en: "Gold" },
    { key: "usd", ur: "ڈالر", en: "USD" },
    { key: "sar", ur: "ریال", en: "Riyal" },
  ].filter((x) => rates[x.key]);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScreenHeader
        title={lang === "ur" ? "لائیو" : "Live"}
        subtitle={lang === "ur" ? "لائیو بلاگز اور ریٹس" : "Live blogs & market rates"}
      />
      {loading ? (
        <LoadingBlock />
      ) : error ? (
        <ErrorBlock message={error} onRetry={() => { setLoading(true); void load(); }} />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[styles.list, { direction: dir as "rtl" | "ltr" }]}
          ListHeaderComponent={
            rateChips.length ? (
              <View style={styles.rates}>
                <Text style={styles.ratesTitle}>{lang === "ur" ? "آج کے ریٹس" : "Today's rates"}</Text>
                <View style={styles.rateRow}>
                  {rateChips.map((r) => (
                    <View key={r.key} style={styles.chip}>
                      <Text style={styles.chipLabel}>{lang === "ur" ? r.ur : r.en}</Text>
                      <Text style={styles.chipValue}>{rates[r.key]}</Text>
                    </View>
                  ))}
                </View>
              </View>
            ) : null
          }
          ListEmptyComponent={
            <EmptyBlock
              message={
                lang === "ur"
                  ? "ابھی کوئی لائیو بلاگ نہیں — ویب سائٹ پر دیکھیں"
                  : "No live blogs right now — open the website"
              }
            />
          }
          renderItem={({ item }) => (
            <Pressable
              style={styles.card}
              onPress={() => void WebBrowser.openBrowserAsync(`${API_BASE}/live/${item.slug}`)}
            >
              <Text style={styles.liveBadge}>{lang === "ur" ? "لائیو" : "LIVE"}</Text>
              <Text style={styles.cardTitle}>
                {pickText(lang, item.titleUr, item.title, item.title)}
              </Text>
            </Pressable>
          )}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.paper },
  list: { padding: spacing.md, paddingBottom: 40 },
  rates: {
    backgroundColor: colors.white,
    borderRadius: 12,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.line,
  },
  ratesTitle: { fontWeight: "900", color: colors.green, marginBottom: 10 },
  rateRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: {
    backgroundColor: "#e7f4ec",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
    minWidth: "45%",
  },
  chipLabel: { fontSize: 12, color: colors.muted, fontWeight: "700" },
  chipValue: { fontSize: 16, color: colors.ink, fontWeight: "900", marginTop: 2 },
  card: {
    backgroundColor: colors.white,
    borderRadius: 12,
    padding: spacing.md,
    marginBottom: 10,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.line,
  },
  liveBadge: {
    alignSelf: "flex-start",
    backgroundColor: colors.danger,
    color: colors.white,
    fontWeight: "900",
    fontSize: 11,
    paddingHorizontal: 8,
    paddingVertical: 3,
    marginBottom: 8,
    overflow: "hidden",
  },
  cardTitle: { fontSize: 17, fontWeight: "800", color: colors.ink, lineHeight: 26 },
});
