import { useCallback, useEffect, useState } from "react";
import { FlatList, RefreshControl, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ArticleCard } from "../../src/components/ArticleCard";
import { EmptyBlock, ErrorBlock, LoadingBlock, ScreenHeader } from "../../src/components/ui";
import { fetchArticles, type Article } from "../../src/api";
import { useLanguage } from "../../src/language";
import { colors, spacing } from "../../src/theme";

export default function LatestScreen() {
  const { lang, dir } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [items, setItems] = useState<Article[]>([]);

  const load = useCallback(async () => {
    setError(null);
    try {
      setItems(await fetchArticles({ limit: 40 }));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScreenHeader
        title={lang === "ur" ? "تازہ ترین" : "Latest"}
        subtitle={lang === "ur" ? "نئی اشاعتیں" : "Newest published stories"}
      />
      {loading ? (
        <LoadingBlock />
      ) : error ? (
        <ErrorBlock message={error} onRetry={() => { setLoading(true); void load(); }} />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[styles.list, { direction: dir as "rtl" | "ltr" }]}
          ListEmptyComponent={
            <EmptyBlock message={lang === "ur" ? "کوئی خبر نہیں ملی" : "No articles found"} />
          }
          renderItem={({ item }) => <ArticleCard article={item} />}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                setRefreshing(true);
                void load();
              }}
              tintColor={colors.green}
            />
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.paper },
  list: { padding: spacing.md, paddingBottom: 40 },
});
