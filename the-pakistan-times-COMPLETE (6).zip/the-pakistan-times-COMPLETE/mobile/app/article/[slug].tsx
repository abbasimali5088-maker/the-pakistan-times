import { Stack, useLocalSearchParams } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { EmptyBlock, ErrorBlock, LoadingBlock } from "../../src/components/ui";
import {
  fetchArticle,
  formatDate,
  pickText,
  stripHtml,
  type Article,
} from "../../src/api";
import { useLanguage } from "../../src/language";
import { colors, spacing } from "../../src/theme";

export default function ArticleScreen() {
  const { slug } = useLocalSearchParams<{ slug: string }>();
  const { lang, dir } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [article, setArticle] = useState<Article | null>(null);

  const load = useCallback(async () => {
    if (!slug) return;
    setError(null);
    setLoading(true);
    try {
      const a = await fetchArticle(String(slug));
      setArticle(a);
      if (!a) setError(lang === "ur" ? "خبر نہیں ملی" : "Article not found");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  }, [slug, lang]);

  useEffect(() => {
    void load();
  }, [load]);

  const title = article
    ? pickText(lang, article.titleUr, article.titleEn, article.title)
    : "";

  return (
    <>
      <Stack.Screen options={{ title: title ? title.slice(0, 28) : lang === "ur" ? "خبر" : "Story" }} />
      {loading ? (
        <LoadingBlock />
      ) : error || !article ? (
        <ErrorBlock message={error || "Missing"} onRetry={() => void load()} />
      ) : (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={[styles.content, { direction: dir as "rtl" | "ltr" }]}
        >
          {article.image?.url ? (
            <Image source={{ uri: article.image.url }} style={styles.hero} contentFit="cover" />
          ) : null}
          <View style={styles.body}>
            {article.category ? (
              <Text style={styles.cat}>
                {pickText(
                  lang,
                  article.category.nameUr,
                  article.category.nameEn,
                  article.category.name || "",
                )}
              </Text>
            ) : null}
            <Text style={styles.title}>{title}</Text>
            <Text style={styles.meta}>
              {[article.author?.name, formatDate(article.publishedAt, lang)]
                .filter(Boolean)
                .join(" · ")}
            </Text>
            <Text style={styles.article}>
              {stripHtml(
                pickText(lang, article.bodyUr, article.bodyEn, article.body || "") ||
                  pickText(lang, article.excerptUr, article.excerptEn, article.excerpt || ""),
              ) || (lang === "ur" ? "تفصیل دستیاب نہیں" : "No body text")}
            </Text>
          </View>
        </ScrollView>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: colors.paper },
  content: { paddingBottom: 48 },
  hero: { width: "100%", height: 240, backgroundColor: colors.greenDeep },
  body: { padding: spacing.lg, gap: 10 },
  cat: { color: colors.green, fontWeight: "900", fontSize: 12, textTransform: "uppercase" },
  title: { fontSize: 26, fontWeight: "900", color: colors.ink, lineHeight: 36 },
  meta: { color: colors.muted, fontSize: 13 },
  article: { marginTop: 8, fontSize: 17, lineHeight: 30, color: colors.ink },
});
