-- AlterTable
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "liveExpiresAt" TIMESTAMP(3);

-- CreateIndex
CREATE INDEX IF NOT EXISTS "Article_liveExpiresAt_idx" ON "Article"("liveExpiresAt");
