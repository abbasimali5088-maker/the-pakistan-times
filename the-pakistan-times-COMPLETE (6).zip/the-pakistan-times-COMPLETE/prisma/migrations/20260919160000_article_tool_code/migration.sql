-- Separate HTML/Tool code from article body (EN + UR)
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "toolTitle" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "toolCode" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "toolTitleUr" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "toolCodeUr" TEXT;
