-- Allow parallel EN/UR category trees sharing the same public slug.
DROP INDEX IF EXISTS "Category_siteId_slug_key";
CREATE UNIQUE INDEX IF NOT EXISTS "Category_siteId_slug_language_key"
  ON "Category"("siteId", "slug", "language");
