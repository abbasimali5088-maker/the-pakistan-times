-- CreateIndex (already present on some envs; IF NOT EXISTS keeps this safe)
CREATE INDEX IF NOT EXISTS "Category_slug_idx" ON "Category"("slug");
