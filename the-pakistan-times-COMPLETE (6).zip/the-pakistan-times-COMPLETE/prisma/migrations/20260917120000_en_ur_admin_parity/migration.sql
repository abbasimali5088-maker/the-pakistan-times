-- Category SEO Urdu
ALTER TABLE "Category" ADD COLUMN IF NOT EXISTS "seoTitleUr" TEXT;
ALTER TABLE "Category" ADD COLUMN IF NOT EXISTS "seoDescriptionUr" TEXT;

-- LiveStory EN/UR dual content
ALTER TABLE "LiveStory" ADD COLUMN IF NOT EXISTS "titleUr" TEXT;
ALTER TABLE "LiveStory" ADD COLUMN IF NOT EXISTS "slugUr" TEXT;
ALTER TABLE "LiveStory" ADD COLUMN IF NOT EXISTS "descriptionUr" TEXT;
CREATE INDEX IF NOT EXISTS "LiveStory_slugUr_idx" ON "LiveStory"("slugUr");

-- LiveUpdate EN/UR
ALTER TABLE "LiveUpdate" ADD COLUMN IF NOT EXISTS "bodyUr" TEXT;
ALTER TABLE "LiveUpdate" ADD COLUMN IF NOT EXISTS "quoteUr" TEXT;
