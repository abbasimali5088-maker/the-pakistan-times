-- Urdu SEO fields (separate from English SEO — never mix)
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "seoTitleUr" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "seoDescriptionUr" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "ogTitleUr" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "ogDescriptionUr" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "focusKeywordUr" TEXT;
