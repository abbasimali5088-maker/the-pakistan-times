-- Separate EN/UR media libraries, article fields, category images, tag locales

-- Media language (EN gallery vs UR gallery)
ALTER TABLE "Media" ADD COLUMN IF NOT EXISTS "language" TEXT NOT NULL DEFAULT 'en';
CREATE INDEX IF NOT EXISTS "Media_language_idx" ON "Media"("language");

-- Tag language
ALTER TABLE "Tag" ADD COLUMN IF NOT EXISTS "language" TEXT NOT NULL DEFAULT 'en';
CREATE INDEX IF NOT EXISTS "Tag_language_idx" ON "Tag"("language");

-- Category language + separate images + Urdu description
ALTER TABLE "Category" ADD COLUMN IF NOT EXISTS "language" TEXT NOT NULL DEFAULT 'en';
ALTER TABLE "Category" ADD COLUMN IF NOT EXISTS "descriptionUr" TEXT;
ALTER TABLE "Category" ADD COLUMN IF NOT EXISTS "imageId" TEXT;
ALTER TABLE "Category" ADD COLUMN IF NOT EXISTS "imageUrId" TEXT;
CREATE INDEX IF NOT EXISTS "Category_language_idx" ON "Category"("language");

-- Article EN/UR separation fields
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "slugUr" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "featuredImageUrId" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "imageCaptionUr" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "imageCreditUr" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "videoUrl" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "videoUrlUr" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "categoryUrId" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "searchKeywords" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "searchKeywordsUr" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "ogImageUr" TEXT;

CREATE INDEX IF NOT EXISTS "Article_categoryUrId_idx" ON "Article"("categoryUrId");
CREATE INDEX IF NOT EXISTS "Article_slugUr_idx" ON "Article"("slugUr");

-- ArticleTag locale (EN vs UR tag attachments)
ALTER TABLE "ArticleTag" ADD COLUMN IF NOT EXISTS "locale" TEXT NOT NULL DEFAULT 'en';

-- Recreate ArticleTag primary key to include locale
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleTag_pkey'
  ) THEN
    ALTER TABLE "ArticleTag" DROP CONSTRAINT "ArticleTag_pkey";
  END IF;
END $$;

ALTER TABLE "ArticleTag" ADD CONSTRAINT "ArticleTag_pkey" PRIMARY KEY ("articleId", "tagId", "locale");

-- Foreign keys for new media/category relations
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'Article_featuredImageUrId_fkey'
  ) THEN
    ALTER TABLE "Article"
      ADD CONSTRAINT "Article_featuredImageUrId_fkey"
      FOREIGN KEY ("featuredImageUrId") REFERENCES "Media"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'Article_categoryUrId_fkey'
  ) THEN
    ALTER TABLE "Article"
      ADD CONSTRAINT "Article_categoryUrId_fkey"
      FOREIGN KEY ("categoryUrId") REFERENCES "Category"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'Category_imageId_fkey'
  ) THEN
    ALTER TABLE "Category"
      ADD CONSTRAINT "Category_imageId_fkey"
      FOREIGN KEY ("imageId") REFERENCES "Media"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'Category_imageUrId_fkey'
  ) THEN
    ALTER TABLE "Category"
      ADD CONSTRAINT "Category_imageUrId_fkey"
      FOREIGN KEY ("imageUrId") REFERENCES "Media"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;

-- Existing categories that have Urdu names stay usable for both pickers (language=en default).
-- Copy categoryId → categoryUrId for published articles that lack categoryUrId.
UPDATE "Article" SET "categoryUrId" = "categoryId"
WHERE "categoryUrId" IS NULL AND "categoryId" IS NOT NULL;
